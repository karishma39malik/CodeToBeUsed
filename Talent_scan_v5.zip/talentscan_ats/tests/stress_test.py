"""
TalentScan ATS v2 — Stress Test Script
Generates 50 diverse CVs (good/bad/irrelevant) and measures
latency, accuracy, and ranking stability.

Run: python tests/stress_test.py
"""
import asyncio
import time
import json
import random
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.scoring_engine import (
    score_skill_match, score_experience, score_relevance,
    calculate_penalties, compute_final_score, detect_keyword_stuffing,
    detect_generic_cv, WEIGHTS
)

# ── 50 synthetic CV profiles ──
CV_PROFILES = [
    # === STRONG MATCHES (should score 70+) ===
    {"name":"Omar Hassan","skills":["Python","SQL","Spark","Databricks","Azure","dbt","Airflow","Delta Lake","PySpark","Unity Catalog"],"years":8,"domain":"Data Engineering","summary":"Senior data engineer with 8yr in cloud data platforms. Led Unity Catalog migration for 400+ pipelines.","expect":"high"},
    {"name":"Fatima Al Zaabi","skills":["Python","SQL","Kafka","Airflow","AWS","Spark","Terraform","Docker","Data Engineering","ETL"],"years":6,"domain":"Data Engineering","summary":"Cloud data engineer specializing in real-time streaming. Built Kafka pipelines at scale.","expect":"high"},
    {"name":"Ahmed Rashidi","skills":["Databricks","Unity Catalog","Azure","Python","SQL","dbt","Delta Lake","Data Mesh","Governance"],"years":10,"domain":"Data Architecture","summary":"Data architect with 10yr designing enterprise data platforms across GCC.","expect":"high"},
    {"name":"Priya Sharma","skills":["Python","SQL","Spark","PySpark","dbt","Airflow","GCP","BigQuery","Terraform","Kafka"],"years":7,"domain":"Data Engineering","summary":"GCP-focused data engineer. Built petabyte-scale data lake at fintech startup.","expect":"high"},
    {"name":"Khalid Mansouri","skills":["Python","SQL","Azure Data Factory","Synapse","Databricks","Power BI","ETL","Data Warehouse"],"years":5,"domain":"Data Engineering","summary":"Azure data engineer with strong BI background. Certified in Databricks and Azure.","expect":"high"},
    {"name":"Riya Patel","skills":["Python","SQL","Spark","Kafka","Kubernetes","Docker","Airflow","dbt","Snowflake","AWS"],"years":6,"domain":"Data Engineering","summary":"Full-stack data engineer with MLOps experience.","expect":"high"},
    {"name":"Youssef Benali","skills":["Python","SQL","Hadoop","Hive","Spark","Databricks","HDFS","Data Lake","ETL","Scala"],"years":9,"domain":"Big Data","summary":"Big data specialist transitioning to modern lakehouse architecture.","expect":"high"},

    # === MODERATE MATCHES (should score 50-69) ===
    {"name":"Meera Nair","skills":["Python","pandas","scikit-learn","SQL","Tableau","Power BI","R","Statistics"],"years":5,"domain":"Data Science","summary":"Data scientist with strong analytics background. Some Spark exposure.","expect":"mid"},
    {"name":"Carlos Mendes","skills":["Java","SQL","Spring Boot","REST API","MySQL","PostgreSQL","Docker"],"years":7,"domain":"Backend Engineering","summary":"Java backend developer with database experience. No specific data engineering tools.","expect":"mid"},
    {"name":"Aisha Mohammed","skills":["SQL","Excel","Power BI","Tableau","Python","Data Analysis","Reporting"],"years":4,"domain":"Business Intelligence","summary":"BI analyst with Python skills. Limited Spark or cloud pipeline experience.","expect":"mid"},
    {"name":"Rohan Gupta","skills":["Python","Machine Learning","TensorFlow","Keras","SQL","NumPy","Pandas"],"years":3,"domain":"ML Engineering","summary":"ML engineer. Has Python and SQL but focused on model training not pipelines.","expect":"mid"},
    {"name":"Sara Al Khatib","skills":["Python","SQL","AWS","Lambda","S3","Glue","Athena","Data Engineering"],"years":3,"domain":"Data Engineering","summary":"Junior data engineer with AWS focus. Less than required experience.","expect":"mid"},

    # === WEAK MATCHES — PENALIZED (should score 20-49) ===
    {"name":"Raj Kumar","skills":["Excel","PowerPoint","Word","VLOOKUP","Pivot Tables","Basic SQL"],"years":6,"domain":"Admin/Finance","summary":"Finance administrator with Excel expertise. No programming or cloud skills.","expect":"low"},
    {"name":"Jennifer Lee","skills":["Project Management","JIRA","Confluence","Agile","Scrum","Microsoft Office"],"years":8,"domain":"Project Management","summary":"Senior PM with no technical data skills.","expect":"low"},
    {"name":"Mohammed Hussain","skills":["Digital Marketing","SEO","Google Analytics","Facebook Ads","Content Strategy"],"years":5,"domain":"Digital Marketing","summary":"Digital marketer with Google Analytics experience. No data engineering.","expect":"low"},
    {"name":"Neha Singh","skills":["HR Management","Recruitment","HRMS","Labour Law","Onboarding","Performance Review"],"years":7,"domain":"Human Resources","summary":"HR specialist with HRMS exposure. No technical data skills.","expect":"low"},
    {"name":"David Okonkwo","skills":["Sales","CRM","Salesforce","Lead Generation","Client Relations","Negotiation"],"years":10,"domain":"Sales","summary":"Sales director. Salesforce user but no data engineering background.","expect":"low"},
    {"name":"Lisa Zhang","skills":["Graphic Design","Figma","Photoshop","Illustrator","UI/UX","Branding"],"years":6,"domain":"Design","summary":"UX designer. No overlap with data engineering requirements.","expect":"low"},

    # === KEYWORD STUFFERS (should be penalized) ===
    {"name":"Fake Expert 1","skills":["Python","SQL","Spark","Kafka","Airflow","dbt","Kubernetes","Docker","Azure","AWS","GCP","Terraform","Redis","Elasticsearch","MongoDB","Cassandra","Neo4j","InfluxDB","Prometheus","Grafana","Jaeger","OpenTelemetry","DataDog","New Relic","Splunk","Tableau","Power BI","Looker","Qlik","MicroStrategy","SAP","Oracle","Salesforce","HubSpot","JIRA","Confluence","GitHub","GitLab","Jenkins","CircleCI","ArgoCD","Helm","Istio","Envoy","NGINX","HAProxy"],"years":3,"domain":"Buzzword Expert","summary":"Expert in everything. Python SQL Spark Kafka Airflow Kubernetes Docker AWS Azure GCP all tools all tech.","expect":"low"},
    {"name":"Fake Expert 2","skills":["Machine Learning","Deep Learning","NLP","Computer Vision","LLM","GPT","BERT","Transformer","Reinforcement Learning","GANs","VAEs","Diffusion Models","Causal AI","Explainable AI","Federated Learning","Quantum Computing","Blockchain","IoT","Edge Computing","5G","AR/VR","Metaverse"],"years":1,"domain":"All AI","summary":"Expert in machine learning deep learning NLP computer vision LLM GPT blockchain quantum.","expect":"low"},

    # === FRESHERS vs SENIOR ROLE (should score low due to exp penalty) ===
    {"name":"Fresh Grad Ali","skills":["Python","SQL","Pandas","NumPy","Basic Spark","Jupyter"],"years":0.5,"domain":"Data Engineering","summary":"Recent CS graduate. Completed a data engineering bootcamp. No production experience.","expect":"low"},
    {"name":"Intern Maya","skills":["Python","SQL","Excel"],"years":0,"domain":"General","summary":"Computer science student seeking internship. Basic Python knowledge.","expect":"low"},
    {"name":"Bootcamp Grad","skills":["Python","SQL","Spark","Airflow"],"years":1,"domain":"Data Engineering","summary":"Completed 6-month data engineering bootcamp. Built sample pipelines.","expect":"low"},

    # === EMPTY / GENERIC CVs ===
    {"name":"Generic Person A","skills":[],"years":None,"domain":"","summary":"","expect":"low"},
    {"name":"Generic Person B","skills":["Communication","Teamwork","Leadership"],"years":5,"domain":"General","summary":"Hardworking professional seeking challenging opportunity.","expect":"low"},
    {"name":"Empty CV","skills":[],"years":None,"domain":"","summary":"","expect":"low"},

    # === DOMAIN MISMATCHES WITH SOME TECH ===
    {"name":"Dr. Medical Tech","skills":["Python","R","SPSS","Clinical Trials","Healthcare Data","HIPAA","EMR Systems"],"years":10,"domain":"Healthcare","summary":"Medical data analyst in healthcare domain. Python and R but medical focus.","expect":"low"},
    {"name":"Finance Quant","skills":["Python","R","MATLAB","Bloomberg","QuantLib","Risk Models","VaR","Derivatives"],"years":8,"domain":"Finance/Quant","summary":"Quantitative analyst in investment banking. Python expert but financial domain only.","expect":"low"},
    {"name":"Supply Chain Analyst","skills":["Python","SQL","SAP","ERP","Logistics","Inventory","Warehouse Management"],"years":6,"domain":"Supply Chain","summary":"Supply chain professional with Python and SAP. Not data engineering background.","expect":"low"},

    # === GOOD MATCHES ADDITIONAL ===
    {"name":"Tanya Reddy","skills":["Python","SQL","Spark","Delta Lake","Azure","Databricks","Airflow","Great Expectations"],"years":5,"domain":"Data Engineering","summary":"Data quality focused engineer. Strong Databricks and data testing experience.","expect":"high"},
    {"name":"Hassan Abdulla","skills":["Scala","Python","Spark","Kafka","HDFS","YARN","HBase","Oozie","Hive","Impala"],"years":7,"domain":"Big Data","summary":"Big data engineer with strong Scala/Spark background. Experience migrating to cloud.","expect":"high"},
    {"name":"Elena Petrov","skills":["Python","dbt","Snowflake","Fivetran","Looker","SQL","Data Vault","Redshift","Airflow"],"years":6,"domain":"Analytics Engineering","summary":"Analytics engineer specializing in dbt/Snowflake stack.","expect":"high"},
    {"name":"John Mensah","skills":["Python","SQL","GCP","BigQuery","Dataflow","Pub/Sub","Terraform","dbt","Looker","Cloud Run"],"years":5,"domain":"Data Engineering","summary":"GCP-native data engineer with streaming and batch expertise.","expect":"high"},
    {"name":"Shreya Kapoor","skills":["Python","SQL","AWS Glue","S3","Redshift","Step Functions","Lambda","DMS","Athena","QuickSight"],"years":4,"domain":"Data Engineering","summary":"AWS data engineer building serverless pipelines. Good cloud-native skills.","expect":"mid"},
    {"name":"Tariq Al Farsi","skills":["Python","SQL","Databricks","Unity Catalog","Azure DevOps","CI/CD","Terraform","MLflow"],"years":6,"domain":"Data/ML Engineering","summary":"Data engineer with MLOps experience in Azure Databricks.","expect":"high"},
    {"name":"Mia Chen","skills":["Python","SQL","Spark","Hudi","Iceberg","Delta Lake","Kubernetes","Docker","Airflow","dbt"],"years":7,"domain":"Data Lakehouse","summary":"Lakehouse specialist with open table format expertise.","expect":"high"},
    {"name":"Arjun Nair","skills":["Python","SQL","Postgres","Redis","Kafka","Docker","Kubernetes","Go","Data Engineering"],"years":4,"domain":"Platform Engineering","summary":"Platform engineer with data infrastructure background.","expect":"mid"},
    {"name":"Layla Hassan","skills":["Python","SQL","Power BI","Azure","Synapse","SSAS","SSRS","ETL","Data Warehouse"],"years":8,"domain":"Data Warehouse","summary":"Traditional DW expert transitioning to modern stack. Strong SQL.","expect":"mid"},
    {"name":"Vijay Krishnan","skills":["Java","Scala","Kafka","Spark","Flink","Storm","Cassandra","HBase","Redis","ZooKeeper"],"years":9,"domain":"Streaming","summary":"Streaming data architect with deep distributed systems knowledge.","expect":"high"},
    {"name":"Nadia Osman","skills":["Python","SQL","dbt","Airbyte","Snowflake","GitHub Actions","Great Expectations","Data Contracts"],"years":3,"domain":"Analytics Engineering","summary":"Modern data stack engineer. Good tooling knowledge but junior.","expect":"mid"},
    {"name":"Tom Bradley","skills":["Python","SQL","Hadoop","Pig","Hive","MapReduce","Sqoop","Oozie"],"years":12,"domain":"Legacy Big Data","summary":"Veteran big data engineer. Skills are legacy — Hadoop/MapReduce era.","expect":"mid"},
    {"name":"Zara Ali","skills":["Python","SQL","Spark","Delta Lake","Databricks","PySpark","Pandas","NumPy","MLflow","Koalas"],"years":5,"domain":"Data Engineering","summary":"Data engineer with ML engineering overlap. Databricks certified.","expect":"high"},
]

# JD requirements for a Senior Data Engineer role
JD_REQUIREMENTS = {
    "required_skills": ["Python","SQL","Spark","Databricks","Azure","dbt","Airflow","Delta Lake"],
    "nice_skills":     ["Unity Catalog","Kafka","Terraform","Docker","PySpark"],
    "min_years":       5,
    "seniority":       "senior",
    "domain":          "Data Engineering",
}


def run_scoring_test():
    """Run the full scoring engine on all 50 CVs and report results."""
    print("=" * 70)
    print("TalentScan ATS v2 — Stress Test (50 CVs)")
    print(f"JD: Senior Data Engineer | Min years: {JD_REQUIREMENTS['min_years']}")
    print("=" * 70)

    results = []
    t_start = time.perf_counter()

    for cv in CV_PROFILES:
        t_cv = time.perf_counter()

        # Simulate embedding similarity (0.4–0.9 based on domain match)
        domain = cv.get("domain","").lower()
        if "data engineer" in domain:
            cosine = random.uniform(0.75, 0.92)
        elif "big data" in domain or "streaming" in domain or "lakehouse" in domain:
            cosine = random.uniform(0.65, 0.82)
        elif "data science" in domain or "ml" in domain or "analytics" in domain:
            cosine = random.uniform(0.45, 0.65)
        elif "backend" in domain or "platform" in domain:
            cosine = random.uniform(0.35, 0.52)
        else:
            cosine = random.uniform(0.05, 0.30)

        rel_score  = score_relevance(cosine)
        skill_s, matched, missing = score_skill_match(
            cv["skills"], JD_REQUIREMENTS["required_skills"], JD_REQUIREMENTS["nice_skills"])
        exp_score  = score_experience(cv.get("years"), JD_REQUIREMENTS["min_years"])

        # Simulate semantic score based on summary quality
        summary  = cv.get("summary","")
        sem_base = 60 if "data engineer" in summary.lower() else (40 if "python" in summary.lower() else 25)
        sem_score = min(100, sem_base + random.randint(-10, 15))

        has_skills  = len(cv["skills"]) > 0
        kw_stuffed  = detect_keyword_stuffing(summary, cv["skills"])
        is_generic  = detect_generic_cv({"technical_skills": cv["skills"], "experience": [{}] if cv.get("years") else [], "cv_summary": summary})
        domain_mis  = cosine < 0.25

        penalty, penalties_applied = calculate_penalties(
            missing_critical=missing[:3],
            cv_years=cv.get("years") or 0,
            required_years=JD_REQUIREMENTS["min_years"],
            domain_mismatch=domain_mis,
            keyword_stuffed=kw_stuffed,
            has_skills=has_skills,
            is_generic=is_generic,
        )

        final = compute_final_score(rel_score, skill_s, exp_score, sem_score, penalty)
        dur_ms = int((time.perf_counter() - t_cv) * 1000)

        if final >= 70:   bucket = "HIGH"
        elif final >= 50: bucket = "MID"
        else:             bucket = "LOW"

        # Accuracy check
        expected  = cv["expect"].upper()
        correct   = (bucket == expected)

        results.append({
            "name":      cv["name"],
            "expected":  expected,
            "got":       bucket,
            "correct":   correct,
            "final":     final,
            "rel":       rel_score,
            "skill":     skill_s,
            "exp":       exp_score,
            "sem":       sem_score,
            "penalty":   penalty,
            "matched":   len(matched),
            "missing":   len(missing),
            "kw_stuff":  kw_stuffed,
            "generic":   is_generic,
            "dur_ms":    dur_ms,
        })

    total_ms = int((time.perf_counter() - t_start) * 1000)

    # ── PRINT RESULTS ──
    results.sort(key=lambda x: x["final"], reverse=True)
    print(f"\n{'Rank':<4} {'Name':<25} {'Score':>5} {'Expected':>8} {'Got':>4} {'✓':>2} {'Pen':>4} {'Match':>6} {'Miss':>5} {'Flags'}")
    print("-" * 90)
    for i, r in enumerate(results, 1):
        flag = ""
        if r["kw_stuff"]: flag += "🚨KW "
        if r["generic"]:  flag += "📭GEN "
        tick = "✅" if r["correct"] else "❌"
        print(f"{i:<4} {r['name'][:24]:<25} {r['final']:>5} {r['expected']:>8} {r['got']:>4} {tick:>2} "
              f"{r['penalty']:>4} {r['matched']:>6} {r['missing']:>5}  {flag}")

    # ── ACCURACY REPORT ──
    total    = len(results)
    correct  = sum(1 for r in results if r["correct"])
    accuracy = correct / total * 100

    high_r   = [r for r in results if r["expected"] == "HIGH"]
    mid_r    = [r for r in results if r["expected"] == "MID"]
    low_r    = [r for r in results if r["expected"] == "LOW"]

    print("\n" + "=" * 70)
    print("ACCURACY REPORT")
    print("=" * 70)
    print(f"Overall accuracy:   {correct}/{total} = {accuracy:.1f}%")
    print(f"High match accuracy: {sum(1 for r in high_r if r['correct'])}/{len(high_r)}")
    print(f"Mid match accuracy:  {sum(1 for r in mid_r  if r['correct'])}/{len(mid_r)}")
    print(f"Low match accuracy:  {sum(1 for r in low_r  if r['correct'])}/{len(low_r)}")
    kw = sum(1 for r in results if r["kw_stuff"])
    print(f"Keyword stuffers detected: {kw}")
    print(f"Generic CVs detected:      {sum(1 for r in results if r['generic'])}")
    print(f"Score never exceeds 100:   {all(r['final'] <= 100 for r in results)}")
    print(f"Score never below 0:       {all(r['final'] >= 0 for r in results)}")

    # ── LATENCY REPORT ──
    latencies = [r["dur_ms"] for r in results]
    print("\n" + "=" * 70)
    print("LATENCY REPORT (scoring engine only — no LLM/network)")
    print("=" * 70)
    print(f"Total for {total} CVs: {total_ms}ms ({total_ms/1000:.2f}s)")
    print(f"Per-CV average:        {sum(latencies)/len(latencies):.1f}ms")
    print(f"Min: {min(latencies)}ms  Max: {max(latencies)}ms")

    # ── RANKING STABILITY ──
    top10 = [r["name"] for r in results[:10]]
    print(f"\nTop 10 candidates: {', '.join(top10[:5])}...")
    print(f"\nScore distribution:")
    print(f"  70-100 (Shortlist): {sum(1 for r in results if r['final']>=70)}")
    print(f"  50-69  (Review):    {sum(1 for r in results if 50<=r['final']<70)}")
    print(f"  0-49   (Rejected):  {sum(1 for r in results if r['final']<50)}")

    print("\n✅ Stress test complete.")
    return results


def run_negative_tests():
    """Explicit negative scenario tests."""
    print("\n" + "=" * 70)
    print("NEGATIVE SCENARIO TESTS")
    print("=" * 70)

    from agents.scoring_engine import score_skill_match, score_experience, calculate_penalties, compute_final_score

    test_cases = [
        {
            "name":      "Admin CV vs Senior Data Engineer JD",
            "skills":    ["Excel","Word","VLOOKUP","Email Management","Office Admin"],
            "years":     8,
            "summary":   "Office administrator with Excel expertise.",
            "expected":  "< 30",
        },
        {
            "name":      "Fresher vs 5yr Senior Role",
            "skills":    ["Python","SQL","Pandas"],
            "years":     0.5,
            "summary":   "Recent graduate with basic Python skills.",
            "expected":  "< 40",
        },
        {
            "name":      "Keyword Stuffing CV",
            "skills":    [f"Skill_{i}" for i in range(55)] + ["Python","SQL"],
            "years":     3,
            "summary":   "Python SQL Spark Kafka Docker Kubernetes AWS Azure GCP Terraform Python SQL Spark",
            "expected":  "< 50 (penalized)",
        },
        {
            "name":      "Empty / Generic CV",
            "skills":    [],
            "years":     None,
            "summary":   "",
            "expected":  "< 20",
        },
        {
            "name":      "Marketing CV vs Data Engineer JD",
            "skills":    ["SEO","Google Analytics","Facebook Ads","Content Marketing","HubSpot"],
            "years":     5,
            "summary":   "Digital marketing expert with Google Analytics and campaign management.",
            "expected":  "< 25",
        },
    ]

    for tc in test_cases:
        cosine     = 0.1 if not any(s in ["Python","SQL","Spark"] for s in tc["skills"]) else 0.35
        rel        = score_relevance(cosine)
        skill_s, matched, missing = score_skill_match(
            tc["skills"], JD_REQUIREMENTS["required_skills"], JD_REQUIREMENTS["nice_skills"])
        exp_s      = score_experience(tc.get("years"), JD_REQUIREMENTS["min_years"])
        sem_s      = 20 if not tc.get("summary") else 35
        kw         = detect_keyword_stuffing(tc.get("summary",""), tc["skills"])
        generic    = detect_generic_cv({"technical_skills":tc["skills"],"experience":[],"cv_summary":tc.get("summary","")})
        penalty, _ = calculate_penalties(
            missing_critical=missing[:2], cv_years=tc.get("years") or 0,
            required_years=JD_REQUIREMENTS["min_years"],
            domain_mismatch=(cosine < 0.2), keyword_stuffed=kw, has_skills=len(tc["skills"])>0,
            is_generic=generic)
        final = compute_final_score(rel, skill_s, exp_s, sem_s, penalty)
        flag = "🚨KEYWORD_STUFFED" if kw else ("📭GENERIC" if generic else "")
        print(f"  {tc['name'][:42]:<45} Score: {final:>3}/100  Expected: {tc['expected']}  {flag}")

    print("\n✅ Negative tests complete.")


if __name__ == "__main__":
    run_scoring_test()
    run_negative_tests()
