import json
from typing import Any, Dict
import ollama as ollama_client
from agents.base_agent import BaseAgent
from config.settings import settings


class PotentialAgent(BaseAgent):
    def __init__(self, db):
        super().__init__("potential", db)
        self.ollama = ollama_client.AsyncClient(host=settings.ollama_base_url)

    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        parsed_cv = payload["parsed_cv"]
        result = await self._analyze(parsed_cv)
        self.log.info("potential_done", trajectory=result.get("career_trajectory"))
        return result

    async def _analyze(self, cv: dict) -> dict:
        prompt = f"""JSON only. Analyze career potential.
Schema: {{"potential_score":0-100,"career_trajectory":"ascending|lateral|pivoting|stagnant|insufficient_data","growth_label":"string","leadership_signals":[],"value_add_insights":[]}}
Rules: potential_score 0-100. Keep lists max 3 items.
Profile: exp={len(cv.get('experience',[]))}, skills={len(cv.get('technical_skills',[]))}, years={cv.get('total_years_exp')}, certs={cv.get('certifications',[])}"""
        try:
            resp = await self.ollama.chat(
                model=settings.ollama_llm_model,
                messages=[{"role": "user", "content": prompt}],
                format="json",
                options={"temperature": 0.1, "num_predict": 400},
            )
            raw = resp["message"]["content"]
            if isinstance(raw, str):
                raw = json.loads(raw)
            raw["potential_score"] = min(100, max(0, int(raw.get("potential_score", 50))))
            return raw
        except Exception as e:
            self.log.error("potential_failed", error=str(e))
            return {"potential_score": 40, "career_trajectory": "insufficient_data",
                    "growth_label": "Insufficient data", "leadership_signals": [],
                    "value_add_insights": []}
