import json, re
from typing import Any, Dict, List
import ollama as ollama_client
from sqlalchemy import text
import structlog

from agents.base_agent import BaseAgent
from agents.scoring_engine import (
    score_relevance, score_skill_match, score_experience,
    calculate_penalties, compute_final_score,
    build_why_selected, build_why_rejected,
    detect_keyword_stuffing, detect_generic_cv,
    WEIGHTS, FORMULA_STR,
)
from shared.utils import truncate_text
from config.settings import settings

logger = structlog.get_logger(__name__)


class MatchingAgent(BaseAgent):
    def __init__(self, db):
        super().__init__("matching", db)
        self.ollama = ollama_client.AsyncClient(host=settings.ollama_base_url)

    def _vec_str(self, vec: List[float]) -> str:
        return "[" + ",".join(str(float(x)) for x in vec) + "]"

    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        cv_version_id   = payload["cv_version_id"]
        job_id          = payload["job_id"]
        parsed_cv       = payload["parsed_cv"]
        job_description = payload["job_description"]
        jd_requirements = payload.get("jd_requirements", {})

        # ── Step 1: Embeddings (run concurrently) ──
        import asyncio
        cv_text  = self._cv_to_text(parsed_cv)
        jd_row   = await self.db.execute(
            text("SELECT embedding::text FROM jobs WHERE id=:id"), {"id": job_id})
        jd_db    = jd_row.fetchone()

        if jd_db and jd_db[0]:
            raw = jd_db[0].strip("[]").split(",")
            jd_embed = [float(x) for x in raw]
            cv_embed = await self._embed(cv_text)
        else:
            cv_embed, jd_embed = await asyncio.gather(
                self._embed(cv_text),
                self._embed(truncate_text(job_description, 4000))
            )

        # ── Step 2: Store CV embedding & compute cosine similarity ──
        cv_vec = self._vec_str(cv_embed)
        jd_vec = self._vec_str(jd_embed)
        try:
            await self.db.execute(
                text("UPDATE cv_versions SET embedding=:e WHERE id=:id"),
                {"e": cv_vec, "id": cv_version_id})
            sim_row = await self.db.execute(
                text("SELECT 1-(embedding<=>:jd) AS sim FROM cv_versions WHERE id=:id"),
                {"jd": jd_vec, "id": cv_version_id})
            row = sim_row.fetchone()
            cosine = max(0.0, min(1.0, float(row.sim or 0.0))) if row else 0.0
        except Exception:
            await self.db.rollback()
            raise

        # ── Step 3: Rule-based scoring ──
        required_skills = jd_requirements.get("required_skills", [])
        nice_skills     = jd_requirements.get("nice_skills", [])
        required_years  = float(jd_requirements.get("min_years", 0) or 0)
        cv_years        = parsed_cv.get("total_years_exp") or 0

        rel_score  = score_relevance(cosine)
        skill_s, matched, missing = score_skill_match(
            parsed_cv.get("technical_skills", []) + parsed_cv.get("domain_expertise", []),
            required_skills, nice_skills
        )
        exp_score = score_experience(cv_years, required_years)

        # ── Step 4: LLM semantic + domain reasoning (compact prompt) ──
        semantic_s, domain_mismatch, llm_rationale, strengths, gaps, transferable = \
            await self._llm_analyze(parsed_cv, job_description, matched, missing)

        # ── Step 5: Penalties ──
        has_skills = len(parsed_cv.get("technical_skills", [])) > 0
        kw_stuffed = detect_keyword_stuffing(
            parsed_cv.get("cv_summary", "") or "",
            parsed_cv.get("technical_skills", []))
        is_generic = detect_generic_cv(parsed_cv)

        penalty, penalties_applied = calculate_penalties(
            missing_critical=missing[:3],
            cv_years=cv_years,
            required_years=required_years,
            domain_mismatch=domain_mismatch,
            keyword_stuffed=kw_stuffed,
            has_skills=has_skills,
            is_generic=is_generic,
        )

        # ── Step 6: Final score ──
        final = compute_final_score(rel_score, skill_s, exp_score, semantic_s, penalty)

        why_sel = build_why_selected(matched, exp_score, rel_score, semantic_s)
        why_rej = build_why_rejected(missing, exp_score, penalty, domain_mismatch)

        score_reasoning = (
            f"Final Score: {final}/100\n"
            f"  Relevance ({WEIGHTS['relevance']}%): {rel_score}/100\n"
            f"  Skill Match ({WEIGHTS['skill_match']}%): {skill_s}/100\n"
            f"  Experience ({WEIGHTS['experience']}%): {exp_score}/100\n"
            f"  Semantic ({WEIGHTS['semantic']}%): {semantic_s}/100\n"
            f"  Penalties: -{penalty}\n"
            f"  Applied: {[p['reason'] for p in penalties_applied]}\n"
            f"  Rationale: {llm_rationale}"
        )

        self.log.info("matching_complete", final=final, cosine=round(cosine, 3),
                      skill=skill_s, exp=exp_score, penalty=penalty)

        return {
            "final_score":        final,
            "relevance_score":    rel_score,
            "skill_match_score":  skill_s,
            "experience_score":   exp_score,
            "semantic_score":     semantic_s,
            "penalty_score":      penalty,
            "semantic_similarity": round(cosine, 4),
            "matched_skills":     matched,
            "missing_skills":     missing,
            "strengths":          strengths,
            "gaps":               gaps,
            "transferable_skills": transferable,
            "why_selected":       why_sel,
            "why_rejected":       why_rej,
            "score_formula":      FORMULA_STR,
            "score_weights":      WEIGHTS,
            "penalties_applied":  penalties_applied,
            "score_reasoning":    score_reasoning,
            "llm_rationale":      llm_rationale,
            "domain_mismatch":    domain_mismatch,
        }

    async def _embed(self, text_str: str) -> List[float]:
        resp = await self.ollama.embeddings(model=settings.ollama_embed_model, prompt=text_str)
        return resp["embedding"]

    def _cv_to_text(self, cv: dict) -> str:
        parts = []
        if cv.get("cv_summary"): parts.append(cv["cv_summary"])
        tech = ", ".join(cv.get("technical_skills", []))
        if tech: parts.append(f"Skills: {tech}")
        dom  = ", ".join(cv.get("domain_expertise", []))
        if dom:  parts.append(f"Domain: {dom}")
        for exp in cv.get("experience", [])[:4]:
            parts.append(f"{exp.get('role','')} at {exp.get('company','')}: {exp.get('description','')}")
        return "\n".join(parts)

    async def _llm_analyze(self, parsed_cv, job_desc, matched, missing):
        cv_s = self._cv_to_text(parsed_cv)
        prompt = f"""You are a strict JSON generator. Respond ONLY with valid JSON.
Schema:
{{"semantic_score":0-100,"domain_mismatch":true/false,"rationale":"2 sentences","strengths":["list"],"gaps":["list"],"transferable":["list"]}}

Rules:
- semantic_score: 0-100 reflecting how well CV reasoning matches JD
- domain_mismatch: true if candidate is from completely different field
- rationale: plain English why candidate fits or not
- Keep each list to max 4 items

JD (excerpt): {truncate_text(job_desc, 1200)}
CV: {cv_s[:800]}
Already matched skills: {matched[:5]}
Missing skills: {missing[:5]}"""

        try:
            resp = await self.ollama.chat(
                model=settings.ollama_llm_model,
                messages=[{"role": "user", "content": prompt}],
                format="json",
                options={"temperature": 0.1, "num_predict": 500},
            )
            raw = resp["message"]["content"]
            if isinstance(raw, str):
                raw = json.loads(raw)
            sem = min(100, max(0, int(raw.get("semantic_score", 50))))
            return (
                sem,
                bool(raw.get("domain_mismatch", False)),
                raw.get("rationale", ""),
                raw.get("strengths", []),
                raw.get("gaps", []),
                raw.get("transferable", []),
            )
        except Exception as e:
            self.log.error("llm_analyze_failed", error=str(e))
            return 40, False, f"LLM error: {e}", [], [], []
