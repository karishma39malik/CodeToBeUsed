"""
TalentScan ATS v2 — Explainable Scoring Engine
==============================================
Final Score (0-100) = Relevance×30 + SkillMatch×25 + Experience×20 + Semantic×25 - Penalties
Score NEVER exceeds 100. Penalties can drive score to 0.
"""
import re
from typing import Any, Dict, List, Tuple


# ── Weights (must sum to 100) ──
WEIGHTS = {
    "relevance":   30,   # embedding cosine similarity
    "skill_match": 25,   # rule-based skill overlap
    "experience":  20,   # years of experience vs requirement
    "semantic":    25,   # LLM qualitative reasoning
}

# ── Penalty rules ──
PENALTY_MISSING_CRITICAL = 20   # per missing critical skill (capped at 40)
PENALTY_EXP_MISMATCH     = 15   # years far below requirement
PENALTY_DOMAIN_MISMATCH  = 10   # completely wrong domain
PENALTY_KEYWORD_STUFFING  = 8   # suspicious pattern
PENALTY_NO_SKILLS        = 15   # empty skills section
PENALTY_GENERIC_CV       = 12   # very generic / no specifics

FORMULA_STR = (
    "Final = (relevance×0.30 + skill_match×0.25 + experience×0.20 + semantic×0.25) × 100 "
    "− penalty_deductions  [capped 0–100]"
)


def score_relevance(cosine_similarity: float) -> int:
    """0–1 cosine → 0–100 int."""
    return min(100, max(0, int(cosine_similarity * 100)))


def score_skill_match(cv_skills: List[str], required_skills: List[str],
                      nice_skills: List[str]) -> Tuple[int, List[str], List[str]]:
    """
    Rule-based overlap between CV skills and JD skills.
    Returns (score_0_100, matched, missing).
    """
    if not required_skills:
        return 50, [], []

    cv_lower  = {s.lower().strip() for s in cv_skills}
    req_lower = [s.lower().strip() for s in required_skills]
    nic_lower = [s.lower().strip() for s in nice_skills]

    matched_req  = [s for s in req_lower if _skill_in_set(s, cv_lower)]
    missing_req  = [s for s in req_lower if not _skill_in_set(s, cv_lower)]
    matched_nice = [s for s in nic_lower if _skill_in_set(s, cv_lower)]

    # Required skills = 80% of weight, nice-to-have = 20%
    req_ratio  = len(matched_req)  / len(req_lower)             if req_lower  else 1.0
    nice_ratio = len(matched_nice) / len(nic_lower)             if nic_lower  else 0.0

    raw_score = (req_ratio * 0.8 + nice_ratio * 0.2) * 100
    return (
        min(100, int(raw_score)),
        [s.title() for s in matched_req + matched_nice],
        [s.title() for s in missing_req],
    )


def score_experience(cv_years: float, required_years: float) -> int:
    """
    Maps years-of-experience gap to 0–100.
    Over-qualified is not penalized. Under-qualified is.
    """
    if required_years <= 0:
        return 80   # JD has no explicit requirement → neutral good

    if cv_years is None:
        return 30   # unknown → moderate penalty

    ratio = cv_years / required_years
    if ratio >= 1.0:
        return 100
    elif ratio >= 0.8:
        return 80
    elif ratio >= 0.6:
        return 60
    elif ratio >= 0.4:
        return 40
    else:
        return 20   # severely under-experienced


def calculate_penalties(
    missing_critical: List[str],
    cv_years: float,
    required_years: float,
    domain_mismatch: bool,
    keyword_stuffed: bool,
    has_skills: bool,
    is_generic: bool,
) -> Tuple[int, List[Dict]]:
    """
    Returns (total_penalty, list_of_applied_penalties).
    Penalties are additive but capped at 60 total.
    """
    penalties = []
    total = 0

    # Missing critical skills (cap contribution at 2 skills = 40pts)
    for skill in missing_critical[:2]:
        penalties.append({"reason": f"Missing critical skill: {skill}", "deduction": PENALTY_MISSING_CRITICAL})
        total += PENALTY_MISSING_CRITICAL

    # Experience far below requirement
    if cv_years is not None and required_years > 0:
        if cv_years < required_years * 0.4:
            penalties.append({"reason": f"Experience gap: {cv_years}yr vs {required_years}yr required",
                               "deduction": PENALTY_EXP_MISMATCH})
            total += PENALTY_EXP_MISMATCH

    if domain_mismatch:
        penalties.append({"reason": "Domain mismatch — completely different industry/function",
                           "deduction": PENALTY_DOMAIN_MISMATCH})
        total += PENALTY_DOMAIN_MISMATCH

    if keyword_stuffed:
        penalties.append({"reason": "Keyword stuffing pattern detected",
                           "deduction": PENALTY_KEYWORD_STUFFING})
        total += PENALTY_KEYWORD_STUFFING

    if not has_skills:
        penalties.append({"reason": "No technical skills section found",
                           "deduction": PENALTY_NO_SKILLS})
        total += PENALTY_NO_SKILLS

    if is_generic:
        penalties.append({"reason": "CV is highly generic with no specific achievements",
                           "deduction": PENALTY_GENERIC_CV})
        total += PENALTY_GENERIC_CV

    return min(total, 60), penalties   # hard cap at 60


def compute_final_score(
    relevance_score:  int,
    skill_match_score: int,
    experience_score:  int,
    semantic_score:    int,
    penalty_score:     int,
) -> int:
    """
    Weighted sum minus penalties, strictly capped 0–100.
    """
    weighted = (
        relevance_score  * WEIGHTS["relevance"]   / 100 +
        skill_match_score * WEIGHTS["skill_match"] / 100 +
        experience_score  * WEIGHTS["experience"]  / 100 +
        semantic_score    * WEIGHTS["semantic"]    / 100
    )
    final = int(weighted) - penalty_score
    return min(100, max(0, final))


def build_why_selected(matched_skills, experience_score, relevance_score, semantic_score) -> str:
    parts = []
    if matched_skills:
        parts.append(f"Matched {len(matched_skills)} required skills: {', '.join(matched_skills[:5])}")
    if experience_score >= 70:
        parts.append("Experience level meets or exceeds the role requirements")
    if relevance_score >= 65:
        parts.append("Strong semantic alignment with the job description")
    if semantic_score >= 65:
        parts.append("AI reasoning confirms strong domain and skill fit")
    return " · ".join(parts) if parts else "Candidate profile broadly aligns with role requirements"


def build_why_rejected(missing_skills, experience_score, penalty_score, domain_mismatch) -> str:
    parts = []
    if missing_skills:
        parts.append(f"Missing critical skills: {', '.join(missing_skills[:5])}")
    if experience_score < 40:
        parts.append("Insufficient years of experience for this seniority level")
    if domain_mismatch:
        parts.append("Domain mismatch — candidate background is in a different industry or function")
    if penalty_score >= 20:
        parts.append(f"Significant penalty deductions ({penalty_score} pts) reduce overall confidence")
    return " · ".join(parts) if parts else "Score below threshold — does not meet minimum role requirements"


def detect_keyword_stuffing(cv_text: str, tech_skills: List[str]) -> bool:
    """Flag CVs that list 50+ skills or repeat skills unnaturally."""
    if len(tech_skills) > 50:
        return True
    # Check if same skill appears 3+ times in text
    if cv_text:
        for skill in tech_skills[:20]:
            count = len(re.findall(re.escape(skill.lower()), cv_text.lower()))
            if count >= 4:
                return True
    return False


def detect_generic_cv(parsed_cv: dict) -> bool:
    """Flag CVs with very little specific content."""
    skills  = parsed_cv.get("technical_skills", [])
    exp     = parsed_cv.get("experience", [])
    summary = parsed_cv.get("cv_summary", "") or ""
    if len(skills) < 2 and len(exp) < 1:
        return True
    if len(summary) < 30 and len(skills) < 3:
        return True
    return False


def _skill_in_set(skill: str, skill_set: set) -> bool:
    """Fuzzy skill match — handles abbreviations like 'ML', 'AI', 'JS'."""
    if skill in skill_set:
        return True
    # partial match for compound skills (e.g. "machine learning" in "ml")
    words = skill.split()
    if len(words) >= 2:
        abbrev = "".join(w[0] for w in words)
        if abbrev in skill_set:
            return True
    for cs in skill_set:
        if skill in cs or cs in skill:
            return True
    return False
