import time, uuid, json
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
import structlog

logger = structlog.get_logger(__name__)


class BaseAgent(ABC):
    def __init__(self, name: str, db: AsyncSession):
        self.name = name
        self.db   = db
        self.log  = logger.bind(agent=name)

    async def run(self, payload: Dict[str, Any], correlation_id: Optional[str] = None) -> Dict[str, Any]:
        correlation_id = correlation_id or str(uuid.uuid4())
        log = self.log.bind(correlation_id=correlation_id)
        log.info("agent_started", keys=list(payload.keys()))
        t0 = time.perf_counter()
        try:
            result   = await self.execute(payload, correlation_id)
            dur_ms   = int((time.perf_counter() - t0) * 1000)
            log.info("agent_done", duration_ms=dur_ms)
            await self._audit(correlation_id, "success", list(payload.keys()), dur_ms)
            return result
        except Exception as e:
            dur_ms = int((time.perf_counter() - t0) * 1000)
            log.error("agent_failed", error=str(e), duration_ms=dur_ms)
            await self._audit(correlation_id, "failure", list(payload.keys()), dur_ms, str(e))
            raise

    @abstractmethod
    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        pass

    async def _audit(self, cid, outcome, keys, dur_ms, error=None):
        try:
            await self.db.execute(
                text("""INSERT INTO audit_logs
                    (correlation_id,event_type,actor,event_data,outcome,duration_ms,error_message)
                    VALUES (:cid,:etype,:actor,CAST(:data AS jsonb),:outcome,:dur,:err)"""),
                {"cid": cid, "etype": f"agent:{self.name}", "actor": self.name,
                 "data": json.dumps({"keys": keys}), "outcome": outcome,
                 "dur": dur_ms, "err": error}
            )
            await self.db.commit()
        except Exception:
            await self.db.rollback()
