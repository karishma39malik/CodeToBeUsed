import json, re, hashlib
from typing import Any, Dict
import pdfplumber
import docx
import chardet
import ollama as ollama_client
from agents.base_agent import BaseAgent
from shared.models import ParsedCV
from shared.utils import truncate_text, get_file_extension
from config.settings import settings


class IngestionAgent(BaseAgent):
    def __init__(self, db):
        super().__init__("ingestion", db)
        self.ollama = ollama_client.AsyncClient(host=settings.ollama_base_url)

    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        file_path = payload["file_path"]
        filename  = payload["filename"]
        ext       = get_file_extension(filename)

        raw_text, warnings = await self._extract_text(file_path, ext)
        if not raw_text or len(raw_text.strip()) < 30:
            raise ValueError(f"Cannot extract text from {filename}")

        with open(file_path, "rb") as f:
            file_hash = hashlib.sha256(f.read()).hexdigest()

        parsed = await self._llm_extract(truncate_text(raw_text, 5000), warnings)
        return {"parsed_cv": parsed.model_dump(), "raw_text": raw_text,
                "file_hash": file_hash, "file_format": ext, "parse_warnings": warnings}

    async def _extract_text(self, path, ext):
        w = []
        if ext == "pdf":
            try:
                parts = []
                with pdfplumber.open(path) as pdf:
                    for i, pg in enumerate(pdf.pages):
                        t = pg.extract_text()
                        if t: parts.append(t)
                        else: w.append(f"Page {i+1} no text")
                return "\n".join(parts), w
            except Exception as e:
                w.append(str(e)); return "", w
        elif ext == "docx":
            try:
                doc = docx.Document(path)
                paras = [p.text for p in doc.paragraphs if p.text.strip()]
                for tbl in doc.tables:
                    for row in tbl.rows:
                        r = " | ".join(c.text.strip() for c in row.cells if c.text.strip())
                        if r: paras.append(r)
                return "\n".join(paras), w
            except Exception as e:
                w.append(str(e)); return "", w
        elif ext == "txt":
            try:
                raw = open(path, "rb").read()
                enc = chardet.detect(raw).get("encoding", "utf-8") or "utf-8"
                return raw.decode(enc, errors="replace"), w
            except Exception as e:
                w.append(str(e)); return "", w
        return "", w

    async def _llm_extract(self, text: str, warnings: list) -> ParsedCV:
        # Compact prompt — fewer tokens = faster
        prompt = f"""Extract CV data. Return ONLY valid JSON, no markdown.
Schema: {{
  "full_name":null,"email":null,"phone":null,"location":null,
  "technical_skills":[],"soft_skills":[],"domain_expertise":[],
  "certifications":[],"languages":[],
  "experience":[{{"company":null,"role":null,"start_date":null,"end_date":null,"duration_months":null,"description":null,"technologies":[]}}],
  "education":[{{"institution":null,"degree":null,"field":null,"graduation_year":null}}],
  "total_years_exp":null,"cv_summary":null,"parse_confidence":0.8
}}
CV:
{text}"""
        try:
            resp = await self.ollama.chat(
                model=settings.ollama_llm_model,
                messages=[{"role": "user", "content": prompt}],
                options={"temperature": 0.0, "num_predict": 1500},
            )
            raw = resp["message"]["content"].strip()
            raw = re.sub(r"```json\s*", "", raw)
            raw = re.sub(r"```\s*", "", raw)
            data = json.loads(raw)
            return ParsedCV(**data)
        except Exception as e:
            warnings.append(f"LLM extraction: {e}")
            return ParsedCV(parse_confidence=0.2, parse_warnings=warnings)
