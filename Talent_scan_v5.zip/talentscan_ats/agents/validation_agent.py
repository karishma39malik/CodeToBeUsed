import json
from typing import Any, Dict, List
from sqlalchemy import text
from agents.base_agent import BaseAgent


class ValidationAgent(BaseAgent):
    def __init__(self, db):
        super().__init__("validation", db)

    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        self.log.info("validation_started")
        anomalies = []
        anomalies += await self._check_duplicate_file(payload)
        anomalies += await self._check_duplicate_application(payload)
        anomalies += await self._check_parse_confidence(payload)
        anomalies += await self._check_employment_gaps(payload)
        anomalies += await self._check_borderline(payload)
        anomalies += await self._check_keyword_stuffing(payload)

        for a in anomalies:
            try:
                await self.db.execute(
                    text("""INSERT INTO anomalies
                        (cv_version_id,candidate_id,job_id,anomaly_type,severity,description,raw_evidence)
                        VALUES (:cv,:cand,:job,:atype,:sev,:desc,CAST(:ev AS jsonb))"""),
                    {"cv": payload["cv_version_id"], "cand": payload["candidate_id"],
                     "job": payload["job_id"], "atype": a["type"], "sev": a["severity"],
                     "desc": a["description"], "ev": json.dumps(a.get("evidence", {}))})
            except Exception:
                await self.db.rollback()

        return {"anomalies": anomalies,
                "requires_review": any(a["severity"] in ["high","critical"] for a in anomalies),
                "anomaly_count": len(anomalies)}

    async def _check_duplicate_file(self, p):
        r = await self.db.execute(
            text("SELECT id,uploaded_at FROM cv_versions WHERE file_hash=:h AND id!=:cv LIMIT 1"),
            {"h": p["file_hash"], "cv": p["cv_version_id"]})
        row = r.fetchone()
        if row:
            return [{"type":"duplicate_cv","severity":"high",
                     "description":f"Exact file uploaded before on {row.uploaded_at}",
                     "evidence":{"prior_id":str(row.id)}}]
        return []

    async def _check_duplicate_application(self, p):
        r = await self.db.execute(
            text("SELECT id FROM screenings WHERE candidate_id=:c AND job_id=:j LIMIT 1"),
            {"c": p["candidate_id"], "j": p["job_id"]})
        row = r.fetchone()
        if row:
            return [{"type":"duplicate_cv","severity":"medium",
                     "description":"Candidate already screened for this role",
                     "evidence":{"prior_screening":str(row.id)}}]
        return []

    async def _check_parse_confidence(self, p):
        conf = p.get("parse_confidence", 1.0)
        if conf < 0.35:
            return [{"type":"low_parse_confidence","severity":"high",
                     "description":f"Parse confidence {conf:.0%} — may be scanned/image-based",
                     "evidence":{"confidence":conf}}]
        if conf < 0.55:
            return [{"type":"low_parse_confidence","severity":"medium",
                     "description":f"Parse confidence {conf:.0%} — some fields may be incomplete",
                     "evidence":{"confidence":conf}}]
        return []

    async def _check_employment_gaps(self, p):
        exp = p.get("parsed_cv", {}).get("experience", [])
        anomalies = []
        try:
            sorted_e = sorted(
                [e for e in exp if e.get("start_date") and e.get("end_date")
                 and str(e.get("end_date","")).lower() != "present"],
                key=lambda x: str(x.get("start_date",""))
            )
            for i in range(1, len(sorted_e)):
                try:
                    py = int(str(sorted_e[i-1]["end_date"])[:4])
                    cy = int(str(sorted_e[i]["start_date"])[:4])
                    gap = (cy - py) * 12
                    if gap > 12:
                        anomalies.append({"type":"employment_gap","severity":"low",
                            "description":f"~{gap//12}yr gap between roles",
                            "evidence":{"gap_months":gap}})
                except Exception:
                    pass
        except Exception:
            pass
        return anomalies

    async def _check_borderline(self, p):
        s = p.get("composite_score", 0)
        if 0.38 <= s <= 0.52:
            return [{"type":"borderline_score","severity":"medium",
                     "description":f"Score {s:.0%} is borderline — HR review required",
                     "evidence":{"score":s}}]
        return []

    async def _check_keyword_stuffing(self, p):
        skills = p.get("parsed_cv", {}).get("technical_skills", [])
        if len(skills) > 50:
            return [{"type":"suspicious_pattern","severity":"medium",
                     "description":f"CV lists {len(skills)} skills — possible keyword stuffing",
                     "evidence":{"skill_count":len(skills)}}]
        return []
