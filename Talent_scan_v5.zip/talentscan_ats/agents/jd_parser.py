"""
JD Requirements Parser
Extracts structured requirements from raw JD text.
Used to power rule-based skill matching and experience scoring.
"""
import re
import json
from typing import Dict, Any, List
import ollama as ollama_client
from config.settings import settings
import structlog

logger = structlog.get_logger(__name__)


async def parse_jd_requirements(jd_text: str) -> Dict[str, Any]:
    """
    Extract structured requirements from JD text.
    Returns: {required_skills, nice_skills, min_years, max_years, seniority, domain}
    """
    # First try fast rule-based extraction
    result = _rule_based_extract(jd_text)

    # Then enhance with LLM if we have Ollama
    try:
        enhanced = await _llm_extract(jd_text)
        # Merge: LLM supplements rule-based
        if enhanced.get("required_skills"):
            result["required_skills"] = list(set(
                result.get("required_skills", []) + enhanced["required_skills"]
            ))
        if enhanced.get("nice_skills"):
            result["nice_skills"] = list(set(
                result.get("nice_skills", []) + enhanced["nice_skills"]
            ))
        if enhanced.get("min_years") and not result.get("min_years"):
            result["min_years"] = enhanced["min_years"]
        if enhanced.get("seniority"):
            result["seniority"] = enhanced["seniority"]
        if enhanced.get("domain"):
            result["domain"] = enhanced["domain"]
    except Exception as e:
        logger.warning("jd_llm_extract_failed", error=str(e))

    return result


def _rule_based_extract(text: str) -> Dict[str, Any]:
    """Fast regex-based extraction — no LLM needed."""
    text_lower = text.lower()
    result: Dict[str, Any] = {
        "required_skills": [],
        "nice_skills":     [],
        "min_years":       0,
        "seniority":       "mid",
        "domain":          "",
    }

    # ── Extract years of experience ──
    year_patterns = [
        r'(\d+)\+?\s*years?\s*(?:of\s+)?(?:experience|exp)',
        r'minimum\s+(\d+)\s*years?',
        r'at\s+least\s+(\d+)\s*years?',
    ]
    for pat in year_patterns:
        m = re.search(pat, text_lower)
        if m:
            result["min_years"] = int(m.group(1))
            break

    # ── Seniority level ──
    if any(w in text_lower for w in ["senior","lead","principal","staff","head of"]):
        result["seniority"] = "senior"
    elif any(w in text_lower for w in ["junior","entry","fresher","graduate"]):
        result["seniority"] = "junior"
    elif any(w in text_lower for w in ["manager","director","vp","vice president"]):
        result["seniority"] = "manager"

    # ── Common tech skills ──
    TECH_SKILLS = [
        "python","sql","java","javascript","typescript","go","rust","c++","c#","scala",
        "r ","matlab","spark","kafka","airflow","hadoop","flink","databricks","dbt",
        "azure","aws","gcp","terraform","docker","kubernetes","helm","ansible",
        "postgresql","mysql","mongodb","redis","elasticsearch","snowflake","bigquery",
        "redshift","dbt","looker","tableau","power bi","qlik",
        "machine learning","deep learning","nlp","computer vision","llm","langchain",
        "tensorflow","pytorch","scikit-learn","pandas","numpy",
        "rest api","graphql","microservices","ci/cd","git","github","gitlab",
        "react","vue","angular","fastapi","django","flask","node.js",
        "data engineering","data science","mlops","devops","data warehouse",
        "etl","elt","unity catalog","data mesh","data governance",
    ]
    found = []
    for skill in TECH_SKILLS:
        if skill in text_lower:
            found.append(skill.title() if len(skill) > 3 else skill.upper())
    result["required_skills"] = found[:20]

    return result


async def _llm_extract(jd_text: str) -> Dict[str, Any]:
    """LLM-enhanced extraction for nuanced requirements."""
    client = ollama_client.AsyncClient(host=settings.ollama_base_url)
    prompt = f"""Extract JD requirements. JSON only.
Schema: {{"required_skills":[],"nice_skills":[],"min_years":0,"seniority":"junior|mid|senior|manager","domain":"string"}}
Rules: required_skills are must-haves, nice_skills are optional. Max 15 items each.
JD: {jd_text[:2000]}"""
    resp = await client.chat(
        model=settings.ollama_llm_model,
        messages=[{"role": "user", "content": prompt}],
        format="json",
        options={"temperature": 0.0, "num_predict": 400},
    )
    raw = resp["message"]["content"]
    if isinstance(raw, str):
        return json.loads(raw)
    return raw
