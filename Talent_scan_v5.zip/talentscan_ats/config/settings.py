from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
from urllib.parse import quote_plus


class Settings(BaseSettings):
    # ── Database ──
    postgres_host:     str   = Field(validation_alias="POSTGRES_HOST")
    postgres_port:     int   = Field(5432, validation_alias="POSTGRES_PORT")
    postgres_db:       str   = Field(validation_alias="POSTGRES_DB")
    postgres_user:     str   = Field(validation_alias="POSTGRES_USER")
    postgres_password: str   = Field(validation_alias="POSTGRES_PASSWORD")

    @property
    def database_url(self) -> str:
        pw = quote_plus(self.postgres_password)
        return f"postgresql+asyncpg://{self.postgres_user}:{pw}@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"

    # ── Ollama ──
    ollama_base_url:    str = Field("http://ollama:11434", validation_alias="OLLAMA_BASE_URL")
    ollama_llm_model:   str = Field("llama3.1:8b",         validation_alias="OLLAMA_LLM_MODEL")
    ollama_embed_model: str = Field("nomic-embed-text",    validation_alias="OLLAMA_EMBED_MODEL")

    # ── API ──
    api_host:    str = "0.0.0.0"
    api_port:    int = 8000
    secret_key:  str = "change_me_in_production"
    environment: str = "production"

    # ── Files ──
    upload_dir:       str = "/app/uploads"
    max_file_size_mb: int = 20
    allowed_extensions: str = "pdf,docx,txt"
    log_dir:          str = "/app/logs"
    max_bulk_upload:  int = 500
    embedding_dimension: int = 768

    @property
    def allowed_ext_list(self) -> list[str]:
        return [e.strip() for e in self.allowed_extensions.split(",")]

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
