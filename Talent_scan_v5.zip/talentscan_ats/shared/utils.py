import hashlib, uuid, os, re
from pathlib import Path
from typing import Optional


def compute_file_hash(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def sanitize_filename(fn: str) -> str:
    return re.sub(r'[^\w\-_\.]', '_', fn)[:255]

def get_file_extension(fn: str) -> str:
    return Path(fn).suffix.lstrip('.').lower()

def truncate_text(text: str, max_chars: int = 6000) -> str:
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rsplit(' ', 1)[0] + "\n[TRUNCATED]"

def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)

def mask_email(email: str) -> str:
    if '@' not in email:
        return email
    u, d = email.split('@', 1)
    return (u[:2] + '*' * max(0, len(u)-2)) + '@' + d
