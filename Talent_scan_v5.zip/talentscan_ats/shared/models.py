from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from uuid import UUID
from enum import Enum


class FileFormat(str, Enum):
    PDF = "pdf"; DOCX = "docx"; TXT = "txt"; UNKNOWN = "unknown"


class ExperienceEntry(BaseModel):
    company:         Optional[str] = None
    role:            Optional[str] = None
    start_date:      Optional[str] = None
    end_date:        Optional[str] = None
    duration_months: Optional[int] = None
    description:     Optional[str] = None
    technologies:    List[str]     = Field(default_factory=list)


class EducationEntry(BaseModel):
    institution:      Optional[str] = None
    degree:           Optional[str] = None
    field:            Optional[str] = None
    graduation_year:  Optional[int] = None
    grade:            Optional[str] = None


class ParsedCV(BaseModel):
    full_name:        Optional[str] = None
    email:            Optional[str] = None
    phone:            Optional[str] = None
    linkedin_url:     Optional[str] = None
    location:         Optional[str] = None
    technical_skills: List[str] = Field(default_factory=list)
    soft_skills:      List[str] = Field(default_factory=list)
    domain_expertise: List[str] = Field(default_factory=list)
    certifications:   List[str] = Field(default_factory=list)
    languages:        List[str] = Field(default_factory=list)
    experience:       List[ExperienceEntry] = Field(default_factory=list)
    education:        List[EducationEntry]  = Field(default_factory=list)
    total_years_exp:  Optional[float] = None
    cv_summary:       Optional[str]   = None
    parse_confidence: float = Field(ge=0.0, le=1.0, default=0.5)
    parse_warnings:   List[str] = Field(default_factory=list)


class ScoreBreakdown(BaseModel):
    """Fully explainable score — never exceeds 100."""
    final_score:      int = Field(ge=0, le=100)
    relevance_score:  int = Field(ge=0, le=100, description="Embedding similarity ×30")
    skill_match_score: int = Field(ge=0, le=100, description="Rule-based skill overlap ×25")
    experience_score:  int = Field(ge=0, le=100, description="Years vs JD requirement ×20")
    semantic_score:    int = Field(ge=0, le=100, description="LLM reasoning ×25")
    penalty_score:     int = Field(ge=0, le=100, description="Deductions for missing criticals")
    potential_score:   int = Field(ge=0, le=100, description="Career trajectory signal")
    score_formula:     str
    score_weights:     Dict[str, int]
    penalties_applied: List[Dict[str, Any]]
    score_reasoning:   str
    matched_skills:    List[str]
    missing_skills:    List[str]
    why_selected:      str
    why_rejected:      str


class BulkUploadResponse(BaseModel):
    total_received:  int
    queued:          int
    failed:          int
    correlation_ids: List[str]
    errors:          List[Dict[str, str]]


class HealthResponse(BaseModel):
    status:   str
    database: bool
    ollama:   bool
    version:  str = "2.0.0"
