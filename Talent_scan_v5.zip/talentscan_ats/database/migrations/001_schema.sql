-- TalentScan ATS v2 — Full Schema
-- Adds: explainable scoring columns, ATS stage tracking, penalty scores

CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ============================================================
-- ENUMS
-- ============================================================
CREATE TYPE candidate_status AS ENUM (
    'new','parsing','parsed','screened',
    'shortlisted','interview_scheduled','interviewed',
    'offered','hired','rejected','on_hold','withdrawn'
);

CREATE TYPE screening_decision AS ENUM (
    'auto_shortlisted','auto_rejected','needs_review',
    'hr_approved','hr_rejected','hr_hold','forwarded'
);

CREATE TYPE ats_stage AS ENUM (
    'new','screening','shortlisted','interview','offer','hired','rejected'
);

CREATE TYPE file_format AS ENUM ('pdf','docx','txt','unknown');

CREATE TYPE anomaly_type AS ENUM (
    'duplicate_cv','employment_gap','inconsistent_dates',
    'missing_required_skills','low_parse_confidence',
    'suspicious_pattern','borderline_score','keyword_stuffing'
);

-- ============================================================
-- TABLE: jobs
-- ============================================================
CREATE TABLE jobs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title           TEXT NOT NULL,
    department      TEXT,
    location        TEXT,
    description_raw TEXT NOT NULL,
    requirements    JSONB,          -- parsed: {required_skills, min_years, seniority}
    embedding       vector(768),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    created_by      TEXT NOT NULL
);

-- ============================================================
-- TABLE: candidates
-- ============================================================
CREATE TABLE candidates (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email           TEXT UNIQUE,
    full_name       TEXT,
    phone           TEXT,
    linkedin_url    TEXT,
    current_status  candidate_status DEFAULT 'new',
    ats_stage       ats_stage DEFAULT 'new',
    first_seen_at   TIMESTAMPTZ DEFAULT NOW(),
    last_updated_at TIMESTAMPTZ DEFAULT NOW(),
    source          TEXT,
    is_returning    BOOLEAN DEFAULT FALSE,
    notes           TEXT
);

-- ============================================================
-- TABLE: cv_versions
-- ============================================================
CREATE TABLE cv_versions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    candidate_id        UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
    job_id              UUID REFERENCES jobs(id),
    original_filename   TEXT NOT NULL,
    stored_path         TEXT NOT NULL,
    file_format         file_format NOT NULL,
    file_size_bytes     INTEGER,
    file_hash           TEXT NOT NULL,
    parsed_data         JSONB,
    parse_confidence    FLOAT,
    parse_errors        JSONB,
    embedding           vector(768),
    embedding_model     TEXT,
    ingestion_status    TEXT DEFAULT 'pending',
    processing_time_ms  INTEGER,          -- track latency
    correlation_id      UUID DEFAULT uuid_generate_v4(),
    uploaded_at         TIMESTAMPTZ DEFAULT NOW(),
    processed_at        TIMESTAMPTZ
);

-- ============================================================
-- TABLE: screenings  (UPGRADED with full scoring breakdown)
-- ============================================================
CREATE TABLE screenings (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cv_version_id       UUID NOT NULL REFERENCES cv_versions(id),
    job_id              UUID NOT NULL REFERENCES jobs(id),
    candidate_id        UUID NOT NULL REFERENCES candidates(id),

    -- ── Explainable Score Components (0–100 each) ──
    final_score         INTEGER NOT NULL DEFAULT 0 CHECK (final_score BETWEEN 0 AND 100),
    relevance_score     INTEGER DEFAULT 0 CHECK (relevance_score BETWEEN 0 AND 100),
    skill_match_score   INTEGER DEFAULT 0 CHECK (skill_match_score BETWEEN 0 AND 100),
    experience_score    INTEGER DEFAULT 0 CHECK (experience_score BETWEEN 0 AND 100),
    semantic_score      INTEGER DEFAULT 0 CHECK (semantic_score BETWEEN 0 AND 100),
    penalty_score       INTEGER DEFAULT 0 CHECK (penalty_score BETWEEN 0 AND 100),

    -- Legacy float scores (kept for backward compat)
    semantic_similarity FLOAT,
    composite_score     FLOAT GENERATED ALWAYS AS (final_score::float/100.0) STORED,

    -- ── Scoring Trace (full transparency) ──
    score_formula       TEXT,             -- e.g. "(rel*0.30 + skill*0.25 + ...)"
    score_weights       JSONB,            -- {"relevance":30,"skill":25,...}
    penalties_applied   JSONB,            -- [{"reason":"Missing Python","deduction":15}]
    score_reasoning     TEXT,             -- full LLM trace paragraph

    -- ── Explainability ──
    matched_skills      JSONB,            -- skills from CV that match JD
    missing_skills      JSONB,            -- required skills not found
    strengths           JSONB,
    gaps                JSONB,
    why_selected        TEXT,
    why_rejected        TEXT,
    transferable_skills JSONB,
    value_add_insights  JSONB,
    llm_rationale       TEXT,

    -- ── Potential Agent ──
    potential_score     INTEGER DEFAULT 0 CHECK (potential_score BETWEEN 0 AND 100),
    career_trajectory   TEXT,
    growth_label        TEXT,

    -- ── ATS Stage ──
    ats_stage           ats_stage DEFAULT 'screening',

    -- ── HR Decision ──
    decision            screening_decision DEFAULT 'needs_review',
    decision_by         TEXT,
    decision_at         TIMESTAMPTZ,
    decision_notes      TEXT,

    -- ── Performance ──
    pipeline_time_ms    INTEGER,          -- total pipeline latency

    screened_at         TIMESTAMPTZ DEFAULT NOW(),

    UNIQUE (cv_version_id, job_id)
);

-- ============================================================
-- TABLE: anomalies
-- ============================================================
CREATE TABLE anomalies (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cv_version_id   UUID REFERENCES cv_versions(id),
    candidate_id    UUID REFERENCES candidates(id),
    job_id          UUID REFERENCES jobs(id),
    anomaly_type    anomaly_type NOT NULL,
    severity        TEXT NOT NULL CHECK (severity IN ('low','medium','high','critical')),
    description     TEXT NOT NULL,
    raw_evidence    JSONB,
    is_resolved     BOOLEAN DEFAULT FALSE,
    resolved_by     TEXT,
    resolved_at     TIMESTAMPTZ,
    resolution_note TEXT,
    detected_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABLE: interviews
-- ============================================================
CREATE TABLE interviews (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    screening_id        UUID NOT NULL REFERENCES screenings(id),
    candidate_id        UUID NOT NULL REFERENCES candidates(id),
    job_id              UUID NOT NULL REFERENCES jobs(id),
    scheduled_at        TIMESTAMPTZ,
    interviewed_at      TIMESTAMPTZ,
    interviewer         TEXT,
    format              TEXT,
    technical_score     INTEGER CHECK (technical_score BETWEEN 1 AND 5),
    communication_score INTEGER CHECK (communication_score BETWEEN 1 AND 5),
    cultural_fit_score  INTEGER CHECK (cultural_fit_score BETWEEN 1 AND 5),
    overall_score       INTEGER CHECK (overall_score BETWEEN 1 AND 5),
    feedback_notes      TEXT,
    recommendation      TEXT CHECK (recommendation IN ('hire','reject','second_round','hold')),
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABLE: score_history  (track re-scoring events)
-- ============================================================
CREATE TABLE score_history (
    id              BIGSERIAL PRIMARY KEY,
    screening_id    UUID REFERENCES screenings(id),
    candidate_id    UUID REFERENCES candidates(id),
    job_id          UUID REFERENCES jobs(id),
    old_score       INTEGER,
    new_score       INTEGER,
    changed_by      TEXT,
    reason          TEXT,
    changed_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABLE: audit_logs (append-only)
-- ============================================================
CREATE TABLE audit_logs (
    id              BIGSERIAL PRIMARY KEY,
    correlation_id  UUID,
    event_type      TEXT NOT NULL,
    actor           TEXT NOT NULL,
    candidate_id    UUID,
    cv_version_id   UUID,
    job_id          UUID,
    screening_id    UUID,
    event_data      JSONB NOT NULL,
    outcome         TEXT,
    error_message   TEXT,
    duration_ms     INTEGER,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
REVOKE UPDATE, DELETE ON audit_logs FROM PUBLIC;

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX idx_cv_embedding       ON cv_versions USING ivfflat (embedding vector_cosine_ops) WITH (lists=100);
CREATE INDEX idx_job_embedding      ON jobs        USING ivfflat (embedding vector_cosine_ops) WITH (lists=10);
CREATE INDEX idx_candidates_email   ON candidates  (email);
CREATE INDEX idx_cvv_candidate      ON cv_versions (candidate_id);
CREATE INDEX idx_cvv_job            ON cv_versions (job_id);
CREATE INDEX idx_cvv_hash           ON cv_versions (file_hash);
CREATE INDEX idx_screenings_job     ON screenings  (job_id, final_score DESC);
CREATE INDEX idx_screenings_cand    ON screenings  (candidate_id);
CREATE INDEX idx_screenings_stage   ON screenings  (ats_stage);
CREATE INDEX idx_audit_correlation  ON audit_logs  (correlation_id);
CREATE INDEX idx_anomaly_cv         ON anomalies   (cv_version_id);
CREATE INDEX idx_cv_parsed_data     ON cv_versions USING GIN (parsed_data);
CREATE INDEX idx_screening_matched  ON screenings  USING GIN (matched_skills);

-- ============================================================
-- VIEWS
-- ============================================================
CREATE VIEW v_job_pipeline AS
SELECT
    j.id, j.title, j.department,
    COUNT(s.id)                                                    AS total_screened,
    COUNT(s.id) FILTER (WHERE s.ats_stage = 'shortlisted')        AS shortlisted,
    COUNT(s.id) FILTER (WHERE s.ats_stage = 'interview')          AS interview,
    COUNT(s.id) FILTER (WHERE s.ats_stage = 'rejected')           AS rejected,
    COUNT(s.id) FILTER (WHERE s.ats_stage = 'screening')          AS in_screening,
    COUNT(s.id) FILTER (WHERE s.decision  = 'needs_review')       AS pending_review,
    ROUND(AVG(s.final_score))                                      AS avg_score,
    MIN(s.pipeline_time_ms)                                        AS min_pipeline_ms,
    MAX(s.pipeline_time_ms)                                        AS max_pipeline_ms,
    ROUND(AVG(s.pipeline_time_ms))                                 AS avg_pipeline_ms
FROM jobs j
LEFT JOIN screenings s ON s.job_id = j.id
GROUP BY j.id, j.title, j.department;

CREATE VIEW v_candidate_summary AS
SELECT
    c.id, c.full_name, c.email, c.current_status, c.is_returning,
    COUNT(DISTINCT cv.id)    AS cv_count,
    COUNT(DISTINCT s.job_id) AS jobs_applied,
    MAX(s.final_score)       AS best_score,
    c.first_seen_at
FROM candidates c
LEFT JOIN cv_versions cv ON cv.candidate_id = c.id
LEFT JOIN screenings  s  ON s.candidate_id  = c.id
GROUP BY c.id;

CREATE VIEW v_analytics AS
SELECT
    s.job_id,
    j.title AS job_title,
    COUNT(*)                                                         AS total,
    COUNT(*) FILTER (WHERE s.final_score >= 70)                     AS high_scores,
    COUNT(*) FILTER (WHERE s.final_score BETWEEN 50 AND 69)         AS mid_scores,
    COUNT(*) FILTER (WHERE s.final_score < 50)                      AS low_scores,
    ROUND(AVG(s.final_score))                                        AS avg_score,
    ROUND(AVG(s.pipeline_time_ms))                                   AS avg_ms,
    ROUND(AVG(s.penalty_score))                                      AS avg_penalty,
    ROUND(AVG(s.skill_match_score))                                  AS avg_skill_match
FROM screenings s
JOIN jobs j ON j.id = s.job_id
GROUP BY s.job_id, j.title;
