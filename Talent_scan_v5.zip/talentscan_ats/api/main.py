import os, structlog
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import httpx

from api.routers import jobs, screening, candidates, analytics
from database.connection import check_db_health
from shared.models import HealthResponse
from config.settings import settings

structlog.configure(
    processors=[
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.JSONRenderer(),
    ],
    logger_factory=structlog.stdlib.LoggerFactory(),
)
logger = structlog.get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("startup", env=settings.environment)
    os.makedirs(f"{settings.upload_dir}/cvs", exist_ok=True)
    os.makedirs(f"{settings.upload_dir}/jds", exist_ok=True)
    os.makedirs(settings.log_dir, exist_ok=True)
    yield
    logger.info("shutdown")


app = FastAPI(
    title="TalentScan ATS API v2",
    version="2.0.0",
    docs_url="/docs" if settings.environment == "development" else None,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8501","http://frontend:8501","http://127.0.0.1:8501"],
    allow_methods=["GET","POST","PATCH","PUT","DELETE"],
    allow_headers=["*"],
)

app.include_router(jobs.router,       prefix="/api/v1/jobs",       tags=["Jobs"])
app.include_router(screening.router,  prefix="/api/v1/screenings", tags=["Screenings"])
app.include_router(candidates.router, prefix="/api/v1/candidates", tags=["Candidates"])
app.include_router(analytics.router,  prefix="/api/v1/analytics",  tags=["Analytics"])


@app.get("/health", response_model=HealthResponse)
async def health():
    db_ok = await check_db_health()
    ollama_ok = False
    try:
        async with httpx.AsyncClient(timeout=3.0) as c:
            r = await c.get(f"{settings.ollama_base_url}/api/tags")
            ollama_ok = r.status_code == 200
    except Exception:
        pass
    return HealthResponse(
        status="healthy" if (db_ok and ollama_ok) else "degraded",
        database=db_ok, ollama=ollama_ok
    )
