import json, os, uuid, time
from typing import List
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
import aiofiles, structlog

from database.connection import get_db, AsyncSessionLocal
from shared.models import BulkUploadResponse
from shared.utils import sanitize_filename, compute_file_hash, get_file_extension
from config.settings import settings
from agents.ingestion_agent import IngestionAgent
from agents.matching_agent import MatchingAgent
from agents.potential_agent import PotentialAgent
from agents.validation_agent import ValidationAgent

router = APIRouter()
logger = structlog.get_logger(__name__)


@router.post("/upload", response_model=BulkUploadResponse)
async def upload_cvs(
    job_id:       str             = Form(...),
    uploaded_by:  str             = Form(...),
    cv_files:     List[UploadFile] = File(...),
    background_tasks: BackgroundTasks = None,
    db:           AsyncSession    = Depends(get_db),
):
    if len(cv_files) > settings.max_bulk_upload:
        raise HTTPException(400, f"Max {settings.max_bulk_upload} files per batch")

    job = (await db.execute(text("SELECT id,description_raw,requirements FROM jobs WHERE id=:id"),
                             {"id":job_id})).mappings().fetchone()
    if not job: raise HTTPException(404, "Job not found")

    queued, failed, corr_ids = [], [], []

    for cv_file in cv_files:
        cid = str(uuid.uuid4())
        try:
            ext = get_file_extension(cv_file.filename)
            if ext not in settings.allowed_ext_list:
                failed.append({"filename": cv_file.filename, "error": f"Unsupported: {ext}"})
                continue
            content = await cv_file.read()
            if len(content) > settings.max_file_size_mb * 1024 * 1024:
                failed.append({"filename": cv_file.filename, "error": "File too large"})
                continue

            os.makedirs(os.path.join(settings.upload_dir, "cvs"), exist_ok=True)
            safe = sanitize_filename(cv_file.filename)
            fpath = os.path.join(settings.upload_dir, "cvs", f"{cid}_{safe}")
            async with aiofiles.open(fpath, "wb") as f:
                await f.write(content)

            file_hash   = compute_file_hash(content)
            candidate_id = str(uuid.uuid4())
            cv_version_id = str(uuid.uuid4())

            await db.execute(
                text("INSERT INTO candidates (id,full_name,email,current_status) VALUES (:id,:name,:email,'new')"),
                {"id": candidate_id, "name": cv_file.filename, "email": None})
            await db.execute(
                text("""INSERT INTO cv_versions
                    (id,candidate_id,job_id,original_filename,stored_path,file_format,
                     file_size_bytes,file_hash,ingestion_status,correlation_id)
                    VALUES (:id,:cand,:job,:fn,:path,:fmt,:sz,:hash,'pending',:cid)"""),
                {"id":cv_version_id,"cand":candidate_id,"job":job_id,"fn":cv_file.filename,
                 "path":fpath,"fmt":ext,"sz":len(content),"hash":file_hash,"cid":cid})
            await db.commit()

            background_tasks.add_task(
                run_pipeline,
                cv_version_id=cv_version_id, candidate_id=candidate_id,
                job_id=job_id, file_path=fpath, filename=cv_file.filename,
                file_hash=file_hash, correlation_id=cid,
                job_desc=str(job["description_raw"]),
                jd_requirements=dict(job.get("requirements") or {}),
            )
            queued.append(cv_version_id)
            corr_ids.append(cid)
        except Exception as e:
            await db.rollback()
            failed.append({"filename": cv_file.filename, "error": str(e)})

    return BulkUploadResponse(
        total_received=len(cv_files), queued=len(queued),
        failed=len(failed), correlation_ids=corr_ids, errors=failed)


async def run_pipeline(
    cv_version_id, candidate_id, job_id, file_path, filename,
    file_hash, correlation_id, job_desc, jd_requirements
):
    log = logger.bind(correlation_id=correlation_id)
    t_start = time.perf_counter()

    async with AsyncSessionLocal() as db:
        try:
            await db.execute(
                text("UPDATE cv_versions SET ingestion_status='processing' WHERE id=:id"),
                {"id": cv_version_id})
            await db.commit()

            # ── Agent 1: Ingestion ──
            log.info("ingestion_started")
            try:
                ing = await IngestionAgent(db).run(
                    {"file_path": file_path, "filename": filename}, correlation_id)
            except Exception as e:
                log.error("ingestion_failed", error=str(e))
                await db.execute(text("UPDATE cv_versions SET ingestion_status='failed' WHERE id=:id"),
                                 {"id": cv_version_id})
                await db.commit()
                return

            parsed_cv = ing.get("parsed_cv") or {}
            if not parsed_cv:
                raise ValueError("Empty parsed_cv")

            # Update candidate with real name/email
            extracted_email = parsed_cv.get("email")
            if extracted_email:
                conflict = (await db.execute(
                    text("SELECT id FROM candidates WHERE email=:e AND id!=:id LIMIT 1"),
                    {"e": extracted_email, "id": candidate_id})).fetchone()
                if conflict:
                    extracted_email = None
            await db.execute(
                text("UPDATE candidates SET full_name=:n,email=:e,last_updated_at=NOW() WHERE id=:id"),
                {"n": parsed_cv.get("full_name") or filename, "e": extracted_email, "id": candidate_id})
            await db.execute(
                text("""UPDATE cv_versions SET parsed_data=CAST(:d AS jsonb),
                    parse_confidence=:c,ingestion_status='done',processed_at=NOW() WHERE id=:id"""),
                {"d": json.dumps(parsed_cv), "c": parsed_cv.get("parse_confidence", 0.5),
                 "id": cv_version_id})
            await db.commit()

            # ── Agent 2: Matching (with full scoring) ──
            log.info("matching_started")
            try:
                match = await MatchingAgent(db).run({
                    "cv_version_id": cv_version_id, "job_id": job_id,
                    "candidate_id": candidate_id, "parsed_cv": parsed_cv,
                    "job_description": job_desc, "jd_requirements": jd_requirements,
                }, correlation_id)
            except Exception as e:
                log.error("matching_failed", error=str(e))
                await db.execute(text("UPDATE cv_versions SET ingestion_status='failed' WHERE id=:id"),
                                 {"id": cv_version_id})
                await db.commit()
                return

            log.info("matching_done", final_score=match["final_score"])

            # ── Agent 3: Potential ──
            log.info("potential_started")
            try:
                pot = await PotentialAgent(db).run({"parsed_cv": parsed_cv}, correlation_id)
            except Exception as e:
                log.error("potential_failed", error=str(e))
                pot = {"potential_score": 40, "career_trajectory": "insufficient_data",
                       "growth_label": "Insufficient data", "value_add_insights": []}

            # ── Agent 4: Validation ──
            log.info("validation_started")
            try:
                val = await ValidationAgent(db).run({
                    "file_hash": file_hash, "cv_version_id": cv_version_id,
                    "candidate_id": candidate_id, "job_id": job_id,
                    "parsed_cv": parsed_cv, "composite_score": match["final_score"] / 100.0,
                    "parse_confidence": parsed_cv.get("parse_confidence", 0.5),
                }, correlation_id)
            except Exception as e:
                log.error("validation_failed", error=str(e))
                val = {"requires_review": False, "anomalies": [], "anomaly_count": 0}

            # ── ATS Stage + Decision ──
            final = match["final_score"]
            if val["requires_review"] or val["anomaly_count"] > 0:
                decision  = "needs_review"
                ats_stage = "screening"
            elif final >= 70:
                decision  = "auto_shortlisted"
                ats_stage = "shortlisted"
            elif final >= 50:
                decision  = "needs_review"
                ats_stage = "screening"
            else:
                decision  = "auto_rejected"
                ats_stage = "rejected"

            pipeline_ms = int((time.perf_counter() - t_start) * 1000)

            # ── Insert screening record ──
            sid = str(uuid.uuid4())
            await db.execute(
                text("""INSERT INTO screenings (
                    id,cv_version_id,candidate_id,job_id,
                    final_score,relevance_score,skill_match_score,experience_score,
                    semantic_score,penalty_score,potential_score,
                    semantic_similarity,
                    matched_skills,missing_skills,strengths,gaps,
                    why_selected,why_rejected,transferable_skills,value_add_insights,
                    llm_rationale,score_formula,score_weights,penalties_applied,score_reasoning,
                    career_trajectory,growth_label,
                    decision,ats_stage,pipeline_time_ms
                ) VALUES (
                    :id,:cv,:cand,:job,
                    :fs,:rs,:ss,:es,
                    :sem,:pen,:pot,
                    :cos,
                    CAST(:msk AS jsonb),CAST(:mis AS jsonb),CAST(:str AS jsonb),CAST(:gap AS jsonb),
                    :wsel,:wrej,CAST(:trans AS jsonb),CAST(:vai AS jsonb),
                    :rat,:formula,CAST(:weights AS jsonb),CAST(:pens AS jsonb),:reasoning,
                    :traj,:glbl,
                    :dec,:stage,:pms
                )"""),
                {
                    "id":sid, "cv":cv_version_id, "cand":candidate_id, "job":job_id,
                    "fs":final, "rs":match["relevance_score"], "ss":match["skill_match_score"],
                    "es":match["experience_score"], "sem":match["semantic_score"],
                    "pen":match["penalty_score"], "pot":pot.get("potential_score",40),
                    "cos":match["semantic_similarity"],
                    "msk":json.dumps(match.get("matched_skills",[])),
                    "mis":json.dumps(match.get("missing_skills",[])),
                    "str":json.dumps(match.get("strengths",[])),
                    "gap":json.dumps(match.get("gaps",[])),
                    "wsel":match.get("why_selected",""),
                    "wrej":match.get("why_rejected",""),
                    "trans":json.dumps(match.get("transferable_skills",[])),
                    "vai":json.dumps(pot.get("value_add_insights",[])),
                    "rat":match.get("llm_rationale",""),
                    "formula":match.get("score_formula",""),
                    "weights":json.dumps(match.get("score_weights",{})),
                    "pens":json.dumps(match.get("penalties_applied",[])),
                    "reasoning":match.get("score_reasoning",""),
                    "traj":pot.get("career_trajectory",""),
                    "glbl":pot.get("growth_label",""),
                    "dec":decision, "stage":ats_stage, "pms":pipeline_ms,
                })
            await db.execute(
                text("UPDATE candidates SET current_status='screened',ats_stage=:s WHERE id=:id"),
                {"s": ats_stage, "id": candidate_id})
            await db.commit()
            log.info("pipeline_complete", screening_id=sid, final_score=final,
                     decision=decision, pipeline_ms=pipeline_ms)

        except Exception as e:
            await db.rollback()
            log.error("pipeline_failed", error=str(e))
            try:
                async with AsyncSessionLocal() as db2:
                    await db2.execute(
                        text("UPDATE cv_versions SET ingestion_status='failed' WHERE id=:id"),
                        {"id": cv_version_id})
                    await db2.commit()
            except Exception:
                pass


@router.get("/results/{job_id}")
async def get_results(
    job_id: str,
    min_score: int = 0,
    limit: int = 100,
    stage: str = None,
    db: AsyncSession = Depends(get_db),
):
    filters = "WHERE s.job_id=:job AND s.final_score>=:min"
    params  = {"job": job_id, "min": min_score, "lim": limit}
    if stage:
        filters += " AND s.ats_stage=:stage"
        params["stage"] = stage

    rows = (await db.execute(text(f"""
        SELECT s.*,
               c.full_name, c.email, c.phone, c.is_returning,
               cv.original_filename, cv.parse_confidence,
               (SELECT COUNT(*) FROM anomalies a WHERE a.cv_version_id=s.cv_version_id) AS anomaly_count
        FROM screenings s
        JOIN candidates c  ON c.id  = s.candidate_id
        JOIN cv_versions cv ON cv.id = s.cv_version_id
        {filters}
        ORDER BY s.final_score DESC
        LIMIT :lim
    """), params)).mappings().fetchall()
    return [dict(r) for r in rows]


@router.get("/candidate/{screening_id}")
async def get_candidate_profile(screening_id: str, db: AsyncSession = Depends(get_db)):
    row = (await db.execute(text("""
        SELECT s.*,
               c.full_name,c.email,c.phone,c.linkedin_url,c.is_returning,c.current_status,
               cv.original_filename,cv.parse_confidence,cv.parsed_data,cv.stored_path,
               j.title AS job_title, j.description_raw,
               (SELECT COUNT(*) FROM anomalies a WHERE a.cv_version_id=s.cv_version_id) AS anomaly_count
        FROM screenings s
        JOIN candidates c   ON c.id  = s.candidate_id
        JOIN cv_versions cv ON cv.id = s.cv_version_id
        JOIN jobs j         ON j.id  = s.job_id
        WHERE s.id=:id
    """), {"id": screening_id})).mappings().fetchone()
    if not row: raise HTTPException(404, "Screening not found")
    return dict(row)


@router.get("/anomalies/{cv_version_id}")
async def get_anomalies(cv_version_id: str, db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(
        text("SELECT * FROM anomalies WHERE cv_version_id=:id ORDER BY detected_at DESC"),
        {"id": cv_version_id})).mappings().fetchall()
    return [dict(r) for r in rows]


@router.patch("/{screening_id}/decision")
async def update_decision(
    screening_id: str,
    decision:     str = Form(...),
    decision_by:  str = Form(None),
    stage:        str = Form(None),
    db: AsyncSession = Depends(get_db),
):
    valid = {"auto_shortlisted","auto_rejected","needs_review","hr_approved","hr_rejected","hr_hold","forwarded"}
    if decision not in valid:
        raise HTTPException(400, f"Invalid decision. Must be one of: {valid}")

    # Map decision to ATS stage
    stage_map = {
        "auto_shortlisted": "shortlisted", "hr_approved": "shortlisted",
        "hr_rejected": "rejected", "auto_rejected": "rejected",
        "forwarded": "interview", "needs_review": "screening", "hr_hold": "screening",
    }
    ats = stage or stage_map.get(decision, "screening")

    await db.execute(
        text("""UPDATE screenings SET decision=:d,decision_by=:by,decision_at=NOW(),ats_stage=:s
             WHERE id=:id"""),
        {"d": decision, "by": decision_by, "s": ats, "id": screening_id})
    await db.commit()
    return {"message": "updated", "decision": decision, "ats_stage": ats}


@router.patch("/{screening_id}/stage")
async def move_stage(
    screening_id: str,
    stage:        str = Form(...),
    moved_by:     str = Form(None),
    db: AsyncSession = Depends(get_db),
):
    valid_stages = {"new","screening","shortlisted","interview","offer","hired","rejected"}
    if stage not in valid_stages:
        raise HTTPException(400, f"Invalid stage")
    await db.execute(
        text("UPDATE screenings SET ats_stage=:s WHERE id=:id"),
        {"s": stage, "id": screening_id})
    await db.execute(
        text("UPDATE candidates SET ats_stage=:s WHERE id=(SELECT candidate_id FROM screenings WHERE id=:sid)"),
        {"s": stage, "sid": screening_id})
    await db.commit()
    return {"message": "stage updated", "stage": stage}
