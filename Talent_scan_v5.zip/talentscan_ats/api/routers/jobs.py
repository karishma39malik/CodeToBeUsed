import os, uuid, io, json
from typing import List
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
import aiofiles, pdfplumber, structlog

from database.connection import get_db
from shared.utils import sanitize_filename, truncate_text
from config.settings import settings
from agents.matching_agent import MatchingAgent
from agents.jd_parser import parse_jd_requirements

router = APIRouter()
logger = structlog.get_logger(__name__)


@router.post("/", status_code=201)
async def create_job(
    title:      str        = Form(...),
    department: str        = Form(None),
    location:   str        = Form(None),
    created_by: str        = Form(...),
    jd_file:    UploadFile = File(...),
    db:         AsyncSession = Depends(get_db),
):
    content = await jd_file.read()
    fn = jd_file.filename.lower()
    if fn.endswith(".pdf"):
        try:
            with pdfplumber.open(io.BytesIO(content)) as pdf:
                jd_text = "\n".join(p.extract_text() or "" for p in pdf.pages)
        except Exception:
            raise HTTPException(400, "Cannot read PDF")
    else:
        jd_text = content.decode("utf-8", errors="ignore")
    jd_text = jd_text.replace("\x00", "")
    if len(jd_text.strip()) < 100:
        raise HTTPException(400, "JD too short — minimum 100 characters")

    # Parse requirements
    requirements = await parse_jd_requirements(jd_text)

    # Generate embedding
    agent = MatchingAgent(db)
    try:
        emb = await agent._embed(truncate_text(jd_text, 4000))
    except Exception as e:
        raise HTTPException(500, f"Embedding failed: {e}")

    job_id = str(uuid.uuid4())
    try:
        await db.execute(
            text("""INSERT INTO jobs (id,title,department,location,description_raw,requirements,embedding,created_by)
                 VALUES (:id,:title,:dept,:loc,:desc,CAST(:req AS jsonb),CAST(:emb AS vector),:by)"""),
            {"id":job_id,"title":title,"dept":department,"loc":location,"desc":jd_text,
             "req":json.dumps(requirements),
             "emb":"["+",".join(str(float(x)) for x in emb)+"]","by":created_by})
        await db.commit()
    except Exception as e:
        await db.rollback()
        raise HTTPException(500, f"DB insert failed: {e}")

    # Save file
    try:
        jd_dir = os.path.join(settings.upload_dir, "jds")
        os.makedirs(jd_dir, exist_ok=True)
        async with aiofiles.open(os.path.join(jd_dir, f"{job_id}_{sanitize_filename(jd_file.filename)}"), "wb") as f:
            await f.write(content)
    except Exception:
        pass

    row = (await db.execute(text("SELECT * FROM jobs WHERE id=:id"), {"id":job_id})).mappings().fetchone()
    logger.info("job_created", job_id=job_id, title=title, required_skills=requirements.get("required_skills",[])[:5])
    return dict(row)


@router.get("/")
async def list_jobs(active_only: bool = True, db: AsyncSession = Depends(get_db)):
    q = "SELECT id,title,department,location,is_active,created_at,requirements FROM jobs"
    if active_only: q += " WHERE is_active=TRUE"
    q += " ORDER BY created_at DESC"
    return [dict(r) for r in (await db.execute(text(q))).mappings()]


@router.get("/{job_id}")
async def get_job(job_id: str, db: AsyncSession = Depends(get_db)):
    row = (await db.execute(text("SELECT * FROM jobs WHERE id=:id"), {"id":job_id})).mappings().fetchone()
    if not row: raise HTTPException(404, "Job not found")
    return dict(row)


@router.get("/{job_id}/pipeline")
async def job_pipeline(job_id: str, db: AsyncSession = Depends(get_db)):
    row = (await db.execute(text("SELECT * FROM v_job_pipeline WHERE id=:id"), {"id":job_id})).mappings().fetchone()
    if not row: raise HTTPException(404, "Job not found")
    return dict(row)
