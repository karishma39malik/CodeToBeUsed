from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from database.connection import get_db

router = APIRouter()

@router.get("/")
async def list_candidates(db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(text("SELECT * FROM v_candidate_summary ORDER BY first_seen_at DESC LIMIT 200"))).mappings().fetchall()
    return [dict(r) for r in rows]

@router.get("/{candidate_id}")
async def get_candidate(candidate_id: str, db: AsyncSession = Depends(get_db)):
    row = (await db.execute(text("SELECT * FROM candidates WHERE id=:id"), {"id": candidate_id})).mappings().fetchone()
    return dict(row) if row else {}
