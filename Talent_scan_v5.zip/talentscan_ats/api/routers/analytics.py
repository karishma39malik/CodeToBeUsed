from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from database.connection import get_db

router = APIRouter()

@router.get("/overview")
async def overview(db: AsyncSession = Depends(get_db)):
    row = (await db.execute(text("""
        SELECT
            COUNT(DISTINCT c.id)                    AS total_candidates,
            COUNT(DISTINCT s.id)                    AS total_screenings,
            COUNT(DISTINCT j.id)                    AS total_jobs,
            COUNT(s.id) FILTER (WHERE s.ats_stage='shortlisted')  AS shortlisted,
            COUNT(s.id) FILTER (WHERE s.ats_stage='interview')    AS in_interview,
            COUNT(s.id) FILTER (WHERE s.ats_stage='rejected')     AS rejected,
            ROUND(AVG(s.final_score))               AS avg_score,
            ROUND(AVG(s.pipeline_time_ms))          AS avg_pipeline_ms,
            COUNT(s.id) FILTER (WHERE s.final_score>=70)  AS high_scores,
            COUNT(s.id) FILTER (WHERE s.final_score<50)   AS low_scores
        FROM candidates c
        LEFT JOIN screenings s ON s.candidate_id=c.id
        LEFT JOIN jobs j       ON j.id=s.job_id
    """))).mappings().fetchone()
    return dict(row) if row else {}

@router.get("/score-distribution/{job_id}")
async def score_dist(job_id: str, db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(text("""
        SELECT final_score, decision, ats_stage,
               full_name, original_filename
        FROM screenings s
        JOIN candidates c  ON c.id=s.candidate_id
        JOIN cv_versions cv ON cv.id=s.cv_version_id
        WHERE s.job_id=:id ORDER BY final_score DESC
    """), {"id": job_id})).mappings().fetchall()
    return [dict(r) for r in rows]

@router.get("/funnel/{job_id}")
async def funnel(job_id: str, db: AsyncSession = Depends(get_db)):
    row = (await db.execute(text("SELECT * FROM v_job_pipeline WHERE id=:id"), {"id": job_id})).mappings().fetchone()
    return dict(row) if row else {}

@router.get("/rejection-reasons/{job_id}")
async def rejection_reasons(job_id: str, db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(text("""
        SELECT s.missing_skills, s.why_rejected, s.penalty_score, s.final_score
        FROM screenings s
        WHERE s.job_id=:id AND s.ats_stage='rejected'
        LIMIT 100
    """), {"id": job_id})).mappings().fetchall()
    return [dict(r) for r in rows]

@router.get("/performance")
async def performance(db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(text("""
        SELECT job_id, j.title, AVG(pipeline_time_ms) AS avg_ms,
               MIN(pipeline_time_ms) AS min_ms, MAX(pipeline_time_ms) AS max_ms,
               COUNT(*) AS count
        FROM screenings s JOIN jobs j ON j.id=s.job_id
        WHERE pipeline_time_ms IS NOT NULL
        GROUP BY job_id, j.title ORDER BY avg_ms DESC
    """))).mappings().fetchall()
    return [dict(r) for r in rows]
