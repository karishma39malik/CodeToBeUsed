import streamlit as st
import requests
import os
import sys
import json
import time
sys.path.insert(0, "/app/frontend")
from shared_style import (CSS, topnav, sidebar_nav, badge_html, parse_list,
    score_color, score_bar_html, gauge, radar, waterfall, PLOTLY_CFG,
    initials, TECH_KW, FB_BLUE)

st.set_page_config(page_title="Candidate Profile · TalentScan", page_icon="👤", layout="wide")
st.markdown(CSS, unsafe_allow_html=True)
API = os.getenv("API_URL","http://api:8000") + "/api/v1"

with st.sidebar:
    sidebar_nav("profile")
    st.markdown('<div style="height:1px;background:#E4E6EB;margin:1rem 0;"></div>', unsafe_allow_html=True)
    screening_id = st.text_input("Screening ID", placeholder="Paste screening ID here")
    st.markdown('<div style="font-size:.72rem;color:#BCC0C4;margin-top:4px;">Find IDs in Screening Results page</div>', unsafe_allow_html=True)

st.markdown(topnav("Candidate Profile · Full Intelligence Report"), unsafe_allow_html=True)

if not screening_id or len(screening_id) < 10:
    st.markdown("""<div class="fb-card" style="text-align:center;padding:3rem;">
      <div style="font-size:2rem;margin-bottom:.5rem;">👤</div>
      <div style="font-weight:700;font-size:1rem;margin-bottom:4px;">Enter a Screening ID</div>
      <div style="font-size:.82rem;color:#65676B;">Paste a candidate screening ID in the sidebar to view their full profile.</div>
    </div>""", unsafe_allow_html=True)
    st.stop()

try:
    resp = requests.get(f"{API}/screenings/candidate/{screening_id}", timeout=10)
    if resp.status_code == 404:
        st.error("Screening not found — check the ID."); st.stop()
    r = resp.json()
except Exception as e:
    st.error(f"API error: {e}"); st.stop()

name    = r.get("full_name") or r.get("original_filename") or "Unknown"
email   = r.get("email") or "—"
phone   = r.get("phone") or "—"
linkedin= r.get("linkedin_url") or "—"
decision= r.get("decision") or "needs_review"
stage   = r.get("ats_stage") or "screening"
ts      = (r.get("screened_at") or "")[:16].replace("T"," ")
score   = r.get("final_score",0)
rel     = r.get("relevance_score",0)
skill   = r.get("skill_match_score",0)
exp     = r.get("experience_score",0)
sem     = r.get("semantic_score",0)
pen     = r.get("penalty_score",0)
pot     = r.get("potential_score",0)
anoms   = r.get("anomaly_count",0)
traj    = r.get("career_trajectory","—")
growth  = r.get("growth_label","—")
reason  = r.get("score_reasoning","")
why_sel = r.get("why_selected","")
why_rej = r.get("why_rejected","")
rationale=r.get("llm_rationale","")
penalties=parse_list(r.get("penalties_applied",[]))
matched = parse_list(r.get("matched_skills",[]))
missing = parse_list(r.get("missing_skills",[]))
strengths=parse_list(r.get("strengths",[]))
gaps    = parse_list(r.get("gaps",[]))
insights=parse_list(r.get("value_add_insights",[]))
transferable=parse_list(r.get("transferable_skills",[]))
parsed_data = r.get("parsed_data") or {}
if isinstance(parsed_data, str):
    try: parsed_data = json.loads(parsed_data)
    except Exception: parsed_data = {}

ini = initials(name)
sc  = score_color(score)

# ── IDENTITY HEADER ──
st.markdown(f"""<div class="fb-card-lg">
  <div style="display:flex;align-items:center;gap:18px;">
    <div style="width:68px;height:68px;border-radius:50%;background:#1877F2;color:white;font-weight:700;font-size:1.4rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;">{ini}</div>
    <div style="flex:1;">
      <div style="font-size:1.6rem;font-weight:700;color:#050505;">{name}</div>
      <div style="font-size:.85rem;color:#65676B;margin-top:4px;">
        📧 {email} &nbsp;·&nbsp; 📞 {phone} &nbsp;·&nbsp; 🔗 {linkedin}
      </div>
      <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;">
        {badge_html(decision)}
        <span class="badge badge-grey">{stage.replace('_',' ').title()}</span>
        {"<span class='badge badge-blue'>↩ Returning</span>" if r.get('is_returning') else ""}
        {f"<span class='badge badge-red'>⚑ {anoms} Flag(s)</span>" if anoms else ""}
      </div>
    </div>
    <div style="text-align:right;flex-shrink:0;">
      <div style="font-size:3rem;font-weight:900;color:{sc};line-height:1;">{score}</div>
      <div style="font-size:.8rem;color:#65676B;">out of 100</div>
      <div style="font-size:.72rem;color:#BCC0C4;margin-top:4px;">{ts}</div>
    </div>
  </div>
</div>""", unsafe_allow_html=True)

# ── SCORE SECTION ──
st.markdown('<div class="sec-label">Score Intelligence</div>', unsafe_allow_html=True)
sc1,sc2,sc3 = st.columns(3, gap="medium")
with sc1:
    st.plotly_chart(gauge(score,"Final Score"), use_container_width=True, config=PLOTLY_CFG)
with sc2:
    st.plotly_chart(radar(rel,skill,exp,sem,pot), use_container_width=True, config=PLOTLY_CFG)
with sc3:
    st.plotly_chart(waterfall(rel,skill,exp,sem,pen,score), use_container_width=True, config=PLOTLY_CFG)

st.markdown(f"""<div class="fb-card">
  {score_bar_html("Relevance Score",   rel,  "· 30%")}
  {score_bar_html("Skill Match Score", skill,"· 25%")}
  {score_bar_html("Experience Score",  exp,  "· 20%")}
  {score_bar_html("Semantic Score",    sem,  "· 25%")}
  {score_bar_html("Potential Score",   pot,  "· bonus")}
  <div style="margin-top:8px;background:#FFEBEE;border-radius:6px;padding:8px 10px;font-size:.78rem;color:#C62828;">
    Penalties applied: <b>-{pen} pts</b>
    {"  ·  " + "  ·  ".join(p["reason"] if isinstance(p,dict) else str(p) for p in penalties[:3]) if penalties else "  ·  None"}
  </div>
  <div style="margin-top:6px;font-family:monospace;font-size:.72rem;color:#BCC0C4;background:#F8F9FA;border-radius:6px;padding:8px 10px;">
    ({rel}×.30) + ({skill}×.25) + ({exp}×.20) + ({sem}×.25) − {pen} = <b>{score}</b> /100
  </div>
</div>""", unsafe_allow_html=True)

# ── AI SUMMARY ──
ai_summary = parsed_data.get("cv_summary","")
if ai_summary:
    st.markdown('<div class="sec-label">AI Summary</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="rationale-box"><div class="rationale-label">🔵 AI-Generated Summary</div>{ai_summary}</div>', unsafe_allow_html=True)

# ── STRENGTHS / GAPS / SKILLS ──
st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="sec-label">Strength vs Gap Analysis</div>', unsafe_allow_html=True)
wc1,wc2 = st.columns(2, gap="medium")
with wc1:
    st.markdown(f'<div class="sg-box sg-box-s"><div class="sg-box-label sg-label-s">✓ Why Selected</div><div style="font-size:.82rem;color:#1B5E20;line-height:1.7;margin-bottom:10px;">{why_sel or "—"}</div>'+"".join(f'<div class="sg-item"><span class="sg-bullet-s">▲</span><span class="sg-text-s">{s}</span></div>' for s in strengths)+'</div>', unsafe_allow_html=True)
with wc2:
    st.markdown(f'<div class="sg-box sg-box-g"><div class="sg-box-label sg-label-g">✕ Why Rejected</div><div style="font-size:.82rem;color:#BF360C;line-height:1.7;margin-bottom:10px;">{why_rej or "—"}</div>'+"".join(f'<div class="sg-item"><span class="sg-bullet-g">▼</span><span class="sg-text-g">{g}</span></div>' for g in gaps)+'</div>', unsafe_allow_html=True)

if matched:
    chips = "".join(f'<span class="chip chip-tech">{s}</span>' for s in matched[:12])
    st.markdown(f'<div class="sec-label" style="margin-top:1rem;">Matched Skills ({len(matched)})</div><div class="chip-wrap">{chips}</div>', unsafe_allow_html=True)
if missing:
    chips = "".join(f'<span class="chip chip-miss">{s}</span>' for s in missing[:10])
    st.markdown(f'<div class="sec-label" style="margin-top:8px;">Missing Skills ({len(missing)})</div><div class="chip-wrap">{chips}</div>', unsafe_allow_html=True)
if transferable:
    tech_s   = [s for s in transferable if any(kw in s.lower() for kw in TECH_KW)]
    domain_s = [s for s in transferable if s not in tech_s]
    tc1,tc2 = st.columns(2, gap="medium")
    with tc1:
        st.markdown('<div class="sec-label" style="margin-top:8px;">Technical Transferable</div>', unsafe_allow_html=True)
        chips = "".join(f'<span class="chip chip-tech">{s}</span>' for s in tech_s) or "<span style='font-size:.8rem;color:#BCC0C4;'>None</span>"
        st.markdown(f'<div class="chip-wrap">{chips}</div>', unsafe_allow_html=True)
    with tc2:
        st.markdown('<div class="sec-label" style="margin-top:8px;">Domain Transferable</div>', unsafe_allow_html=True)
        chips = "".join(f'<span class="chip" style="background:#F3E8FF;color:#6B2FA0;border:1px solid #DDB8FA;">{s}</span>' for s in domain_s) or "<span style='font-size:.8rem;color:#BCC0C4;'>None</span>"
        st.markdown(f'<div class="chip-wrap">{chips}</div>', unsafe_allow_html=True)

# ── POTENTIAL & INSIGHTS ──
st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
st.markdown(f'<div class="sec-label">Career Potential · {traj} · {growth}</div>', unsafe_allow_html=True)
if insights:
    for idx, ins in enumerate(insights, 1):
        st.markdown(f'<div class="insight-item"><div class="insight-num">Insight {idx:02d}</div>{ins}</div>', unsafe_allow_html=True)

# ── AI RATIONALE ──
if rationale:
    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-label">AI Decision Rationale</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="rationale-box"><div class="rationale-label">🔵 Model Reasoning Output</div>{rationale}<div style="margin-top:10px;font-size:.7rem;color:#BCC0C4;font-style:normal;">Generated by LLM · For HR augmentation only</div></div>', unsafe_allow_html=True)

# ── SCORE TRACE ──
if reason:
    st.markdown('<div class="sec-label" style="margin-top:1.2rem;">Full Score Trace</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="score-trace">{reason}</div>', unsafe_allow_html=True)

# ── WORK HISTORY ──
experience = parsed_data.get("experience",[]) or []
if experience:
    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-label">Work History</div>', unsafe_allow_html=True)
    for e in experience[:6]:
        role = e.get("role","—"); company = e.get("company","—")
        start = e.get("start_date",""); end = e.get("end_date","Present")
        desc  = e.get("description","")
        techs = e.get("technologies",[]) or []
        tech_chips = "".join(f'<span class="chip chip-tech" style="font-size:.65rem;padding:2px 8px;">{t}</span>' for t in techs[:6])
        st.markdown(f"""<div class="fb-card" style="margin-bottom:8px;">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;">
            <div>
              <div style="font-weight:700;font-size:.9rem;color:#050505;">{role}</div>
              <div style="font-size:.8rem;color:#65676B;margin-top:2px;">{company}</div>
              {f'<div style="font-size:.75rem;color:#BCC0C4;margin-top:4px;font-style:italic;">{desc}</div>' if desc else ''}
            </div>
            <div style="font-size:.75rem;color:#BCC0C4;flex-shrink:0;margin-left:12px;">{start} — {end}</div>
          </div>
          {f'<div class="chip-wrap" style="margin-top:8px;">{tech_chips}</div>' if tech_chips else ''}
        </div>""", unsafe_allow_html=True)

# ── HR DECISION ──
st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="sec-label">HR Decision</div>', unsafe_allow_html=True)
dm = {"✅ Approve":"hr_approved","📤 Forward to Interview":"forwarded",
      "⏸ Hold":"hr_hold","❌ Reject":"hr_rejected"}
da,db_,dc = st.columns([2,2,1], gap="medium")
with da:
    choice = st.selectbox("Decision", list(dm.keys()), key="prof_dec")
with db_:
    hr_name = st.text_input("HR Officer Name", placeholder="Your full name", key="prof_name")
with dc:
    st.markdown("<br>", unsafe_allow_html=True)
    if st.button("Save Decision", use_container_width=True):
        if not hr_name.strip():
            st.error("Name required")
        else:
            try:
                p = requests.patch(f"{API}/screenings/{screening_id}/decision",
                    data={"decision":dm[choice],"decision_by":hr_name.strip()}, timeout=10)
                if p.status_code == 200:
                    st.success("✅ Decision saved"); time.sleep(1); st.rerun()
                else:
                    st.error(p.json().get("detail","Error"))
            except Exception as ex:
                st.error(str(ex))

# ── EXPORT ──
st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="sec-label">Export Profile</div>', unsafe_allow_html=True)
try:
    from export_utils import generate_excel_report
    import io
    buf = io.BytesIO()
    generate_excel_report([r], buf)
    buf.seek(0)
    st.download_button(
        "⬇️ Download Excel Profile Report",
        data=buf.getvalue(),
        file_name=f"profile_{name.replace(' ','_')}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=False)
except Exception as e:
    st.warning(f"Export unavailable: {e}")
