import streamlit as st
import requests
import os
import sys
from collections import Counter
import plotly.graph_objects as go
sys.path.insert(0, "/app/frontend")
from shared_style import CSS, topnav, sidebar_nav, PLOTLY_CFG, FB_BLUE

st.set_page_config(page_title="Post a Job · TalentScan", page_icon="📋", layout="wide")
st.markdown(CSS, unsafe_allow_html=True)
API = os.getenv("API_URL", "http://api:8000") + "/api/v1"

with st.sidebar:
    sidebar_nav("post")
    st.markdown("""<div style="margin-top:1.5rem;background:#F0F2F5;border-radius:8px;padding:10px 12px;">
      <div class="sec-label">JD Parsing Extracts</div>
      <div style="font-size:.75rem;color:#050505;line-height:1.9;">
        ✓ Required skills<br>✓ Min years of experience<br>✓ Seniority level<br>✓ Domain keywords<br><br>
        <b>These power rule-based scoring</b> — not just embeddings.
      </div>
    </div>""", unsafe_allow_html=True)

st.markdown(topnav("Post a Job · Create a Role"), unsafe_allow_html=True)

fc, sc = st.columns([3, 2], gap="large")

with fc:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Role Details</div>', unsafe_allow_html=True)
    with st.form("post_job"):
        c1, c2 = st.columns(2)
        with c1:
            title = st.text_input("Job Title *",  placeholder="e.g. Senior Data Engineer")
            dept  = st.text_input("Department",   placeholder="e.g. Technology")
        with c2:
            loc   = st.text_input("Location",     placeholder="e.g. Dubai, UAE")
            by    = st.text_input("Your Name *",  placeholder="HR Manager name")
        jd_file = st.file_uploader("Upload Job Description * (PDF or TXT)", type=["txt","pdf"])
        sub = st.form_submit_button("🚀  Post Role & Generate Embeddings", type="primary", use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

    if sub:
        if not all([title, by, jd_file]):
            st.error("All * fields required.")
        else:
            with st.spinner("Parsing JD requirements + generating embeddings…"):
                try:
                    resp = requests.post(
                        f"{API}/jobs/",
                        data={"title":title,"department":dept,"location":loc,"created_by":by},
                        files={"jd_file":(jd_file.name,jd_file.getvalue(),jd_file.type or "text/plain")},
                        timeout=90,
                    )
                    if resp.status_code == 201:
                        job  = resp.json()
                        reqs = job.get("requirements") or {}
                        st.success("✅ Role posted successfully!")
                        st.markdown(f"""<div class="fb-card-blue">
                          <div style="font-size:.7rem;font-weight:700;text-transform:uppercase;color:#1877F2;margin-bottom:6px;">Job Created</div>
                          <div style="font-weight:700;font-size:1rem;color:#050505;">{job.get('title','')}</div>
                          <div style="font-family:monospace;font-size:.78rem;color:#65676B;margin-top:4px;">ID: {job.get('id','')}</div>
                        </div>""", unsafe_allow_html=True)
                        if isinstance(reqs, dict) and reqs.get("required_skills"):
                            chips = "".join(f'<span class="chip chip-tech">{s}</span>' for s in reqs["required_skills"][:12])
                            st.markdown(f"""<div class="fb-card">
                              <div class="sec-label">Parsed JD Requirements</div>
                              <div style="font-size:.8rem;color:#050505;margin-bottom:6px;">
                                <b>{len(reqs['required_skills'])}</b> required skills · Min exp: <b>{reqs.get('min_years',0)} yrs</b> · Seniority: <b>{reqs.get('seniority','mid')}</b>
                              </div>
                              <div class="chip-wrap">{chips}</div>
                            </div>""", unsafe_allow_html=True)
                        st.balloons()
                    else:
                        st.error(resp.json().get("detail", "Error posting job"))
                except Exception as e:
                    st.error(str(e))

with sc:
    try:
        jobs = requests.get(f"{API}/jobs/", timeout=5).json()
        if not isinstance(jobs, list): jobs = []
    except Exception:
        jobs = []

    st.markdown(f"""<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;">
      <div style="background:#FFF;border-radius:8px;border:1px solid #CED0D4;padding:1rem;">
        <div style="font-size:1.8rem;font-weight:700;color:#050505;">{len(jobs)}</div>
        <div style="font-size:.7rem;font-weight:600;text-transform:uppercase;color:#65676B;">Active Roles</div>
      </div>
      <div style="background:#FFF;border-radius:8px;border:1px solid #CED0D4;padding:1rem;">
        <div style="font-size:1.8rem;font-weight:700;color:#1877F2;">AI</div>
        <div style="font-size:.7rem;font-weight:600;text-transform:uppercase;color:#65676B;">Auto JD Parse</div>
      </div>
    </div>""", unsafe_allow_html=True)

    if jobs:
        depts = Counter(j.get("department") or "Other" for j in jobs)
        fig_d = go.Figure(go.Pie(
            labels=list(depts.keys()), values=list(depts.values()), hole=0.5,
            textinfo="label+value", textfont=dict(size=10),
            marker=dict(line=dict(color="white", width=2))))
        fig_d.update_layout(
            title=dict(text="Roles by Department",font=dict(size=11,color="#65676B"),x=0.02),
            height=230, margin=dict(t=40,b=10,l=10,r=10),
            paper_bgcolor="#FFFFFF", showlegend=False, font={"family":"system-ui"})
        st.markdown('<div class="fb-card-lg">', unsafe_allow_html=True)
        st.plotly_chart(fig_d, use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)

        locs = Counter(j.get("location") or "Unknown" for j in jobs)
        fig_l = go.Figure(go.Bar(
            x=list(locs.values()), y=list(locs.keys()), orientation="h",
            marker_color=FB_BLUE, marker_opacity=0.75,
            text=list(locs.values()), textposition="outside",
            hovertemplate="%{y}: %{x}<extra></extra>", showlegend=False))
        fig_l.update_layout(
            title=dict(text="Roles by Location",font=dict(size=11,color="#65676B"),x=0.02),
            height=max(160,len(locs)*35+60), margin=dict(t=40,b=10,l=10,r=40),
            paper_bgcolor="#FFFFFF", plot_bgcolor="#FFFFFF",
            xaxis=dict(visible=False), yaxis=dict(tickfont=dict(size=10,color="#050505")),
            font={"family":"system-ui"})
        st.markdown('<div class="fb-card-lg">', unsafe_allow_html=True)
        st.plotly_chart(fig_l, use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)

st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="sec-label">Active Postings</div>', unsafe_allow_html=True)
for j in (jobs or []):
    reqs = j.get("requirements") or {}
    req_skills = reqs.get("required_skills",[]) if isinstance(reqs,dict) else []
    with st.expander(f"📋  {j['title']}  ·  {j.get('department','—')}  ·  {j.get('location','—')}"):
        c1,c2 = st.columns([3,1])
        with c1:
            st.markdown(f"""<div style="font-size:.8rem;color:#65676B;line-height:2.0;">
              <b>Department:</b> {j.get('department','—')}<br>
              <b>Location:</b> {j.get('location','—')}<br>
              <b>Created:</b> {(j.get('created_at') or '')[:10]}<br>
              <b>Min years:</b> {reqs.get('min_years',0) if isinstance(reqs,dict) else '—'} ·
              <b>Seniority:</b> {reqs.get('seniority','mid') if isinstance(reqs,dict) else '—'}
            </div>""", unsafe_allow_html=True)
            if req_skills:
                chips = "".join(f'<span class="chip chip-tech">{s}</span>' for s in req_skills[:10])
                st.markdown(f'<div class="sec-label" style="margin-top:8px;">Required Skills</div><div class="chip-wrap">{chips}</div>', unsafe_allow_html=True)
        with c2:
            st.markdown('<div class="sec-label">Job ID</div>', unsafe_allow_html=True)
            st.code(j["id"], language=None)
