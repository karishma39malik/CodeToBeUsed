import streamlit as st
import requests
import os
import sys
import plotly.graph_objects as go
sys.path.insert(0, "/app/frontend")
from shared_style import CSS, topnav, sidebar_nav, PLOTLY_CFG, FB_BLUE, FB_GREEN, FB_ORANGE, FB_RED

st.set_page_config(page_title="Upload CVs · TalentScan", page_icon="📤", layout="wide")
st.markdown(CSS, unsafe_allow_html=True)
API = os.getenv("API_URL", "http://api:8000") + "/api/v1"

with st.sidebar:
    sidebar_nav("upload")
    st.markdown("""<div style="margin-top:1.5rem;background:#F0F2F5;border-radius:8px;padding:10px 12px;">
      <div class="sec-label">Pipeline Steps</div>
      <div style="font-size:.75rem;color:#050505;line-height:2.0;">
        1️⃣ Ingestion Agent<br>2️⃣ Matching + Scoring<br>3️⃣ Potential Agent<br>4️⃣ Validation Agent<br><br>
        <b>Target:</b> &lt;90s per CV (CPU)<br>
        <b>Parallel:</b> asyncio.gather()
      </div>
    </div>""", unsafe_allow_html=True)

st.markdown(topnav("Upload CVs · Start Screening"), unsafe_allow_html=True)

try:
    jobs = requests.get(f"{API}/jobs/", timeout=5).json()
    if not isinstance(jobs, list): jobs = []
    job_options = {j["title"]: j["id"] for j in jobs}
except Exception as e:
    st.error(f"Cannot reach API: {e}"); st.stop()

if not job_options:
    st.warning("No active roles. Post a job first."); st.stop()

uc, pc = st.columns([3, 2], gap="large")

with uc:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Upload Configuration</div>', unsafe_allow_html=True)
    selected = st.selectbox("Select Role", list(job_options.keys()))
    job_id   = job_options[selected]
    uploader = st.text_input("Your Name", placeholder="HR Officer full name")
    cv_files = st.file_uploader("Upload CVs (PDF, DOCX, TXT)", type=["pdf","docx","txt"],
                                accept_multiple_files=True)
    if cv_files:
        st.markdown(f'<div style="font-size:.78rem;color:#65676B;margin:8px 0;">{len(cv_files)} file(s) selected</div>', unsafe_allow_html=True)
        for f in cv_files[:5]:
            sz = len(f.getvalue())/1024
            ext = f.name.split(".")[-1].upper()
            ec = {"PDF":"#FA3E3E","DOCX":"#1877F2","TXT":"#42B72A"}.get(ext,"#65676B")
            st.markdown(f'<div style="display:flex;align-items:center;gap:10px;padding:6px 10px;background:#F0F2F5;border-radius:6px;margin:4px 0;"><span style="background:{ec};color:white;font-size:.65rem;font-weight:700;padding:2px 6px;border-radius:3px;">{ext}</span><span style="font-size:.8rem;color:#050505;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{f.name}</span><span style="font-size:.72rem;color:#BCC0C4;">{sz:.0f} KB</span></div>', unsafe_allow_html=True)
        if len(cv_files) > 5:
            st.markdown(f'<div style="font-size:.72rem;color:#BCC0C4;padding:4px 10px;">+ {len(cv_files)-5} more files</div>', unsafe_allow_html=True)
    start = st.button("🚀  Start Screening Pipeline", use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

    if start:
        if not cv_files:
            st.error("Upload at least one CV.")
        elif not uploader.strip():
            st.error("Enter your name.")
        else:
            prog = st.progress(0, text="Preparing upload…")
            try:
                files = [("cv_files",(f.name,f.getvalue(),f.type or "application/octet-stream")) for f in cv_files]
                prog.progress(30, text="Sending to API…")
                resp = requests.post(f"{API}/screenings/upload",
                    data={"job_id":job_id,"uploaded_by":uploader.strip()},
                    files=files, timeout=180)
                prog.progress(100, text="Queued!")
                if resp.status_code != 200:
                    st.error(f"Upload failed ({resp.status_code})")
                    try: st.json(resp.json())
                    except: st.text(resp.text)
                else:
                    r = resp.json()
                    total_r = r.get("total_received",0)
                    queued  = r.get("queued",0)
                    failed  = r.get("failed",0)
                    st.success(f"✅ {queued} CV(s) queued for AI pipeline!")
                    c1,c2,c3 = st.columns(3)
                    c1.metric("Received", total_r); c2.metric("Queued", queued); c3.metric("Failed", failed)
                    if r.get("errors"):
                        with st.expander(f"⚠️ {len(r['errors'])} failed"):
                            for e in r["errors"]:
                                st.markdown(f'<div style="font-size:.8rem;color:#FA3E3E;">• {e.get("filename","?")} — {e.get("error","")}</div>', unsafe_allow_html=True)
                    est = queued * 90
                    st.info(f"⏳ Pipeline running in background. Estimated: ~{est//60}m {est%60}s. Check Screening Results when complete.")
            except Exception as e:
                st.error(str(e)); prog.empty()

with pc:
    # Pipeline architecture chart
    st.markdown('<div class="fb-card-lg"><div class="sec-label">AI Pipeline Flow</div>', unsafe_allow_html=True)
    agents = ["Ingest","Match+Score","Potential","Validate","Done"]
    colors = [FB_BLUE,"#6366F1",FB_ORANGE,"#8B5CF6",FB_GREEN]
    fig_pipe = go.Figure()
    for i,(a,c) in enumerate(zip(agents,colors)):
        fig_pipe.add_trace(go.Scatter(x=[i],y=[0],mode="markers+text",
            marker=dict(size=46,color=c,line=dict(color="white",width=3)),
            text=[str(i+1)],textfont=dict(size=13,color="white"),
            textposition="middle center",showlegend=False,
            hovertemplate=f"{a}<extra></extra>"))
        fig_pipe.add_annotation(x=i,y=-0.38,text=a,showarrow=False,font=dict(size=9,color="#65676B"))
        if i < len(agents)-1:
            fig_pipe.add_annotation(x=i+0.55,y=0,text="→",showarrow=False,font=dict(size=18,color="#CED0D4"))
    fig_pipe.update_layout(height=160,margin=dict(t=20,b=44,l=20,r=20),
        paper_bgcolor="#FFFFFF",plot_bgcolor="#FFFFFF",
        xaxis=dict(visible=False,range=[-0.5,4.5]),yaxis=dict(visible=False,range=[-0.7,0.5]),
        font={"family":"system-ui"})
    st.plotly_chart(fig_pipe, use_container_width=True, config=PLOTLY_CFG)
    st.markdown("</div>", unsafe_allow_html=True)

    # Scoring formula card
    n = len(cv_files) if cv_files else 0
    st.markdown(f"""<div class="fb-card">
      <div class="sec-label">Scoring Formula</div>
      <div class="score-trace">Final (0-100) =
  Relevance    × 30%  → embedding similarity
  Skill Match  × 25%  → rule-based overlap
  Experience   × 20%  → years vs requirement
  Semantic     × 25%  → LLM reasoning
  ─────────────────────
  − Penalties  (max 60)
    Missing critical skill: -20 each
    Exp gap &lt;40%: -15
    Domain mismatch: -10
    Keyword stuffing: -8
    Generic CV: -12</div>
    </div>""", unsafe_allow_html=True)

    st.markdown(f"""<div class="fb-card">
      <div class="sec-label">Estimate</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
        <div style="background:#FFF;border-radius:6px;border:1px solid #CED0D4;padding:.7rem;">
          <div style="font-size:1.4rem;font-weight:700;color:#050505;">{n}</div>
          <div style="font-size:.65rem;font-weight:600;text-transform:uppercase;color:#65676B;">Files</div>
        </div>
        <div style="background:#FFF;border-radius:6px;border:1px solid #CED0D4;padding:.7rem;">
          <div style="font-size:1.4rem;font-weight:700;color:#1877F2;">~{n*90//60}m</div>
          <div style="font-size:.65rem;font-weight:600;text-transform:uppercase;color:#65676B;">Est. Time</div>
        </div>
      </div>
      <div style="font-size:.72rem;color:#BCC0C4;margin-top:8px;">~90s per CV on CPU · Llama 3.1 8B</div>
    </div>""", unsafe_allow_html=True)

    try:
        pipe = requests.get(f"{API}/jobs/{job_id}/pipeline", timeout=5).json()
        st.markdown(f"""<div class="fb-card">
          <div class="sec-label">{selected} — Current Status</div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;">
            <div style="text-align:center;padding:.6rem;background:#F0F2F5;border-radius:6px;">
              <div style="font-size:1.2rem;font-weight:700;color:#050505;">{pipe.get('total_screened',0)}</div>
              <div style="font-size:.65rem;color:#65676B;text-transform:uppercase;">Screened</div>
            </div>
            <div style="text-align:center;padding:.6rem;background:#F0F2F5;border-radius:6px;">
              <div style="font-size:1.2rem;font-weight:700;color:#F5A623;">{pipe.get('pending_review',0)}</div>
              <div style="font-size:.65rem;color:#65676B;text-transform:uppercase;">Pending</div>
            </div>
            <div style="text-align:center;padding:.6rem;background:#F0F2F5;border-radius:6px;">
              <div style="font-size:1.2rem;font-weight:700;color:#1877F2;">{pipe.get('avg_score') or '—'}</div>
              <div style="font-size:.65rem;color:#65676B;text-transform:uppercase;">Avg Score</div>
            </div>
          </div>
        </div>""", unsafe_allow_html=True)
    except Exception:
        pass
