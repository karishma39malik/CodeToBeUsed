import streamlit as st
import requests
import os
import sys
sys.path.insert(0, "/app/frontend")
from shared_style import (CSS, topnav, sidebar_nav, score_color, donut, score_histogram,
    funnel_chart, pool_bar, skills_heatmap, rejection_reasons_chart, latency_chart,
    parse_list, PLOTLY_CFG, FB_BLUE, FB_GREEN, FB_ORANGE, FB_RED)
import plotly.graph_objects as go
import plotly.express as px

st.set_page_config(page_title="Analytics · TalentScan", page_icon="📈", layout="wide")
st.markdown(CSS, unsafe_allow_html=True)
API = os.getenv("API_URL","http://api:8000") + "/api/v1"

with st.sidebar:
    sidebar_nav("analytics")
    st.markdown('<div style="height:1px;background:#E4E6EB;margin:1rem 0;"></div>', unsafe_allow_html=True)
    try:
        jobs = requests.get(f"{API}/jobs/", timeout=5).json()
        if not isinstance(jobs, list): jobs = []
        job_map = {"All Roles": None} | {j["title"]: j["id"] for j in jobs}
    except Exception:
        job_map = {"All Roles": None}
    sel = st.selectbox("Role", list(job_map.keys()))
    sel_jid = job_map[sel]
    if st.button("↻ Refresh", use_container_width=True): st.rerun()

st.markdown(topnav("Analytics · Hiring Intelligence"), unsafe_allow_html=True)

# Fetch data
try:
    overview = requests.get(f"{API}/analytics/overview", timeout=8).json()
except Exception:
    overview = {}

all_s = []
try:
    if sel_jid:
        all_s = requests.get(f"{API}/screenings/results/{sel_jid}", params={"min_score":0,"limit":500}, timeout=10).json()
    else:
        for j in (jobs or []):
            r = requests.get(f"{API}/screenings/results/{j['id']}", params={"min_score":0,"limit":200}, timeout=8).json()
            if isinstance(r, list):
                for x in r: x["_job_title"] = j["title"]
                all_s.extend(r)
    if not isinstance(all_s, list): all_s = []
except Exception:
    all_s = []

total   = overview.get("total_screenings",0) or len(all_s)
shortl  = overview.get("shortlisted",0) or sum(1 for r in all_s if r.get("final_score",0)>=70)
intv    = overview.get("in_interview",0)
rej     = overview.get("rejected",0) or sum(1 for r in all_s if r.get("final_score",0)<50)
avg_s   = overview.get("avg_score",0) or (int(sum(r.get("final_score",0) for r in all_s)/len(all_s)) if all_s else 0)
avg_ms  = int(overview.get("avg_pipeline_ms",0) or 0)
high    = overview.get("high_scores",0) or sum(1 for r in all_s if r.get("final_score",0)>=70)
low     = overview.get("low_scores",0) or sum(1 for r in all_s if r.get("final_score",0)<50)

m1,m2,m3,m4,m5,m6 = st.columns(6)
m1.metric("Total Screened",   total)
m2.metric("Shortlisted",      shortl)
m3.metric("In Interview",     intv)
m4.metric("Rejected",         rej)
m5.metric("Avg Score",        f"{avg_s}/100")
m6.metric("Avg Pipeline",     f"{avg_ms//1000}s" if avg_ms else "—")

st.markdown('<div class="divider"></div>', unsafe_allow_html=True)

# Row 1 — distribution + funnel + donut
if all_s:
    r1c1, r1c2, r1c3 = st.columns(3, gap="medium")
    with r1c1:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Score Distribution</div>', unsafe_allow_html=True)
        st.plotly_chart(score_histogram(all_s), use_container_width=True, config=PLOTLY_CFG)
        st.markdown("</div>", unsafe_allow_html=True)
    with r1c2:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Hiring Funnel</div>', unsafe_allow_html=True)
        st.plotly_chart(funnel_chart(total,shortl,intv), use_container_width=True, config=PLOTLY_CFG)
        st.markdown("</div>", unsafe_allow_html=True)
    with r1c3:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Decision Breakdown</div>', unsafe_allow_html=True)
        st.plotly_chart(donut(all_s), use_container_width=True, config=PLOTLY_CFG)
        st.markdown("</div>", unsafe_allow_html=True)

    # Row 2 — heatmap + rejection reasons
    r2c1, r2c2 = st.columns([3,2], gap="medium")
    with r2c1:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Top Matching Skills</div>', unsafe_allow_html=True)
        fig = skills_heatmap(all_s)
        if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
        else: st.markdown('<div style="font-size:.8rem;color:#BCC0C4;padding:1rem 0;">No skill data yet</div>', unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)
    with r2c2:
        rejected_r = [r for r in all_s if r.get("final_score",0) < 50]
        st.markdown(f'<div class="fb-card-lg"><div class="sec-label">Rejection Reasons ({len(rejected_r)} rejected)</div>', unsafe_allow_html=True)
        fig = rejection_reasons_chart(rejected_r)
        if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
        else: st.markdown('<div style="font-size:.8rem;color:#BCC0C4;padding:1rem 0;">No rejection data yet</div>', unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

    # Row 3 — full candidate ranking
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Full Candidate Ranking</div>', unsafe_allow_html=True)
    top30 = sorted(all_s, key=lambda x: x.get("final_score",0), reverse=True)[:30]
    fig = pool_bar(top30)
    if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
    st.markdown("</div>", unsafe_allow_html=True)

    # Row 4 — score component box plot
    if len(all_s) >= 3:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Score Components Distribution</div>', unsafe_allow_html=True)
        
        components = {
            "Relevance":  [r.get("relevance_score",0) for r in all_s],
            "Skill Match":[r.get("skill_match_score",0) for r in all_s],
            "Experience": [r.get("experience_score",0) for r in all_s],
            "Semantic":   [r.get("semantic_score",0) for r in all_s],
            "Potential":  [r.get("potential_score",0) for r in all_s],
        }
        colors = [FB_BLUE,"#6366F1",FB_GREEN,FB_ORANGE,"#8B5CF6"]
        fig_box = go.Figure()
        for (name,vals),c in zip(components.items(),colors):
            fig_box.add_trace(go.Box(y=vals,name=name,marker_color=c,
                boxpoints="outliers",jitter=0.3,pointpos=-1.8))
        fig_box.update_layout(height=300,margin=dict(t=20,b=10,l=10,r=10),
            paper_bgcolor="#FFFFFF",plot_bgcolor="#FFFFFF",
            yaxis=dict(range=[0,105],gridcolor="#F0F2F5",title="Score /100"),
            xaxis=dict(showgrid=False),font={"family":"system-ui"},showlegend=False)
        st.plotly_chart(fig_box, use_container_width=True, config=PLOTLY_CFG)
        st.markdown("</div>", unsafe_allow_html=True)

# Row 5 — processing latency
try:
    perf = requests.get(f"{API}/analytics/performance", timeout=5).json()
    if perf:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Pipeline Processing Time</div>', unsafe_allow_html=True)
        fig = latency_chart(perf)
        if fig:
            st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
        st.markdown("</div>", unsafe_allow_html=True)
except Exception:
    pass

if not all_s:
    st.markdown('<div class="fb-card" style="text-align:center;padding:3rem;"><div style="font-size:2rem;margin-bottom:.5rem;">📈</div><div style="font-weight:700;">No data yet</div><div style="font-size:.82rem;color:#65676B;margin-top:4px;">Upload CVs and run the pipeline to see analytics here.</div></div>', unsafe_allow_html=True)

# Negative scenarios summary
st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="sec-label">Negative Scenario Detection</div>', unsafe_allow_html=True)
if all_s:
    keyword_stuffed = [r for r in all_s if r.get("penalty_score",0) >= 8 and r.get("final_score",0) < 50]
    mismatched      = [r for r in all_s if r.get("final_score",0) < 30]
    borderline      = [r for r in all_s if 45 <= r.get("final_score",0) <= 55]
    n1,n2,n3 = st.columns(3)
    n1.metric("Keyword Stuffed / Penalized", len(keyword_stuffed), help="Score < 50 with high penalties")
    n2.metric("Severe Mismatch (< 30/100)",  len(mismatched))
    n3.metric("Borderline (45–55/100)",       len(borderline), help="Require HR judgment")
