"""TalentScan ATS v2 — Shared design system (Facebook/Meta aesthetic)"""
import plotly.graph_objects as go
from collections import Counter
import json

FB_BLUE   = "#1877F2"
FB_GREEN  = "#42B72A"
FB_ORANGE = "#F5A623"
FB_RED    = "#FA3E3E"
FB_GREY   = "#BCC0C4"
PLOT_BG   = "#FFFFFF"
PLOTLY_CFG = {"displayModeBar": False}

CSS = """
<style>
html,body,[class*="css"]{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;font-size:15px;}
.stApp{background:#F0F2F5!important;}
.block-container{padding:0 1.5rem 3rem!important;max-width:1300px;}
header,[data-testid="stHeader"]{background:#FFFFFF!important;border-bottom:1px solid #CED0D4!important;}
section[data-testid="stSidebar"]{background:#FFFFFF!important;border-right:1px solid #CED0D4!important;}
h1,h2,h3,h4{color:#050505!important;}
p,li{color:#050505!important;}
label{color:#65676B!important;font-size:.8rem!important;}

.fb-nav{background:#1877F2;padding:0 1.5rem;height:56px;display:flex;align-items:center;justify-content:space-between;margin:-0.1rem -1.5rem 1.5rem;}
.fb-nav-logo{font-size:1.5rem;font-weight:900;color:#FFF;letter-spacing:-.5px;}
.fb-nav-title{font-size:.85rem;font-weight:600;color:rgba(255,255,255,.85);background:rgba(255,255,255,.15);padding:6px 14px;border-radius:20px;}
.fb-nav-right{font-size:.78rem;color:rgba(255,255,255,.6);}

.fb-card{background:#FFF;border-radius:8px;border:1px solid #CED0D4;padding:1.2rem 1.4rem;margin-bottom:12px;box-shadow:0 1px 2px rgba(0,0,0,.06);}
.fb-card-lg{background:#FFF;border-radius:8px;border:1px solid #CED0D4;padding:1.5rem;margin-bottom:16px;box-shadow:0 1px 2px rgba(0,0,0,.06);}
.fb-card-blue{background:#E7F0FF;border-radius:8px;border:1px solid #BBD3FB;padding:1.2rem 1.4rem;margin-bottom:12px;}

.sec-label{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#65676B;margin-bottom:10px;}
.divider{height:1px;background:#E4E6EB;margin:1.2rem 0;}

.badge{display:inline-flex;align-items:center;gap:5px;padding:4px 12px;border-radius:20px;font-size:.78rem;font-weight:600;}
.badge-green{background:#E7F3E8;color:#1A6B1E;}
.badge-blue{background:#E7F0FF;color:#1877F2;}
.badge-orange{background:#FFF3E0;color:#E65100;}
.badge-red{background:#FFEBEE;color:#C62828;}
.badge-grey{background:#F0F2F5;color:#65676B;}
.badge-dot{width:7px;height:7px;border-radius:50%;}

/* Score bars */
.sbar-row{margin:10px 0;}
.sbar-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:5px;}
.sbar-name{font-size:.8rem;font-weight:600;color:#050505;}
.sbar-weight{font-size:.7rem;color:#BCC0C4;}
.sbar-val{font-size:.85rem;font-weight:700;}
.sbar-track{height:8px;background:#F0F2F5;border-radius:4px;overflow:hidden;}
.sbar-fill{height:100%;border-radius:4px;}
.fill-blue{background:linear-gradient(90deg,#1877F2,#42A5F5);}
.fill-green{background:linear-gradient(90deg,#42B72A,#66BB6A);}
.fill-orange{background:linear-gradient(90deg,#F5A623,#FFB74D);}
.fill-red{background:linear-gradient(90deg,#FA3E3E,#EF5350);}

/* Kanban */
.kanban-col{background:#F0F2F5;border-radius:8px;padding:10px;min-height:200px;}
.kanban-header{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#65676B;margin-bottom:10px;padding:4px 0;border-bottom:2px solid #CED0D4;}
.kanban-card{background:#FFF;border-radius:6px;border:1px solid #CED0D4;padding:10px 12px;margin-bottom:8px;box-shadow:0 1px 2px rgba(0,0,0,.06);}
.kanban-name{font-weight:600;font-size:.85rem;color:#050505;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.kanban-score{font-size:.75rem;font-weight:700;}
.kanban-meta{font-size:.7rem;color:#65676B;margin-top:2px;}

/* Strengths/Gaps */
.sg-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
.sg-box{border-radius:8px;padding:1rem;}
.sg-box-s{background:#E7F3E8;border:1px solid #B5DFBB;}
.sg-box-g{background:#FFF3E0;border:1px solid #FFCC80;}
.sg-box-label{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px;}
.sg-label-s{color:#1A6B1E;}
.sg-label-g{color:#E65100;}
.sg-item{display:flex;gap:8px;align-items:flex-start;padding:5px 0;font-size:.8rem;line-height:1.5;border-bottom:1px solid rgba(0,0,0,.05);}
.sg-item:last-child{border-bottom:none;}
.sg-bullet-s{color:#42B72A;margin-top:3px;font-size:.6rem;flex-shrink:0;}
.sg-bullet-g{color:#F5A623;margin-top:3px;font-size:.6rem;flex-shrink:0;}
.sg-text-s{color:#1B5E20;}
.sg-text-g{color:#BF360C;}

.chip-wrap{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;}
.chip{padding:4px 12px;border-radius:20px;font-size:.75rem;font-weight:600;}
.chip-tech{background:#E7F0FF;color:#1877F2;border:1px solid #BBD3FB;}
.chip-domain{background:#F3E8FF;color:#6B2FA0;border:1px solid #DDB8FA;}
.chip-miss{background:#FFEBEE;color:#C62828;border:1px solid #FFCDD2;}

.insight-item{background:#F0F2F5;border-left:3px solid #1877F2;border-radius:0 6px 6px 0;padding:10px 14px;margin-bottom:8px;font-size:.82rem;color:#050505;line-height:1.7;}
.insight-num{font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#1877F2;margin-bottom:3px;}

.rationale-box{background:#F0F2F5;border-radius:8px;border:1px solid #CED0D4;padding:1.2rem 1.4rem;font-size:.85rem;color:#050505;line-height:1.85;font-style:italic;}
.rationale-label{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#1877F2;margin-bottom:8px;}

.score-trace{background:#F8F9FA;border:1px solid #E4E6EB;border-radius:6px;padding:10px 14px;font-family:monospace;font-size:.75rem;color:#050505;line-height:1.8;white-space:pre-wrap;}

.signal-strip{display:grid;grid-template-columns:repeat(4,1fr);gap:1px;background:#CED0D4;border-radius:8px;overflow:hidden;}
.signal-cell{background:#FFF;padding:14px 16px;}
.signal-val{font-size:1.5rem;font-weight:700;color:#050505;line-height:1;}
.signal-lbl{font-size:.7rem;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:#65676B;margin-top:3px;}

.stButton>button{background:#1877F2!important;color:#FFF!important;border:none!important;border-radius:6px!important;font-weight:700!important;font-size:.82rem!important;padding:8px 18px!important;}
.stButton>button:hover{background:#166FE5!important;}
.stSelectbox>div>div{background:#FFF!important;border-color:#CED0D4!important;border-radius:6px!important;color:#050505!important;}
.stTextInput>div>div{background:#FFF!important;border-color:#CED0D4!important;border-radius:6px!important;}
.stTextInput input,.stTextArea textarea{color:#050505!important;}
.stTextArea>div>div{background:#FFF!important;border-color:#CED0D4!important;border-radius:6px!important;}
.stMultiSelect>div{background:#FFF!important;border-color:#CED0D4!important;border-radius:6px!important;}
.stFileUploader{background:#FFF!important;border-color:#CED0D4!important;border-radius:6px!important;}
[data-testid="stMetricValue"]{color:#050505!important;font-weight:700!important;}
[data-testid="stMetricLabel"]{color:#65676B!important;font-size:.72rem!important;font-weight:600!important;}
div[data-testid="stExpander"]{background:#FFF!important;border:1px solid #CED0D4!important;border-radius:8px!important;margin-bottom:8px!important;}
div[data-testid="stExpander"] summary{font-weight:600!important;color:#050505!important;}
[data-testid="stFormSubmitButton"]>button{width:100%!important;padding:.7rem!important;font-size:1rem!important;}
</style>"""


def topnav(title, subtitle="AI Screening Intelligence"):
    return f"""<div class="fb-nav">
  <div class="fb-nav-logo">TalentScan</div>
  <div class="fb-nav-title">{title}</div>
  <div class="fb-nav-right">{subtitle}</div>
</div>"""


def sidebar_nav(active="dashboard"):
    import streamlit as st
    st.markdown("""<div style="padding:.5rem 0 1.2rem;">
      <div style="font-size:1.4rem;font-weight:900;color:#1877F2;letter-spacing:-.5px;">TalentScan</div>
      <div style="font-size:.72rem;color:#65676B;margin-top:2px;font-weight:600;">ATS v2 · Explainable AI</div>
    </div><div style="height:1px;background:#E4E6EB;margin-bottom:1rem;"></div>""", unsafe_allow_html=True)
    st.page_link("app.py",                        label="🏠  Dashboard")
    st.page_link("pages/01_Post_a_Job.py",        label="📋  Post a Job")
    st.page_link("pages/02_Upload_CVs.py",        label="📤  Upload CVs")
    st.page_link("pages/03_Screening_Results.py", label="📊  Screening Results")
    st.page_link("pages/04_Analytics.py",         label="📈  Analytics")
    st.page_link("pages/05_Candidate_Profile.py", label="👤  Candidate Profile")


def parse_list(val):
    if isinstance(val, list): return val
    if not val: return []
    try:
        r = json.loads(val)
        return r if isinstance(r, list) else [str(r)]
    except Exception:
        return [str(val)] if val else []


def score_color(s):
    return FB_GREEN if s >= 70 else (FB_ORANGE if s >= 50 else FB_RED)


def badge_html(decision):
    d = (decision or "").lower()
    label = (decision or "").replace("_", " ").title()
    if "shortlisted" in d or "approved" in d: cls, dot = "badge-green",  "#42B72A"
    elif "rejected" in d:                      cls, dot = "badge-red",    "#FA3E3E"
    elif "hold" in d:                          cls, dot = "badge-grey",   "#BCC0C4"
    elif "forward" in d:                       cls, dot = "badge-blue",   "#1877F2"
    else:                                      cls, dot = "badge-orange", "#F5A623"
    return f'<span class="badge {cls}"><span class="badge-dot" style="background:{dot};"></span>{label}</span>'


def score_bar_html(name, value, weight, max_val=100):
    pct  = min(100, max(0, int(value)))
    col  = score_color(pct)
    fc   = "fill-green" if pct >= 70 else ("fill-orange" if pct >= 50 else "fill-red")
    return f"""<div class="sbar-row">
      <div class="sbar-header">
        <span class="sbar-name">{name} <span class="sbar-weight">{weight}</span></span>
        <span class="sbar-val" style="color:{col};">{pct}/100</span>
      </div>
      <div class="sbar-track"><div class="sbar-fill {fc}" style="width:{pct}%;"></div></div>
    </div>"""


def initials(name):
    parts = (name or "?").split()
    return "".join(p[0] for p in parts[:2]).upper()


TECH_KW = {"python","sql","spark","cloud","azure","aws","gcp","kafka","airflow","api",
           "ml","ai","etl","pipeline","databricks","tableau","data","docker","java","scala"}


# ── CHARTS ──────────────────────────────────────────────────────────────

def gauge(value, title="Score"):
    pct = min(100, max(0, value))
    col = score_color(pct)
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=pct,
        number={"font":{"size":40,"color":"#050505"},"suffix":"/100"},
        title={"text":title,"font":{"size":11,"color":"#65676B"}},
        gauge={
            "axis":{"range":[0,100],"tickvals":[0,25,50,75,100],
                    "tickfont":{"size":9,"color":"#BCC0C4"},"tickwidth":0},
            "bar":{"color":col,"thickness":0.25},
            "bgcolor":"#F0F2F5","borderwidth":0,
            "steps":[{"range":[0,50],"color":"#FFEBEE"},
                     {"range":[50,70],"color":"#FFF3E0"},
                     {"range":[70,100],"color":"#E7F3E8"}],
            "threshold":{"line":{"color":col,"width":3},"thickness":0.8,"value":pct}
        }
    ))
    fig.update_layout(height=200,margin=dict(t=30,b=10,l=20,r=20),
                      paper_bgcolor=PLOT_BG,font={"family":"system-ui"})
    return fig


def score_breakdown_bar(scores: dict):
    """Horizontal bar for score component breakdown."""
    labels = list(scores.keys())
    values = list(scores.values())
    colors = [score_color(v) for v in values]
    fig = go.Figure(go.Bar(
        x=values, y=labels, orientation="h",
        marker_color=colors,
        text=[f"{v}/100" for v in values], textposition="outside",
        textfont=dict(size=11,color="#050505"),
        hovertemplate="%{y}: %{x}/100<extra></extra>", showlegend=False
    ))
    fig.update_layout(height=240,margin=dict(t=10,b=10,l=120,r=60),
                      paper_bgcolor=PLOT_BG,plot_bgcolor=PLOT_BG,
                      xaxis=dict(range=[0,120],showgrid=False,visible=False),
                      yaxis=dict(tickfont=dict(size=11,color="#050505")),
                      font={"family":"system-ui"})
    return fig


def radar(rel, skill, exp, sem, pot):
    cats  = ["Relevance","Skill Match","Experience","Semantic","Potential"]
    vals  = [rel, skill, exp, sem, pot]
    fig   = go.Figure(go.Scatterpolar(
        r=vals+[vals[0]], theta=cats+[cats[0]],
        fill="toself", fillcolor="rgba(24,119,242,0.1)",
        line=dict(color=FB_BLUE,width=2),
        marker=dict(color=FB_BLUE,size=5),
        hovertemplate="%{theta}: %{r}<extra></extra>"
    ))
    fig.update_layout(
        polar=dict(bgcolor="#F0F2F5",
                   radialaxis=dict(visible=True,range=[0,100],
                                   tickvals=[0,25,50,75,100],
                                   tickfont=dict(size=8,color="#BCC0C4"),
                                   gridcolor="#E4E6EB"),
                   angularaxis=dict(tickfont=dict(size=10,color="#050505"),
                                    gridcolor="#E4E6EB")),
        showlegend=False,height=250,margin=dict(t=20,b=20,l=40,r=40),
        paper_bgcolor=PLOT_BG,font={"family":"system-ui"}
    )
    return fig


def waterfall(rel, skill, exp, sem, penalty, final):
    colors = [FB_BLUE,FB_BLUE,FB_BLUE,FB_BLUE,FB_RED,score_color(final)]
    fig = go.Figure(go.Waterfall(
        orientation="v",
        measure=["relative","relative","relative","relative","relative","total"],
        x=["Relevance<br>×30%","Skill<br>×25%","Experience<br>×20%",
           "Semantic<br>×25%","Penalties","Final"],
        y=[rel*.3, skill*.25, exp*.2, sem*.25, -penalty, 0],
        text=[f"{rel*.3:.0f}",f"{skill*.25:.0f}",f"{exp*.2:.0f}",
              f"{sem*.25:.0f}",f"-{penalty}",f"{final}"],
        textposition="outside",
        textfont={"size":10,"color":"#050505"},
        increasing={"marker":{"color":FB_BLUE}},
        decreasing={"marker":{"color":FB_RED}},
        totals={"marker":{"color":score_color(final)}},
        connector={"line":{"color":"#E4E6EB","width":1}},
        hovertemplate="%{x}: %{y:.1f}<extra></extra>"
    ))
    fig.update_layout(height=280,margin=dict(t=30,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG,plot_bgcolor=PLOT_BG,
                      xaxis=dict(showgrid=False,tickfont=dict(size=10,color="#050505")),
                      yaxis=dict(range=[-15,115],gridcolor="#F0F2F5",
                                 tickfont=dict(size=9,color="#65676B")),
                      showlegend=False,font={"family":"system-ui"})
    return fig


def pool_bar(results, name_field="full_name"):
    if len(results) < 1: return None
    names  = [(r.get(name_field) or f"#{i+1}")[:18] for i,r in enumerate(results)]
    scores = [r.get("final_score",0) for r in results]
    colors = [score_color(s) for s in scores]
    fig = go.Figure(go.Bar(
        x=names,y=scores,marker_color=colors,
        text=[f"{s}" for s in scores],textposition="outside",
        textfont=dict(size=10,color="#050505"),
        hovertemplate="%{x}: %{y}<extra></extra>",showlegend=False
    ))
    fig.add_hline(y=70,line_dash="dot",line_color=FB_GREEN,
                  annotation_text="Shortlist (70)",
                  annotation_font_size=9,annotation_font_color=FB_GREEN)
    fig.add_hline(y=50,line_dash="dot",line_color=FB_ORANGE,
                  annotation_text="Review (50)",
                  annotation_font_size=9,annotation_font_color=FB_ORANGE)
    fig.update_layout(height=300,margin=dict(t=30,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG,plot_bgcolor=PLOT_BG,
                      xaxis=dict(tickfont=dict(size=10,color="#050505"),showgrid=False),
                      yaxis=dict(range=[0,115],gridcolor="#F0F2F5",
                                 tickfont=dict(size=9,color="#65676B"),title="Score /100"),
                      bargap=0.35,font={"family":"system-ui"})
    return fig


def donut(results, field="decision"):
    counts = Counter(r.get(field,"unknown") for r in results)
    labels = list(counts.keys()); values = list(counts.values())
    cmap   = {"auto_shortlisted":FB_GREEN,"hr_approved":FB_GREEN,
               "needs_review":FB_ORANGE,"hr_hold":FB_GREY,
               "auto_rejected":FB_RED,"hr_rejected":FB_RED,"forwarded":FB_BLUE}
    colors = [cmap.get(l,FB_GREY) for l in labels]
    fig = go.Figure(go.Pie(
        labels=[l.replace("_"," ").title() for l in labels],values=values,
        hole=0.55,marker=dict(colors=colors,line=dict(color="white",width=2)),
        textinfo="label+percent",textfont=dict(size=10),
        hovertemplate="%{label}: %{value}<extra></extra>"
    ))
    fig.update_layout(height=250,margin=dict(t=20,b=20,l=20,r=20),
                      paper_bgcolor=PLOT_BG,showlegend=False,font={"family":"system-ui"},
                      annotations=[dict(text=f"<b>{sum(values)}</b>",x=.5,y=.5,
                                        font_size=18,showarrow=False,font_color="#050505")])
    return fig


def score_histogram(results):
    scores = [r.get("final_score",0) for r in results]
    fig = go.Figure(go.Histogram(
        x=scores,nbinsx=10,marker_color=FB_BLUE,marker_opacity=0.75,
        hovertemplate="Score %{x}: %{y} candidates<extra></extra>"
    ))
    fig.add_vline(x=70,line_dash="dot",line_color=FB_GREEN,
                  annotation_text="Shortlist",annotation_font_size=9,annotation_font_color=FB_GREEN)
    fig.add_vline(x=50,line_dash="dot",line_color=FB_ORANGE,
                  annotation_text="Review",annotation_font_size=9,annotation_font_color=FB_ORANGE)
    fig.update_layout(height=230,margin=dict(t=20,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG,plot_bgcolor=PLOT_BG,
                      xaxis=dict(title="Score /100",showgrid=False,range=[0,105]),
                      yaxis=dict(title="Candidates",gridcolor="#F0F2F5"),
                      font={"family":"system-ui"},bargap=0.1)
    return fig


def funnel_chart(total, shortlisted, interview, offer=0, hired=0):
    fig = go.Figure(go.Funnel(
        y=["Applications","Shortlisted","Interview","Offer","Hired"],
        x=[total, shortlisted, interview, offer, hired],
        marker_color=[FB_BLUE,FB_GREEN,FB_ORANGE,"#8B5CF6","#059669"],
        textinfo="value+percent initial",
        hovertemplate="%{y}: %{x}<extra></extra>"
    ))
    fig.update_layout(height=300,margin=dict(t=20,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG,font={"family":"system-ui"})
    return fig


def skills_heatmap(results):
    """Top matching skills across all candidates."""
    from collections import Counter
    all_skills = []
    for r in results:
        all_skills.extend(parse_list(r.get("matched_skills",[])))
    if not all_skills: return None
    top = Counter(all_skills).most_common(12)
    labels = [t[0] for t in top]; values = [t[1] for t in top]
    fig = go.Figure(go.Bar(
        x=values,y=labels,orientation="h",
        marker_color=FB_BLUE,marker_opacity=0.75,
        text=values,textposition="outside",
        hovertemplate="%{y}: %{x} candidates<extra></extra>",showlegend=False
    ))
    fig.update_layout(height=max(200,len(labels)*28+40),
                      margin=dict(t=10,b=10,l=10,r=40),
                      paper_bgcolor=PLOT_BG,plot_bgcolor=PLOT_BG,
                      xaxis=dict(visible=False),
                      yaxis=dict(tickfont=dict(size=10,color="#050505")),
                      bargap=0.3,font={"family":"system-ui"})
    return fig


def rejection_reasons_chart(rejection_data):
    from collections import Counter
    reasons = []
    for r in rejection_data:
        why = r.get("why_rejected","")
        if "skills" in (why or "").lower(): reasons.append("Missing Skills")
        elif "experience" in (why or "").lower(): reasons.append("Experience Gap")
        elif "domain" in (why or "").lower(): reasons.append("Domain Mismatch")
        elif "penalty" in (why or "").lower(): reasons.append("Heavy Penalties")
        else: reasons.append("Low Score")
    if not reasons: return None
    counts = Counter(reasons)
    fig = go.Figure(go.Pie(
        labels=list(counts.keys()),values=list(counts.values()),
        marker_color=[FB_RED,FB_ORANGE,"#8B5CF6",FB_GREY,FB_BLUE],
        textinfo="label+percent",textfont=dict(size=11),
        hovertemplate="%{label}: %{value}<extra></extra>"
    ))
    fig.update_layout(height=250,margin=dict(t=10,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG,showlegend=False,font={"family":"system-ui"})
    return fig


def latency_chart(perf_data):
    if not perf_data: return None
    labels = [p.get("title","?")[:15] for p in perf_data]
    avgs   = [int(p.get("avg_ms",0)/1000) for p in perf_data]
    fig = go.Figure(go.Bar(
        x=labels,y=avgs,marker_color=FB_BLUE,marker_opacity=0.75,
        text=[f"{v}s" for v in avgs],textposition="outside",
        hovertemplate="%{x}: %{y}s<extra></extra>",showlegend=False
    ))
    fig.update_layout(height=230,margin=dict(t=20,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG,plot_bgcolor=PLOT_BG,
                      xaxis=dict(showgrid=False),
                      yaxis=dict(title="Avg seconds",gridcolor="#F0F2F5"),
                      bargap=0.35,font={"family":"system-ui"})
    return fig
