"""
TalentScan ATS v2 — Excel Export Utility
Generates candidate profile Excel reports with score breakdown,
reasoning trace, skill gap analysis, and penalty details.
"""
import io
import json
from typing import List, Dict, Any
from datetime import datetime

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False


def parse_list(val):
    if isinstance(val, list): return val
    if not val: return []
    try:
        r = json.loads(val)
        return r if isinstance(r, list) else [str(r)]
    except Exception:
        return [str(val)] if val else []


def generate_excel_report(candidates: List[Dict[str, Any]], output: io.BytesIO) -> None:
    """Generate a multi-sheet Excel workbook for a list of candidates."""
    if not OPENPYXL_AVAILABLE:
        raise ImportError("openpyxl not installed. Run: pip install openpyxl")

    wb = openpyxl.Workbook()

    # ── Styles ──
    BLUE_FILL   = PatternFill("solid", fgColor="1877F2")
    GREEN_FILL  = PatternFill("solid", fgColor="E7F3E8")
    RED_FILL    = PatternFill("solid", fgColor="FFEBEE")
    ORANGE_FILL = PatternFill("solid", fgColor="FFF3E0")
    GREY_FILL   = PatternFill("solid", fgColor="F0F2F5")
    WHITE_FONT  = Font(color="FFFFFF", bold=True)
    HEADER_FONT = Font(bold=True, size=11)
    TITLE_FONT  = Font(bold=True, size=14, color="1877F2")
    BOLD        = Font(bold=True)
    CENTER      = Alignment(horizontal="center", vertical="center")
    LEFT        = Alignment(horizontal="left",   vertical="center", wrap_text=True)
    THIN        = Border(
        left  =Side(style="thin"), right =Side(style="thin"),
        top   =Side(style="thin"), bottom=Side(style="thin")
    )

    def set_header(ws, row, col, text, fill=None, font=None, width=None):
        cell = ws.cell(row=row, column=col, value=text)
        if fill:  cell.fill = fill
        if font:  cell.font = font
        cell.alignment = CENTER
        cell.border    = THIN
        if width:
            ws.column_dimensions[get_column_letter(col)].width = width
        return cell

    def set_cell(ws, row, col, value, fill=None, font=None, align=LEFT):
        cell = ws.cell(row=row, column=col, value=str(value) if value is not None else "—")
        if fill:  cell.fill = fill
        if font:  cell.font = font
        cell.alignment = align
        cell.border    = THIN
        return cell

    def score_fill(score):
        try:
            s = int(score)
            if s >= 70: return GREEN_FILL
            if s >= 50: return ORANGE_FILL
            return RED_FILL
        except Exception:
            return GREY_FILL

    def recommendation(score):
        try:
            s = int(score)
            if s >= 70: return "✅ SELECTED"
            if s >= 50: return "🔄 MAYBE / REVIEW"
            return "❌ REJECTED"
        except Exception:
            return "—"

    # ═══════════════════════════════════════════════
    # SHEET 1: SUMMARY
    # ═══════════════════════════════════════════════
    ws_sum = wb.active
    ws_sum.title = "Summary"
    ws_sum.row_dimensions[1].height = 30

    # Title
    ws_sum.merge_cells("A1:L1")
    title_cell = ws_sum["A1"]
    title_cell.value     = f"TalentScan ATS — Candidate Report  ·  Generated {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    title_cell.font      = TITLE_FONT
    title_cell.alignment = CENTER
    title_cell.fill      = GREY_FILL

    # Headers
    headers = [
        ("Rank",              8),  ("Name",           22), ("Email",          28),
        ("Job Title",         22), ("Final Score",     12), ("Recommendation", 22),
        ("Relevance",         12), ("Skill Match",     12), ("Experience",     12),
        ("Semantic",          12), ("Potential",       12), ("Penalty",        10),
        ("Decision",          18), ("ATS Stage",       14), ("Screened At",    18),
    ]
    for col, (header, width) in enumerate(headers, 1):
        set_header(ws_sum, 2, col, header, BLUE_FILL, WHITE_FONT, width)

    # Data rows
    for rank, c in enumerate(candidates, 1):
        score = c.get("final_score", 0)
        row   = rank + 2
        vals  = [
            rank,
            c.get("full_name") or c.get("original_filename") or "Unknown",
            c.get("email") or "—",
            c.get("job_title") or "—",
            score,
            recommendation(score),
            c.get("relevance_score",  0),
            c.get("skill_match_score",0),
            c.get("experience_score", 0),
            c.get("semantic_score",   0),
            c.get("potential_score",  0),
            c.get("penalty_score",    0),
            (c.get("decision") or "").replace("_"," ").title(),
            (c.get("ats_stage") or "").replace("_"," ").title(),
            (c.get("screened_at") or "")[:16],
        ]
        fills = [None,None,None,None,score_fill(score),score_fill(score),
                 None,None,None,None,None,RED_FILL,None,None,None]
        for col,(val,fill) in enumerate(zip(vals,fills),1):
            set_cell(ws_sum, row, col, val, fill)

    ws_sum.freeze_panes = "A3"

    # ═══════════════════════════════════════════════
    # SHEET 2: SCORE BREAKDOWN
    # ═══════════════════════════════════════════════
    ws_sc = wb.create_sheet("Score Breakdown")
    ws_sc.merge_cells("A1:J1")
    ws_sc["A1"].value = "Score Breakdown — Formula: (Rel×30%) + (Skill×25%) + (Exp×20%) + (Sem×25%) − Penalties"
    ws_sc["A1"].font  = TITLE_FONT; ws_sc["A1"].fill = GREY_FILL; ws_sc["A1"].alignment = CENTER

    sc_headers = [("Name",22),("Final",10),("Relevance\n×30%",14),("Skill Match\n×25%",14),
                  ("Experience\n×20%",14),("Semantic\n×25%",14),("Potential",12),("Penalty",12),
                  ("Formula",40),("Score Reasoning",60)]
    for col,(h,w) in enumerate(sc_headers,1):
        set_header(ws_sc,2,col,h,BLUE_FILL,WHITE_FONT,w)

    for row,c in enumerate(candidates,3):
        score = c.get("final_score",0)
        rel   = c.get("relevance_score",0)
        skill = c.get("skill_match_score",0)
        exp   = c.get("experience_score",0)
        sem   = c.get("semantic_score",0)
        pot   = c.get("potential_score",0)
        pen   = c.get("penalty_score",0)
        formula = f"({rel}×.30)+({skill}×.25)+({exp}×.20)+({sem}×.25)−{pen} = {score}"
        vals = [c.get("full_name") or "Unknown", score, rel, skill, exp, sem, pot, pen,
                formula, c.get("score_reasoning","")]
        fills=[None,score_fill(score),None,None,None,None,None,RED_FILL,GREY_FILL,None]
        for col,(v,f) in enumerate(zip(vals,fills),1):
            set_cell(ws_sc,row,col,v,f)
    ws_sc.freeze_panes = "A3"

    # ═══════════════════════════════════════════════
    # SHEET 3: SKILL ANALYSIS
    # ═══════════════════════════════════════════════
    ws_sk = wb.create_sheet("Skill Analysis")
    ws_sk.merge_cells("A1:F1")
    ws_sk["A1"].value = "Skill Gap Analysis — Matched vs Missing vs Transferable"
    ws_sk["A1"].font  = TITLE_FONT; ws_sk["A1"].fill = GREY_FILL; ws_sk["A1"].alignment = CENTER

    sk_headers = [("Name",22),("Matched Skills",50),("Missing Skills (Required)",50),
                  ("Transferable Skills",45),("Why Selected",50),("Why Rejected",50)]
    for col,(h,w) in enumerate(sk_headers,1):
        set_header(ws_sk,2,col,h,BLUE_FILL,WHITE_FONT,w)

    for row,c in enumerate(candidates,3):
        matched  = ", ".join(parse_list(c.get("matched_skills",[])))
        missing  = ", ".join(parse_list(c.get("missing_skills",[])))
        transfer = ", ".join(parse_list(c.get("transferable_skills",[])))
        fills    = [None,GREEN_FILL,RED_FILL,ORANGE_FILL,GREEN_FILL,RED_FILL]
        vals     = [c.get("full_name") or "Unknown", matched, missing, transfer,
                    c.get("why_selected",""), c.get("why_rejected","")]
        for col,(v,f) in enumerate(zip(vals,fills),1):
            set_cell(ws_sk,row,col,v,f)
        ws_sk.row_dimensions[row].height = 45
    ws_sk.freeze_panes = "A3"

    # ═══════════════════════════════════════════════
    # SHEET 4: AI EXPLANATION
    # ═══════════════════════════════════════════════
    ws_ai = wb.create_sheet("AI Explanation")
    ws_ai.merge_cells("A1:E1")
    ws_ai["A1"].value = "AI Explainability — Rationale, Penalties, Trajectory"
    ws_ai["A1"].font  = TITLE_FONT; ws_ai["A1"].fill = GREY_FILL; ws_ai["A1"].alignment = CENTER

    ai_headers = [("Name",22),("LLM Rationale",70),("Penalties Applied",50),
                  ("Career Trajectory",20),("Growth Label",30)]
    for col,(h,w) in enumerate(ai_headers,1):
        set_header(ws_ai,2,col,h,BLUE_FILL,WHITE_FONT,w)

    for row,c in enumerate(candidates,3):
        pens = parse_list(c.get("penalties_applied",[]))
        pens_str = "; ".join(p.get("reason","") + f" ({p.get('deduction',0)}pts)"
                             if isinstance(p,dict) else str(p) for p in pens)
        vals = [c.get("full_name") or "Unknown", c.get("llm_rationale",""),
                pens_str or "None", c.get("career_trajectory",""),
                c.get("growth_label","")]
        fills=[None,None,RED_FILL if pens else GREEN_FILL,None,None]
        for col,(v,f) in enumerate(zip(vals,fills),1):
            set_cell(ws_ai,row,col,v,f)
        ws_ai.row_dimensions[row].height = 60
    ws_ai.freeze_panes = "A3"

    # ═══════════════════════════════════════════════
    # SHEET 5: TIMELINE / HISTORY
    # ═══════════════════════════════════════════════
    ws_tl = wb.create_sheet("Timeline")
    ws_tl.merge_cells("A1:D1")
    ws_tl["A1"].value = "Candidate Timeline — Decision History"
    ws_tl["A1"].font  = TITLE_FONT; ws_tl["A1"].fill = GREY_FILL; ws_tl["A1"].alignment = CENTER

    tl_headers = [("Name",22),("Event",30),("Value/Detail",40),("Timestamp",20)]
    for col,(h,w) in enumerate(tl_headers,1):
        set_header(ws_tl,2,col,h,BLUE_FILL,WHITE_FONT,w)

    tl_row = 3
    for c in candidates:
        name   = c.get("full_name") or "Unknown"
        events = [
            ("CV Uploaded",    c.get("original_filename",""),    ""),
            ("AI Screened",    f"Final Score: {c.get('final_score',0)}/100", c.get("screened_at","")),
            ("Decision",       (c.get("decision") or "").replace("_"," ").title(),   c.get("decision_at","")),
            ("ATS Stage",      (c.get("ats_stage") or "").replace("_"," ").title(), ""),
        ]
        for evt,val,ts in events:
            for col,v in enumerate([name,evt,val,ts[:16] if ts else ""],1):
                set_cell(ws_tl,tl_row,col,v)
            tl_row+=1
        tl_row+=1  # blank separator
    ws_tl.freeze_panes = "A3"

    wb.save(output)
