import streamlit as st, requests, os, sys
sys.path.insert(0, "/app/frontend")
from shared_style import CSS, topnav, sidebar_nav, score_color, badge_html, donut, score_histogram, funnel_chart, pool_bar, PLOTLY_CFG, FB_BLUE, FB_GREEN, FB_ORANGE
import plotly.graph_objects as go

st.set_page_config(page_title="TalentScan ATS v2", page_icon="🎯", layout="wide", initial_sidebar_state="expanded")
st.markdown(CSS, unsafe_allow_html=True)

API = os.getenv("API_URL", "http://api:8000") + "/api/v1"

with st.sidebar:
    sidebar_nav("dashboard")
    st.markdown('<div style="height:1px;background:#E4E6EB;margin:1rem 0;"></div>', unsafe_allow_html=True)
    try:
        h = requests.get(os.getenv("API_URL","http://api:8000")+"/health", timeout=3).json()
        api_ok, db_ok, ai_ok = True, h.get("database",False), h.get("ollama",False)
    except Exception:
        api_ok = db_ok = ai_ok = False
    for lbl, ok, c in [("API Gateway",api_ok,"#42B72A"),("PostgreSQL",db_ok,"#42B72A"),("Ollama LLM",ai_ok,"#F5A623")]:
        col = c if ok else "#FA3E3E"
        st.markdown(f'<div style="display:flex;align-items:center;gap:7px;font-size:.8rem;color:#65676B;margin:5px 0;"><span style="width:8px;height:8px;border-radius:50%;background:{col};display:inline-block;"></span>{lbl}</div>', unsafe_allow_html=True)
    st.markdown('<div style="margin-top:1.5rem;background:#F0F2F5;border-radius:8px;padding:10px 12px;font-size:.72rem;color:#65676B;line-height:1.9;">v2.0 · Explainable AI<br>Scoring: 0-100 capped<br>Formula: Rel×30 + Skill×25<br>+ Exp×20 + Sem×25 − Pen</div>', unsafe_allow_html=True)

st.markdown(topnav("Dashboard · Hiring Overview"), unsafe_allow_html=True)

try:
    jobs = requests.get(f"{API}/jobs/", timeout=5).json()
    if not isinstance(jobs, list): jobs = []
except Exception:
    jobs = []

all_s = []
for j in jobs:
    try:
        r = requests.get(f"{API}/screenings/results/{j['id']}", params={"min_score":0,"limit":500}, timeout=8).json()
        if isinstance(r, list):
            for x in r: x["_job_title"] = j["title"]
            all_s.extend(r)
    except Exception:
        pass

total_j = len(jobs)
total_s = len(all_s)
shortl  = sum(1 for r in all_s if r.get("final_score",0) >= 70)
pend    = sum(1 for r in all_s if r.get("decision") == "needs_review")
avg_s   = int(sum(r.get("final_score",0) for r in all_s)/total_s) if total_s else 0
avg_ms  = int(sum(r.get("pipeline_time_ms",0) or 0 for r in all_s)/total_s) if total_s else 0

m1,m2,m3,m4,m5,m6 = st.columns(6)
m1.metric("Active Roles", total_j)
m2.metric("CVs Screened", total_s)
m3.metric("Shortlisted (≥70)", shortl)
m4.metric("Pending Review", pend)
m5.metric("Avg Score", f"{avg_s}/100")
m6.metric("Avg Pipeline", f"{avg_ms//1000}s" if avg_ms else "—")

st.markdown('<div class="divider"></div>', unsafe_allow_html=True)

if all_s:
    c1,c2,c3 = st.columns(3, gap="medium")
    with c1:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Score Distribution</div>', unsafe_allow_html=True)
        st.plotly_chart(score_histogram(all_s), use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)
    with c2:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Decision Breakdown</div>', unsafe_allow_html=True)
        st.plotly_chart(donut(all_s), use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)
    with c3:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Hiring Funnel</div>', unsafe_allow_html=True)
        intv = sum(1 for r in all_s if r.get("ats_stage") == "interview")
        st.plotly_chart(funnel_chart(total_s, shortl, intv), use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="fb-card-lg"><div class="sec-label">Candidate Pool — All Roles</div>', unsafe_allow_html=True)
    top = sorted(all_s, key=lambda x: x.get("final_score",0), reverse=True)[:25]
    fig = pool_bar(top)
    if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
    st.markdown('</div>', unsafe_allow_html=True)

st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
pc1,pc2 = st.columns([2,1], gap="large")
with pc1:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">AI Pipeline Architecture</div>', unsafe_allow_html=True)
    for i,(n,d) in enumerate([
        ("Ingestion Agent","PDF/DOCX/TXT parsing · LLM structured extraction · confidence scoring"),
        ("Matching Agent","Embedding similarity + Rule-based skill match + Experience scoring + LLM semantic + Penalty engine"),
        ("Potential Agent","Career trajectory · Leadership signals · Learning velocity"),
        ("Validation Agent","Duplicate detection · Keyword stuffing · Employment gaps · Borderline flags"),
    ],1):
        st.markdown(f'<div class="pipeline-step" style="display:flex;align-items:center;gap:12px;padding:10px 14px;background:#F0F2F5;border-radius:8px;margin-bottom:6px;"><div style="width:28px;height:28px;border-radius:50%;background:#1877F2;color:white;font-weight:700;font-size:.8rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;">{i}</div><div><div style="font-weight:600;font-size:.85rem;color:#050505;">{n}</div><div style="font-size:.75rem;color:#65676B;margin-top:1px;">{d}</div></div></div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)
with pc2:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Scoring Weights</div>', unsafe_allow_html=True)
    fig_w = go.Figure(go.Pie(
        labels=["Relevance (30%)","Skill Match (25%)","Experience (20%)","Semantic (25%)"],
        values=[30,25,20,25], hole=0.5,
        marker=dict(colors=[FB_BLUE,"#6366F1",FB_GREEN,FB_ORANGE],line=dict(color="white",width=2)),
        textinfo="label+percent",textfont=dict(size=10),
    ))
    fig_w.update_layout(height=220,margin=dict(t=10,b=10,l=10,r=10),paper_bgcolor="#FFFFFF",showlegend=False,font={"family":"system-ui"})
    st.plotly_chart(fig_w, use_container_width=True, config=PLOTLY_CFG)
    st.markdown('<div style="font-size:.72rem;color:#65676B;margin-top:4px;line-height:1.9;">⚠️ Penalties deducted from total<br>Max penalty: 60 pts<br>Score NEVER exceeds 100</div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

if jobs:
    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-label">Active Roles</div>', unsafe_allow_html=True)
    for j in jobs:
        cnt = sum(1 for r in all_s if str(r.get("job_id","")) == str(j.get("id","")))
        ini = (j.get("title") or "J")[0].upper()
        st.markdown(f'<div class="job-row" style="display:flex;align-items:center;gap:14px;padding:1rem 1.2rem;background:#FFF;border-radius:8px;border:1px solid #CED0D4;margin-bottom:8px;"><div style="width:40px;height:40px;border-radius:8px;background:#1877F2;color:white;font-weight:700;font-size:1rem;display:flex;align-items:center;justify-content:center;">{ini}</div><div style="flex:1;"><div style="font-weight:700;font-size:.92rem;color:#050505;">{j["title"]}</div><div style="font-size:.75rem;color:#65676B;">{j.get("department","—")} · {j.get("location","—")}</div></div><span class="badge badge-blue">{cnt} screened</span><span style="font-size:.72rem;color:#BCC0C4;">{(j.get("created_at") or "")[:10]}</span></div>', unsafe_allow_html=True)
