# TalentScan ATS v2 — Explainable AI CV Screening System

## Architecture

```
Frontend (Streamlit :8501)  →  FastAPI (:8000)  →  PostgreSQL + pgvector
                                      ↓
                            4-Agent AI Pipeline
                            ┌─────────────────────────────────────────────┐
                            │ 1. Ingestion Agent    PDF/DOCX/TXT → JSON   │
                            │ 2. Matching Agent     Scoring Engine        │
                            │    • Relevance Score  (embedding ×30%)      │
                            │    • Skill Match      (rule-based ×25%)     │
                            │    • Experience       (years ×20%)          │
                            │    • Semantic         (LLM ×25%)            │
                            │    • Penalties        (deducted from total) │
                            │ 3. Potential Agent    Career trajectory      │
                            │ 4. Validation Agent   Anomaly detection     │
                            └─────────────────────────────────────────────┘
                                      ↕
                                 Ollama (LLM)
                               llama3.1:8b + nomic-embed-text
```

## Scoring Formula

```
Final Score (0-100) =
  (Relevance × 30%) + (Skill Match × 25%) + (Experience × 20%) + (Semantic × 25%)
  − Penalty Deductions

Penalties:
  Missing critical skill:  -20 pts each (max 2 = -40)
  Experience gap <40%:     -15 pts
  Domain mismatch:         -10 pts
  Keyword stuffing:         -8 pts
  No skills section:       -15 pts
  Generic CV:              -12 pts
  Max total penalty:        60 pts

Score NEVER exceeds 100. Score NEVER goes below 0.
```

## Quick Start

```bash
# Clone and start
docker compose up --build

# Wait for: "All models ready!" in logs (~5-10 min first run)

# Access
# Frontend:  http://localhost:8501
# API docs:  http://localhost:8000/docs (development only)
```

## Pages

| Page | Description |
|------|-------------|
| 🏠 Dashboard | KPIs, score distribution, funnel, pipeline architecture |
| 📋 Post a Job | Upload JD → auto-parse required skills, years, seniority |
| 📤 Upload CVs | Batch upload → async 4-agent pipeline |
| 📊 Screening Results | Ranked list + Kanban board, full score breakdown, export |
| 📈 Analytics | Distribution, heatmap, rejection reasons, latency charts |
| 👤 Candidate Profile | Full profile with work history, timeline, HR decision |

## Run Stress Test (50 CVs, no Docker needed)

```bash
cd talentscan_ats
pip install -r requirements.txt
python tests/stress_test.py
```

Expected output: >80% accuracy on good/bad/irrelevant CV classification.

## Negative Scenarios Handled

| Scenario | Expected Score | How |
|----------|---------------|-----|
| Admin CV vs Data Engineer JD | <30 | Domain mismatch penalty + missing skills |
| Fresher vs Senior role | <40 | Experience penalty (years <40% of required) |
| Keyword stuffing CV | <50 | Keyword stuffing detection flag + penalty |
| Empty CV | <20 | No-skills penalty + generic CV penalty |
| Marketing CV vs tech JD | <25 | Domain mismatch + cosine similarity low |

## Performance

- Scoring engine (rules only): <1ms per CV
- Full pipeline (LLM on CPU): ~90s per CV (llama3.1:8b)
- Batch: async background tasks — multiple CVs queued in parallel
- Embeddings: cached per job (JD embedded once at posting)
