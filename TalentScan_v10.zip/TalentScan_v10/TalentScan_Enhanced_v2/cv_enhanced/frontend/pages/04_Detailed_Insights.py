# ── GLOBAL PDF (ALL CANDIDATES) ──────────────────────────────────────────────
import io
import json        # FIX 1: was missing — parse_list() uses json.loads
import time        # FIX 2: was missing — auto-refresh uses time.sleep
import os
from collections import Counter
from datetime import datetime

import requests
import openpyxl
from openpyxl.styles import Side, Border, Font, Alignment, PatternFill
import plotly.graph_objects as go
from branding import BRAND_NAME, BRAND_ICON
import streamlit as st

# ── PDF / reportlab imports ───────────────────────────────────────────────────
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, Image, HRFlowable, KeepTogether
)

# ── PDF builder functions (inlined) ─────────────────────────────────────────


# ── Shared colour palette (mirrors the Streamlit UI) ─────────────────────────
_NAVY   = colors.HexColor("#0F2D6B")
_BLUE   = colors.HexColor("#1877F2")
_GREEN  = colors.HexColor("#42B72A")
_ORANGE = colors.HexColor("#F5A623")
_RED    = colors.HexColor("#FA3E3E")
_PURPLE = colors.HexColor("#6B2FA0")
_GREY   = colors.HexColor("#65676B")
_LGREY  = colors.HexColor("#F0F2F5")
_BORDER = colors.HexColor("#CED0D4")
_TEXT   = colors.HexColor("#050505")
_WHITE  = colors.white

_PLOT_BG = "#FFFFFF"
_FB_BLUE   = "#1877F2"
_FB_GREEN  = "#42B72A"
_FB_ORANGE = "#F5A623"
_FB_RED    = "#FA3E3E"
_FB_GREY   = "#BCC0C4"
_FB_PURPLE = "#6B2FA0"


# ── Internal helpers ──────────────────────────────────────────────────────────

def _score_hex(s: float) -> str:
    return _FB_GREEN if s >= 0.65 else (_FB_ORANGE if s >= 0.45 else _FB_RED)

def _score_rl(s: float):
    return _GREEN if s >= 0.65 else (_ORANGE if s >= 0.45 else _RED)

def _fit_label(s: float) -> str:
    if s >= 0.65: return "Strong Fit"
    if s >= 0.45: return "Moderate Fit"
    return "Weak Fit"

def _parse_list(val):
    if isinstance(val, list): return val
    if not val: return []
    try:
        import json
        r = json.loads(val)
        return r if isinstance(r, list) else [str(r)]
    except Exception:
        return [str(val)] if val else []

def _get_parsed(r: dict) -> dict:
    p = r.get("parsed_data") or {}
    if isinstance(p, str):
        try:
            import json
            p = json.loads(p)
        except Exception:
            p = {}
    return p

def _safe_float(val, default=0.0) -> float:
    try:
        return float(str(val).split()[0])
    except Exception:
        return default

def _fig_to_image_flowable(fig, width_cm=17, height_cm=7):
    """Render a Plotly figure to a ReportLab Image flowable.
    Requires kaleido==0.2.1 in the Docker image.
    Install: pip install kaleido==0.2.1
    """
    try:
        png_bytes = fig.to_image(format="png", width=int(width_cm * 37.8),
                                  height=int(height_cm * 37.8), scale=2)
        return Image(io.BytesIO(png_bytes),
                     width=width_cm * cm, height=height_cm * cm)
    except Exception as _e:
        # kaleido not installed or chart render failed — return a placeholder text box
        from reportlab.lib.styles import getSampleStyleSheet
        _styles = getSampleStyleSheet()
        return Paragraph(
            f"<i>[Chart unavailable — install kaleido==0.2.1: pip install kaleido==0.2.1]</i>",
            ParagraphStyle("ChartErr", parent=_styles["Normal"],
                           fontSize=8, textColor=colors.HexColor("#FA3E3E"),
                           backColor=colors.HexColor("#FFF0F0"),
                           leftIndent=8, spaceBefore=4, spaceAfter=4)
        )

def _section_header(text: str, styles) -> list:
    """Returns a labelled section divider (HRFlowable + bold heading)."""
    return [
        Spacer(1, 0.3 * cm),
        HRFlowable(width="100%", thickness=1, color=_BORDER, spaceAfter=4),
        Paragraph(f"<b>{text}</b>",
                  ParagraphStyle("SecHdr", parent=styles["Normal"],
                                 fontName="Helvetica-Bold", fontSize=10,
                                 textColor=_NAVY, spaceBefore=4, spaceAfter=6)),
    ]

def _kv_table(rows: list, col_widths=(5 * cm, 12 * cm)) -> Table:
    """Two-column key/value table."""
    t = Table(rows, colWidths=col_widths)
    t.setStyle(TableStyle([
        ("FONTNAME",   (0, 0), (-1, -1), "Helvetica"),
        ("FONTNAME",   (0, 0), (0, -1),  "Helvetica-Bold"),
        ("FONTSIZE",   (0, 0), (-1, -1), 9),
        ("TEXTCOLOR",  (0, 0), (-1, -1), _TEXT),
        ("BACKGROUND", (0, 0), (0, -1),  _LGREY),
        ("GRID",       (0, 0), (-1, -1), 0.4, _BORDER),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [_WHITE, colors.HexColor("#FAFBFC")]),
        ("TOPPADDING",    (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING",   (0, 0), (-1, -1), 8),
    ]))
    return t

def _score_table(comp, rel, sem, pot) -> Table:
    """4-column score summary table."""
    score_col = _score_rl(comp)
    data = [
        ["Composite", "Relevance", "Semantic", "Potential"],
        [f"{int(comp*100)}%", f"{int(rel*100)}%",
         f"{int(sem*100)}%", f"{int(pot*100)}%"],
    ]
    t = Table(data, colWidths=[4.25 * cm] * 4)
    t.setStyle(TableStyle([
        ("FONTNAME",    (0, 0), (-1, 0),   "Helvetica-Bold"),
        ("FONTNAME",    (0, 1), (-1, 1),   "Helvetica-Bold"),
        ("FONTSIZE",    (0, 0), (-1, 0),   8),
        ("FONTSIZE",    (0, 1), (-1, 1),   14),
        ("TEXTCOLOR",   (0, 0), (-1, 0),   _WHITE),
        ("TEXTCOLOR",   (0, 1), (-1, 1),   score_col),
        ("BACKGROUND",  (0, 0), (-1, 0),   _NAVY),
        ("BACKGROUND",  (0, 1), (-1, 1),   colors.HexColor("#EBF3FF")),
        ("ALIGN",       (0, 0), (-1, -1),  "CENTER"),
        ("VALIGN",      (0, 0), (-1, -1),  "MIDDLE"),
        ("GRID",        (0, 0), (-1, -1),  0.4, _BORDER),
        ("TOPPADDING",  (0, 0), (-1, -1),  6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    return t


# ── Chart builders (same logic as the Streamlit versions) ─────────────────────

def _make_gauge(comp: float):
    pct = comp * 100
    col = _score_hex(comp)
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=pct,
        number={"suffix": "%", "font": {"size": 32, "color": "#050505"}},
        title={"text": "Composite Score", "font": {"size": 11, "color": "#65676B"}},
        gauge={
            "axis": {"range": [0, 100], "tickvals": [0, 25, 50, 65, 75, 100],
                     "tickfont": {"size": 9, "color": "#BCC0C4"}},
            "bar": {"color": col, "thickness": 0.28},
            "bgcolor": "#F0F2F5", "bordercolor": "#E4E6EB",
            "steps": [
                {"range": [0,  45], "color": "#FFECEC"},
                {"range": [45, 65], "color": "#FFF4E5"},
                {"range": [65,100], "color": "#E6F9EE"},
            ],
            "threshold": {"line": {"color": col, "width": 3},
                          "thickness": 0.8, "value": pct},
        },
    ))
    fig.update_layout(height=220, margin=dict(t=40, b=10, l=20, r=20),
                      paper_bgcolor=_PLOT_BG, font={"family": "Helvetica"})
    return fig


def _make_radar(rel: float, sem: float, pot: float):
    cats = ["Relevance", "Semantic", "Potential"]
    vals = [rel * 100, sem * 100, pot * 100]
    cats_c = cats + [cats[0]]
    vals_c = vals + [vals[0]]
    fig = go.Figure(go.Scatterpolar(
        r=vals_c, theta=cats_c,
        fill="toself", fillcolor="rgba(24,119,242,0.12)",
        line=dict(color=_FB_BLUE, width=2),
        marker=dict(color=_FB_BLUE, size=6),
        hovertemplate="%{theta}: %{r:.0f}%<extra></extra>",
    ))
    fig.update_layout(
        polar=dict(
            bgcolor="#F0F2F5",
            radialaxis=dict(visible=True, range=[0, 100],
                            tickvals=[0, 25, 50, 75, 100],
                            tickfont=dict(size=9, color="#BCC0C4"),
                            gridcolor="#E4E6EB"),
            angularaxis=dict(tickfont=dict(size=11, color="#050505"),
                             gridcolor="#E4E6EB"),
        ),
        showlegend=False, height=260,
        margin=dict(t=30, b=30, l=60, r=60),
        paper_bgcolor=_PLOT_BG, font={"family": "Helvetica"},
    )
    return fig


def _make_waterfall(rel: float, sem: float, pot: float, comp: float):
    r = rel * 0.40 * 100
    s = sem * 0.35 * 100
    p = pot * 0.25 * 100
    col = _score_hex(comp)
    fig = go.Figure(go.Waterfall(
        orientation="v",
        measure=["relative", "relative", "relative", "total"],
        x=["Relevance ×40%", "Semantic ×35%", "Potential ×25%", "Composite Score"],
        y=[r, s, p, 0],
        text=[f"{r:.1f}", f"{s:.1f}", f"{p:.1f}", f"{comp*100:.1f}"],
        textposition="outside",
        textfont={"size": 11, "color": "#050505"},
        increasing={"marker": {"color": _FB_BLUE}},
        totals={"marker": {"color": col}},
        connector={"line": {"color": "#E4E6EB", "width": 1}},
    ))
    fig.update_layout(
        height=280, margin=dict(t=30, b=10, l=10, r=10),
        paper_bgcolor=_PLOT_BG, plot_bgcolor=_PLOT_BG,
        xaxis=dict(showgrid=False, tickfont=dict(size=10, color="#050505")),
        yaxis=dict(range=[0, 115], gridcolor="#F0F2F5",
                   tickfont=dict(size=9, color="#65676B"), title="Score pts"),
        showlegend=False, font={"family": "Helvetica"},
    )
    return fig


def _make_skills_hbar(items: list, color: str = _FB_BLUE, max_items: int = 10):
    if not items:
        return None
    labels = [(s[:45] + "…" if len(s) > 45 else s) for s in items[:max_items]]
    fig = go.Figure(go.Bar(
        x=list(range(len(labels), 0, -1)),
        y=labels, orientation="h",
        marker_color=color, marker_opacity=0.80,
        text=labels, textposition="inside",
        insidetextanchor="start",
        textfont=dict(color="white", size=10),
        showlegend=False,
    ))
    fig.update_layout(
        height=max(140, len(labels) * 28 + 30),
        margin=dict(t=10, b=10, l=10, r=10),
        paper_bgcolor=_PLOT_BG, plot_bgcolor=_PLOT_BG,
        xaxis=dict(visible=False), yaxis=dict(visible=False),
        bargap=0.3, font={"family": "Helvetica"},
    )
    return fig


def _make_pool_bar(results: list):
    names  = [(r.get("full_name") or f"#{i+1}")[:22] for i, r in enumerate(results)]
    scores = [r.get("composite_score", 0) * 100 for r in results]
    bar_colors = [_score_hex(s / 100) for s in scores]
    fig = go.Figure(go.Bar(
        x=names, y=scores,
        marker_color=bar_colors,
        text=[f"{s:.0f}%" for s in scores],
        textposition="outside",
        textfont=dict(size=9, color="#050505"),
        showlegend=False,
    ))
    fig.add_hline(y=65, line_dash="dot", line_color=_FB_GREEN,
                  annotation_text="≥65% Shortlist",
                  annotation_font_size=9, annotation_font_color=_FB_GREEN)
    fig.add_hline(y=45, line_dash="dot", line_color=_FB_ORANGE,
                  annotation_text="≥45% Review",
                  annotation_font_size=9, annotation_font_color=_FB_ORANGE)
    fig.update_layout(
        height=300, margin=dict(t=30, b=10, l=10, r=10),
        paper_bgcolor=_PLOT_BG, plot_bgcolor=_PLOT_BG,
        xaxis=dict(tickfont=dict(size=9, color="#050505"), showgrid=False),
        yaxis=dict(range=[0, 115], gridcolor="#F0F2F5",
                   tickfont=dict(size=9, color="#65676B"), title="Score (%)"),
        bargap=0.3, font={"family": "Helvetica"},
    )
    return fig


def _make_score_dist(results: list):
    scores = [r.get("composite_score", 0) * 100 for r in results]
    fig = go.Figure(go.Histogram(
        x=scores, nbinsx=20,
        marker_color=_FB_BLUE, marker_opacity=0.75,
    ))
    fig.add_vline(x=65, line_dash="dot", line_color=_FB_GREEN,
                  annotation_text="65%", annotation_font_size=9)
    fig.add_vline(x=45, line_dash="dot", line_color=_FB_ORANGE,
                  annotation_text="45%", annotation_font_size=9)
    fig.update_layout(
        height=240, margin=dict(t=30, b=20, l=30, r=10),
        paper_bgcolor=_PLOT_BG, plot_bgcolor=_PLOT_BG,
        xaxis=dict(title="AI Score (%)", gridcolor="#F0F2F5",
                   tickfont=dict(size=9, color="#65676B")),
        yaxis=dict(title="Candidates", gridcolor="#F0F2F5",
                   tickfont=dict(size=9, color="#65676B")),
        showlegend=False, font={"family": "Helvetica"},
    )
    return fig


def _make_fit_donut(results: list):
    from collections import Counter
    labels_map = {
        "auto_shortlisted": ("Auto Shortlisted", _FB_GREEN),
        "hr_approved":      ("HR Approved",       "#17A589"),
        "needs_review":     ("Needs Review",       _FB_ORANGE),
        "hr_hold":          ("HR Hold",            _FB_GREY),
        "auto_rejected":    ("Auto Rejected",      _FB_RED),
        "hr_rejected":      ("HR Rejected",        "#C62828"),
        "forwarded":        ("Forwarded",           _FB_BLUE),
    }
    counts = Counter(r.get("decision", "needs_review") for r in results)
    labels, values, clrs = [], [], []
    for k, v in counts.items():
        lbl, col = labels_map.get(k, (k.replace("_", " ").title(), _FB_GREY))
        labels.append(lbl); values.append(v); clrs.append(col)
    fig = go.Figure(go.Pie(
        labels=labels, values=values, hole=0.58,
        marker=dict(colors=clrs, line=dict(color="white", width=2)),
        textinfo="label+percent", textfont=dict(size=9),
    ))
    fig.update_layout(
        height=260, margin=dict(t=20, b=20, l=20, r=20),
        paper_bgcolor=_PLOT_BG, showlegend=False,
        font={"family": "Helvetica"},
        annotations=[dict(text=f"<b>{sum(values)}</b><br>Total",
                          x=0.5, y=0.5, font_size=13, showarrow=False,
                          font_color="#050505")],
    )
    return fig


def _make_pool_radar(results: list, top_n: int = 5):
    top = sorted(results, key=lambda x: x.get("composite_score", 0),
                 reverse=True)[:top_n]
    cats = ["Relevance", "Semantic", "Potential"]
    cats_c = cats + [cats[0]]
    palette = [_FB_BLUE, _FB_GREEN, _FB_ORANGE, _FB_PURPLE, _FB_RED]
    fig = go.Figure()
    for i, r in enumerate(top):
        name = (r.get("full_name") or f"#{i+1}")[:18]
        vals = [r.get("relevance_score", 0) * 100,
                r.get("semantic_similarity", 0) * 100,
                r.get("potential_score", 0) * 100]
        hx = palette[i]
        r_int = int(hx[1:3], 16)
        g_int = int(hx[3:5], 16)
        b_int = int(hx[5:7], 16)
        fig.add_trace(go.Scatterpolar(
            r=vals + [vals[0]], theta=cats_c,
            fill="toself",
            fillcolor=f"rgba({r_int},{g_int},{b_int},0.08)",
            line=dict(color=hx, width=2), name=name,
        ))
    fig.update_layout(
        polar=dict(
            bgcolor="#F0F2F5",
            radialaxis=dict(visible=True, range=[0, 100],
                            tickfont=dict(size=8, color="#BCC0C4"),
                            gridcolor="#E4E6EB"),
            angularaxis=dict(tickfont=dict(size=10, color="#050505"),
                             gridcolor="#E4E6EB"),
        ),
        showlegend=True, height=300,
        margin=dict(t=30, b=20, l=50, r=50),
        paper_bgcolor=_PLOT_BG, font={"family": "Helvetica"},
        legend=dict(font=dict(size=9)),
    )
    return fig


# ── Candidate-level header banner ─────────────────────────────────────────────

def _candidate_header_table(rank, name, email, decision, fit_text, ts,
                             comp, styles) -> Table:
    decision_label = (decision or "needs_review").replace("_", " ").title()
    score_col = _score_hex(comp)
    data = [
        [Paragraph(f"<b>#{rank}  {name}</b>",
                   ParagraphStyle("CName", parent=styles["Normal"],
                                  fontName="Helvetica-Bold", fontSize=13,
                                  textColor=_WHITE)),
         Paragraph(f"<b>{int(comp*100)}%</b>",
                   ParagraphStyle("CPct", parent=styles["Normal"],
                                  fontName="Helvetica-Bold", fontSize=20,
                                  textColor=colors.HexColor(score_col),
                                  alignment=TA_RIGHT))],
        [Paragraph(email or "",
                   ParagraphStyle("CEmail", parent=styles["Normal"],
                                  fontSize=9, textColor=colors.HexColor("#BCC0C4"))),
         Paragraph(f"{fit_text}  ·  {decision_label}",
                   ParagraphStyle("CFit", parent=styles["Normal"],
                                  fontSize=9, textColor=_WHITE,
                                  alignment=TA_RIGHT))],
        [Paragraph(ts or "",
                   ParagraphStyle("CTs", parent=styles["Normal"],
                                  fontSize=8, textColor=colors.HexColor("#8A9BB0"))),
         Paragraph("", styles["Normal"])],
    ]
    t = Table(data, colWidths=[13 * cm, 4 * cm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), _NAVY),
        ("VALIGN",     (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("LEFTPADDING",  (0, 0), (0, -1), 14),
        ("RIGHTPADDING", (1, 0), (1, -1), 14),
        ("ROUNDEDCORNERS", [6]),
    ]))
    return t


# ══════════════════════════════════════════════════════════════════════════════
#  PER-CANDIDATE PDF  (replaces build_candidate_pdf)
# ══════════════════════════════════════════════════════════════════════════════

def build_candidate_pdf(r: dict, role_name: str = "") -> tuple:
    """
    Returns (bytes, "pdf").
    Includes: personal info, scores table, gauge + radar + waterfall charts,
    score breakdown bars, strengths & gaps (with bar charts), skills chips,
    transferable skills, strategic insights, AI rationale, system signals.
    """
    styles   = getSampleStyleSheet()
    buf      = io.BytesIO()
    doc      = SimpleDocTemplate(
        buf, pagesize=A4,
        rightMargin=1.8 * cm, leftMargin=1.8 * cm,
        topMargin=1.8 * cm, bottomMargin=2 * cm,
    )

    # ── Extract candidate data ────────────────────────────────────────────────
    name      = r.get("full_name") or r.get("original_filename") or "Unknown"
    email     = r.get("email") or ""
    phone     = r.get("phone") or _get_parsed(r).get("phone") or ""
    location  = r.get("location") or ""
    gender    = r.get("gender") or ""
    nat       = r.get("nationality") or ""
    decision  = r.get("decision") or "needs_review"
    ts        = (r.get("screened_at") or "")[:16].replace("T", " ")
    comp      = r.get("composite_score", 0)
    rel       = r.get("relevance_score", 0)
    sem       = r.get("semantic_similarity", 0)
    pot       = r.get("potential_score", 0)
    conf      = r.get("parse_confidence") or 0.8
    anoms     = r.get("anomaly_count") or 0
    returning = r.get("is_returning", False)
    rationale = r.get("llm_rationale") or ""
    fit_text  = _fit_label(comp)

    parsed       = _get_parsed(r)
    edu          = parsed.get("education") or []
    exp_lst      = parsed.get("experience") or []
    strengths    = _parse_list(r.get("strengths"))
    gaps         = _parse_list(r.get("gaps"))
    tech_skills  = _parse_list(r.get("technical_skills") or parsed.get("technical_skills"))
    soft_skills  = _parse_list(r.get("soft_skills") or parsed.get("soft_skills"))
    transferable = _parse_list(r.get("transferable_skills"))
    insights     = _parse_list(r.get("value_add_insights"))
    yoe          = r.get("years_of_experience") or parsed.get("total_years_exp") or ""

    # ── Styles ────────────────────────────────────────────────────────────────
    normal   = styles["Normal"]
    body_s   = ParagraphStyle("Body",   parent=normal, fontSize=9,
                               leading=14, textColor=_TEXT,
                               fontName="Helvetica")
    italic_s = ParagraphStyle("Italic", parent=normal, fontSize=9,
                               leading=14, textColor=_TEXT,
                               fontName="Helvetica-Oblique")
    chip_s   = ParagraphStyle("Chip",   parent=normal, fontSize=8,
                               leading=12, textColor=colors.HexColor("#1877F2"),
                               fontName="Helvetica")
    label_s  = ParagraphStyle("Lbl",    parent=normal, fontSize=7.5,
                               fontName="Helvetica-Bold",
                               textColor=_GREY,
                               spaceAfter=4)

    story = []

    # ── Page header ───────────────────────────────────────────────────────────
    # Top banner
    story.append(Paragraph(
        "<b>TalentScan AI · Candidate Profile</b>",
        ParagraphStyle("Banner", parent=normal, fontName="Helvetica-Bold",
                       fontSize=16, textColor=_WHITE,
                       backColor=_NAVY, spaceAfter=0,
                       leftIndent=0, leading=22),
    ))
    story.append(Paragraph(
        f"Role: {role_name}   ·   Generated: {datetime.now().strftime('%d %b %Y, %H:%M')}",
        ParagraphStyle("Sub", parent=normal, fontSize=9, textColor=_WHITE,
                       backColor=_BLUE, spaceAfter=10, leading=16),
    ))
    story.append(Spacer(1, 0.15 * cm))

    # Candidate header row
    story.append(_candidate_header_table(
        rank="", name=name, email=email,
        decision=decision, fit_text=fit_text, ts=ts, comp=comp, styles=styles,
    ))
    story.append(Spacer(1, 0.4 * cm))

    # ── Personal info ─────────────────────────────────────────────────────────
    story += _section_header("Personal Information", styles)
    info_rows = [
        ["Email",       email     or "—"],
        ["Phone",       phone     or "—"],
        ["Location",    location  or "—"],
        ["Gender",      gender    or "—"],
        ["Nationality", nat       or "—"],
        ["Experience",  f"{yoe} yrs" if yoe else "—"],
    ]
    story.append(_kv_table(info_rows))

    # Education
    if edu:
        story += _section_header("Education", styles)
        edu_rows = []
        for e in edu[:4]:
            deg  = e.get("degree", "")
            fld  = e.get("field", "")
            inst = e.get("institution", "")
            yr   = e.get("graduation_year", "")
            edu_rows.append([deg, f"{fld}  ·  {inst}  ·  {yr}"])
        story.append(_kv_table(edu_rows))

    # Experience
    if exp_lst:
        story += _section_header("Work Experience", styles)
        exp_rows = []
        for e in exp_lst[:5]:
            exp_rows.append([
                e.get("role", ""),
                f"{e.get('company','')}  ·  "
                f"{e.get('start_date','')} – {e.get('end_date','')}",
            ])
        story.append(_kv_table(exp_rows))

    story.append(Spacer(1, 0.3 * cm))

    # ── Score Intelligence ────────────────────────────────────────────────────
    story += _section_header("📊 Score Intelligence", styles)

    # Score summary table
    story.append(_score_table(comp, rel, sem, pot))
    story.append(Spacer(1, 0.3 * cm))

    # Score formula text
    story.append(Paragraph(
        f"({int(rel*100)} × 0.40) + ({int(sem*100)} × 0.35) + "
        f"({int(pot*100)} × 0.25) = <b>{int(comp*100)}</b>",
        ParagraphStyle("Formula", parent=normal, fontSize=8.5,
                       fontName="Helvetica", textColor=_GREY,
                       backColor=_LGREY, leftIndent=8, rightIndent=8,
                       spaceBefore=4, spaceAfter=8, leading=14),
    ))

    # Three charts side by side: gauge | radar | waterfall
    g_img = _fig_to_image_flowable(_make_gauge(comp),   width_cm=5.5, height_cm=5.5)
    r_img = _fig_to_image_flowable(_make_radar(rel, sem, pot), width_cm=5.8, height_cm=5.5)
    w_img = _fig_to_image_flowable(_make_waterfall(rel, sem, pot, comp), width_cm=5.8, height_cm=5.5)

    chart_row_data = [[g_img or "", r_img or "", w_img or ""]]
    chart_labels   = [
        [Paragraph("Composite Gauge", label_s),
         Paragraph("Score Profile Radar", label_s),
         Paragraph("Score Contribution", label_s)],
    ]
    ct = Table(chart_labels + chart_row_data, colWidths=[5.8 * cm] * 3)
    ct.setStyle(TableStyle([
        ("ALIGN",  (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING",    (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]))
    story.append(ct)
    story.append(Spacer(1, 0.35 * cm))

    # Sub-score breakdown bars (text-based to keep file small)
    story += _section_header("Score Breakdown with Weights", styles)
    breakdown_data = [
        ["Relevance Score",    f"{int(rel*100)}%", "40% – LLM JD/CV alignment"],
        ["Semantic Similarity",f"{int(sem*100)}%", "35% – vector embedding cosine"],
        ["Potential Score",    f"{int(pot*100)}%", "25% – career trajectory signals"],
    ]
    bt = Table(breakdown_data, colWidths=[5 * cm, 2 * cm, 10 * cm])
    bt.setStyle(TableStyle([
        ("FONTNAME",   (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME",   (1, 0), (1, -1), "Helvetica-Bold"),
        ("FONTNAME",   (2, 0), (2, -1), "Helvetica"),
        ("FONTSIZE",   (0, 0), (-1, -1), 9),
        ("TEXTCOLOR",  (1, 0), (1, -1), _score_rl(comp)),
        ("TEXTCOLOR",  (2, 0), (2, -1), _GREY),
        ("BACKGROUND", (0, 0), (-1, -1), _LGREY),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [_WHITE, colors.HexColor("#FAFBFC")]),
        ("GRID",       (0, 0), (-1, -1), 0.4, _BORDER),
        ("TOPPADDING",    (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING",   (0, 0), (-1, -1), 8),
    ]))
    story.append(bt)
    story.append(Spacer(1, 0.3 * cm))

    # ── Strength & Gap Analysis ───────────────────────────────────────────────
    story += _section_header("✅ Strength & Gap Analysis", styles)

    if strengths or gaps:
        sg_data = [[
            [Paragraph("<b>✓ Strengths</b>",
                       ParagraphStyle("SHdr", parent=normal, fontSize=9,
                                      textColor=colors.HexColor("#1A6B1E"),
                                      fontName="Helvetica-Bold", spaceAfter=6)),
             ] + [Paragraph(f"▲  {s}", body_s) for s in strengths] or
             [Paragraph("—", body_s)],

            [Paragraph("<b>⚠ Gaps</b>",
                       ParagraphStyle("GHdr", parent=normal, fontSize=9,
                                      textColor=colors.HexColor("#E65100"),
                                      fontName="Helvetica-Bold", spaceAfter=6)),
             ] + [Paragraph(f"▼  {g}", body_s) for g in gaps] or
             [Paragraph("—", body_s)],
        ]]
        sg_t = Table(sg_data, colWidths=[8.7 * cm, 8.7 * cm])
        sg_t.setStyle(TableStyle([
            ("VALIGN",     (0, 0), (-1, -1), "TOP"),
            ("BACKGROUND", (0, 0), (0, -1),  colors.HexColor("#E7F3E8")),
            ("BACKGROUND", (1, 0), (1, -1),  colors.HexColor("#FFF3E0")),
            ("GRID",       (0, 0), (-1, -1), 0.4, _BORDER),
            ("TOPPADDING",    (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ("LEFTPADDING",   (0, 0), (-1, -1), 10),
            ("RIGHTPADDING",  (0, 0), (-1, -1), 10),
        ]))
        story.append(sg_t)
        story.append(Spacer(1, 0.25 * cm))

    # Strength + gap charts
    if strengths:
        story.append(Paragraph("Strength Signal Depth", label_s))
        s_img = _fig_to_image_flowable(
            _make_skills_hbar(strengths, _FB_BLUE), width_cm=17,
            height_cm=max(3, min(len(strengths) * 0.65, 7)))
        if s_img:
            story.append(s_img)
            story.append(Spacer(1, 0.2 * cm))

    if gaps:
        story.append(Paragraph("Gap Signal Depth", label_s))
        g_img = _fig_to_image_flowable(
            _make_skills_hbar(gaps, _FB_RED), width_cm=17,
            height_cm=max(3, min(len(gaps) * 0.65, 7)))
        if g_img:
            story.append(g_img)
            story.append(Spacer(1, 0.2 * cm))

    # ── Skills Breakdown ──────────────────────────────────────────────────────
    if tech_skills or soft_skills:
        story += _section_header("🛠 Skills Breakdown", styles)
        sk_data = [[
            [Paragraph("<b>Technical Skills</b>", label_s)] +
            [Paragraph(s, chip_s) for s in tech_skills[:20]] or [Paragraph("—", body_s)],

            [Paragraph("<b>Soft Skills</b>", label_s)] +
            [Paragraph(s, ParagraphStyle("SoftChip", parent=normal, fontSize=8,
                                          leading=12, textColor=colors.HexColor("#6B2FA0"),
                                          fontName="Helvetica"))
             for s in soft_skills[:15]] or [Paragraph("—", body_s)],
        ]]
        sk_t = Table(sk_data, colWidths=[8.7 * cm, 8.7 * cm])
        sk_t.setStyle(TableStyle([
            ("VALIGN",     (0, 0), (-1, -1), "TOP"),
            ("BACKGROUND", (0, 0), (0, -1),  colors.HexColor("#E7F0FF")),
            ("BACKGROUND", (1, 0), (1, -1),  colors.HexColor("#F3E8FF")),
            ("GRID",       (0, 0), (-1, -1), 0.4, _BORDER),
            ("TOPPADDING",    (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ("LEFTPADDING",   (0, 0), (-1, -1), 10),
        ]))
        story.append(sk_t)
        story.append(Spacer(1, 0.25 * cm))

        # Tech skills bar chart
        if len(tech_skills) > 3:
            ts_img = _fig_to_image_flowable(
                _make_skills_hbar(tech_skills[:10], _FB_BLUE), width_cm=17,
                height_cm=max(3, min(len(tech_skills[:10]) * 0.7, 7)))
            if ts_img:
                story.append(ts_img)
                story.append(Spacer(1, 0.2 * cm))

    # ── Transferable Skills ───────────────────────────────────────────────────
    if transferable:
        story += _section_header("🔄 Transferable Skills", styles)
        story.append(Paragraph(
            "  ·  ".join(transferable[:20]), body_s))
        story.append(Spacer(1, 0.2 * cm))

    # ── Strategic Insights ────────────────────────────────────────────────────
    if insights:
        story += _section_header("💡 Strategic Insights", styles)
        for idx, insight in enumerate(insights, 1):
            story.append(Paragraph(
                f"<b>Insight {idx:02d}:</b>  {insight}",
                ParagraphStyle("Insight", parent=normal, fontSize=9,
                               leading=14, textColor=_TEXT,
                               fontName="Helvetica",
                               backColor=_LGREY,
                               leftIndent=8, borderPadding=6,
                               spaceBefore=3, spaceAfter=3),
            ))
        story.append(Spacer(1, 0.2 * cm))

    # ── AI Rationale ──────────────────────────────────────────────────────────
    if rationale:
        story += _section_header("🧠 AI Rationale", styles)
        story.append(Paragraph(rationale[:1800], italic_s))
        story.append(Spacer(1, 0.2 * cm))

    # ── System Signals ────────────────────────────────────────────────────────
    story += _section_header("📡 System Signals", styles)
    sig_data = [
        ["Composite Score", f"{int(comp*100)}%",
         "Anomaly Flags",   str(anoms),
         "Returning",       "Yes" if returning else "No",
         "Parse Confidence",f"{int(conf*100)}%"],
    ]
    sig_t = Table(sig_data, colWidths=[3.5*cm, 1.8*cm] * 4)
    sig_t.setStyle(TableStyle([
        ("FONTNAME",  (0, 0), (-1, -1), "Helvetica"),
        ("FONTNAME",  (0, 0), (0, -1),  "Helvetica-Bold"),
        ("FONTNAME",  (2, 0), (2, -1),  "Helvetica-Bold"),
        ("FONTNAME",  (4, 0), (4, -1),  "Helvetica-Bold"),
        ("FONTNAME",  (6, 0), (6, -1),  "Helvetica-Bold"),
        ("FONTSIZE",  (0, 0), (-1, -1), 9),
        ("TEXTCOLOR", (1, 0), (1, -1),  _score_rl(comp)),
        ("TEXTCOLOR", (3, 0), (3, -1),  _RED if anoms else _GREEN),
        ("BACKGROUND",(0, 0), (-1, -1), colors.HexColor("#EBF3FF")),
        ("GRID",      (0, 0), (-1, -1), 0.4, _BORDER),
        ("ALIGN",     (0, 0), (-1, -1), "CENTER"),
        ("TOPPADDING",    (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(sig_t)

    # ── Footer ────────────────────────────────────────────────────────────────
    story.append(Spacer(1, 0.5 * cm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=_BORDER))
    story.append(Paragraph(
        f"Generated by TalentScan AI  ·  {datetime.now().strftime('%d %b %Y, %H:%M')}  "
        f"·  For HR use only",
        ParagraphStyle("Footer", parent=normal, fontSize=7.5,
                       textColor=_GREY, alignment=TA_CENTER, spaceBefore=6),
    ))

    doc.build(story)
    buf.seek(0)
    return buf.getvalue(), "pdf"


# ══════════════════════════════════════════════════════════════════════════════
#  FULL POOL PDF  (replaces build_all_candidates_pdf)
# ══════════════════════════════════════════════════════════════════════════════

def build_all_candidates_pdf(results: list, role_name: str = "Role") -> bytes:
    """
    Full pool report:
      Page 1  – Pool analytics (score dist, rankings, decision donut,
                tier pie, pool radar)
      Page N+ – One section per candidate with all Score Intelligence
                charts + strengths/gaps/skills/rationale
    """
    styles = getSampleStyleSheet()
    buf    = io.BytesIO()
    doc    = SimpleDocTemplate(
        buf, pagesize=A4,
        rightMargin=1.8 * cm, leftMargin=1.8 * cm,
        topMargin=1.8 * cm, bottomMargin=2 * cm,
    )

    normal  = styles["Normal"]
    body_s  = ParagraphStyle("Body",  parent=normal, fontSize=9,
                              leading=14, textColor=_TEXT, fontName="Helvetica")
    label_s = ParagraphStyle("Lbl",   parent=normal, fontSize=7.5,
                              fontName="Helvetica-Bold", textColor=_GREY, spaceAfter=3)

    story = []

    # ─── Cover / title ────────────────────────────────────────────────────────
    story.append(Paragraph(
        "<b>TalentScan AI · Full Candidate Pool Report</b>",
        ParagraphStyle("Cover", parent=normal, fontName="Helvetica-Bold",
                       fontSize=20, textColor=_WHITE, backColor=_NAVY,
                       leading=28, spaceAfter=0),
    ))
    story.append(Paragraph(
        f"Role: {role_name}   ·   {len(results)} candidates   ·   "
        f"Generated: {datetime.now().strftime('%d %b %Y, %H:%M')}",
        ParagraphStyle("CoverSub", parent=normal, fontSize=10,
                       textColor=_WHITE, backColor=_BLUE, leading=18, spaceAfter=14),
    ))

    # Pool KPI row
    strong = sum(1 for r in results if r.get("composite_score", 0) >= 0.65)
    mod    = sum(1 for r in results if 0.45 <= r.get("composite_score", 0) < 0.65)
    weak   = sum(1 for r in results if r.get("composite_score", 0) < 0.45)
    avg    = (sum(r.get("composite_score", 0) for r in results) / len(results)) if results else 0
    short_ = sum(1 for r in results if "shortlisted" in (r.get("decision") or ""))

    kpi_data = [
        ["Total", "Strong Fit", "Moderate", "Weak", "Shortlisted", "Avg Score"],
        [str(len(results)), str(strong), str(mod), str(weak),
         str(short_), f"{avg:.0%}"],
    ]
    kpi_t = Table(kpi_data, colWidths=[2.8 * cm] * 6)
    kpi_t.setStyle(TableStyle([
        ("FONTNAME",    (0, 0), (-1, 0),  "Helvetica-Bold"),
        ("FONTNAME",    (0, 1), (-1, 1),  "Helvetica-Bold"),
        ("FONTSIZE",    (0, 0), (-1, 0),  8),
        ("FONTSIZE",    (0, 1), (-1, 1),  15),
        ("TEXTCOLOR",   (0, 0), (-1, 0),  _WHITE),
        ("TEXTCOLOR",   (1, 1), (1, 1),   _GREEN),
        ("TEXTCOLOR",   (2, 1), (2, 1),   _ORANGE),
        ("TEXTCOLOR",   (3, 1), (3, 1),   _RED),
        ("BACKGROUND",  (0, 0), (-1, 0),  _NAVY),
        ("BACKGROUND",  (0, 1), (-1, 1),  colors.HexColor("#EBF3FF")),
        ("ALIGN",       (0, 0), (-1, -1), "CENTER"),
        ("GRID",        (0, 0), (-1, -1), 0.4, _BORDER),
        ("TOPPADDING",  (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING",(0,0), (-1, -1), 7),
    ]))
    story.append(kpi_t)
    story.append(Spacer(1, 0.4 * cm))

    # ─── Pool Analytics charts ────────────────────────────────────────────────
    story += _section_header("📊 Pool Analytics", styles)

    if len(results) >= 2:
        # Row 1: Score distribution + Rankings bar
        dist_img = _fig_to_image_flowable(_make_score_dist(results),
                                           width_cm=8.3, height_cm=5.5)
        bar_img  = _fig_to_image_flowable(_make_pool_bar(results[:20]),
                                           width_cm=8.3, height_cm=5.5)
        row1 = Table([[dist_img or "", bar_img or ""]],
                     colWidths=[8.7 * cm, 8.7 * cm])
        row1_lbl = Table(
            [[Paragraph("Score Distribution", label_s),
              Paragraph("Candidate Rankings (top 20)", label_s)]],
            colWidths=[8.7 * cm, 8.7 * cm])
        for t in (row1_lbl, row1):
            t.setStyle(TableStyle([
                ("ALIGN",  (0, 0), (-1, -1), "CENTER"),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]))
        story.append(row1_lbl)
        story.append(row1)
        story.append(Spacer(1, 0.3 * cm))

        # Row 2: Decision donut + Tier pie
        donut_img = _fig_to_image_flowable(_make_fit_donut(results),
                                            width_cm=8.3, height_cm=5.5)
        # Tier pie
        tier_fig = go.Figure(go.Pie(
            labels=["Strong Fit (≥65%)", "Moderate Fit (45–65%)", "Weak Fit (<45%)"],
            values=[strong, mod, weak], hole=0.5,
            marker=dict(colors=[_FB_GREEN, _FB_ORANGE, _FB_RED],
                        line=dict(color="white", width=2)),
            textinfo="label+percent+value", textfont=dict(size=9),
        ))
        tier_fig.update_layout(height=260, margin=dict(t=20, b=20, l=20, r=20),
                                paper_bgcolor=_PLOT_BG, showlegend=False,
                                font={"family": "Helvetica"})
        tier_img = _fig_to_image_flowable(tier_fig, width_cm=8.3, height_cm=5.5)

        row2 = Table([[donut_img or "", tier_img or ""]],
                     colWidths=[8.7 * cm, 8.7 * cm])
        row2_lbl = Table(
            [[Paragraph("Decision Breakdown", label_s),
              Paragraph("Score Tier Summary", label_s)]],
            colWidths=[8.7 * cm, 8.7 * cm])
        for t in (row2_lbl, row2):
            t.setStyle(TableStyle([
                ("ALIGN",  (0, 0), (-1, -1), "CENTER"),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]))
        story.append(row2_lbl)
        story.append(row2)
        story.append(Spacer(1, 0.3 * cm))

        # Row 3: Multi-candidate radar
        radar_img = _fig_to_image_flowable(
            _make_pool_radar(results, top_n=min(5, len(results))),
            width_cm=17, height_cm=6.5)
        if radar_img:
            story.append(Paragraph("Top-5 Score Profile Radar Overlay", label_s))
            story.append(radar_img)
            story.append(Spacer(1, 0.3 * cm))

    # ─── Per-candidate sections ───────────────────────────────────────────────
    for rank, r in enumerate(results, 1):
        story.append(PageBreak())

        name         = r.get("full_name") or r.get("original_filename") or "Unknown"
        email        = r.get("email") or ""
        phone        = r.get("phone") or _get_parsed(r).get("phone") or ""
        location     = r.get("location") or ""
        gender       = r.get("gender") or ""
        nat          = r.get("nationality") or ""
        decision     = r.get("decision") or "needs_review"
        ts           = (r.get("screened_at") or "")[:16].replace("T", " ")
        comp         = r.get("composite_score", 0)
        rel          = r.get("relevance_score", 0)
        sem          = r.get("semantic_similarity", 0)
        pot          = r.get("potential_score", 0)
        conf         = r.get("parse_confidence") or 0.8
        anoms        = r.get("anomaly_count") or 0
        returning    = r.get("is_returning", False)
        rationale    = r.get("llm_rationale") or ""
        yoe          = r.get("years_of_experience") or ""
        fit_text     = _fit_label(comp)

        parsed       = _get_parsed(r)
        edu          = parsed.get("education") or []
        exp_lst      = parsed.get("experience") or []
        strengths    = _parse_list(r.get("strengths"))
        gaps         = _parse_list(r.get("gaps"))
        tech_skills  = _parse_list(r.get("technical_skills") or parsed.get("technical_skills"))
        soft_skills  = _parse_list(r.get("soft_skills") or parsed.get("soft_skills"))
        transferable = _parse_list(r.get("transferable_skills"))
        insights     = _parse_list(r.get("value_add_insights"))

        # No-JD data
        _sb           = r.get("score_breakdown") or {}
        _is_no_jd     = bool(_sb.get("no_jd_mode")) or (r.get("ai_summary") or "").startswith("[NO JD]")
        _suggested    = _sb.get("suggested_departments") or []
        _best_cluster = _sb.get("best_cluster") or ""
        _top_clusters = _sb.get("top_clusters") or []
        _seniority    = _sb.get("seniority_band") or ""

        # ── Candidate header ──────────────────────────────────────────────────
        story.append(_candidate_header_table(
            rank=rank, name=name, email=email,
            decision=decision, fit_text=fit_text, ts=ts, comp=comp, styles=styles))
        story.append(Spacer(1, 0.25 * cm))

        # ── Personal Info ─────────────────────────────────────────────────────
        story += _section_header("Personal Information", styles)
        info_rows = [
            ["Email",       email    or "—"],
            ["Phone",       phone    or "—"],
            ["Location",    location or "—"],
            ["Gender",      gender   or "—"],
            ["Nationality", nat      or "—"],
            ["Experience",  f"{yoe} yrs" if yoe else "—"],
        ]
        story.append(_kv_table(info_rows))

        if edu:
            story += _section_header("Education", styles)
            story.append(_kv_table([
                [e.get("degree",""), f"{e.get('field','')}  ·  {e.get('institution','')}  ·  {e.get('graduation_year','')}"]
                for e in edu[:3]
            ]))

        if exp_lst:
            story += _section_header("Work Experience", styles)
            story.append(_kv_table([
                [e.get("role",""), f"{e.get('company','')}  ·  {e.get('start_date','')} – {e.get('end_date','')}"]
                for e in exp_lst[:4]
            ]))

        story.append(Spacer(1, 0.2 * cm))

        # ── Score Intelligence ────────────────────────────────────────────────
        story += _section_header("📊 Score Intelligence", styles)
        story.append(_score_table(comp, rel, sem, pot))
        story.append(Spacer(1, 0.2 * cm))

        story.append(Paragraph(
            f"({int(rel*100)} × 0.40) + ({int(sem*100)} × 0.35) + "
            f"({int(pot*100)} × 0.25) = <b>{int(comp*100)}</b>",
            ParagraphStyle("Formula2", parent=normal, fontSize=8,
                           fontName="Helvetica", textColor=_GREY,
                           backColor=_LGREY, leftIndent=8,
                           spaceBefore=2, spaceAfter=6, leading=13),
        ))

        # Charts row: gauge | radar | waterfall
        g_img  = _fig_to_image_flowable(_make_gauge(comp),              width_cm=5.5, height_cm=5.2)
        rd_img = _fig_to_image_flowable(_make_radar(rel, sem, pot),     width_cm=5.8, height_cm=5.2)
        w_img  = _fig_to_image_flowable(_make_waterfall(rel,sem,pot,comp), width_cm=5.8, height_cm=5.2)

        lbl_row = Table(
            [[Paragraph("Composite Gauge", label_s),
              Paragraph("Score Profile Radar", label_s),
              Paragraph("Score Contribution", label_s)]],
            colWidths=[5.8 * cm] * 3)
        chart_row = Table([[g_img or "", rd_img or "", w_img or ""]],
                          colWidths=[5.8 * cm] * 3)
        for ct in (lbl_row, chart_row):
            ct.setStyle(TableStyle([
                ("ALIGN",  (0, 0), (-1, -1), "CENTER"),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]))
        story.append(lbl_row)
        story.append(chart_row)
        story.append(Spacer(1, 0.25 * cm))

        # Sub-score breakdown bars
        bd_data = [
            ["Relevance Score",     f"{int(rel*100)}%", "40% — LLM JD/CV alignment"],
            ["Semantic Similarity", f"{int(sem*100)}%", "35% — vector embedding cosine"],
            ["Potential Score",     f"{int(pot*100)}%", "25% — career trajectory signals"],
        ]
        bd_t = Table(bd_data, colWidths=[5*cm, 2*cm, 10*cm])
        bd_t.setStyle(TableStyle([
            ("FONTNAME",   (0,0),(0,-1), "Helvetica-Bold"),
            ("FONTNAME",   (1,0),(1,-1), "Helvetica-Bold"),
            ("FONTNAME",   (2,0),(2,-1), "Helvetica"),
            ("FONTSIZE",   (0,0),(-1,-1), 9),
            ("TEXTCOLOR",  (1,0),(1,-1), _score_rl(comp)),
            ("TEXTCOLOR",  (2,0),(2,-1), _GREY),
            ("ROWBACKGROUNDS",(0,0),(-1,-1),[_WHITE, colors.HexColor("#FAFBFC")]),
            ("GRID",       (0,0),(-1,-1), 0.4, _BORDER),
            ("TOPPADDING", (0,0),(-1,-1), 5),
            ("BOTTOMPADDING",(0,0),(-1,-1), 5),
            ("LEFTPADDING",(0,0),(-1,-1), 8),
        ]))
        story.append(bd_t)
        story.append(Spacer(1, 0.25 * cm))

        # ── Strength & Gap Analysis ───────────────────────────────────────────
        story += _section_header("✅ Strength & Gap Analysis", styles)
        str_items = [Paragraph(f"▲  {s}", body_s) for s in strengths] or [Paragraph("—", body_s)]
        gap_items = [Paragraph(f"▼  {g}", body_s) for g in gaps]       or [Paragraph("—", body_s)]

        sg_data = [[
            [Paragraph("<b>✓ Strengths</b>",
                       ParagraphStyle("SHdr3", parent=normal, fontSize=9,
                                      textColor=colors.HexColor("#1A6B1E"),
                                      fontName="Helvetica-Bold", spaceAfter=5))] + str_items,
            [Paragraph("<b>⚠ Gaps</b>",
                       ParagraphStyle("GHdr3", parent=normal, fontSize=9,
                                      textColor=colors.HexColor("#E65100"),
                                      fontName="Helvetica-Bold", spaceAfter=5))] + gap_items,
        ]]
        sg_t = Table(sg_data, colWidths=[8.7*cm, 8.7*cm])
        sg_t.setStyle(TableStyle([
            ("VALIGN",        (0,0),(-1,-1), "TOP"),
            ("BACKGROUND",    (0,0),(0,-1),  colors.HexColor("#E7F3E8")),
            ("BACKGROUND",    (1,0),(1,-1),  colors.HexColor("#FFF3E0")),
            ("GRID",          (0,0),(-1,-1), 0.4, _BORDER),
            ("TOPPADDING",    (0,0),(-1,-1), 8),
            ("BOTTOMPADDING", (0,0),(-1,-1), 8),
            ("LEFTPADDING",   (0,0),(-1,-1), 10),
        ]))
        story.append(sg_t)
        story.append(Spacer(1, 0.15 * cm))

        if strengths:
            s_chart = _fig_to_image_flowable(
                _make_skills_hbar(strengths, _FB_BLUE), width_cm=17,
                height_cm=max(2.5, min(len(strengths) * 0.55, 6)))
            if s_chart:
                story.append(Paragraph("Strength Signal Depth", label_s))
                story.append(s_chart)
                story.append(Spacer(1, 0.15 * cm))

        if gaps:
            g_chart = _fig_to_image_flowable(
                _make_skills_hbar(gaps, _FB_RED), width_cm=17,
                height_cm=max(2.5, min(len(gaps) * 0.55, 5)))
            if g_chart:
                story.append(Paragraph("Gap Signal Depth", label_s))
                story.append(g_chart)
                story.append(Spacer(1, 0.15 * cm))

        # ── Skills Breakdown ──────────────────────────────────────────────────
        if tech_skills or soft_skills:
            story += _section_header("🛠 Skills Breakdown", styles)
            tech_items   = [Paragraph(s, ParagraphStyle("TChip", parent=normal, fontSize=8,
                               leading=12, textColor=colors.HexColor("#1877F2"),
                               fontName="Helvetica")) for s in tech_skills[:20]] or [Paragraph("—", body_s)]
            soft_items   = [Paragraph(s, ParagraphStyle("SChip", parent=normal, fontSize=8,
                               leading=12, textColor=colors.HexColor("#6B2FA0"),
                               fontName="Helvetica")) for s in soft_skills[:15]] or [Paragraph("—", body_s)]
            sk_data = [[
                [Paragraph("<b>Technical Skills</b>",
                           ParagraphStyle("TH", parent=normal, fontSize=9,
                                          fontName="Helvetica-Bold", textColor=colors.HexColor("#1877F2"),
                                          spaceAfter=5))] + tech_items,
                [Paragraph("<b>Soft Skills</b>",
                           ParagraphStyle("SH", parent=normal, fontSize=9,
                                          fontName="Helvetica-Bold", textColor=colors.HexColor("#6B2FA0"),
                                          spaceAfter=5))] + soft_items,
            ]]
            sk_t = Table(sk_data, colWidths=[8.7*cm, 8.7*cm])
            sk_t.setStyle(TableStyle([
                ("VALIGN",        (0,0),(-1,-1), "TOP"),
                ("BACKGROUND",    (0,0),(0,-1),  colors.HexColor("#E7F0FF")),
                ("BACKGROUND",    (1,0),(1,-1),  colors.HexColor("#F3E8FF")),
                ("GRID",          (0,0),(-1,-1), 0.4, _BORDER),
                ("TOPPADDING",    (0,0),(-1,-1), 8),
                ("BOTTOMPADDING", (0,0),(-1,-1), 8),
                ("LEFTPADDING",   (0,0),(-1,-1), 10),
            ]))
            story.append(sk_t)
            story.append(Spacer(1, 0.15 * cm))

            if len(tech_skills) > 3:
                ts_chart = _fig_to_image_flowable(
                    _make_skills_hbar(tech_skills[:10], _FB_BLUE), width_cm=17,
                    height_cm=max(2.5, min(len(tech_skills[:10]) * 0.65, 6)))
                if ts_chart:
                    story.append(ts_chart)
                    story.append(Spacer(1, 0.15 * cm))

        # ── Transferable Skills ───────────────────────────────────────────────
        if transferable:
            story += _section_header("🔄 Transferable Skills", styles)
            TECH_KW_PDF = {"python","sql","spark","cloud","azure","aws","gcp","kafka","airflow",
                           "ml","ai","etl","pipeline","databricks","power bi","tableau","data",
                           "engineering","model","docker","scala","java","react","node","typescript"}
            tech_t   = [s for s in transferable if any(kw in s.lower() for kw in TECH_KW_PDF)]
            domain_t = [s for s in transferable if s not in tech_t]
            tr_data = [[
                [Paragraph("<b>Technical</b>",
                           ParagraphStyle("TrTH", parent=normal, fontSize=9,
                                          fontName="Helvetica-Bold", textColor=colors.HexColor("#1877F2"),
                                          spaceAfter=5))] +
                ([Paragraph(s, body_s) for s in tech_t] or [Paragraph("—", body_s)]),

                [Paragraph("<b>Domain</b>",
                           ParagraphStyle("TrDH", parent=normal, fontSize=9,
                                          fontName="Helvetica-Bold", textColor=colors.HexColor("#6B2FA0"),
                                          spaceAfter=5))] +
                ([Paragraph(s, body_s) for s in domain_t] or [Paragraph("—", body_s)]),
            ]]
            tr_t = Table(tr_data, colWidths=[8.7*cm, 8.7*cm])
            tr_t.setStyle(TableStyle([
                ("VALIGN",        (0,0),(-1,-1), "TOP"),
                ("BACKGROUND",    (0,0),(0,-1),  colors.HexColor("#E7F0FF")),
                ("BACKGROUND",    (1,0),(1,-1),  colors.HexColor("#F3E8FF")),
                ("GRID",          (0,0),(-1,-1), 0.4, _BORDER),
                ("TOPPADDING",    (0,0),(-1,-1), 8),
                ("BOTTOMPADDING", (0,0),(-1,-1), 8),
                ("LEFTPADDING",   (0,0),(-1,-1), 10),
            ]))
            story.append(tr_t)
            story.append(Spacer(1, 0.15 * cm))

        # ── Strategic Insights ────────────────────────────────────────────────
        if insights:
            story += _section_header("💡 Strategic Insights", styles)
            for idx, insight in enumerate(insights, 1):
                story.append(Paragraph(
                    f"<b>{idx:02d}.</b>  {insight}",
                    ParagraphStyle("Ins3", parent=normal, fontSize=9,
                                   leading=14, textColor=_TEXT,
                                   fontName="Helvetica", backColor=_LGREY,
                                   leftIndent=8, spaceBefore=3, spaceAfter=3),
                ))
            story.append(Spacer(1, 0.15 * cm))

        # ── AI Rationale ──────────────────────────────────────────────────────
        if rationale:
            story += _section_header("🧠 AI Rationale", styles)
            story.append(Paragraph(
                rationale[:2000],
                ParagraphStyle("Rat3", parent=normal, fontSize=9,
                               leading=15, textColor=_TEXT,
                               fontName="Helvetica-Oblique",
                               backColor=colors.HexColor("#F8F9FF"),
                               leftIndent=8, rightIndent=8,
                               spaceBefore=4, spaceAfter=4),
            ))
            story.append(Spacer(1, 0.15 * cm))

        # ── Department Fit Analysis (No-JD) ───────────────────────────────────
        if _is_no_jd:
            story += _section_header("🏢 Department Fit Analysis (No-JD Mode)", styles)
            story.append(Paragraph(
                f"⚠ No-JD Mode: Score capped at 72%. Seniority band: {_seniority or '—'}",
                ParagraphStyle("NoJDWarn", parent=normal, fontSize=8.5,
                               fontName="Helvetica-Bold", textColor=colors.HexColor("#7A5700"),
                               backColor=colors.HexColor("#FFF8E6"),
                               leftIndent=8, spaceBefore=4, spaceAfter=6),
            ))
            if _best_cluster:
                story.append(Paragraph(
                    f"Best-Fit Cluster: <b>{_best_cluster}</b>",
                    ParagraphStyle("BestCluster", parent=normal, fontSize=10,
                                   fontName="Helvetica-Bold", textColor=colors.HexColor("#1877F2"),
                                   spaceBefore=4, spaceAfter=6),
                ))
            if _top_clusters:
                _cnames  = [c["cluster"][:40] for c in _top_clusters]
                _cscores = [c["score"] * 100 for c in _top_clusters]
                _cfig = go.Figure(go.Bar(
                    x=_cscores, y=_cnames, orientation="h",
                    marker_color=[_FB_BLUE if i == 0 else _FB_GREY for i in range(len(_cnames))],
                    text=[f"{s:.0f}%" for s in _cscores], textposition="outside", showlegend=False,
                ))
                _cfig.update_layout(height=max(180, len(_cnames)*34+40),
                    margin=dict(t=10,b=10,l=10,r=40),
                    paper_bgcolor=_PLOT_BG, plot_bgcolor=_PLOT_BG,
                    xaxis=dict(range=[0,110], ticksuffix="%", gridcolor="#F0F2F5"),
                    yaxis=dict(tickfont=dict(size=10)), font={"family":"Helvetica"})
                _cimg = _fig_to_image_flowable(_cfig, width_cm=17,
                    height_cm=max(3, min(len(_cnames) * 0.8, 8)))
                if _cimg:
                    story.append(Paragraph("All Cluster Scores", label_s))
                    story.append(_cimg)
                    story.append(Spacer(1, 0.15 * cm))
            if _suggested:
                story += [Paragraph("Suggested Departments", label_s)]
                dept_rows = [["Department", "Fit Score"]]
                dept_rows += [[item["department"], f"{int(item['score']*100)}%"]
                              for item in _suggested[:8]]
                d_t = Table(dept_rows, colWidths=[13*cm, 4.4*cm])
                d_t.setStyle(TableStyle([
                    ("FONTNAME",    (0,0),(-1,0),  "Helvetica-Bold"),
                    ("FONTSIZE",    (0,0),(-1,-1), 9),
                    ("TEXTCOLOR",   (0,0),(-1,0),  _WHITE),
                    ("BACKGROUND",  (0,0),(-1,0),  _NAVY),
                    ("ROWBACKGROUNDS",(0,1),(-1,-1),[_WHITE, colors.HexColor("#FAFBFC")]),
                    ("GRID",        (0,0),(-1,-1), 0.4, _BORDER),
                    ("ALIGN",       (1,0),(1,-1),  "CENTER"),
                    ("TOPPADDING",  (0,0),(-1,-1), 5),
                    ("BOTTOMPADDING",(0,0),(-1,-1), 5),
                    ("LEFTPADDING", (0,0),(-1,-1), 8),
                ]))
                story.append(d_t)
                story.append(Spacer(1, 0.15 * cm))

        # ── System Signals ────────────────────────────────────────────────────
        story += _section_header("📡 System Signals", styles)
        sig_data = [
            ["Composite", "Anomaly Flags", "Returning", "Parse Confidence"],
            [f"{int(comp*100)}%", str(anoms),
             "Yes" if returning else "No", f"{int(conf*100)}%"],
        ]
        sig_t = Table(sig_data, colWidths=[4.25*cm]*4)
        sig_t.setStyle(TableStyle([
            ("FONTNAME",     (0,0),(-1,0),  "Helvetica-Bold"),
            ("FONTNAME",     (0,1),(-1,1),  "Helvetica-Bold"),
            ("FONTSIZE",     (0,0),(-1,0),  8),
            ("FONTSIZE",     (0,1),(-1,1),  13),
            ("TEXTCOLOR",    (0,0),(-1,0),  _WHITE),
            ("TEXTCOLOR",    (0,1),(0,1),   _score_rl(comp)),
            ("TEXTCOLOR",    (1,1),(1,1),   _RED if anoms else _GREEN),
            ("BACKGROUND",   (0,0),(-1,0),  _NAVY),
            ("BACKGROUND",   (0,1),(-1,1),  colors.HexColor("#EBF3FF")),
            ("ALIGN",        (0,0),(-1,-1), "CENTER"),
            ("GRID",         (0,0),(-1,-1), 0.4, _BORDER),
            ("TOPPADDING",   (0,0),(-1,-1), 6),
            ("BOTTOMPADDING",(0,0),(-1,-1), 6),
        ]))
        story.append(sig_t)

        # Per-candidate footer
        story.append(Spacer(1, 0.4 * cm))
        story.append(HRFlowable(width="100%", thickness=0.4, color=_BORDER))
        story.append(Paragraph(
            f"Candidate {rank} of {len(results)}  ·  TalentScan AI  ·  For HR use only",
            ParagraphStyle("CandFtr2", parent=normal, fontSize=7,
                           textColor=_GREY, alignment=TA_CENTER, spaceBefore=4),
        ))

    # ── Final footer page ─────────────────────────────────────────────────────
    story.append(PageBreak())
    story.append(Spacer(1, 4 * cm))
    story.append(Paragraph(
        "<b>End of Report</b>",
        ParagraphStyle("End", parent=normal, fontSize=18, textColor=_NAVY,
                       fontName="Helvetica-Bold", alignment=TA_CENTER),
    ))
    story.append(Spacer(1, 0.4 * cm))
    story.append(Paragraph(
        f"TalentScan AI  ·  {role_name}  ·  "
        f"{len(results)} candidates reviewed  ·  "
        f"{datetime.now().strftime('%d %b %Y, %H:%M')}",
        ParagraphStyle("EndSub", parent=normal, fontSize=10,
                       textColor=_GREY, alignment=TA_CENTER),
    ))

    doc.build(story)
    buf.seek(0)
    return buf.getvalue()


import sys
sys.path.insert(0, "/app/frontend")
from shared_style import CSS, topnav, sidebar_nav, page_header, sidebar_status_footer

st.set_page_config(
    page_title="TalentScan · Detailed Insights",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded",
)
st.markdown(CSS, unsafe_allow_html=True)

st.title("Dashboard")

API_BASE = os.getenv("API_URL", "http://api:8000")
API      = f"{API_BASE}/api/v1"

FB_BLUE   = "#1877F2"
FB_GREEN  = "#42B72A"
FB_ORANGE = "#F5A623"
FB_RED    = "#FA3E3E"
FB_GREY   = "#BCC0C4"
FB_PURPLE = "#6B2FA0"
PLOT_BG   = "#FFFFFF"

# ── CSS ───────────────────────────────────────────────────────────────────────



# ── Helpers ───────────────────────────────────────────────────────────────────
def parse_list(val):
    if isinstance(val, list): return val
    if not val: return []
    try:
        r = json.loads(val)
        return r if isinstance(r, list) else [str(r)]
    except Exception:
        return [str(val)] if val else []

def score_color(s):
    return FB_GREEN if s >= 0.65 else (FB_ORANGE if s >= 0.45 else FB_RED)

def fill_cls(s):
    return "fill-green" if s >= 0.65 else ("fill-orange" if s >= 0.45 else "fill-red")

def fit_label(s):
    if s >= 0.65: return ("Strong Fit", "strong")
    if s >= 0.45: return ("Moderate Fit", "moderate")
    return ("Weak Fit", "weak")

def badge_html(decision):
    d = (decision or "unknown").lower()
    label = (decision or "unknown").replace("_", " ").title()
    if "shortlisted" in d or "approved" in d: cls, dot = "badge-green",  "#42B72A"
    elif "rejected" in d:                      cls, dot = "badge-red",    "#FA3E3E"
    elif "hold" in d:                          cls, dot = "badge-grey",   "#BCC0C4"
    elif "forward" in d:                       cls, dot = "badge-blue",   "#1877F2"
    else:                                      cls, dot = "badge-orange", "#F5A623"
    return f'<span class="badge {cls}"><span class="badge-dot" style="background:{dot};"></span>{label}</span>'

def initials(name):
    parts = (name or "?").split()
    return "".join(p[0] for p in parts[:2]).upper()

def safe_float(val, default=0.0):
    try: return float(str(val).split()[0])
    except: return default

def get_parsed(r):
    p = r.get("parsed_data") or {}
    if isinstance(p, str):
        try: p = json.loads(p)
        except: p = {}
    return p

def subscore_html(name, value, weight):
    pct = int(value * 100)
    col = score_color(value); fc = fill_cls(value)
    return f"""<div class="sbar-row">
      <div class="sbar-header">
        <span class="sbar-name">{name} <span class="sbar-weight">{weight}</span></span>
        <span class="sbar-val" style="color:{col};">{pct}%</span>
      </div>
      <div class="sbar-track"><div class="sbar-fill {fc}" style="width:{pct}%;"></div></div>
    </div>"""

TECH_KW = {"python","sql","spark","cloud","azure","aws","gcp","kafka","airflow","api",
            "ml","ai","etl","pipeline","databricks","power bi","tableau","data",
            "engineering","model","docker","scala","java","react","node","typescript"}


# ── Chart helpers ──────────────────────────────────────────────────────────────
def gauge_chart(value, key_suffix=""):
    pct = value * 100; color = score_color(value)
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=pct,
        number={"suffix": "%", "font": {"size": 38, "color": "#050505"}},
        title={"text": "Composite Score", "font": {"size": 12, "color": "#65676B"}},
        gauge={"axis": {"range": [0, 100], "tickvals": [0,25,50,65,75,100],
                        "tickfont": {"size": 9, "color": "#BCC0C4"}},
               "bar": {"color": color, "thickness": 0.3},
               "bgcolor": "#F0F2F5", "bordercolor": "#E4E6EB",
               "steps": [{"range": [0,45],  "color": "#FFECEC"},
                         {"range": [45,65], "color": "#FFF4E5"},
                         {"range": [65,100],"color": "#E6F9EE"}],
               "threshold": {"line": {"color": color, "width": 3}, "thickness": 0.8, "value": pct}},
    ))
    fig.update_layout(height=220, margin=dict(t=30,b=10,l=20,r=20),
                      paper_bgcolor=PLOT_BG, font={"family": "Inter"})
    return fig

def radar_chart(rel, sem, pot, key_suffix=""):
    cats = ["Relevance<br>Score", "Semantic<br>Similarity", "Potential<br>Score"]
    vals = [rel*100, sem*100, pot*100]
    fig  = go.Figure(go.Scatterpolar(
        r=vals+[vals[0]], theta=cats+[cats[0]],
        fill="toself", fillcolor="rgba(24,119,242,0.12)",
        line=dict(color=FB_BLUE, width=2), marker=dict(color=FB_BLUE, size=6),
        hovertemplate="%{theta}: %{r:.0f}%<extra></extra>"
    ))
    fig.update_layout(
        polar=dict(bgcolor="#F0F2F5",
            radialaxis=dict(visible=True, range=[0,100], tickvals=[0,25,50,75,100],
                            tickfont=dict(size=9, color="#BCC0C4"), gridcolor="#E4E6EB"),
            angularaxis=dict(tickfont=dict(size=11, color="#050505"), gridcolor="#E4E6EB")),
        showlegend=False, height=260, margin=dict(t=20,b=20,l=50,r=50),
        paper_bgcolor=PLOT_BG, font={"family": "Inter"}
    )
    return fig

def waterfall_chart(rel, sem, pot, composite, key_suffix=""):
    r = rel*0.40*100; s = sem*0.35*100; p = pot*0.25*100
    color = score_color(composite)
    fig = go.Figure(go.Waterfall(
        orientation="v", measure=["relative","relative","relative","total"],
        x=["Relevance<br>×40%","Semantic<br>×35%","Potential<br>×25%","Composite<br>Score"],
        y=[r, s, p, 0],
        text=[f"{r:.1f}",f"{s:.1f}",f"{p:.1f}",f"{composite*100:.1f}"],
        textposition="outside", textfont={"size": 11, "color": "#050505"},
        increasing={"marker": {"color": FB_BLUE}},
        totals={"marker": {"color": color}},
        connector={"line": {"color": "#E4E6EB", "width": 1}},
        hovertemplate="%{x}: %{y:.1f} pts<extra></extra>"
    ))
    fig.update_layout(height=280, margin=dict(t=30,b=10,l=10,r=10),
        paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
        xaxis=dict(showgrid=False, tickfont=dict(size=11, color="#050505")),
        yaxis=dict(range=[0,110], gridcolor="#F0F2F5",
                   tickfont=dict(size=10, color="#65676B"), title="Score Points"),
        showlegend=False, font={"family": "Inter"})
    return fig

def pool_bar_chart(results):
    if len(results) < 2: return None
    names  = [(r.get("full_name") or f"#{i+1}")[:20] for i,r in enumerate(results)]
    scores = [r.get("composite_score",0)*100 for r in results]
    colors = [score_color(s/100) for s in scores]
    fig = go.Figure(go.Bar(
        x=names, y=scores, marker_color=colors,
        text=[f"{s:.0f}%" for s in scores], textposition="outside",
        textfont=dict(size=10, color="#050505"),
        hovertemplate="%{x}: %{y:.1f}%<extra></extra>", showlegend=False
    ))
    fig.add_hline(y=65, line_dash="dot", line_color=FB_GREEN,
                  annotation_text="Shortlist ≥65%",
                  annotation_font_size=10, annotation_font_color=FB_GREEN)
    fig.add_hline(y=45, line_dash="dot", line_color=FB_ORANGE,
                  annotation_text="Review ≥45%",
                  annotation_font_size=10, annotation_font_color=FB_ORANGE)
    fig.update_layout(height=300, margin=dict(t=30,b=10,l=10,r=10),
        paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
        xaxis=dict(tickfont=dict(size=10, color="#050505"), showgrid=False),
        yaxis=dict(range=[0,115], gridcolor="#F0F2F5",
                   tickfont=dict(size=10, color="#65676B"), title="Score (%)"),
        bargap=0.3, font={"family": "Inter"})
    return fig

def score_distribution_chart(results):
    scores = [r.get("composite_score",0)*100 for r in results]
    fig = go.Figure(go.Histogram(
        x=scores, nbinsx=20,
        marker_color=FB_BLUE, marker_opacity=0.75,
        hovertemplate="Score band %{x:.0f}%: %{y} candidates<extra></extra>"
    ))
    fig.add_vline(x=65, line_dash="dot", line_color=FB_GREEN,
                  annotation_text="65% threshold", annotation_font_size=10)
    fig.add_vline(x=45, line_dash="dot", line_color=FB_ORANGE,
                  annotation_text="45% threshold", annotation_font_size=10)
    fig.update_layout(height=250, margin=dict(t=30,b=20,l=30,r=10),
        paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
        xaxis=dict(title="AI Score (%)", gridcolor="#F0F2F5",
                   tickfont=dict(size=10, color="#65676B")),
        yaxis=dict(title="Candidates", gridcolor="#F0F2F5",
                   tickfont=dict(size=10, color="#65676B")),
        showlegend=False, font={"family": "Inter"})
    return fig

def experience_histogram(results):
    exps = []
    for r in results:
        parsed = get_parsed(r)
        v = r.get("years_of_experience") or parsed.get("total_years_exp")
        try: exps.append(float(str(v).split()[0]))
        except: pass
    if not exps: return None
    fig = go.Figure(go.Histogram(
        x=exps, nbinsx=12,
        marker_color=FB_PURPLE, marker_opacity=0.75,
        hovertemplate="%{x:.0f} yrs: %{y} candidates<extra></extra>"
    ))
    fig.update_layout(height=220, margin=dict(t=30,b=20,l=30,r=10),
        paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
        xaxis=dict(title="Years of Experience", gridcolor="#F0F2F5",
                   tickfont=dict(size=10)),
        yaxis=dict(title="Candidates", gridcolor="#F0F2F5",
                   tickfont=dict(size=10)),
        showlegend=False, font={"family": "Inter"})
    return fig

def dept_bar_chart(results):
    def _dept(r):
        parsed = get_parsed(r)
        domain = parse_list(parsed.get("domain_expertise"))
        tech   = parse_list(r.get("technical_skills") or parsed.get("technical_skills"))
        text   = " ".join([str(x) for x in domain] + [str(x) for x in tech] +
                          [r.get("current_designation") or ""]).lower()
        if any(k in text for k in ["finance","accounting","treasury","audit"]): return "Finance"
        if any(k in text for k in ["data","analytics","bi","tableau","power bi","databricks","sql","python","ml","ai"]): return "Data & Analytics"
        if any(k in text for k in ["hr","human resource","talent","recruit"]): return "HR"
        if any(k in text for k in ["marketing","brand","digital","seo"]): return "Marketing"
        if any(k in text for k in ["sales","revenue","business development","crm"]): return "Sales"
        if any(k in text for k in ["engineering","software","developer","devops","cloud"]): return "Engineering"
        if any(k in text for k in ["operations","supply chain","logistics"]): return "Operations"
        if any(k in text for k in ["legal","compliance","regulatory","risk"]): return "Legal"
        if any(k in text for k in ["project","program","pmo","agile"]): return "PMO"
        return "General"

    counts = Counter(_dept(r) for r in results)
    labels = list(counts.keys()); values = list(counts.values())
    clrs = [FB_BLUE, FB_GREEN, FB_ORANGE, FB_PURPLE, FB_RED,
            "#0F2D6B", "#17A589", "#E67E22", "#8E44AD", "#2ECC71"]
    fig = go.Figure(go.Bar(
        y=labels, x=values, orientation="h",
        marker_color=clrs[:len(labels)], marker_opacity=0.8,
        text=values, textposition="outside",
        hovertemplate="%{y}: %{x} candidates<extra></extra>", showlegend=False
    ))
    fig.update_layout(height=max(180, len(labels)*35+40), margin=dict(t=10,b=10,l=10,r=30),
        paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
        xaxis=dict(visible=True, gridcolor="#F0F2F5", tickfont=dict(size=10)),
        yaxis=dict(tickfont=dict(size=11)), bargap=0.3, font={"family": "Inter"})
    return fig

def fit_donut(results):
    labels_map = {
        "auto_shortlisted": ("Auto Shortlisted", FB_GREEN),
        "hr_approved":      ("HR Approved",      "#17A589"),
        "needs_review":     ("Needs Review",      FB_ORANGE),
        "hr_hold":          ("HR Hold",           FB_GREY),
        "auto_rejected":    ("Auto Rejected",     FB_RED),
        "hr_rejected":      ("HR Rejected",       "#C62828"),
        "forwarded":        ("Forwarded",          FB_BLUE),
    }
    counts = Counter(r.get("decision","needs_review") for r in results)
    labels = []; values = []; clrs = []
    for k, v in counts.items():
        lbl, col = labels_map.get(k, (k.replace("_"," ").title(), FB_GREY))
        labels.append(lbl); values.append(v); clrs.append(col)
    fig = go.Figure(go.Pie(
        labels=labels, values=values, hole=0.62,
        marker=dict(colors=clrs, line=dict(color="white", width=2)),
        textinfo="label+percent", textfont=dict(size=10),
        hovertemplate="%{label}: %{value}<extra></extra>"
    ))
    fig.update_layout(height=260, margin=dict(t=20,b=20,l=20,r=20),
        paper_bgcolor=PLOT_BG, showlegend=False, font={"family": "Inter"},
        annotations=[dict(text=f"<b>{sum(values)}</b><br>Total",
                          x=0.5, y=0.5, font_size=14, showarrow=False, font_color="#050505")])
    return fig

def skills_hbar(items, color=FB_BLUE):
    if not items: return None
    labels = [s[:48]+"…" if len(s)>48 else s for s in items[:10]]
    fig = go.Figure(go.Bar(
        x=list(range(len(labels),0,-1)), y=labels, orientation="h",
        marker_color=color, marker_opacity=0.78,
        hovertemplate="%{y}<extra></extra>", showlegend=False,
        text=labels, textposition="inside", insidetextanchor="start",
        textfont=dict(color="white", size=11)
    ))
    fig.update_layout(height=max(160, len(labels)*32+40), margin=dict(t=10,b=10,l=10,r=10),
        paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
        xaxis=dict(visible=False), yaxis=dict(visible=False),
        bargap=0.3, font={"family": "Inter"})
    return fig

def score_spider_pool(results, top_n=5):
    top = sorted(results, key=lambda x: x.get("composite_score",0), reverse=True)[:top_n]
    cats = ["Relevance", "Semantic", "Potential"]; cats_c = cats + [cats[0]]
    clrs = [FB_BLUE, FB_GREEN, FB_ORANGE, FB_PURPLE, FB_RED]
    fig = go.Figure()
    for i, r in enumerate(top):
        name = (r.get("full_name") or f"#{i+1}")[:18]
        vals = [r.get("relevance_score",0)*100, r.get("semantic_similarity",0)*100,
                r.get("potential_score",0)*100]
        fig.add_trace(go.Scatterpolar(
            r=vals+[vals[0]], theta=cats_c,
            fill="toself",
            fillcolor=f"rgba({int(clrs[i][1:3],16)},{int(clrs[i][3:5],16)},{int(clrs[i][5:7],16)},0.08)",
            line=dict(color=clrs[i], width=2), name=name,
            hovertemplate=f"{name} — %{{theta}}: %{{r:.0f}}%<extra></extra>"
        ))
    fig.update_layout(
        polar=dict(bgcolor="#F0F2F5",
            radialaxis=dict(visible=True, range=[0,100],
                            tickfont=dict(size=9, color="#BCC0C4"), gridcolor="#E4E6EB"),
            angularaxis=dict(tickfont=dict(size=12, color="#050505"), gridcolor="#E4E6EB")),
        showlegend=True, height=300, margin=dict(t=30,b=10,l=40,r=40),
        paper_bgcolor=PLOT_BG, font={"family": "Inter"},
        legend=dict(font=dict(size=10))
    )
    return fig


# ── Per-candidate Excel export ─────────────────────────────────────────────────
def build_candidate_excel(r, role_name=""):
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Candidate Profile"
    NAVY="0F2D6B"; BLUE="1877F2"; LIGHT="EBF3FF"
    BORDER_C="E2E6EA"; GRAY="8A9BB0"
    thin = Side(border_style="thin", color=BORDER_C)
    bdr  = Border(left=thin,right=thin,top=thin,bottom=thin)

    parsed     = get_parsed(r)
    edu        = parsed.get("education") or []
    exp_lst    = parsed.get("experience") or []
    strengths  = parse_list(r.get("strengths") or [])
    gaps       = parse_list(r.get("gaps") or [])
    tech_skills= parse_list(r.get("technical_skills") or parsed.get("technical_skills") or [])
    comp = r.get("composite_score",0); rel=r.get("relevance_score",0)
    sem  = r.get("semantic_similarity",0); pot=r.get("potential_score",0)
    fit_text, _ = fit_label(comp)
    name = r.get("full_name") or r.get("original_filename") or "Unknown"

    ws.merge_cells("A1:D1")
    c = ws["A1"]; c.value = f"TalentScan — Candidate Profile: {name}"
    c.font = Font(name="Calibri",bold=True,size=14,color="FFFFFF")
    c.fill = PatternFill("solid",fgColor=NAVY)
    c.alignment = Alignment(horizontal="left",vertical="center",indent=1)
    ws.row_dimensions[1].height = 30

    ws.merge_cells("A2:D2")
    c = ws["A2"]; c.value = f"Role: {role_name}   |   Screened: {(r.get('screened_at') or '')[:10]}   |   {fit_text}"
    c.font = Font(name="Calibri",size=10,color="FFFFFF"); c.fill = PatternFill("solid",fgColor=BLUE)
    c.alignment = Alignment(horizontal="left",vertical="center",indent=1)
    ws.row_dimensions[2].height = 20
    ws.row_dimensions[3].height = 6

    def hdr(row, text):
        ws.merge_cells(f"A{row}:D{row}")
        c = ws[f"A{row}"]; c.value = text
        c.font = Font(name="Calibri",bold=True,size=9,color=GRAY)
        c.fill = PatternFill("solid",fgColor="F7F8FC")
        c.alignment = Alignment(horizontal="left",vertical="center",indent=1)
        ws.row_dimensions[row].height = 18

    def row2(row, label, val):
        a = ws.cell(row=row,column=1,value=label)
        a.font = Font(name="Calibri",bold=True,size=10,color="050505"); a.border=bdr
        a.fill = PatternFill("solid",fgColor="F7F8FC")
        a.alignment = Alignment(vertical="top",indent=1)
        b = ws.cell(row=row,column=2,value=str(val) if val is not None else "")
        b.font = Font(name="Calibri",size=10); b.border=bdr
        b.alignment = Alignment(vertical="top",wrap_text=True)
        ws.merge_cells(f"B{row}:D{row}")
        ws.row_dimensions[row].height = 18

    ROW = 4
    hdr(ROW, "PERSONAL INFORMATION"); ROW+=1
    row2(ROW, "Full Name",  name);                                            ROW+=1
    row2(ROW, "Email",      r.get("email") or "");                            ROW+=1
    row2(ROW, "Phone",      r.get("phone") or parsed.get("phone") or "");     ROW+=1
    row2(ROW, "Location",   r.get("location") or "");                         ROW+=1
    row2(ROW, "Gender",     r.get("gender") or "");                           ROW+=1
    row2(ROW, "Nationality",r.get("nationality") or "");                      ROW+=1

    hdr(ROW, "EDUCATION"); ROW+=1
    if edu:
        for e in edu[:3]:
            row2(ROW, e.get("degree",""),
                 f"{e.get('field','')} | {e.get('institution','')} | {e.get('graduation_year','')}"); ROW+=1
    else:
        row2(ROW, "—", ""); ROW+=1

    hdr(ROW, "EXPERIENCE"); ROW+=1
    row2(ROW, "Total Years", r.get("years_of_experience") or parsed.get("total_years_exp") or ""); ROW+=1
    if exp_lst:
        for e in exp_lst[:4]:
            row2(ROW, e.get("role",""), f"{e.get('company','')} | {e.get('start_date','')} – {e.get('end_date','')}"); ROW+=1

    hdr(ROW, "AI SCORES"); ROW+=1
    for lbl, val in [("Composite Score", f"{int(comp*100)}%"),
                     ("Relevance Score", f"{int(rel*100)}%"),
                     ("Semantic Score",  f"{int(sem*100)}%"),
                     ("Potential Score", f"{int(pot*100)}%"),
                     ("Fit Status",      fit_text)]:
        row2(ROW, lbl, val); ROW+=1

    hdr(ROW, "STRENGTHS & GAPS"); ROW+=1
    row2(ROW, "Strengths", " | ".join(strengths[:8]) if strengths else ""); ROW+=1
    row2(ROW, "Gaps",      " | ".join(gaps[:8])      if gaps else "");      ROW+=1

    hdr(ROW, "TECHNICAL SKILLS"); ROW+=1
    row2(ROW, "Skills", ", ".join(tech_skills[:20]) if tech_skills else ""); ROW+=1

    hdr(ROW, "AI RATIONALE"); ROW+=1
    rat = r.get("llm_rationale") or ""
    ws.merge_cells(f"A{ROW}:D{ROW+3}")
    c = ws[f"A{ROW}"]; c.value = rat[:1500]; c.border=bdr
    c.font = Font(name="Calibri",size=10,italic=True)
    c.alignment = Alignment(wrap_text=True,vertical="top"); ROW+=4

    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 20
    ws.column_dimensions["D"].width = 20

    buf = io.BytesIO(); wb.save(buf); buf.seek(0); return buf.getvalue()


# ── Sidebar ────────────────────────────────────────────────────────────────────

# ── Job selector ───────────────────────────────────────────────────────────────
try:
    jobs_resp = requests.get(f"{API}/jobs/", timeout=10)
    if jobs_resp.status_code == 200:
        jobs_data = jobs_resp.json()
        if isinstance(jobs_data, dict):
            jobs = (jobs_data.get("jobs") or jobs_data.get("data")
                    or jobs_data.get("items") or [])
        elif isinstance(jobs_data, list):
            jobs = jobs_data
        else:
            jobs = []
        active_jobs = [j for j in jobs
                       if j.get("is_active", True)
                       or str(j.get("status","")).lower() in ("active","open","published","")]
        job_options = {
            str(j.get("title") or j.get("job_title") or f"Role {i+1}"): j.get("id")
            for i, j in enumerate(active_jobs) if j.get("id")
        }
    else:
        st.error(f"Jobs API failed: {jobs_resp.status_code}")
        job_options = {}
except Exception as e:
    st.error(f"Cannot load jobs: {e}")
    job_options = {}

if not job_options:
    st.warning("No active roles found.")
    st.stop()

st.markdown('<div class="sec-label">Active Role</div>', unsafe_allow_html=True)
selected_label  = st.selectbox("Role", list(job_options.keys()), label_visibility="collapsed")
selected_job_id = job_options[selected_label]

# ── Nav + Sidebar (after role is known) ───────────────────────────────────────
st.markdown(topnav("Detailed Insights", selected_label), unsafe_allow_html=True)
st.markdown(page_header("Detailed Insights", subtitle="Deep-dive into individual candidate profiles and AI scoring breakdown.", icon="🔬"), unsafe_allow_html=True)
sidebar_nav()

st.markdown('<div style="height:1px;background:#E4E6EB;margin:1rem 0;"></div>', unsafe_allow_html=True)
st.markdown('<div class="sec-label">Decision Filter</div>', unsafe_allow_html=True)
filter_decision = st.multiselect(
    "Decision",
    ["auto_shortlisted","auto_rejected","needs_review","hr_approved","hr_hold","hr_rejected","forwarded"],
    default=["auto_shortlisted","needs_review","hr_approved","hr_hold"],
    label_visibility="collapsed",
)

st.markdown('<div style="height:1px;background:#E4E6EB;margin:1rem 0;"></div>', unsafe_allow_html=True)
col_r1, col_r2 = st.columns(2)
with col_r1:
    if st.button("↻ Refresh", use_container_width=True):
        st.rerun()
with col_r2:
    auto = st.checkbox("Auto 30s")

if auto:
    time.sleep(30)
    st.rerun()

st.markdown("""
<div style="margin-top:1.5rem;background:#F0F2F5;border-radius:8px;padding:10px 12px;">
  <div class="sec-label">Scoring Weights</div>
  <div style="font-size:0.78rem;color:#050505;line-height:2.0;">
    Relevance &nbsp;·&nbsp; 40%<br>
    Semantic &nbsp;·&nbsp; 35%<br>
    Potential &nbsp;·&nbsp; 25%
  </div>
</div>
""", unsafe_allow_html=True)


# ── Fetch results ──────────────────────────────────────────────────────────────
try:
    resp = requests.get(f"{API}/screenings/results/{selected_job_id}",
                        params={"min_score": 0, "limit": 500}, timeout=15)
    if resp.status_code != 200:
        st.error(f"API error {resp.status_code}"); st.stop()
    all_results = resp.json()
    if not isinstance(all_results, list): all_results = []
except Exception as e:
    st.error(f"Cannot reach API: {e}"); st.stop()

results_by_decision = [r for r in all_results if isinstance(r, dict)
                       and (not filter_decision or r.get("decision") in filter_decision)]


# ── Top nav ────────────────────────────────────────────────────────────────────



# ── No-JD banner ──────────────────────────────────────────────────────────────
_no_jd_results = [r for r in all_results
                  if (r.get("score_breakdown") or {}).get("no_jd_mode") or
                  (r.get("ai_summary") or "").startswith("[NO JD]")]
if _no_jd_results:
    best_clusters = {}
    for r in _no_jd_results:
        bc = (r.get("score_breakdown") or {}).get("best_cluster","")
        if bc: best_clusters[bc] = best_clusters.get(bc, 0) + 1
    top_clusters_str = ", ".join(f"{k} ({v})" for k,v in
                                  sorted(best_clusters.items(), key=lambda x:-x[1])[:4])
    st.markdown(
        f'<div style="background:#FFF8E6;border:1px solid #FFD975;border-radius:8px;'
        f'padding:14px 18px;margin-bottom:1.2rem;font-size:0.82rem;color:#7A5700;">'
        f'<strong>⚠️ No-JD Generic Screening — {len(_no_jd_results)} candidate(s)</strong><br>'
        f'These CVs were screened without a Job Description using the organisation\'s department taxonomy. '
        f'Scores are capped at 72% and represent general department fit, not role-specific suitability. '
        f'Top department clusters: <strong>{top_clusters_str or "see individual cards"}</strong>.'
        f'<br><em>Add a JD to this role for full role-specific screening.</em></div>',
        unsafe_allow_html=True,
    )


# ── Pool Analytics ─────────────────────────────────────────────────────────────
if len(all_results) >= 2:
    st.markdown('<div class="fb-card-lg">', unsafe_allow_html=True)
    st.markdown('<div class="sec-label">📊  Pool Analytics</div>', unsafe_allow_html=True)

    tab1, tab2, tab3, tab4 = st.tabs(["Score Distribution", "Fit Breakdown + Rankings",
                                       "Experience & Dept", "Multi-Candidate Radar"])

    with tab1:
        col_dist1, col_dist2 = st.columns(2, gap="medium")
        with col_dist1:
            st.markdown('<div class="sec-label">AI Score Distribution</div>', unsafe_allow_html=True)
            st.plotly_chart(score_distribution_chart(all_results), use_container_width=True,
                            key="score_dist", config={"displayModeBar": False})
        with col_dist2:
            st.markdown('<div class="sec-label">Candidate Rankings (AI Score)</div>', unsafe_allow_html=True)
            fig = pool_bar_chart(all_results[:20])
            if fig:
                st.plotly_chart(fig, use_container_width=True, key="pool_bar",
                                config={"displayModeBar": False})

    with tab2:
        col_pie1, col_pie2 = st.columns(2, gap="medium")
        with col_pie1:
            st.markdown('<div class="sec-label">Decision Breakdown</div>', unsafe_allow_html=True)
            st.plotly_chart(fit_donut(all_results), use_container_width=True,
                            key="fit_donut", config={"displayModeBar": False})
        with col_pie2:
            st.markdown('<div class="sec-label">Score Tier Summary</div>', unsafe_allow_html=True)
            strong = sum(1 for r in all_results if r.get("composite_score",0)>=0.65)
            mod    = sum(1 for r in all_results if 0.45<=r.get("composite_score",0)<0.65)
            weak   = sum(1 for r in all_results if r.get("composite_score",0)<0.45)
            fig2 = go.Figure(go.Pie(
                labels=["Strong Fit (≥65%)", "Moderate Fit (45–65%)", "Weak Fit (<45%)"],
                values=[strong, mod, weak], hole=0.5,
                marker=dict(colors=[FB_GREEN, FB_ORANGE, FB_RED],
                            line=dict(color="white", width=2)),
                textinfo="label+percent+value", textfont=dict(size=11),
                hovertemplate="%{label}: %{value}<extra></extra>"
            ))
            fig2.update_layout(height=260, margin=dict(t=20,b=20,l=20,r=20),
                paper_bgcolor=PLOT_BG, showlegend=False, font={"family": "Inter"})
            st.plotly_chart(fig2, use_container_width=True, key="tier_pie",
                            config={"displayModeBar": False})

    with tab3:
        col_e1, col_e2 = st.columns(2, gap="medium")
        with col_e1:
            st.markdown('<div class="sec-label">Experience Distribution</div>', unsafe_allow_html=True)
            fig = experience_histogram(all_results)
            if fig:
                st.plotly_chart(fig, use_container_width=True, key="exp_hist",
                                config={"displayModeBar": False})
            else:
                st.caption("No experience data available.")
        with col_e2:
            st.markdown('<div class="sec-label">Inferred Department Fit</div>', unsafe_allow_html=True)
            st.plotly_chart(dept_bar_chart(all_results), use_container_width=True,
                            key="dept_bar", config={"displayModeBar": False})

    with tab4:
        st.markdown('<div class="sec-label">Top-5 Candidate Score Profile (Radar Overlay)</div>',
                    unsafe_allow_html=True)
        st.plotly_chart(score_spider_pool(all_results, top_n=min(5, len(all_results))),
                        use_container_width=True, key="pool_radar",
                        config={"displayModeBar": False})
        st.caption("Shows Relevance, Semantic, and Potential sub-scores for the top-5 candidates.")

    st.markdown('</div>', unsafe_allow_html=True)


# ── Smart Filter Panel ─────────────────────────────────────────────────────────
st.markdown('<div class="filter-panel">', unsafe_allow_html=True)
st.markdown('<div class="filter-title">🔍  Smart Filters</div>', unsafe_allow_html=True)

def unique_vals(field):
    vals = set()
    for r in all_results:
        v = r.get(field)
        if v and str(v).strip() not in ("—","","None"): vals.add(str(v).strip())
    return sorted(vals)

fcol1, fcol2, fcol3 = st.columns([3, 2, 2])
with fcol1: name_search = st.text_input("Candidate Name", placeholder="Type to filter by name…")
with fcol2: score_min, score_max = st.slider("Score Range (%)", 0, 100, (0, 100), step=5)
with fcol3: top5_only = st.toggle("🏆 Top 5 Only", value=False)

fcol4, fcol5, fcol6, fcol7 = st.columns(4)
loc_opts = ["All"] + list(dict.fromkeys(unique_vals("location") + unique_vals("city")))
nat_opts = ["All"] + unique_vals("nationality")
gen_opts = ["All"] + unique_vals("gender")
with fcol4: sel_location    = st.selectbox("Location",    loc_opts)
with fcol5: sel_nationality = st.selectbox("Nationality", nat_opts)
with fcol6: sel_gender      = st.selectbox("Gender",      gen_opts)
with fcol7: exp_range       = st.slider("Years Exp", 0, 30, (0, 30), step=1)

fcol8, fcol9, fcol10, fcol11 = st.columns(4)
emp_opts = ["All"] + list(dict.fromkeys(unique_vals("current_employer") + unique_vals("current_company")))
des_opts = ["All"] + list(dict.fromkeys(unique_vals("current_designation") +
                                         unique_vals("current_role") + unique_vals("job_title")))
with fcol8:  sel_company     = st.selectbox("Company",     emp_opts)
with fcol9:  sel_designation = st.selectbox("Designation", des_opts)
with fcol10: sel_fit = st.selectbox("Fit Category", ["All","Strong Fit","Moderate Fit","Weak Fit"])
with fcol11: sort_by = st.selectbox("Sort By", ["Highest Score","Lowest Score",
                                                  "Most Experience","Recently Added"])
st.markdown('</div>', unsafe_allow_html=True)


# ── Apply filters ──────────────────────────────────────────────────────────────
def get_exp_years(r):
    v = r.get("years_of_experience") or get_parsed(r).get("total_years_exp")
    return safe_float(v)

def matches_fit(r, sel):
    if sel == "All": return True
    s = r.get("composite_score",0)
    if sel == "Strong Fit":   return s >= 0.65
    if sel == "Moderate Fit": return 0.45 <= s < 0.65
    if sel == "Weak Fit":     return s < 0.45
    return True

filtered = []
for r in results_by_decision:
    comp      = r.get("composite_score",0)
    score_pct = int(comp*100)
    name_v    = (r.get("full_name") or r.get("original_filename") or "").lower()
    loc_v     = str(r.get("location") or r.get("city") or "").lower()
    nat_v     = str(r.get("nationality") or "").lower()
    gen_v     = str(r.get("gender") or "").lower()
    emp_v     = str(r.get("current_employer") or r.get("current_company") or "").lower()
    des_v     = str(r.get("current_designation") or r.get("current_role") or r.get("job_title") or "").lower()
    exp_v     = get_exp_years(r)
    if name_search and name_search.lower() not in name_v:                         continue
    if not (score_min <= score_pct <= score_max):                                 continue
    if sel_location    != "All" and sel_location.lower()    not in loc_v:         continue
    if sel_nationality != "All" and sel_nationality.lower() not in nat_v:         continue
    if sel_gender      != "All" and sel_gender.lower()      not in gen_v:         continue
    if sel_company     != "All" and sel_company.lower()     not in emp_v:         continue
    if sel_designation != "All" and sel_designation.lower() not in des_v:         continue
    if not (exp_range[0] <= exp_v <= exp_range[1]):                               continue
    if not matches_fit(r, sel_fit):                                               continue
    filtered.append(r)

if sort_by == "Highest Score":     filtered.sort(key=lambda x: x.get("composite_score",0), reverse=True)
elif sort_by == "Lowest Score":    filtered.sort(key=lambda x: x.get("composite_score",0))
elif sort_by == "Most Experience": filtered.sort(key=lambda x: get_exp_years(x), reverse=True)
elif sort_by == "Recently Added":  filtered.sort(key=lambda x: x.get("screened_at") or "", reverse=True)

results = filtered[:5] if top5_only else filtered

active_filters = sum([
    1 if name_search else 0,
    1 if (score_min,score_max)!=(0,100) else 0,
    1 if sel_location!="All" else 0,
    1 if sel_nationality!="All" else 0,
    1 if sel_gender!="All" else 0,
    1 if (exp_range[0],exp_range[1])!=(0,30) else 0,
    1 if sel_company!="All" else 0,
    1 if sel_designation!="All" else 0,
    1 if sel_fit!="All" else 0,
    1 if top5_only else 0,
])

_filter_note = f" (filtered from {len(results_by_decision)})" if active_filters else ""
_filter_badge  = f"🔵 {active_filters} filter(s) active" if active_filters else "No filters applied"
_cand_word     = "candidate" if len(results) == 1 else "candidates"
st.markdown(
    f'<div class="result-meta">' +
    f'<span>Showing <strong>{len(results)}</strong> {_cand_word}{_filter_note}' +
    f' &nbsp;&#183;&nbsp; Sorted by <strong>{sort_by}</strong></span>' +
    f'<span style="font-size:0.75rem;color:#8A9BB0;">{_filter_badge}</span>' +
    f'</div>',
    unsafe_allow_html=True
)

if not results:
    st.markdown("""
    <div style="text-align:center;padding:3rem;background:#FFFFFF;border-radius:10px;border:1px solid #CED0D4;">
      <div style="font-size:2rem;">🔍</div>
      <div style="font-weight:700;font-size:1rem;margin:8px 0 4px;">No candidates match the current filters</div>
      <div style="font-size:0.82rem;color:#65676B;">Adjust filters above to broaden the search.</div>
    </div>""", unsafe_allow_html=True)
    st.stop()

st.markdown('<div style="height:1px;background:#CED0D4;margin:0.5rem 0 1.5rem;"></div>',
            unsafe_allow_html=True)


# ── Candidate cards ────────────────────────────────────────────────────────────
for rank, r in enumerate(results, 1):
    name      = r.get("full_name") or r.get("original_filename") or "Unknown"
    email     = r.get("email") or ""
    fname     = r.get("original_filename") or ""
    decision  = r.get("decision") or "needs_review"
    ts        = (r.get("screened_at") or "")[:16].replace("T", " ")
    comp      = r.get("composite_score", 0)
    sem       = r.get("semantic_similarity", 0)
    rel       = r.get("relevance_score", 0)
    pot       = r.get("potential_score", 0)
    anoms     = r.get("anomaly_count", 0) or 0
    returning = r.get("is_returning", False)
    sid       = r.get("screening_id", "") or str(rank)
    rationale = r.get("llm_rationale") or ""
    conf      = r.get("parse_confidence") or 0.8

    strengths    = parse_list(r.get("strengths"))
    gaps         = parse_list(r.get("gaps"))
    transferable = parse_list(r.get("transferable_skills"))
    insights     = parse_list(r.get("value_add_insights"))
    parsed       = get_parsed(r)
    tech_skills  = parse_list(r.get("technical_skills") or parsed.get("technical_skills"))
    soft_skills  = parse_list(r.get("soft_skills") or parsed.get("soft_skills"))

    ini          = initials(name)
    comp_color   = score_color(comp)
    fit_text, fit_cls = fit_label(comp)
    key_id       = f"{sid}_{rank}"

    ret_badge  = '<span class="badge badge-orange">↩ Returning</span>' if returning else ""
    anom_badge = f'<span class="badge badge-red">⚑ {anoms} Flag{"s" if anoms!=1 else ""}</span>' if anoms else ""
    _fit_style = (
        "background:#DCFCE7;color:#15803D;border:1px solid #BBF7D0;" if fit_cls == "strong"
        else "background:#FEF3C7;color:#B45309;border:1px solid #FDE68A;" if fit_cls == "mod"
        else "background:#FEE2E2;color:#DC2626;border:1px solid #FECACA;"
    )
    fit_badge  = f'<span style="display:inline-flex;align-items:center;padding:3px 10px;border-radius:20px;font-size:0.7rem;font-weight:700;{_fit_style}">{fit_text}</span>'

    _card_html = (
        '<div class="fb-card-lg"><div class="cand-header">' +
        f'<div class="cand-avatar">{ini}</div>' +
        f'<div style="flex:1;min-width:0;">' +
        f'<div class="cand-name">#{rank} &nbsp;{name}</div>' +
        f'<div class="cand-email">{email}</div>' +
        f'<div style="font-size:0.75rem;color:#BCC0C4;">{fname}</div>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px;flex-shrink:0;">' +
        badge_html(decision) +
        fit_badge +
        ret_badge +
        anom_badge +
        f'<div style="font-size:0.72rem;color:#BCC0C4;">{ts}</div>' +
        '</div></div></div>'
    )
    st.markdown(_card_html, unsafe_allow_html=True)

    # ── Score Intelligence ───────────────────────────────────────────────────
    with st.expander(f"📊  Score Intelligence — {name}", expanded=(rank == 1)):
        gc1, gc2, gc3 = st.columns(3, gap="medium")
        with gc1:
            st.markdown('<div class="sec-label">Composite Gauge</div>', unsafe_allow_html=True)
            st.plotly_chart(gauge_chart(comp), use_container_width=True,
                            key=f"gauge_{key_id}", config={"displayModeBar": False})
        with gc2:
            st.markdown('<div class="sec-label">Score Profile Radar</div>', unsafe_allow_html=True)
            st.plotly_chart(radar_chart(rel, sem, pot), use_container_width=True,
                            key=f"radar_{key_id}", config={"displayModeBar": False})
        with gc3:
            st.markdown('<div class="sec-label">Score Contribution</div>', unsafe_allow_html=True)
            st.plotly_chart(waterfall_chart(rel, sem, pot, comp), use_container_width=True,
                            key=f"wfall_{key_id}", config={"displayModeBar": False})

        st.markdown(f"""
        <div class="fb-card">
          <div class="sec-label">Score Breakdown with Weights</div>
          {subscore_html("Relevance Score", rel, "· 40% — LLM JD–CV alignment")}
          {subscore_html("Semantic Similarity", sem, "· 35% — vector embedding cosine")}
          {subscore_html("Potential Score", pot, "· 25% — career trajectory signals")}
          <div style="margin-top:10px;font-size:0.72rem;color:#BCC0C4;background:#F0F2F5;border-radius:6px;padding:8px 10px;font-family:monospace;">
            ({int(rel*100)} × 0.40) + ({int(sem*100)} × 0.35) + ({int(pot*100)} × 0.25)
            &nbsp;=&nbsp; <b style="color:#1877F2;font-size:0.9rem;">{int(comp*100)}</b>
          </div>
        </div>
        """, unsafe_allow_html=True)

    # ── Strength & Gap Analysis ──────────────────────────────────────────────
    with st.expander(f"✅  Strength & Gap Analysis — {name}"):
        s_rows = "".join(
            f'<div class="sg-item"><span style="color:#42B72A;font-size:0.6rem;margin-top:3px;">▲</span>'
            f'<span class="sg-text-s">{s}</span></div>' for s in strengths) \
            or "<div style='font-size:0.8rem;color:#BCC0C4;padding:4px 0;'>None identified</div>"
        g_rows = "".join(
            f'<div class="sg-item"><span style="color:#F5A623;font-size:0.6rem;margin-top:3px;">▼</span>'
            f'<span class="sg-text-g">{g}</span></div>' for g in gaps) \
            or "<div style='font-size:0.8rem;color:#BCC0C4;padding:4px 0;'>None identified</div>"
        st.markdown(f"""
        <div class="sg-grid">
          <div class="sg-box sg-box-s"><div class="sg-box-label sg-label-s">✓ Strengths ({len(strengths)})</div>{s_rows}</div>
          <div class="sg-box sg-box-g"><div class="sg-box-label sg-label-g">⚠ Gaps ({len(gaps)})</div>{g_rows}</div>
        </div>
        """, unsafe_allow_html=True)
        if strengths:
            st.markdown("<div style='margin-top:14px;'><div class='sec-label'>Strength Signal Depth</div></div>",
                        unsafe_allow_html=True)
            fig = skills_hbar(strengths, FB_BLUE)
            if fig:
                st.plotly_chart(fig, use_container_width=True,
                                key=f"str_bar_{key_id}", config={"displayModeBar": False})
        if gaps:
            st.markdown("<div style='margin-top:8px;'><div class='sec-label'>Gap Signal Depth</div></div>",
                        unsafe_allow_html=True)
            fig = skills_hbar(gaps, FB_RED)
            if fig:
                st.plotly_chart(fig, use_container_width=True,
                                key=f"gap_bar_{key_id}", config={"displayModeBar": False})

    # ── Skills Breakdown ─────────────────────────────────────────────────────
    if tech_skills or soft_skills:
        with st.expander(f"🛠  Skills Breakdown — {name}"):
            sk1, sk2 = st.columns(2, gap="medium")
            with sk1:
                st.markdown('<div class="sec-label">Technical Skills</div>', unsafe_allow_html=True)
                chips = "".join(f'<span class="chip chip-tech">{s}</span>' for s in tech_skills[:20]) \
                        or "<span style='font-size:0.8rem;color:#BCC0C4;'>None extracted</span>"
                st.markdown(f'<div class="chip-wrap">{chips}</div>', unsafe_allow_html=True)
                if len(tech_skills) > 3:
                    fig = skills_hbar(tech_skills[:10], FB_BLUE)
                    if fig:
                        st.plotly_chart(fig, use_container_width=True,
                                        key=f"tech_bar_{key_id}", config={"displayModeBar": False})
            with sk2:
                st.markdown('<div class="sec-label">Soft Skills</div>', unsafe_allow_html=True)
                chips = "".join(f'<span class="chip chip-domain">{s}</span>' for s in soft_skills[:15]) \
                        or "<span style='font-size:0.8rem;color:#BCC0C4;'>None extracted</span>"
                st.markdown(f'<div class="chip-wrap">{chips}</div>', unsafe_allow_html=True)

    # ── Transferable Skills ──────────────────────────────────────────────────
    if transferable:
        with st.expander(f"🔄  Transferable Skills — {name}"):
            tech_t   = [s for s in transferable if any(kw in s.lower() for kw in TECH_KW)]
            domain_t = [s for s in transferable if s not in tech_t]
            tc1, tc2 = st.columns(2, gap="medium")
            with tc1:
                st.markdown('<div class="sec-label">Technical</div>', unsafe_allow_html=True)
                chips = "".join(f'<span class="chip chip-tech">{s}</span>' for s in tech_t) \
                        or "<span style='font-size:0.8rem;color:#BCC0C4;'>None</span>"
                st.markdown(f'<div class="chip-wrap">{chips}</div>', unsafe_allow_html=True)
            with tc2:
                st.markdown('<div class="sec-label">Domain</div>', unsafe_allow_html=True)
                chips = "".join(f'<span class="chip chip-domain">{s}</span>' for s in domain_t) \
                        or "<span style='font-size:0.8rem;color:#BCC0C4;'>None</span>"
                st.markdown(f'<div class="chip-wrap">{chips}</div>', unsafe_allow_html=True)

    # ── Strategic Insights ───────────────────────────────────────────────────
    if insights:
        with st.expander(f"💡  Strategic Insights — {name}"):
            for idx, insight in enumerate(insights, 1):
                st.markdown(f"""
                <div class="insight-item">
                  <div style="font-size:0.65rem;font-weight:700;text-transform:uppercase;
                              letter-spacing:0.1em;color:#1877F2;margin-bottom:3px;">Insight {idx:02d}</div>
                  {insight}
                </div>""", unsafe_allow_html=True)

    # ── AI Rationale ──────────────────────────────────────────────────────────
    if rationale:
        with st.expander(f"🧠  AI Rationale — {name}"):
            st.markdown(f"""
            <div class="rationale-box">
              <div class="rationale-label">🔵 AI Decision Rationale</div>
              {rationale}
              <div style="margin-top:10px;font-size:0.7rem;color:#BCC0C4;font-style:normal;">
                Generated by LLM pipeline · Not human-authored · For HR augmentation only
              </div>
            </div>""", unsafe_allow_html=True)

    # ── No-JD Dept Fit ────────────────────────────────────────────────────────
    _sb = r.get("score_breakdown") or {}
    _is_no_jd = bool(_sb.get("no_jd_mode")) or (r.get("ai_summary") or "").startswith("[NO JD]")
    if _is_no_jd:
        _suggested    = _sb.get("suggested_departments") or []
        _best_cluster = _sb.get("best_cluster") or ""
        _top_clusters = _sb.get("top_clusters") or []
        _seniority    = _sb.get("seniority_band") or ""
        with st.expander(f"🏢  Department Fit Analysis — {name} (No-JD Mode)", expanded=True):
            st.markdown(f"""
            <div style="background:#FFF8E6;border:1px solid #FFD975;border-radius:8px;
                        padding:12px 16px;margin-bottom:1rem;font-size:0.8rem;color:#7A5700;">
              ⚠️ <strong>No-JD Mode:</strong> Score capped at 72%. Seniority: <strong>{_seniority}</strong>
            </div>""", unsafe_allow_html=True)
            if _best_cluster:
                st.markdown(f'<div class="sec-label">Best-Fit Cluster</div>', unsafe_allow_html=True)
                st.markdown(f'<div style="font-size:1.1rem;font-weight:800;color:#1877F2;">{_best_cluster}</div>',
                            unsafe_allow_html=True)
            if _top_clusters:
                st.markdown('<div class="sec-label" style="margin-top:12px;">All Cluster Scores</div>',
                            unsafe_allow_html=True)
                _clust_names  = [c["cluster"][:35] for c in _top_clusters]
                _clust_scores = [c["score"]*100 for c in _top_clusters]
                _colors2      = [FB_BLUE if i==0 else FB_GREY for i in range(len(_clust_names))]
                _fig = go.Figure(go.Bar(x=_clust_scores, y=_clust_names, orientation="h",
                    marker_color=_colors2, text=[f"{s:.0f}%" for s in _clust_scores],
                    textposition="outside", showlegend=False))
                _fig.update_layout(height=max(180, len(_clust_names)*36+40),
                    margin=dict(t=10,b=10,l=10,r=40),
                    paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
                    xaxis=dict(range=[0,100], ticksuffix="%", gridcolor="#F0F2F5"),
                    yaxis=dict(tickfont=dict(size=11)), font={"family":"Inter"})
                st.plotly_chart(_fig, use_container_width=True,
                                key=f"nojd_bar_{key_id}", config={"displayModeBar":False})
            if _suggested:
                st.markdown('<div class="sec-label" style="margin-top:12px;">Suggested Departments</div>',
                            unsafe_allow_html=True)
                for item in _suggested[:8]:
                    _sc = "#42B72A" if item["score"]>=0.6 else ("#F5A623" if item["score"]>=0.35 else "#BCC0C4")
                    st.markdown(f"""
                    <div style="display:flex;justify-content:space-between;align-items:center;
                        padding:7px 12px;background:#F7F8FC;border-radius:6px;margin-bottom:4px;
                        border-left:3px solid {_sc};">
                      <span style="font-size:0.82rem;font-weight:600;">{item["department"]}</span>
                      <span style="font-size:0.75rem;color:{_sc};font-weight:700;">{int(item["score"]*100)}% fit</span>
                    </div>""", unsafe_allow_html=True)

    # ── System Signals ────────────────────────────────────────────────────────
    with st.expander(f"📡  System Signals — {name}"):
        conf_pct = int((conf or 0.8) * 100)
        st.markdown(f"""
        <div class="signal-strip">
          <div class="signal-cell">
            <div class="signal-val" style="color:{comp_color};">{int(comp*100)}%</div>
            <div class="signal-lbl">Composite</div><div class="signal-sub">Weighted score</div>
          </div>
          <div class="signal-cell">
            <div class="signal-val" style="color:{'#FA3E3E' if anoms else '#42B72A'};">{anoms}</div>
            <div class="signal-lbl">Anomaly Flags</div>
            <div class="signal-sub">{'Review required' if anoms else 'Clean'}</div>
          </div>
          <div class="signal-cell">
            <div class="signal-val" style="color:{'#1877F2' if returning else '#BCC0C4'};">{'Yes' if returning else 'No'}</div>
            <div class="signal-lbl">Returning</div>
            <div class="signal-sub">{'Prior application' if returning else 'First application'}</div>
          </div>
          <div class="signal-cell">
            <div class="signal-val" style="color:#1877F2;">{conf_pct}%</div>
            <div class="signal-lbl">Parse Confidence</div><div class="signal-sub">CV extraction quality</div>
          </div>
        </div>
        <div class="conf-row">
          <div class="conf-label">Parse Confidence</div>
          <div class="conf-track"><div class="conf-fill" style="width:{conf_pct}%;"></div></div>
          <div class="conf-pct">{conf_pct}%</div>
        </div>""", unsafe_allow_html=True)

    # ── HR Decision ───────────────────────────────────────────────────────────
    with st.expander(f"✍️  HR Decision — {name}"):
        decision_map = {"✅ Approve":"hr_approved","📤 Forward":"forwarded",
                        "⏸ Hold":"hr_hold","❌ Reject":"hr_rejected"}
        da, db, dc = st.columns([2,2,1], gap="medium")
        with da:
            choice = st.selectbox("Decision", list(decision_map.keys()), key=f"dec_{key_id}")
        with db:
            hr_name = st.text_input("HR Officer Name", placeholder="Your full name", key=f"hrn_{key_id}")
        with dc:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("Save", key=f"save_{key_id}", use_container_width=True):
                if not hr_name.strip():
                    st.error("Name required.")
                else:
                    try:
                        patch = requests.patch(
                            f"{API}/screenings/{sid}/decision",
                            data={"decision": decision_map[choice],
                                  "decision_by": hr_name.strip()},
                            timeout=10,
                        )
                        if patch.status_code == 200:
                            st.success("✅ Decision saved.")
                            time.sleep(1); st.rerun()
                        else:
                            err = patch.json() if patch.headers.get(
                                "content-type","").startswith("application/json") else {}
                            st.error(err.get("detail", f"Error {patch.status_code}"))
                    except Exception as ex:
                        st.error(str(ex))

    st.markdown('<div style="height:8px;"></div>', unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════════════
# REPORTS SECTION  (FIX 5: session_state pattern — no nested button/download)
# ═══════════════════════════════════════════════════════════════════════════════
st.markdown('<div style="height:1px;background:#E4E6EB;margin:1rem 0;"></div>',
            unsafe_allow_html=True)
st.markdown('<div class="sec-label">Reports</div>', unsafe_allow_html=True)

_pool_key       = f"pool_pdf_{selected_job_id}"
_pool_ready_key = f"pool_pdf_ready_{selected_job_id}"

rc1, rc2 = st.columns([3, 1])
with rc1:
    st.markdown(
        f'<div style="font-size:0.82rem;color:#65676B;padding-top:6px;">'
        f'Full pool report — <b>{len(results)}</b> candidate(s) shown · role: <b>{selected_label}</b>'
        f'</div>',
        unsafe_allow_html=True,
    )
with rc2:
    if st.button("⚙️ Build Pool PDF", use_container_width=True, key="build_pool_pdf_btn"):
        with st.spinner("Rendering charts and building PDF…"):
            try:
                _pdf_bytes = build_all_candidates_pdf(results, role_name=selected_label)
                st.session_state[_pool_key]       = _pdf_bytes
                st.session_state[_pool_ready_key] = True
            except Exception as _exc:
                st.error(f"PDF generation failed: {_exc}")
                st.session_state[_pool_ready_key] = False

if st.session_state.get(_pool_ready_key):
    _pdf_bytes = st.session_state[_pool_key]
    st.download_button(
        label="⬇️ Download Full Candidate Pool Report (PDF)",
        data=_pdf_bytes,
        file_name=f"TalentScan_Pool_{selected_label.replace(' ','_')}"
                  f"_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf",
        mime="application/pdf",
        key="dl_pool_pdf",
        use_container_width=False,
    )
    st.success(f"✅ Pool report ready — {len(_pdf_bytes)//1024} KB · {len(results)} candidate(s)")