import streamlit as st
import requests
import pandas as pd
import os
import json

st.set_page_config(
    page_title="Screening Results · TalentScan AI",
    page_icon="📊",
    layout="wide"
)

API_BASE = os.getenv("API_URL", "http://api:8000")
API = f"{API_BASE}/api/v1"

# ── HEADER ─────────────────────────────────────────────
st.title("📊 Screening Results")


# ── JOBS ───────────────────────────────────────────────
try:
    jobs = requests.get(f"{API}/jobs/", timeout=5).json()
except:
    jobs = []

if not jobs:
    st.stop()

job_map = {f"{j['title']}": j["id"] for j in jobs}

selected_job = st.selectbox("Select Role", list(job_map.keys()))
job_id = job_map[selected_job]


# ── SCREENINGS (FIXED ENDPOINT) ────────────────────────
try:
    resp = requests.get(
        f"{API}/screenings/results/{job_id}",
        timeout=10
    )
    raw = resp.json() if resp.ok else []
except:
    raw = []

if not raw:
    st.info("No screening results yet for this role.")
    st.stop()

df = pd.DataFrame(raw)

# ── NORMALIZE BACKEND RESPONSE ─────────────────────────
df["name"] = df.get("full_name", "Unknown")
df["score"] = pd.to_numeric(df.get("composite_score", 0), errors="coerce").fillna(0)
df["decision"] = df.get("decision", "needs_review")

df = df.sort_values("score", ascending=False)

# ── KPI ────────────────────────────────────────────────
st.subheader("Overview")

st.metric("Total Candidates", len(df))
st.metric("Avg Score", f"{df['score'].mean():.1f}")


# ── TABLE ───────────────────────────────────────────────
st.subheader("Candidates")

for _, row in df.iterrows():
    st.markdown("---")
    st.write(f"**{row['name']}**")
    st.write(f"Score: {row['score']:.2f}")
    st.write(f"Decision: {row['decision']}")