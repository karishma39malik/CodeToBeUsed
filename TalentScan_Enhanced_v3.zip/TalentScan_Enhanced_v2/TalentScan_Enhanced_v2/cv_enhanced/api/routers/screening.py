import json
import os
import uuid
from typing import List

from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
import aiofiles
import structlog

from database.connection import get_db, AsyncSessionLocal
from shared.models import BulkUploadResponse
from shared.utils import sanitize_filename, compute_file_hash, get_file_extension
from config.settings import settings
from agents.ingestion_agent import IngestionAgent
from agents.matching_agent import MatchingAgent
from agents.potential_agent import PotentialAgent
from agents.validation_agent import ValidationAgent

router = APIRouter()
logger = structlog.get_logger(__name__)


# =====================================================
# BULK UPLOAD
# =====================================================
@router.post("/upload", response_model=BulkUploadResponse)
async def upload_cvs(
    job_id: str = Form(...),
    uploaded_by: str = Form(...),
    cv_files: List[UploadFile] = File(...),
    background_tasks: BackgroundTasks = None,
    db: AsyncSession = Depends(get_db),
):
    """
    Upload CVs and queue background processing.
    FIXED:
    - candidate_id created before cv_versions insert
    - no NULL candidate_id issue
    """

    if len(cv_files) > settings.max_bulk_upload:
        raise HTTPException(
            status_code=400,
            detail=f"Maximum {settings.max_bulk_upload} files allowed."
        )

    # verify job exists
    job_check = await db.execute(
        text("SELECT id FROM jobs WHERE id = :id"),
        {"id": job_id}
    )
    if not job_check.fetchone():
        raise HTTPException(status_code=404, detail="Job not found")

    queued = []
    failed = []
    correlation_ids = []

    for cv_file in cv_files:

        correlation_id = str(uuid.uuid4())

        try:
            ext = get_file_extension(cv_file.filename)

            if ext not in settings.allowed_ext_list:
                failed.append({
                    "filename": cv_file.filename,
                    "error": f"Unsupported file type {ext}"
                })
                continue

            content = await cv_file.read()

            size_mb = len(content) / (1024 * 1024)
            if size_mb > settings.max_file_size_mb:
                failed.append({
                    "filename": cv_file.filename,
                    "error": "File too large"
                })
                continue

            # -----------------------------
            # SAVE FILE
            # -----------------------------
            os.makedirs(os.path.join(settings.upload_dir, "cvs"), exist_ok=True)

            safe_name = sanitize_filename(cv_file.filename)
            file_path = os.path.join(
                settings.upload_dir,
                "cvs",
                f"{correlation_id}_{safe_name}"
            )

            async with aiofiles.open(file_path, "wb") as f:
                await f.write(content)

            file_hash = compute_file_hash(content)

            # -----------------------------
            # CREATE CANDIDATE FIRST
            # -----------------------------
            candidate_id = str(uuid.uuid4())

            await db.execute(
                text("""
                    INSERT INTO candidates
                    (id, full_name, email, current_status, created_at)
                    VALUES
                    (:id, :name, :email, 'uploaded', NOW())
                """),
                {
                    "id": candidate_id,
                    "name": cv_file.filename,
                    "email": None
                }
            )

            # -----------------------------
            # CREATE CV VERSION
            # -----------------------------
            cv_version_id = str(uuid.uuid4())

            await db.execute(
                text("""
                    INSERT INTO cv_versions
                    (
                        id,
                        candidate_id,
                        job_id,
                        original_filename,
                        stored_path,
                        file_format,
                        file_size_bytes,
                        file_hash,
                        ingestion_status,
                        correlation_id
                    )
                    VALUES
                    (
                        :id,
                        :candidate_id,
                        :job_id,
                        :fname,
                        :path,
                        :fmt,
                        :size,
                        :hash,
                        'pending',
                        :cid
                    )
                """),
                {
                    "id": cv_version_id,
                    "candidate_id": candidate_id,
                    "job_id": job_id,
                    "fname": cv_file.filename,
                    "path": file_path,
                    "fmt": ext,
                    "size": len(content),
                    "hash": file_hash,
                    "cid": correlation_id
                }
            )

            await db.commit()

            queued.append(cv_version_id)
            correlation_ids.append(correlation_id)

            # -----------------------------
            # BACKGROUND TASK
            # -----------------------------
            background_tasks.add_task(
                process_cv_pipeline,
                cv_version_id=cv_version_id,
                candidate_id=candidate_id,
                job_id=job_id,
                file_path=file_path,
                filename=cv_file.filename,
                file_hash=file_hash,
                correlation_id=correlation_id
            )

        except Exception as e:
            await db.rollback()
            failed.append({
                "filename": cv_file.filename,
                "error": str(e)
            })

    return BulkUploadResponse(
        total_received=len(cv_files),
        queued=len(queued),
        failed=len(failed),
        correlation_ids=correlation_ids,
        errors=failed
    )


# =====================================================
# BACKGROUND PIPELINE
# =====================================================
async def process_cv_pipeline(
    cv_version_id: str,
    candidate_id: str,
    job_id: str,
    file_path: str,
    filename: str,
    file_hash: str,
    correlation_id: str
):

    log = logger.bind(correlation_id=correlation_id)

    async with AsyncSessionLocal() as db:
        try:

            await db.execute(
                text("""
                    UPDATE cv_versions
                    SET ingestion_status='processing'
                    WHERE id=:id
                """),
                {"id": cv_version_id}
            )
            await db.commit()

            # -----------------------------
            # INGESTION
            # -----------------------------
            ingestion = IngestionAgent(db)
            ing_result = None
            try:
                ing_result = await ingestion.run(
                    payload={
                        "file_path": file_path,
                        "filename": filename
                    },
                    correlation_id=correlation_id
                )
            except Exception as e:
                logger.error("ingestion_failed", error=str(e))
                await update_status("failed_ingestion")
                return

            logger.info("ingestion_completed", result=ing_result)

            parsed_cv = ing_result.get("parsed_cv")

            if not parsed_cv:
                raise ValueError("parsed_cv missing from ingestion result")

            # -----------------------------
            # UPDATE CANDIDATE REAL DATA
            # -----------------------------
            await db.execute(
                text("""
                    UPDATE candidates
                    SET
                        full_name=:name,
                        email=:email,
                        last_updated_at=NOW()
                    WHERE id=:id
                """),
                {
                    "id": candidate_id,
                    "name": parsed_cv.get("full_name", filename),
                    "email": parsed_cv.get("email")
                }
            )

            await db.execute(
                text("""
                    UPDATE cv_versions
                    SET
                        parsed_data=CAST(:data AS jsonb),
                        parse_confidence=:conf,
                        ingestion_status='done',
                        processed_at=NOW()
                    WHERE id=:id
                """),
                {
                    "id": cv_version_id,
                    "data": json.dumps(parsed_cv),
                    "conf": parsed_cv.get("parse_confidence", 0.5)
                }
            )

            await db.commit()

            # -----------------------------
            # JOB DESCRIPTION
            # -----------------------------
            jd = await db.execute(
                text("""
                    SELECT description_raw
                    FROM jobs
                    WHERE id=:id
                """),
                {"id": job_id}
            )

            jd_row = jd.fetchone()
            job_description = jd_row.description_raw if jd_row else ""

            # -----------------------------
            # MATCHING
            # -----------------------------
            log.info("matching_started")
            matcher = MatchingAgent(db)
            try:
                match = await matcher.run(
                    payload={
                        "cv_version_id": cv_version_id,
                        "candidate_id": candidate_id,
                        "job_id": job_id,
                        "parsed_cv": parsed_cv,
                        "job_description": job_description
                    },
                    correlation_id=correlation_id
                )
            except Exception as e:
                log.error("matching_failed", error=str(e))
                await update_status("failed_matching")
                return
            log.info("matching_done", match=match)
            # -----------------------------
            # POTENTIAL
            # -----------------------------
            log.info("potential_started")
            potential = PotentialAgent(db)
            try:
                pot = await potential.run(
                    payload={"parsed_cv": parsed_cv},
                    correlation_id=correlation_id
                )
            except Exception as e:
                log.error("potential_failed", error=str(e))
                pot = {"value_add_insights": []}
            log.info("potential_done", pot=pot)
            # -----------------------------
            # VALIDATION
            # -----------------------------
            validator = ValidationAgent(db)
            logger.info("VALIDATION STARTED")

            val = await validator.run(
                payload={
                    "candidate_id": candidate_id,
                    "job_id": job_id,
                    "cv_version_id": cv_version_id,
                    "file_hash": file_hash,
                    "parsed_cv": parsed_cv,
                    "composite_score": match["composite_score"],
                    "parse_confidence": parsed_cv.get("parse_confidence", 0.5)
                },
                correlation_id=correlation_id
            )

            # -----------------------------
            # INSERT SCREENING RESULT
            # -----------------------------
            screening_id = str(uuid.uuid4())
            log.info("before_screening_insert", match=match, pot=pot, val=val)
            await db.execute(
                text("""
                    INSERT INTO screenings
                    (
                        id,
                        cv_version_id,
                        candidate_id,
                        job_id,
                        semantic_similarity,
                        relevance_score,
                        potential_score,
                        composite_score,
                        strengths,
                        gaps,
                        transferable_skills,
                        value_add_insights,
                        llm_rationale,
                        decision
                    )
                    VALUES
                    (
                        :id,
                        :cv,
                        :cand,
                        :job,
                        :sim,
                        :rel,
                        :pot,
                        :comp,
                        :str::jsonb,
                        :gaps::jsonb,
                        :trans::jsonb,
                        :vai::jsonb,
                        :rat,
                        :decision
                    )
                """),
                {
                    "id": screening_id,
                    "cv": cv_version_id,
                    "cand": candidate_id,
                    "job": job_id,
                    "sim": match["semantic_similarity"],
                    "rel": match["relevance_score"],
                    "pot": pot.get("potential_score", 0.5),
                    "comp": match["composite_score"],
                    "str": json.dumps(match["strengths"]),
                    "gaps": json.dumps(match["gaps"]),
                    "trans": json.dumps(match["transferable_skills"]),
                    "vai": json.dumps(pot.get("value_add_insights", [])),
                    "rat": match["llm_rationale"],
                    "decision": "needs_review" if val["requires_review"] else "shortlisted"
                }
            )
            log.info("screening_inserted", screening_id=screening_id)
            await db.execute(
                text("""
                    UPDATE candidates
                    SET current_status='screened'
                    WHERE id=:id
                """),
                {"id": candidate_id}
            )

            await db.commit()

            log.info("pipeline_complete")

        except Exception as e:
            await db.rollback()

            await db.execute(
                text("""
                    UPDATE cv_versions
                    SET ingestion_status='failed'
                    WHERE id=:id
                """),
                {"id": cv_version_id}
            )

            await db.commit()

            log.error("pipeline_failed", error=str(e))


# =====================================================
# RESULTS
# =====================================================
@router.get("/results/{job_id}")
async def get_screening_results(
    job_id: str,
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        text("""
            SELECT *
            FROM screenings
            WHERE job_id=:id
            ORDER BY composite_score DESC
        """),
        {"id": job_id}
    )

    return [dict(row._mapping) for row in result.fetchall()]


# =====================================================
# UPDATE DECISION
# =====================================================
@router.patch("/{screening_id}/decision")
async def update_decision(
    screening_id: str,
    decision: str = Form(...),
    db: AsyncSession = Depends(get_db)
):
    await db.execute(
        text("""
            UPDATE screenings
            SET decision=:d
            WHERE id=:id
        """),
        {"d": decision, "id": screening_id}
    )

    await db.commit()

    return {"message": "updated"}