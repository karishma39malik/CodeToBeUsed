import streamlit as st
import requests
import pandas as pd
import json
import os
import time

st.set_page_config(page_title="Screening Results · TalentScan AI", page_icon="📊", layout="wide")

API_BASE = os.getenv("API_URL", "http://api:8000")
API      = f"{API_BASE}/api/v1"


def parse_json_field(val):
    if isinstance(val, list): return val
    if not val: return []
    try:
        result = json.loads(val)
        return result if isinstance(result, list) else [str(result)]
    except Exception:
        return [str(val)]


def score_css(s):
    if s >= 0.65: return "cand-score-high"
    if s >= 0.45: return "cand-score-mid"
    return "cand-score-low"


def score_bar_css(s):
    if s >= 0.65: return "score-high"
    if s >= 0.45: return "score-mid"
    return "score-low"


def score_label(s):
    if s >= 0.65: return "Strong"
    if s >= 0.45: return "Moderate"
    return "Weak"


# ── Sidebar ──────────────────────────────────────────────
with st.sidebar:
    try:
        jobs_resp = requests.get(f"{API}/jobs/", timeout=5)

        if jobs_resp.status_code != 200:
            st.error("Failed to load jobs")
            st.stop()

        jobs = jobs_resp.json()
        job_options = {f"{j['title']} — {j.get('department','—')}": j['id'] for j in jobs}

    except Exception:
        job_options = {}

    if not job_options:
        st.warning("No jobs found.")
        st.stop()

    selected_label  = st.selectbox("Role", list(job_options.keys()))
    selected_job_id = job_options[selected_label]

    min_score       = st.slider("Min Score", 0.0, 1.0, 0.0, 0.05)
    show_limit      = st.slider("Max candidates", 10, 200, 50, 10)

    filter_decision = st.multiselect(
        "Decision Filter",
        ["needs_review", "shortlisted", "hr_approved", "hr_hold", "hr_rejected", "forwarded"],
        default=["needs_review", "shortlisted", "hr_approved", "hr_hold"],
    )

    if st.button("🔄 Refresh Now"):
        st.rerun()

    auto_refresh = st.checkbox("Auto-refresh (30s)")
    if auto_refresh:
        time.sleep(30)
        st.rerun()


# ── Fetch results (FIXED) ─────────────────────────────────
try:
    resp = requests.get(
        f"{API}/screenings/results/{selected_job_id}",
        params={"min_score": min_score, "limit": show_limit},
        timeout=15,
    )

    if resp.status_code != 200:
        st.error(f"Failed to load results ({resp.status_code})")
        try:
            st.write(resp.json())
        except:
            st.write(resp.text)
        st.stop()

    try:
        results = resp.json()
    except Exception:
        st.error(f"Invalid response:\n{resp.text}")
        st.stop()

except Exception as e:
    st.error(f"Error loading results: {e}")
    st.stop()

# ✅ ensure list
if not isinstance(results, list):
    results = []

# ✅ safe filter
if filter_decision:
    results = [
        r for r in results
        if isinstance(r, dict) and r.get("decision") in (filter_decision or [])
    ]


# ── Pipeline metrics (safe) ───────────────────────────────
try:
    pipe_resp = requests.get(f"{API}/jobs/{selected_job_id}/pipeline", timeout=5)

    if pipe_resp.status_code == 200:
        pipe = pipe_resp.json()

        st.write("Pipeline:", pipe)

except Exception:
    pass


# ── No results ────────────────────────────────────────────
if not results:
    st.warning("No candidates found.")
    st.stop()


# ── Table ────────────────────────────────────────────────
table_rows = []

for i, r in enumerate(results, 1):
    s = r.get("composite_score", 0)

    table_rows.append({
        "Rank": i,
        "Name": r.get("full_name") or "Unknown",
        "Score": round(s, 2),
        "Decision": (r.get("decision") or "").replace("_", " ").title(),
    })

df = pd.DataFrame(table_rows) if table_rows else pd.DataFrame()
st.dataframe(df, use_container_width=True)


# ── Detail ───────────────────────────────────────────────
for r in results:
    with st.expander(r.get("full_name", "Unknown")):

        st.write("Score:", r.get("composite_score", 0))

        st.write("Strengths:", parse_json_field(r.get("strengths")))
        st.write("Gaps:", parse_json_field(r.get("gaps")))

        # Decision update
        decision_map = {
            "Shortlist": "hr_approved",
            "Reject": "hr_rejected",
        }

        choice = st.selectbox("Decision", list(decision_map.keys()), key=f"dec_{r['screening_id']}")
        name   = st.text_input("Your name", key=f"name_{r['screening_id']}")

        if st.button("Save", key=f"save_{r['screening_id']}"):
            if not name:
                st.error("Enter your name")
            else:
                try:
                    resp = requests.patch(
                        f"{API}/screenings/{r['screening_id']}/decision",
                        data={"decision": decision_map[choice], "decision_by": name},
                        timeout=10,
                    )

                    if resp.status_code == 200:
                        st.success("Saved")
                        st.rerun()
                    else:
                        try:
                            st.error(resp.json().get("detail", "Error"))
                        except:
                            st.error(resp.text)

                except Exception as e:
                    st.error(str(e))