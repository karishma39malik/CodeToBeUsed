import streamlit as st
import requests
import os
import pandas as pd

st.set_page_config(page_title="Upload CVs · TalentScan AI", page_icon="📤", layout="wide")

API_BASE = os.getenv("API_URL", "http://api:8000")
API = f"{API_BASE}/api/v1"

st.title("📤 Upload CVs")

# ── Load jobs ─────────────────────────────────────────
try:
    jobs_resp = requests.get(f"{API}/jobs/", timeout=5)

    if jobs_resp.status_code != 200:
        st.error(f"Jobs API failed: {jobs_resp.text}")
        st.stop()

    jobs = jobs_resp.json()
    job_options = {f"{j['title']}": j['id'] for j in jobs}

except Exception as e:
    st.error(f"Cannot connect to API: {str(e)}")
    st.stop()

if not job_options:
    st.warning("No active jobs found.")
    st.stop()

selected_label = st.selectbox("Select Role", list(job_options.keys()))
selected_job_id = job_options[selected_label]

uploaded_by = st.text_input("Your Name")

# ── File upload ───────────────────────────────────────
cv_files = st.file_uploader(
    "Upload CVs",
    type=["pdf", "docx", "txt"],
    accept_multiple_files=True
)

# ── Submit ───────────────────────────────────────────
if st.button("🚀 Start Screening"):

    if not cv_files:
        st.error("Please upload at least one file.")
        st.stop()

    if not uploaded_by:
        st.error("Please enter your name.")
        st.stop()

    progress_bar = st.progress(0, text="Uploading CVs...")

    try:
        # ✅ Prepare files correctly
        file_tuples = [
            ("cv_files", (f.name, f.getvalue(), f.type or "application/octet-stream"))
            for f in cv_files
        ]

        progress_bar.progress(30, text="Sending to API...")

        resp = requests.post(
            f"{API}/screenings/upload",
            data={
                "job_id": selected_job_id,
                "uploaded_by": uploaded_by
            },
            files=file_tuples,
            timeout=180,
        )

        progress_bar.progress(100, text="Upload complete!")

        # ✅ HANDLE FAILURE FIRST
        if resp.status_code != 200:
            st.error(f"Upload failed ({resp.status_code})")

            try:
                st.write("Response JSON:", resp.json())
            except:
                st.write("Raw Response:", resp.text)

            progress_bar.empty()
            st.stop()

        # ✅ SAFE JSON PARSE
        try:
            result = resp.json()
        except Exception:
            st.error(f"Invalid response from server:\n{resp.text}")
            progress_bar.empty()
            st.stop()

        # ✅ Extract values safely
        total_received = result.get("total_received", 0)
        queued = result.get("queued", 0)
        failed = result.get("failed", 0)

        # ✅ Save screening_id for results page
        screening_id = result.get("screening_id")
        if screening_id:
            st.session_state["screening_id"] = screening_id

        # ✅ SUCCESS UI
        st.success("Upload Successful!")

        col1, col2, col3 = st.columns(3)
        col1.metric("Received", total_received)
        col2.metric("Queued", queued)
        col3.metric("Failed", failed)

        st.info("⏳ Go to Screening Results page to view results.")

    except requests.exceptions.Timeout:
        st.error("Request timed out. Try smaller batch.")
        progress_bar.empty()

    except Exception as e:
        st.error(f"Error: {str(e)}")
        progress_bar.empty()