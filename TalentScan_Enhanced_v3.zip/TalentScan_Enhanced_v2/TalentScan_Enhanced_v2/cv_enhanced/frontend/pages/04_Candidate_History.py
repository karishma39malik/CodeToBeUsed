# BUG FIX: This file was completely empty (1 byte) — implemented from scratch
import streamlit as st
import requests
import pandas as pd
import os
import time

st.set_page_config(page_title="Candidate History · TalentScan AI", page_icon="📁", layout="wide")

PAGE_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500&display=swap');
html,body,[class*="css"]{ font-family:'DM Sans',sans-serif; }
.stApp { background:#090d16 !important; }
section[data-testid="stSidebar"]{ background:#0c1018 !important; border-right:1px solid #1a2035 !important; }
h1,h2,h3{ font-family:'Syne',sans-serif !important; color:#eef2ff !important; }
p,li,label{ color:#8892aa !important; }
.ts-rule{ height:1px; background:#1a2035; margin:1.2rem 0; }
.cand-card{ background:#0f1522; border:1px solid #1a2035; border-radius:12px; padding:14px 18px; margin:6px 0; }
.cand-name{ font-family:'Syne',sans-serif; font-weight:700; color:#c8d3f5; }
.cand-email{ font-size:0.78rem; color:#4e5c7a; margin-top:3px; }
.decision-hr_approved{ color:#34d399; }
.decision-hr_rejected{ color:#f87171; }
.decision-hr_hold{ color:#fbbf24; }
.decision-forwarded{ color:#818cf8; }
.decision-needs_review{ color:#6b7a9a; }
.decision-shortlisted{ color:#34d399; }
.stButton>button{ background:linear-gradient(135deg,#818cf8,#6366f1)!important;
  color:white!important; border:none!important; border-radius:8px!important; font-weight:600!important; }
.stTextInput>div>div{ background:#0f1522!important; border-color:#1a2035!important; }
.stTextInput input{ color:#c8d3f5!important; }
.stSelectbox>div>div{ background:#0f1522!important; border-color:#1a2035!important; color:#c8d3f5!important; }
</style>
"""
st.markdown(PAGE_CSS, unsafe_allow_html=True)

API_BASE = os.getenv("API_URL", "http://api:8000")
API      = f"{API_BASE}/api/v1"

st.markdown("""
<div style="padding:1rem 0 0.2rem;">
  <div style="font-family:'Syne',sans-serif;font-size:1.7rem;font-weight:800;color:#eef2ff;">📁 Candidate History</div>
  <div style="font-size:0.82rem;color:#3d4a65;margin-top:4px;">Full audit trail of screened candidates and HR decisions</div>
</div>
""", unsafe_allow_html=True)

st.markdown('<div class="ts-rule"></div>', unsafe_allow_html=True)

# ── Load all jobs to build history ───────────────────────
try:
    jobs = requests.get(f"{API}/jobs/", timeout=5).json()
except Exception:
    st.error("Cannot connect to API.")
    st.stop()

if not jobs:
    st.markdown('<div style="color:#3d4a65;padding:2rem 0;">No jobs posted yet.</div>', unsafe_allow_html=True)
    st.stop()

# ── Filters ───────────────────────────────────────────────
col1, col2, col3 = st.columns(3)
with col1:
    job_options = {"All Roles": None} | {f"{j['title']} ({j.get('department','—')})": j['id'] for j in jobs}
    selected_label  = st.selectbox("Role", list(job_options.keys()))
    selected_job_id = job_options[selected_label]
with col2:
    decision_filter = st.selectbox("Decision", ["All", "hr_approved", "hr_rejected", "hr_hold", "forwarded", "needs_review", "shortlisted"])
with col3:
    search_name = st.text_input("Search by name", placeholder="e.g. Ahmed")

# ── Collect results for selected job(s) ───────────────────
all_results = []
jobs_to_fetch = [j for j in jobs if selected_job_id is None or j["id"] == selected_job_id]

for job in jobs_to_fetch:
    try:
        r = requests.get(
            f"{API}/screenings/results/{job['id']}",
            params={"min_score": 0.0, "limit": 500},
            timeout=10,
        ).json()
        for item in r:
            item["_job_title"] = job["title"]
        all_results.extend(r)
    except Exception:
        pass

# ── Apply filters ─────────────────────────────────────────
if decision_filter != "All":
    all_results = [r for r in all_results if r.get("decision") == decision_filter]

if search_name:
    all_results = [r for r in all_results
                   if search_name.lower() in (r.get("full_name") or "").lower()]

# ── Sort by screened_at desc ─────────────────────────────
all_results.sort(key=lambda x: x.get("screened_at") or "", reverse=True)

# ── Stats row ─────────────────────────────────────────────
total     = len(all_results)
approved  = sum(1 for r in all_results if r.get("decision") in ["hr_approved", "shortlisted", "forwarded"])
rejected  = sum(1 for r in all_results if r.get("decision") == "hr_rejected")
returning = sum(1 for r in all_results if r.get("is_returning"))

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Records",    total)
c2.metric("Approved/Fwd",     approved)
c3.metric("Rejected",         rejected)
c4.metric("Returning Candidates", returning)

st.markdown('<div class="ts-rule"></div>', unsafe_allow_html=True)

if not all_results:
    st.markdown('<div style="color:#3d4a65;padding:1rem 0;">No records match the current filters.</div>', unsafe_allow_html=True)
    st.stop()

# ── Table view ────────────────────────────────────────────
st.markdown(f'<div style="font-family:\'Syne\',sans-serif;font-weight:700;color:#c8d3f5;margin-bottom:10px;">Records ({total})</div>', unsafe_allow_html=True)

table = []
for r in all_results:
    email  = r.get("email") or ""
    masked = (email[:2] + "***@" + email.split("@")[-1]) if "@" in email else "—"
    table.append({
        "Name":       r.get("full_name") or "Unknown",
        "Email":      masked,
        "Role":       r.get("_job_title", "—"),
        "Score":      f"{r.get('composite_score',0):.2f}",
        "Decision":   (r.get("decision") or "—").replace("_", " ").title(),
        "Returning":  "↩ Yes" if r.get("is_returning") else "—",
        "Screened":   (r.get("screened_at") or "")[:10],
        "Flags":      r.get("anomaly_count", 0),
    })

df = pd.DataFrame(table)
st.dataframe(df, use_container_width=True, hide_index=True, height=min(35*len(table)+38, 500))

# ── Export ────────────────────────────────────────────────
st.markdown("")
csv_data = df.to_csv(index=False).encode("utf-8")
st.download_button(
    "⬇️ Export to CSV",
    data=csv_data,
    file_name=f"candidate_history_{int(time.time())}.csv",
    mime="text/csv",
    use_container_width=False,
)

# ── Detailed records ──────────────────────────────────────
st.markdown('<div class="ts-rule"></div>', unsafe_allow_html=True)
st.markdown('<div style="font-family:\'Syne\',sans-serif;font-weight:700;color:#c8d3f5;margin-bottom:10px;">Detail View</div>', unsafe_allow_html=True)

for r in all_results[:50]:  # Cap at 50 for performance
    name    = r.get("full_name") or "Unknown"
    score   = r.get("composite_score", 0)
    dec     = r.get("decision") or "needs_review"
    dec_label = dec.replace("_", " ").title()
    dec_css = f"decision-{dec}"
    date    = (r.get("screened_at") or "")[:10]
    job_ttl = r.get("_job_title", "—")

    with st.expander(f"{name}  ·  {job_ttl}  ·  {score:.2f}"):
        col1, col2 = st.columns(2)
        with col1:
            email = r.get("email") or ""
            masked = (email[:2] + "***@" + email.split("@")[-1]) if "@" in email else "Not extracted"
            st.markdown(f"""
            <div class="cand-card">
              <div class="cand-name">{name}</div>
              <div class="cand-email">📧 {masked}</div>
              <div style="margin-top:8px;font-size:0.8rem;color:#6b7a9a;">
                Role: {job_ttl}<br>
                Screened: {date}<br>
                File: {r.get('original_filename','—')}
              </div>
            </div>
            """, unsafe_allow_html=True)
        with col2:
            ci1, ci2 = st.columns(2)
            ci1.metric("Composite",  f"{score:.2f}")
            ci2.metric("Potential",  f"{r.get('potential_score',0):.2f}")
            ci3, ci4 = st.columns(2)
            ci3.metric("Relevance",  f"{r.get('relevance_score',0):.2f}")
            ci4.metric("Similarity", f"{r.get('semantic_similarity',0):.2f}")
            st.markdown(f'<div class="{dec_css}" style="font-size:0.85rem;font-weight:600;margin-top:8px;">Decision: {dec_label}</div>', unsafe_allow_html=True)
            if r.get("is_returning"):
                st.markdown('<span style="background:#2e1065;color:#a78bfa;border-radius:100px;padding:2px 9px;font-size:0.72rem;">↩ Returning Candidate</span>', unsafe_allow_html=True)

        rationale = r.get("llm_rationale") or ""
        if rationale:
            st.markdown(f'<div style="background:#0c1320;border:1px solid #141e30;border-left:3px solid #6366f1;border-radius:0 8px 8px 0;padding:10px 14px;font-size:0.8rem;color:#6b7a9a;line-height:1.7;margin-top:8px;">{rationale[:600]}{"..." if len(rationale)>600 else ""}</div>', unsafe_allow_html=True)
