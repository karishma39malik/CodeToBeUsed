import streamlit as st
import requests
import os

st.set_page_config(page_title="Post a Job · TalentScan AI", page_icon="📋", layout="wide")

PAGE_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500&display=swap');
html,body,[class*="css"]{ font-family:'DM Sans',sans-serif; }
.stApp { background:#090d16 !important; }
section[data-testid="stSidebar"]{ background:#0c1018 !important; border-right:1px solid #1a2035 !important; }
h1,h2,h3{ font-family:'Syne',sans-serif !important; color:#eef2ff !important; }
p,li,label{ color:#8892aa !important; }
.ts-rule{ height:1px; background:#1a2035; margin:1.2rem 0; }
.ts-card{ background:#0f1522; border:1px solid #1a2035; border-radius:14px; padding:1.8rem; margin-bottom:1rem; }
.ts-job-row{ background:#0f1522; border:1px solid #1a2035; border-radius:10px; padding:13px 16px;
  margin:6px 0; display:flex; justify-content:space-between; align-items:center; }
.ts-job-title{ font-family:'Syne',sans-serif; font-weight:700; color:#c8d3f5; font-size:0.9rem; }
.ts-job-id{ font-family:monospace; font-size:0.75rem; color:#4e5c7a; margin-top:3px; }
.ts-chip{ background:#181f30; border:1px solid #1a2035; border-radius:100px;
  padding:3px 11px; font-size:0.75rem; color:#6b7a9a; display:inline-block; margin:2px 3px; }
.stButton>button{ background:linear-gradient(135deg,#818cf8,#6366f1)!important;
  color:white!important; border:none!important; border-radius:8px!important; font-weight:600!important; }
.stTextInput>div>div{ background:#0f1522!important; border-color:#1a2035!important; }
.stTextInput input{ color:#c8d3f5!important; }
.stFileUploader{ background:#0f1522!important; border-color:#1a2035!important; }
.stSelectbox>div>div{ background:#0f1522!important; border-color:#1a2035!important; color:#c8d3f5!important; }
[data-testid="stFormSubmitButton"]>button{ width:100%; padding:0.7rem!important; font-size:1rem!important; }
</style>
"""
st.markdown(PAGE_CSS, unsafe_allow_html=True)

API_BASE = os.getenv("API_URL", "http://api:8000")
API      = f"{API_BASE}/api/v1"

st.markdown("""
<div style="padding:1rem 0 0.2rem;">
  <div style="font-family:'Syne',sans-serif;font-size:1.7rem;font-weight:800;color:#eef2ff;">📋 Post a Job</div>
  <div style="font-size:0.82rem;color:#3d4a65;margin-top:4px;">Upload a Job Description to enable AI-powered CV screening</div>
</div>
""", unsafe_allow_html=True)

st.markdown('<div class="ts-rule"></div>', unsafe_allow_html=True)

# ── Form ─────────────────────────────────────────────────
st.markdown('<div class="ts-card">', unsafe_allow_html=True)
with st.form("create_job_form"):
    col1, col2 = st.columns(2)
    with col1:
        title      = st.text_input("Job Title *",   placeholder="e.g. Senior Data Engineer")
        department = st.text_input("Department",    placeholder="e.g. Technology")
    with col2:
        location   = st.text_input("Location",      placeholder="e.g. Dubai, UAE")
        created_by = st.text_input("Your Name *",   placeholder="HR Manager name")

    jd_file = st.file_uploader(
        "Upload Job Description *",
        type=["txt", "pdf"],
        help="Plain text or PDF containing the full JD (minimum 100 characters)"
    )

    st.markdown("")
    submitted = st.form_submit_button("🚀 Post Job & Generate Embeddings", type="primary", use_container_width=True)
st.markdown('</div>', unsafe_allow_html=True)

if submitted:
    if not all([title, created_by, jd_file]):
        st.error("Please fill all required fields (*) and upload a JD file.")
    else:
        with st.spinner("Creating job and generating semantic embeddings via Ollama..."):
            try:
                resp = requests.post(
                    f"{API}/jobs/",
                    data={"title": title, "department": department,
                          "location": location, "created_by": created_by},
                    files={"jd_file": (jd_file.name, jd_file.getvalue(), jd_file.type or "text/plain")},
                    timeout=90,
                )
                if resp.status_code == 201:
                    job = resp.json()
                    st.success("✅ Job posted successfully!")
                    st.markdown(f"""
                    <div style="background:#0d1f16;border:1px solid #065f31;border-radius:10px;padding:1rem 1.2rem;margin:0.8rem 0;">
                      <div style="font-size:0.78rem;color:#34d399;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;">Job Created</div>
                      <div style="font-family:'Syne',sans-serif;font-weight:700;color:#eef2ff;margin-bottom:4px;">{job.get('title','')}</div>
                      <div style="font-family:monospace;font-size:0.8rem;color:#6b7a9a;">ID: {job.get('id','')}</div>
                      <div style="font-size:0.78rem;color:#4e5c7a;margin-top:6px;">Share this Job ID with your team to upload CVs against this role.</div>
                    </div>
                    """, unsafe_allow_html=True)
                    st.balloons()
                else:
                    st.error(f"Error: {resp.json().get('detail', 'Unknown error')}")
            except requests.exceptions.ConnectionError:
                st.error("Cannot connect to API. Ensure the system is running.")
            except Exception as e:
                st.error(f"Unexpected error: {str(e)}")

# ── Active postings ──────────────────────────────────────
st.markdown('<div class="ts-rule"></div>', unsafe_allow_html=True)
st.markdown('<div style="font-family:\'Syne\',sans-serif;font-weight:700;color:#c8d3f5;margin-bottom:10px;">Active Job Postings</div>', unsafe_allow_html=True)

try:
    jobs = requests.get(f"{API}/jobs/", timeout=5).json()
    if jobs:
        for job in jobs:
            dept = job.get('department') or '—'
            loc  = job.get('location')   or '—'
            date = (job.get('created_at') or '')[:10]
            with st.expander(f"**{job['title']}** — {dept} · {loc}"):
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.markdown(f'<span class="ts-chip">📍 {loc}</span><span class="ts-chip">🏢 {dept}</span><span class="ts-chip">📅 {date}</span>', unsafe_allow_html=True)
                with col2:
                    st.code(job['id'], language=None)
    else:
        st.markdown('<div style="color:#3d4a65;font-size:0.85rem;padding:1rem 0;">No active jobs yet. Post your first role above.</div>', unsafe_allow_html=True)
except Exception:
    st.warning("Could not load jobs — is the API running?")
