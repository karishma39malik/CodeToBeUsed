import streamlit as st
import os
import requests

st.set_page_config(
    page_title="TalentScan AI",
    page_icon="⬡",
    layout="wide",
    initial_sidebar_state="expanded",
)

DARK_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,400&display=swap');

html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
.stApp { background: #090d16 !important; }
section[data-testid="stSidebar"] { background: #0c1018 !important; border-right: 1px solid #1a2035 !important; }
.block-container { padding-top: 1.5rem; padding-bottom: 2rem; max-width: 1380px; }
header { background: transparent !important; }
[data-testid="stHeader"] { background: transparent !important; }

/* Typography */
h1, h2, h3, h4 { font-family: 'Syne', sans-serif !important; color: #eef2ff !important; }
p, li { color: #8892aa !important; }
label { color: #8892aa !important; }

/* Hero */
.ts-wordmark { font-family: 'Syne', sans-serif; font-size: 2rem; font-weight: 800;
  background: linear-gradient(135deg, #818cf8 0%, #34d399 100%);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent; letter-spacing: -1px; }
.ts-tagline { font-size: 0.78rem; color: #3d4a65; text-transform: uppercase; letter-spacing: 0.1em; margin-top: 2px; }

/* Divider */
.ts-rule { height: 1px; background: linear-gradient(90deg, #1a2035 0%, #1a2035 80%, transparent 100%); margin: 1.2rem 0; }

/* Status pill */
.status-dot { width: 7px; height: 7px; border-radius: 50%; display: inline-block; margin-right: 6px; }
.status-on  { background: #34d399; box-shadow: 0 0 6px #34d39966; }
.status-off { background: #f87171; }
.status-warn{ background: #fbbf24; }
.status-row { font-size: 0.8rem; color: #6b7a9a; display: flex; align-items: center; margin: 5px 0; }

/* Feature cards */
.feat-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 1rem; }
.feat-card { background: #0f1522; border: 1px solid #1a2035; border-radius: 12px;
  padding: 1.3rem 1.4rem; transition: border-color 0.2s; }
.feat-card:hover { border-color: #818cf833; }
.feat-icon { font-size: 1.4rem; margin-bottom: 8px; }
.feat-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 0.9rem; color: #c8d3f5; margin-bottom: 5px; }
.feat-desc { font-size: 0.8rem; color: #4e5c7a; line-height: 1.65; }

/* Job list */
.job-row { background: #0f1522; border: 1px solid #1a2035; border-radius: 10px;
  padding: 11px 15px; margin: 6px 0; display: flex; justify-content: space-between; align-items: center; }
.job-title { font-family: 'Syne', sans-serif; font-weight: 700; color: #c8d3f5; font-size: 0.9rem; }
.job-meta { font-size: 0.76rem; color: #3d4a65; margin-top: 2px; }
.job-date { font-size: 0.73rem; color: #2d3650; }

/* Streamlit overrides */
.stButton > button {
  background: linear-gradient(135deg, #818cf8, #6366f1) !important;
  color: white !important; border: none !important; border-radius: 8px !important;
  font-weight: 600 !important; font-family: 'DM Sans', sans-serif !important;
}
.stButton > button:hover { opacity: 0.88 !important; transform: translateY(-1px) !important; }
[data-testid="stMetricValue"] { color: #eef2ff !important; }
[data-testid="stMetricLabel"] { color: #4e5c7a !important; }
div[data-testid="stSidebarContent"] { padding-top: 0.5rem; }
.stSelectbox > div > div { background: #0f1522 !important; border-color: #1a2035 !important; color: #c8d3f5 !important; }
.stTextInput > div > div { background: #0f1522 !important; border-color: #1a2035 !important; }
.stTextInput input { color: #c8d3f5 !important; }
</style>
"""

st.markdown(DARK_CSS, unsafe_allow_html=True)

# ── Header ──────────────────────────────────────────────
st.markdown("""
<div style="padding: 1rem 0 0.5rem;">
  <div class="ts-wordmark">⬡ TalentScan AI</div>
  <div class="ts-tagline">Agentic Hiring Intelligence · HR Always in Control</div>
</div>
""", unsafe_allow_html=True)

API_URL = os.getenv("API_URL", "http://api:8000")

# ── Sidebar ─────────────────────────────────────────────
with st.sidebar:
    st.markdown('<div style="font-family:\'Syne\',sans-serif;font-weight:700;color:#c8d3f5;font-size:0.9rem;padding:0.8rem 0 0.4rem;">NAVIGATION</div>', unsafe_allow_html=True)
    st.page_link("app.py",                        label="⬡  Dashboard")
    st.page_link("pages/01_Post_a_Job.py",        label="📋  Post a Job")
    st.page_link("pages/02_Upload_CVs.py",        label="📤  Upload CVs")
    st.page_link("pages/03_Screening_Results.py", label="📊  Screening Results")
    st.page_link("pages/04_Candidate_History.py", label="📁  Candidate History")

    st.markdown('<div class="ts-rule"></div>', unsafe_allow_html=True)
    st.markdown('<div style="font-size:0.72rem;text-transform:uppercase;letter-spacing:0.08em;color:#2d3650;margin-bottom:6px;">System Status</div>', unsafe_allow_html=True)

    try:
        r = requests.get(f"{API_URL}/health", timeout=4)
        h = r.json()
        api_ok = True; db_ok = h.get("database", False); ai_ok = h.get("ollama", False)
    except Exception:
        api_ok = db_ok = ai_ok = False

    def status_row(label, ok, warn=False):
        css = "status-on" if ok else ("status-warn" if warn else "status-off")
        st.markdown(f'<div class="status-row"><span class="status-dot {css}"></span>{label}</div>', unsafe_allow_html=True)

    status_row("API Gateway", api_ok)
    status_row("PostgreSQL",  db_ok)
    status_row("Ollama LLM",  ai_ok, warn=True)

    st.markdown('<div class="ts-rule"></div>', unsafe_allow_html=True)
    st.markdown('<div style="font-size:0.72rem;color:#2d3650;line-height:1.7;">v1.1.0 · UAE Data Residency<br>AI augments — HR decides.</div>', unsafe_allow_html=True)

# ── Metrics ─────────────────────────────────────────────
try:
    jobs_data = requests.get(f"{API_URL}/api/v1/jobs/", timeout=4).json()
    total_jobs = len(jobs_data)
except Exception:
    jobs_data = []; total_jobs = 0

c1, c2, c3 = st.columns(3)
c1.metric("Active Roles",   total_jobs)
c2.metric("AI Engine",      "Llama 3.1" if ai_ok  else "Offline")
c3.metric("Pipeline",       "Live"      if api_ok else "Offline")

st.markdown('<div class="ts-rule"></div>', unsafe_allow_html=True)

# ── Feature overview ─────────────────────────────────────
st.markdown("""
<div class="feat-grid">
  <div class="feat-card">
    <div class="feat-icon">📋</div>
    <div class="feat-title">Post a Job</div>
    <div class="feat-desc">Upload a Job Description (PDF or TXT). Semantic embeddings are generated automatically for intelligent candidate matching.</div>
  </div>
  <div class="feat-card">
    <div class="feat-icon">📤</div>
    <div class="feat-title">Bulk CV Upload</div>
    <div class="feat-desc">Upload up to 500 CVs per batch — PDF, DOCX, or TXT. Processed asynchronously via a 4-agent AI pipeline.</div>
  </div>
  <div class="feat-card">
    <div class="feat-icon">📊</div>
    <div class="feat-title">Ranked Results</div>
    <div class="feat-desc">Candidates ranked by composite AI score. Explainable strengths, skill gaps, and talent development insights per profile.</div>
  </div>
  <div class="feat-card">
    <div class="feat-icon">📁</div>
    <div class="feat-title">Candidate History</div>
    <div class="feat-desc">Full audit trail of HR decisions. Returning candidate detection and cross-role application tracking built in.</div>
  </div>
</div>
""", unsafe_allow_html=True)

# ── Active jobs ───────────────────────────────────────────
if jobs_data:
    st.markdown('<div class="ts-rule"></div>', unsafe_allow_html=True)
    st.markdown('<div style="font-family:\'Syne\',sans-serif;font-weight:700;color:#c8d3f5;margin-bottom:10px;">Active Roles</div>', unsafe_allow_html=True)
    for job in jobs_data[:6]:
        dept = job.get("department") or "—"
        loc  = job.get("location")   or "—"
        date = (job.get("created_at") or "")[:10]
        st.markdown(f"""
        <div class="job-row">
          <div>
            <div class="job-title">{job['title']}</div>
            <div class="job-meta">{dept} &middot; {loc}</div>
          </div>
          <div class="job-date">{date}</div>
        </div>""", unsafe_allow_html=True)
