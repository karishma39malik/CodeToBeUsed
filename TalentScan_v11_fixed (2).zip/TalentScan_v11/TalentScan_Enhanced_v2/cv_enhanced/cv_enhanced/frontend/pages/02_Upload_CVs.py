"""
TalentScan — Upload CVs v10
Fixes:
 - Upload endpoint was POST /screenings/upload (wrong) → now POST /screenings/upload/{job_id} (correct)
 - Shows No-JD mode badge when selected role has no_jd=True
 - Shows clear warning that scores will be generic in No-JD mode
 - Error messages improved with full API response body
"""

import streamlit as st
import requests
import os
import time
import json
import plotly.graph_objects as go

st.set_page_config(page_title="Upload CVs · TalentScan", page_icon="📤", layout="wide")

API_BASE = os.getenv("API_URL", "http://api:8000")
API      = f"{API_BASE}/api/v1"

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
html,body,[class*="css"]{font-family:'Inter',-apple-system,sans-serif;font-size:14px;}
.stApp{background:#F7F8FC!important;}
.block-container{padding:0 1.5rem 3rem!important;max-width:1300px;}
header,[data-testid="stHeader"]{background:#FFFFFF!important;border-bottom:1px solid #E2E6EA!important;}
section[data-testid="stSidebar"]{background:#FFFFFF!important;border-right:1px solid #E2E6EA!important;}
.ts-nav{background:linear-gradient(135deg,#0F2D6B 0%,#1877F2 100%);padding:0 1.5rem;height:60px;
  display:flex;align-items:center;justify-content:space-between;
  margin:-0.1rem -1.5rem 1.8rem -1.5rem;box-shadow:0 2px 12px rgba(24,119,242,0.25);}
.ts-nav-logo{font-size:1.4rem;font-weight:800;color:#FFFFFF;letter-spacing:-0.5px;}
.ts-nav-title{font-size:0.9rem;font-weight:600;color:rgba(255,255,255,0.9);}
.fb-card{background:#FFFFFF;border-radius:8px;border:1px solid #E2E6EA;
  padding:1.2rem 1.4rem;margin-bottom:12px;box-shadow:0 1px 2px rgba(0,0,0,0.06);}
.fb-card-lg{background:#FFFFFF;border-radius:10px;border:1px solid #E2E6EA;
  padding:1.5rem;margin-bottom:16px;box-shadow:0 1px 4px rgba(0,0,0,0.05);}
.sec-label{font-size:0.68rem;font-weight:700;text-transform:uppercase;
  letter-spacing:0.1em;color:#8A9BB0;margin-bottom:10px;}
.metric-card{background:#FFFFFF;border-radius:8px;border:1px solid #E2E6EA;
  padding:0.8rem 1rem;box-shadow:0 1px 2px rgba(0,0,0,0.04);position:relative;overflow:hidden;}
.metric-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;
  background:var(--accent,#1877F2);}
.metric-val{font-size:1.6rem;font-weight:800;color:#050505;line-height:1;}
.metric-lbl{font-size:0.65rem;font-weight:700;text-transform:uppercase;
  letter-spacing:0.08em;color:#8A9BB0;margin-top:3px;}
.nojd-badge{display:inline-flex;align-items:center;gap:6px;background:#FFF8E6;
  border:1px solid #FFD975;border-radius:20px;padding:4px 12px;
  font-size:0.75rem;font-weight:700;color:#7A5700;}
.jd-badge{display:inline-flex;align-items:center;gap:6px;background:#E7F0FF;
  border:1px solid #BBD3FB;border-radius:20px;padding:4px 12px;
  font-size:0.75rem;font-weight:700;color:#1244A2;}
label{color:#65676B!important;font-size:0.78rem!important;}
.stSelectbox>div>div{background:#FFFFFF!important;border-color:#E2E6EA!important;border-radius:7px!important;}
.stTextInput>div>div{background:#FFFFFF!important;border-color:#E2E6EA!important;border-radius:7px!important;}
.stTextInput input{color:#050505!important;}
.stButton>button{background:#1877F2!important;color:#FFFFFF!important;border:none!important;
  border-radius:7px!important;font-weight:700!important;font-size:0.85rem!important;padding:10px 22px!important;}
.stButton>button:hover{background:#166FE5!important;}
</style>
""", unsafe_allow_html=True)

FB_BLUE   = "#1877F2"
FB_GREEN  = "#42B72A"
FB_ORANGE = "#F5A623"
FB_RED    = "#FA3E3E"

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="padding:0.5rem 0 1.2rem;">
      <div style="font-size:1.4rem;font-weight:900;color:#1877F2;letter-spacing:-0.5px;">TalentScan</div>
      <div style="font-size:0.7rem;color:#8A9BB0;margin-top:2px;font-weight:600;text-transform:uppercase;">Upload CVs</div>
    </div><div style="height:1px;background:#E2E6EA;margin-bottom:1rem;"></div>
    """, unsafe_allow_html=True)
    st.page_link("app.py",                        label="🏠  Dashboard")
    st.page_link("pages/01_Post_a_Job.py",         label="📋  Post a Job")
    st.page_link("pages/02_Upload_CVs.py",         label="📤  Upload CVs")
    st.page_link("pages/03_High_Level_Review.py",  label="📊  High-Level Review")
    st.page_link("pages/04_Detailed_Insights.py",  label="🔬  Detailed Insights")
    st.page_link("pages/05_Candidate_History.py",  label="📁  Candidate History")
    st.markdown("""
    <div style="margin-top:1.5rem;background:#F0F2F5;border-radius:8px;padding:10px 12px;">
      <div style="font-size:0.72rem;font-weight:700;color:#65676B;text-transform:uppercase;
          letter-spacing:0.06em;margin-bottom:8px;">Pipeline Agents</div>
      <div style="font-size:0.75rem;color:#050505;line-height:2.0;">
        1️⃣ Ingestion Agent<br>
        2️⃣ Matching / No-JD Agent<br>
        3️⃣ Potential Agent<br>
        4️⃣ Validation Agent
      </div>
    </div>""", unsafe_allow_html=True)

# ── Topnav ─────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="ts-nav">
  <div style="display:flex;align-items:center;">
    <div class="ts-nav-logo">TalentScan</div>
  </div>
  <div class="ts-nav-title">Upload CVs · Start Screening</div>
  <div style="font-size:0.78rem;color:rgba(255,255,255,0.55);">Step 2 of 3</div>
</div>""", unsafe_allow_html=True)

# ── Fetch jobs ─────────────────────────────────────────────────────────────────
try:
    jobs_resp = requests.get(f"{API}/jobs/", timeout=5)
    jobs_list = jobs_resp.json() if jobs_resp.status_code == 200 else []
    if not isinstance(jobs_list, list):
        jobs_list = []
except Exception as e:
    st.error(f"Cannot connect to API: {e}")
    st.stop()

if not jobs_list:
    st.warning("No active roles found. Please post a job first.")
    st.stop()

# Build map: title → full job dict
job_map = {j["title"]: j for j in jobs_list}

# ── Layout ─────────────────────────────────────────────────────────────────────
upload_col, pipe_col = st.columns([3, 2], gap="large")

with upload_col:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Upload Configuration</div>', unsafe_allow_html=True)

    selected_label = st.selectbox("Select Role", list(job_map.keys()))
    selected_job   = job_map[selected_label]
    selected_job_id = selected_job["id"]
    is_no_jd = bool(selected_job.get("no_jd"))

    # ── Mode badge ─────────────────────────────────────────────────────────────
    if is_no_jd:
        st.markdown("""
        <div class="nojd-badge">🏢 No-JD Mode — Generic Department Screening</div>
        <div style="background:#FFF8E6;border:1px solid #FFD975;border-radius:8px;
            padding:10px 14px;margin:8px 0 12px;font-size:0.8rem;color:#7A5700;">
          <strong>⚠️ No Job Description available for this role.</strong><br>
          CVs will be screened against the organisation's department taxonomy (15 clusters, 130+ depts).
          Scores are generic and capped at 72%. Output will suggest best-fit departments for each candidate.
        </div>""", unsafe_allow_html=True)
    else:
        st.markdown("""
        <div class="jd-badge">📄 JD Mode — Role-Specific Screening</div>
        <div style="background:#EBF3FF;border:1px solid #BBD3FB;border-radius:8px;
            padding:8px 14px;margin:8px 0 12px;font-size:0.8rem;color:#1244A2;">
          CVs will be scored against the job description with full must-have / nice-to-have analysis.
        </div>""", unsafe_allow_html=True)

    uploaded_by = st.text_input("Your Name", placeholder="HR Officer full name")

    cv_files = st.file_uploader(
        "Upload CVs (PDF, DOCX, or TXT)",
        type=["pdf", "docx", "txt"],
        accept_multiple_files=True,
        help="Upload multiple CVs at once — each processed through the AI pipeline"
    )

    if cv_files:
        st.markdown(f'<div style="font-size:0.78rem;color:#65676B;margin:8px 0;">{len(cv_files)} file(s) selected</div>',
                    unsafe_allow_html=True)
        for f in cv_files[:5]:
            size_kb = len(f.getvalue()) / 1024
            ext = f.name.split(".")[-1].upper()
            ext_color = {"PDF": "#FA3E3E", "DOCX": "#1877F2", "TXT": "#42B72A"}.get(ext, "#65676B")
            st.markdown(f"""
            <div style="display:flex;align-items:center;gap:10px;padding:6px 10px;
                background:#F0F2F5;border-radius:6px;margin:4px 0;">
              <span style="background:{ext_color};color:white;font-size:0.65rem;font-weight:700;
                  padding:2px 6px;border-radius:3px;">{ext}</span>
              <span style="font-size:0.8rem;color:#050505;flex:1;overflow:hidden;
                  text-overflow:ellipsis;white-space:nowrap;">{f.name}</span>
              <span style="font-size:0.72rem;color:#BCC0C4;">{size_kb:.0f} KB</span>
            </div>""", unsafe_allow_html=True)
        if len(cv_files) > 5:
            st.markdown(f'<div style="font-size:0.72rem;color:#BCC0C4;padding:4px 10px;">+ {len(cv_files)-5} more files</div>',
                        unsafe_allow_html=True)

    st.markdown("", unsafe_allow_html=True)
    start = st.button("🚀  Start Screening Pipeline", use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

    if start:
        if not cv_files:
            st.error("Please upload at least one CV file.")
        elif not uploaded_by.strip():
            st.error("Please enter your name.")
        else:
            progress = st.progress(0, text="Preparing upload…")
            try:
                file_tuples = [
                    ("files", (f.name, f.getvalue(), f.type or "application/octet-stream"))
                    for f in cv_files
                ]
                progress.progress(30, text="Sending to API…")

                # ✅ CORRECT endpoint: POST /screenings/upload/{job_id}
                resp = requests.post(
                    f"{API}/screenings/upload/{selected_job_id}",
                    files=file_tuples,
                    timeout=180,
                )
                progress.progress(100, text="Upload complete!")

                if resp.status_code != 200:
                    st.error(f"Upload failed ({resp.status_code})")
                    # Show full error body for debugging
                    try:
                        err_body = resp.json()
                        st.json(err_body)
                    except Exception:
                        st.code(resp.text[:500])
                    st.stop()

                result = resp.json()
                total_r = result.get("total_received", 0)
                queued  = result.get("queued", 0)
                failed  = result.get("failed", 0)
                errors  = result.get("errors", [])

                if is_no_jd:
                    st.success(f"✅ {queued} CV(s) queued — **No-JD generic screening** running in background.")
                    st.info("📋 Department-fit scores (max 72%) will appear in High-Level Review and Detailed Insights once processing completes.")
                else:
                    st.success(f"✅ {queued} CV(s) queued for AI processing!")

                r1, r2, r3 = st.columns(3)
                r1.metric("Received", total_r)
                r2.metric("Queued",   queued)
                r3.metric("Failed",   failed,
                           delta=f"-{failed}" if failed else None,
                           delta_color="inverse")

                if errors:
                    with st.expander(f"⚠️ {len(errors)} file(s) failed"):
                        for e in errors:
                            fname = e.get("file") or e.get("filename") or "?"
                            reason = e.get("reason") or e.get("error") or ""
                            st.markdown(
                                f'<div style="font-size:0.8rem;color:#FA3E3E;padding:2px 0;">'
                                f'• {fname} — {reason}</div>',
                                unsafe_allow_html=True,
                            )

                est = queued * 4
                st.markdown(
                    f'<div style="font-size:0.75rem;color:#8A9BB0;margin-top:6px;">'
                    f'⏳ Estimated processing time: ~{est} min ({queued} CV × ~4 min each on CPU). '
                    f'Check Detailed Insights when complete.</div>',
                    unsafe_allow_html=True,
                )

            except requests.exceptions.Timeout:
                st.error("Request timed out. Try uploading fewer files at once.")
                progress.empty()
            except Exception as e:
                st.error(f"Unexpected error: {e}")
                progress.empty()

with pipe_col:
    # Pipeline diagram
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Pipeline Architecture</div>', unsafe_allow_html=True)
    agents = ["Ingestion", "Match/NoJD", "Potential", "Validation", "Result"]
    colors = [FB_BLUE, "#6366F1" if not is_no_jd else FB_ORANGE, FB_ORANGE, "#8B5CF6", FB_GREEN]
    fig_pipe = go.Figure()
    for i, (agent, color) in enumerate(zip(agents, colors)):
        fig_pipe.add_trace(go.Scatter(
            x=[i], y=[0], mode="markers+text",
            marker=dict(size=46, color=color, line=dict(color="white", width=3)),
            text=[str(i+1)], textfont=dict(size=13, color="white"),
            textposition="middle center", showlegend=False,
            hovertemplate=f"{agent}<extra></extra>",
        ))
        fig_pipe.add_annotation(x=i, y=-0.38, text=agent,
                                showarrow=False, font=dict(size=9, color="#65676B"))
        if i < len(agents) - 1:
            fig_pipe.add_annotation(x=i+0.55, y=0, text="→",
                                    showarrow=False, font=dict(size=16, color="#CED0D4"))
    fig_pipe.update_layout(
        height=155, margin=dict(t=10, b=45, l=10, r=10),
        paper_bgcolor="#FFFFFF", plot_bgcolor="#FFFFFF",
        xaxis=dict(visible=False, range=[-0.5, 4.5]),
        yaxis=dict(visible=False, range=[-0.75, 0.5]),
        font={"family": "Inter"},
    )
    st.plotly_chart(fig_pipe, use_container_width=True, config={"displayModeBar": False})

    # Agent 2 label changes based on mode
    if is_no_jd:
        st.markdown("""
        <div style="background:#FFF8E6;border:1px solid #FFD975;border-radius:6px;
            padding:8px 12px;font-size:0.75rem;color:#7A5700;margin-top:-8px;margin-bottom:8px;">
          Agent 2 = <strong>No-JD Agent</strong> — dept taxonomy matching
        </div>""", unsafe_allow_html=True)
    else:
        st.markdown("""
        <div style="background:#EBF3FF;border:1px solid #BBD3FB;border-radius:6px;
            padding:8px 12px;font-size:0.75rem;color:#1244A2;margin-top:-8px;margin-bottom:8px;">
          Agent 2 = <strong>Matching Agent</strong> — JD-specific scoring
        </div>""", unsafe_allow_html=True)

    st.markdown("</div>", unsafe_allow_html=True)

    # Estimated time
    n_files = len(cv_files) if cv_files else 0
    est_min = n_files * 4
    st.markdown(f"""
    <div class="fb-card">
      <div class="sec-label">Estimated Processing Time</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
        <div class="metric-card" style="--accent:#1877F2;">
          <div class="metric-val">{n_files}</div>
          <div class="metric-lbl">Files Selected</div>
        </div>
        <div class="metric-card" style="--accent:#42B72A;">
          <div class="metric-val" style="color:#1877F2;">~{est_min}m</div>
          <div class="metric-lbl">Est. Time</div>
        </div>
      </div>
      <div style="font-size:0.72rem;color:#BCC0C4;margin-top:8px;">~4 min per CV on CPU · Ollama LLaMA 3.1 8B</div>
    </div>""", unsafe_allow_html=True)

    # Current role status
    try:
        pipe_status = requests.get(f"{API}/jobs/{selected_job_id}/pipeline", timeout=5).json()
        total_ = pipe_status.get("total_screened", 0)
        pend_  = pipe_status.get("pending_review", 0)
        avg_   = pipe_status.get("avg_score") or 0
        mode_badge = "🏢 No-JD" if is_no_jd else "📄 JD"
        st.markdown(f"""
        <div class="fb-card">
          <div class="sec-label">Role Status — {selected_label} &nbsp; {mode_badge}</div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;">
            <div class="metric-card" style="padding:0.7rem;--accent:#1877F2;">
              <div class="metric-val" style="font-size:1.4rem;">{total_}</div>
              <div class="metric-lbl">Screened</div>
            </div>
            <div class="metric-card" style="padding:0.7rem;--accent:#F5A623;">
              <div class="metric-val" style="font-size:1.4rem;color:#F5A623;">{pend_}</div>
              <div class="metric-lbl">Pending</div>
            </div>
            <div class="metric-card" style="padding:0.7rem;--accent:#6B2FA0;">
              <div class="metric-val" style="font-size:1.4rem;color:#1877F2;">
                {f"{avg_:.0%}" if avg_ else "—"}
              </div>
              <div class="metric-lbl">Avg Score</div>
            </div>
          </div>
          {"<div style='font-size:0.7rem;color:#B35900;margin-top:8px;'>⚠️ Scores capped at 72% — No-JD mode</div>" if is_no_jd else ""}
        </div>""", unsafe_allow_html=True)
    except Exception:
        pass

    # Formats
    st.markdown("""
    <div class="fb-card">
      <div class="sec-label">Supported Formats</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <span style="background:#FFEBEE;color:#C62828;font-weight:700;font-size:0.75rem;padding:4px 10px;border-radius:4px;">PDF</span>
        <span style="background:#E7F0FF;color:#1877F2;font-weight:700;font-size:0.75rem;padding:4px 10px;border-radius:4px;">DOCX</span>
        <span style="background:#E7F3E8;color:#1A6B1E;font-weight:700;font-size:0.75rem;padding:4px 10px;border-radius:4px;">TXT</span>
      </div>
      <div style="font-size:0.72rem;color:#BCC0C4;margin-top:8px;">Max 10MB per file · Up to 500 files per batch</div>
    </div>""", unsafe_allow_html=True)
