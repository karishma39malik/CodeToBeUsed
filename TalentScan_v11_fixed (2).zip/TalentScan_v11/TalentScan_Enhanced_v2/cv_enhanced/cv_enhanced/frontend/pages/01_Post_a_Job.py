"""
TalentScan — Post a Job v10
Supports: full JD upload (PDF/TXT), plain text JD, OR No-JD mode.
No-JD mode routes all uploaded CVs to the generic department-fit screener.
"""

import os
import streamlit as st
import requests

st.set_page_config(page_title="Post a Job · TalentScan", page_icon="📋", layout="wide")

API_BASE = os.getenv("API_URL", "http://api:8000")
API      = f"{API_BASE}/api/v1"

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
html,body,[class*="css"]{font-family:'Inter',-apple-system,sans-serif;font-size:14px;}
.stApp{background:#F7F8FC!important;}
.block-container{padding:0 1.5rem 3rem!important;max-width:1200px;}
header,[data-testid="stHeader"]{background:#FFFFFF!important;border-bottom:1px solid #E2E6EA!important;}
section[data-testid="stSidebar"]{background:#FFFFFF!important;border-right:1px solid #E2E6EA!important;}
.ts-nav{background:linear-gradient(135deg,#0F2D6B 0%,#1877F2 100%);padding:0 1.5rem;height:60px;display:flex;align-items:center;justify-content:space-between;margin:-0.1rem -1.5rem 1.8rem -1.5rem;box-shadow:0 2px 12px rgba(24,119,242,0.25);}
.ts-nav-logo{font-size:1.4rem;font-weight:800;color:#FFFFFF;letter-spacing:-0.5px;}
.ts-nav-title{font-size:0.9rem;font-weight:600;color:rgba(255,255,255,0.9);}
.fb-card-lg{background:#FFFFFF;border-radius:10px;border:1px solid #E2E6EA;padding:1.5rem;margin-bottom:16px;box-shadow:0 1px 4px rgba(0,0,0,0.05);}
.sec-label{font-size:0.68rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:#8A9BB0;margin-bottom:10px;}
.mode-box{border-radius:10px;padding:1.2rem 1.4rem;margin-bottom:1rem;}
.mode-jd{background:#EBF3FF;border:1px solid #BBD3FB;}
.mode-nojd{background:#FFF8E6;border:1px solid #FFD975;}
.nojd-banner{background:#FFF4CD;border:1px solid #FFD600;border-radius:8px;padding:12px 16px;font-size:0.82rem;color:#7A5700;margin-bottom:1rem;}
label{color:#65676B!important;font-size:0.78rem!important;}
.stTextInput>div>div{background:#FFFFFF!important;border-color:#E2E6EA!important;border-radius:7px!important;}
.stTextInput input{color:#050505!important;}
.stButton>button{background:#1877F2!important;color:#FFFFFF!important;border:none!important;border-radius:7px!important;font-weight:700!important;font-size:0.85rem!important;padding:10px 22px!important;}
.stButton>button:hover{background:#166FE5!important;}
</style>
""", unsafe_allow_html=True)

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="padding:0.5rem 0 1.2rem;">
      <div style="font-size:1.4rem;font-weight:900;color:#1877F2;letter-spacing:-0.5px;">TalentScan</div>
      <div style="font-size:0.7rem;color:#8A9BB0;margin-top:2px;font-weight:600;text-transform:uppercase;">Post a Role</div>
    </div><div style="height:1px;background:#E2E6EA;margin-bottom:1rem;"></div>
    """, unsafe_allow_html=True)
    st.page_link("app.py",                        label="🏠  Dashboard")
    st.page_link("pages/01_Post_a_Job.py",         label="📋  Post a Job")
    st.page_link("pages/02_Upload_CVs.py",         label="📤  Upload CVs")
    st.page_link("pages/03_High_Level_Review.py",  label="📊  High-Level Review")
    st.page_link("pages/04_Detailed_Insights.py",  label="🔬  Detailed Insights")
    st.page_link("pages/05_Candidate_History.py",  label="📁  Candidate History")

    st.markdown("""
    <div style="margin-top:1.5rem;background:#F0F2F5;border-radius:8px;padding:10px 12px;">
      <div style="font-size:0.72rem;font-weight:700;color:#65676B;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:8px;">Two Modes</div>
      <div style="font-size:0.75rem;color:#050505;line-height:2.0;">
        📄 <b>With JD</b> — full role-specific scoring<br>
        🏢 <b>No JD</b> — generic dept-fit screening
      </div>
    </div>""", unsafe_allow_html=True)

# ── Topnav ─────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="ts-nav">
  <div style="display:flex;align-items:center;">
    <div class="ts-nav-logo">TalentScan</div>
  </div>
  <div class="ts-nav-title">Post a Role</div>
  <div style="font-size:0.78rem;color:rgba(255,255,255,0.55);">Step 1 of 3</div>
</div>""", unsafe_allow_html=True)

form_col, info_col = st.columns([3, 2], gap="large")

with form_col:
    st.markdown('<div class="fb-card-lg">', unsafe_allow_html=True)
    st.markdown('<div class="sec-label">Role Details</div>', unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    with c1:
        title = st.text_input("Job Title *", placeholder="e.g. Senior Systems Engineer")
        dept  = st.text_input("Department", placeholder="e.g. Engineering")
    with c2:
        loc       = st.text_input("Location", placeholder="e.g. Abu Dhabi, UAE")
        posted_by = st.text_input("Your Name *", placeholder="HR Manager name")

    st.markdown('<div style="height:1px;background:#E2E6EA;margin:1rem 0;"></div>', unsafe_allow_html=True)

    # ── JD Mode toggle ─────────────────────────────────────────────────────────
    st.markdown('<div class="sec-label">Job Description Mode</div>', unsafe_allow_html=True)
    mode = st.radio(
        "mode",
        ["📄  I have a Job Description (JD)", "🏢  No JD — Generic Department Screening"],
        label_visibility="collapsed",
    )
    no_jd_mode = "No JD" in mode

    if no_jd_mode:
        st.markdown("""
        <div class="nojd-banner">
          ⚠️ <strong>No-JD Mode:</strong> CVs will be screened against your organisation's
          department taxonomy (15 clusters, 130+ departments). Scores are generic and capped at 72%
          to avoid false precision. Output will clearly show which departments the candidate best fits.
          A Job Description is always recommended for role-specific hiring.
        </div>""", unsafe_allow_html=True)
        jd_file = None
        description_text = None
    else:
        jd_tab1, jd_tab2 = st.tabs(["📎 Upload PDF / TXT", "✏️ Paste JD Text"])
        with jd_tab1:
            jd_file = st.file_uploader("Upload Job Description", type=["txt", "pdf"],
                                       label_visibility="collapsed")
        with jd_tab2:
            description_text = st.text_area("Paste JD here", height=220,
                                            placeholder="Paste the full job description…")
            jd_file = None if description_text else jd_file

    st.markdown('<div style="height:1px;background:#E2E6EA;margin:1rem 0;"></div>', unsafe_allow_html=True)

    if st.button("🚀  Post Role", type="primary", use_container_width=True):
        if not title.strip():
            st.error("Job title is required.")
        elif not posted_by.strip():
            st.error("Your name is required.")
        elif not no_jd_mode and not jd_file and not (description_text or "").strip():
            st.error("Please upload a JD file or paste JD text, or switch to No-JD mode.")
        else:
            with st.spinner("Creating role…"):
                try:
                    data = {
                        "title":      title.strip(),
                        "department": dept.strip() or "General",
                        "location":   loc.strip() or "UAE",
                        "created_by": posted_by.strip(),
                        "no_jd":      str(no_jd_mode).lower(),
                    }
                    if description_text and description_text.strip():
                        data["description"] = description_text.strip()

                    files = {}
                    if jd_file:
                        files["jd_file"] = (jd_file.name, jd_file.getvalue(), jd_file.type)

                    resp = requests.post(f"{API}/jobs/", data=data, files=files or None, timeout=30)

                    if resp.status_code == 200:
                        result = resp.json()
                        mode_badge = "🏢 No-JD Generic Mode" if no_jd_mode else "📄 JD-Matched Mode"
                        st.success(f"✅ Role **{title}** created! ({mode_badge})")
                        st.markdown(f"""
                        <div style="background:#E6F9EE;border:1px solid #B5E8C9;border-radius:8px;padding:14px 16px;margin-top:1rem;font-size:0.85rem;">
                          <strong>Job ID:</strong> <code>{result.get('id','')}</code><br>
                          <strong>Mode:</strong> {mode_badge}<br>
                          {"<strong>⚠️ Note:</strong> Scores will be generic (max 72%) — recommend adding a JD for precise screening." if no_jd_mode else ""}
                        </div>""", unsafe_allow_html=True)
                        st.info("➡️ Next: Go to **Upload CVs** to start screening.")
                    else:
                        err = resp.json() if resp.headers.get("content-type","").startswith("application/json") else {}
                        st.error(f"Error {resp.status_code}: {err.get('detail', resp.text[:200])}")
                except Exception as e:
                    st.error(f"Cannot reach API: {e}")

    st.markdown('</div>', unsafe_allow_html=True)

with info_col:
    st.markdown("""
    <div class="fb-card-lg">
      <div class="sec-label">Mode Comparison</div>
      <div class="mode-box mode-jd">
        <div style="font-weight:700;font-size:0.9rem;color:#1877F2;margin-bottom:6px;">📄 With Job Description</div>
        <div style="font-size:0.8rem;color:#050505;line-height:1.9;">
          ✓ Role-specific skill matching<br>
          ✓ Must-have / nice-to-have scoring<br>
          ✓ Hard filter on mandatory skills<br>
          ✓ Scores up to 100%<br>
          ✓ Full LLM rationale vs JD<br>
          ✓ Recommended for active hiring
        </div>
      </div>
      <div class="mode-box mode-nojd">
        <div style="font-weight:700;font-size:0.9rem;color:#B35900;margin-bottom:6px;">🏢 No JD — Generic Screening</div>
        <div style="font-size:0.8rem;color:#050505;line-height:1.9;">
          ✓ No JD required<br>
          ✓ Matches against 15 dept clusters<br>
          ✓ 130+ departments in taxonomy<br>
          ✓ Suggests best-fit departments<br>
          ⚠ Scores capped at 72% (generic)<br>
          ⚠ Output labelled NO-JD clearly<br>
          ✓ Good for talent pool building
        </div>
      </div>
    </div>
    <div class="fb-card-lg" style="margin-top:0;">
      <div class="sec-label">Organisation Department Clusters</div>
      <div style="font-size:0.78rem;color:#050505;line-height:2.0;">
        Finance &amp; Accounts · Engineering &amp; Design<br>
        Flight Test &amp; Prototypes · Manufacturing<br>
        Missiles &amp; Defence R&amp;D · Digital &amp; IT<br>
        Program &amp; Project Management · Quality &amp; Safety<br>
        Supply Chain &amp; Procurement · People &amp; Culture<br>
        Marketing &amp; Comms · Business Development<br>
        Facilities &amp; Infrastructure · Legal &amp; Admin<br>
        UAV &amp; Special Operations
      </div>
      <div style="margin-top:8px;font-size:0.7rem;color:#8A9BB0;">130+ sub-departments mapped · Calidus taxonomy</div>
    </div>
    """, unsafe_allow_html=True)