"""
TalentScan — No-JD Screening Agent
====================================
When no Job Description exists, this agent evaluates a CV purely against
the organisation's known department taxonomy using:
  1. Skill-to-department keyword mapping (industry best-practice skill clusters)
  2. LLM rationale generation (department fit reasoning)
  3. A transparent scoring model with GENERIC caveats clearly surfaced in output

The composite score produced here is deliberately conservative (max ~0.72)
because without a JD we cannot validate must-have requirements.
The output always carries a NO_JD flag so the UI can surface the right caveats.

Scoring model (No-JD mode):
  dept_fit_score   × 0.50   — how well CV skills map to the best-fit department(s)
  experience_score × 0.25   — seniority / years of experience signal
  breadth_score    × 0.25   — cross-functional transferability

MAX possible composite in no-JD mode: ~0.72  (capped to prevent false precision)
"""

import json
import re
from typing import Any, Dict, List, Optional, Tuple

import structlog
import ollama as ollama_client

from agents.base_agent import BaseAgent
from config.settings import settings

logger = structlog.get_logger(__name__)

# ── Organisation department taxonomy (read from images) ──────────────────────
# Grouped into parent clusters for scoring purposes.
ORG_DEPARTMENTS = [
    # Finance & Corporate
    "Finance & Accounts",
    "Accounting And Reporting",
    "Director - Finance & Accounts",
    "Finance",
    # Engineering (Aero / Core)
    "Engineering",
    "Engineering Systems",
    "Design - Engineering",
    "Flight Science - Engineering",
    "Structural Integrity - Engineering",
    "System Engineering - Engineering",
    "Chief Engineer Office - Engineering",
    "Avionics - Engineering",
    "Avionics And Mission",
    "Electrical Systems",
    # Flight Test & Prototypes
    "Flight Test And Prototypes",
    "Fti - Flight Test And Prototypes",
    "Maintenance - Flight Test And Prototypes",
    "Prototype & Testing",
    "Prototype & Testing - M4",
    "Flight Test and Prototype - CLS",
    # Aerospace / Safety
    "Aerospace",
    "Safety (Aero)",
    "Safety (Land)",
    "Director - Airworthiness & Certification",
    "Certification /Continued / Continuing Airworthiness",
    # Manufacturing & Industrial
    "Industrial Operations",
    "Manufacturing - Industrial Operations",
    "Production - Industrial Operations",
    "Advanced Industries Machining",
    "Fabrication - CLS",
    "Production",
    "Production - CLS",
    # Mechanical Systems / M4
    "Mechanical Systems - M4",
    "Mechanical - Hard Services",
    "Protection - M4",
    "Production - M4",
    # Missiles & Development (M&D)
    "Missiles And Technology - M&D",
    "Research And Development - M&D",
    "Research and Development - M&D",
    "System Integraion - M&D",
    "Project/Engineering/Store - M&D",
    "Business Support Services M & D",
    "Program Managers - M&D",
    "Program Managers - M&D 1",
    "Head Of M & D",
    "Project Management Office M&D",
    # CLS (Customer & Lifecycle Support)
    "CLS Office",
    "Chief - Land System - CLS",
    "Head - Scm - CLS",
    "Field Support",
    "Product Quality (Land) - CLS",
    "Governance Risk & Compliance - CLS",
    "Infrastructure & Support Division- CLS",
    "Lead - Land System Engineering - CLS",
    "Design - Engineering - CLS",
    "Prototype & Testing - CLS",
    "Warehouse - CLS",
    "Purchasing - Scm - CLS",
    "Project Management Office - Programs - CLS",
    "Lead - Protection - CLS",
    "Protection - CLS",
    # Land Systems Engineering
    "Head - Land System Engineering",
    "Lead - Land System Engineering",
    # Digital / IT / Cyber
    "Cybersecurity & Network",
    "Cyber",
    "Digital Transformation",
    "Director - Digital Transformation",
    "ERP & Applications Division",
    "Ai",
    # Programs / PMO
    "Program Management",
    "Project Management Office - Programs",
    "Director - Program Management",
    "PMO",
    # People & Culture / HR
    "People & Culture",
    "Director - People & Culture",
    "Employee Relations",
    "Strategic People Management",
    "Training &Development",
    "Emiratisation",
    # Marketing & Comms
    "Marketing & Communications",
    "Manager - Marketing & Communications",
    "Director - Marketing & Communications",
    "Branding & Design",
    "Public Relations",
    "Exhibitions & Corp Events",
    # Business Development / Sales
    "Director - Business Development",
    "International Market (Gcc,Mena,Europe)",
    "Mod & Governmental Contracts",
    # Operations / Supply Chain
    "Operations - Uav",
    "Procurement",
    "Purchasing - SCM",
    "Supplier Contracts Management",
    "Transportation Services",
    "Warehouse",
    "Product Support",
    # Quality / Compliance
    "Product Quality (Aero)",
    "Governance Risk & Compliance",
    "Compliance & Audit Team",
    "Director - Qhse",
    # Legal / Admin
    "Administration - Legal",
    "Director - Legal",
    "Director - Strategic Planning",
    "Corporate Service",
    # Facilities / Infrastructure
    "Facilities & Projects",
    "Director - Facilities & Projects",
    "Admin - Facilities & Projects",
    "Infrastructure & Support Division",
    "Construction - Hard Services",
    "Electrical - Hard Services",
    "Hard Services Maintenance - Hard Services",
    "Soft Services - Soft Services",
    "Security Section - Soft Services",
    "Operation - Soft Services",
    "General Services",
    "Director - General Services",
    "Admin - General Services",
    "Travel Desk",
    # Executive / Strategy
    "CEO Office",
    "Chairman",
    "Director - Strategic Planning",
    "Consultant Internal",
    # UAV / Special Projects
    "Project - UAV",
    "Operations - Uav",
]

# ── Department clusters with skill keywords ──────────────────────────────────
DEPT_CLUSTERS = {
    "Finance & Accounts": {
        "keywords": ["finance","accounting","accounts","ifrs","gaap","audit","tax","treasury","budgeting",
                     "financial reporting","erp","sap","oracle financials","cost control","variance analysis",
                     "cash flow","balance sheet","p&l","forecasting","financial analysis","cpa","acca","cma"],
        "departments": ["Finance & Accounts","Accounting And Reporting","Director - Finance & Accounts","Finance"],
    },
    "Engineering & Design": {
        "keywords": ["mechanical engineering","electrical engineering","structural engineering","systems engineering",
                     "autocad","catia","solidworks","matlab","ansys","fea","cfd","tolerance analysis",
                     "technical drawings","design review","engineering change","airworthiness","DO-178","DO-254",
                     "avionics","aerodynamics","flight mechanics","propulsion","stress analysis"],
        "departments": ["Engineering","Engineering Systems","Design - Engineering","Flight Science - Engineering",
                        "Structural Integrity - Engineering","System Engineering - Engineering","Avionics - Engineering",
                        "Avionics And Mission","Electrical Systems","Chief Engineer Office - Engineering"],
    },
    "Flight Test & Prototypes": {
        "keywords": ["flight test","prototype","test pilot","flight dynamics","telemetry","test planning",
                     "ground testing","rig testing","airworthiness testing","data acquisition","fti",
                     "flight envelope","test reports","flight safety","certification testing"],
        "departments": ["Flight Test And Prototypes","Fti - Flight Test And Prototypes",
                        "Prototype & Testing","Flight Test and Prototype - CLS"],
    },
    "Manufacturing & Production": {
        "keywords": ["manufacturing","production","machining","fabrication","cnc","lean","six sigma",
                     "quality control","assembly","industrial engineering","process improvement","tooling",
                     "jig","fixture","welding","composites","5s","kaizen","production planning"],
        "departments": ["Industrial Operations","Manufacturing - Industrial Operations","Production - Industrial Operations",
                        "Advanced Industries Machining","Fabrication - CLS","Production","Production - CLS"],
    },
    "Digital & IT": {
        "keywords": ["software","python","java","cloud","azure","aws","gcp","cybersecurity","network",
                     "erp","sap","oracle","digital transformation","it infrastructure","database","sql",
                     "devops","agile","scrum","ai","machine learning","data analytics","power bi",
                     "tableau","information security","iso 27001","penetration testing","siem","it governance"],
        "departments": ["Cybersecurity & Network","Cyber","Digital Transformation","ERP & Applications Division","Ai"],
    },
    "Program & Project Management": {
        "keywords": ["project management","program management","pmp","prince2","agile","scrum","stakeholder",
                     "milestone","risk management","schedule","budget management","pmo","earned value",
                     "change management","delivery management","msp","pgmp","program director"],
        "departments": ["Program Management","Project Management Office - Programs","Director - Program Management",
                        "Program Managers - M&D","Program Managers - M&D 1"],
    },
    "Missiles & Defence R&D": {
        "keywords": ["missiles","weapons systems","defence","munitions","guided systems","propulsion systems",
                     "warhead","guidance navigation","target acquisition","electronic warfare","countermeasures",
                     "radar","sensor fusion","defence procurement","mil-std","nato","research and development",
                     "systems integration","combat systems","armaments"],
        "departments": ["Missiles And Technology - M&D","Research And Development - M&D","System Integraion - M&D",
                        "Project/Engineering/Store - M&D","Head Of M & D"],
    },
    "Quality, Safety & Compliance": {
        "keywords": ["quality management","qms","iso 9001","as9100","safety management","sms","qhse",
                     "audit","compliance","regulatory","risk assessment","root cause analysis","ncr",
                     "corrective action","airworthiness","easa","gcaa","faa","iso 45001","hse",
                     "governance","risk and compliance","grc"],
        "departments": ["Product Quality (Aero)","Governance Risk & Compliance","Compliance & Audit Team",
                        "Director - Qhse","Safety (Aero)","Safety (Land)"],
    },
    "Supply Chain & Procurement": {
        "keywords": ["supply chain","procurement","purchasing","scm","vendor management","sourcing",
                     "logistics","warehouse","inventory","erp","sap mm","contract management",
                     "supplier evaluation","import export","customs","freight","material planning",
                     "demand planning","bom","mrp"],
        "departments": ["Procurement","Purchasing - SCM","Supplier Contracts Management",
                        "Warehouse","Transportation Services","Product Support"],
    },
    "People & Culture / HR": {
        "keywords": ["human resources","hr","recruitment","talent acquisition","talent management",
                     "learning and development","performance management","compensation","benefits",
                     "employee relations","hr policies","payroll","emiratisation","nationalization",
                     "organizational development","hris","succession planning","workforce planning"],
        "departments": ["People & Culture","Director - People & Culture","Employee Relations",
                        "Strategic People Management","Training &Development","Emiratisation"],
    },
    "Marketing & Communications": {
        "keywords": ["marketing","communications","brand","digital marketing","social media","public relations",
                     "content","campaign","seo","advertising","events","exhibitions","media relations",
                     "corporate communications","market research","product marketing","b2b","b2g"],
        "departments": ["Marketing & Communications","Branding & Design","Public Relations",
                        "Exhibitions & Corp Events","Director - Marketing & Communications"],
    },
    "Business Development & Sales": {
        "keywords": ["business development","sales","commercial","contracts","government contracts",
                     "mod","tenders","rfp","rfq","account management","customer relations","crm",
                     "revenue growth","international sales","gcc","mena","defence contracts",
                     "offset","industrial participation"],
        "departments": ["Director - Business Development","International Market (Gcc,Mena,Europe)",
                        "Mod & Governmental Contracts"],
    },
    "Facilities & Infrastructure": {
        "keywords": ["facilities management","fm","building services","maintenance","hvac","electrical",
                     "plumbing","construction","infrastructure","hard services","soft services",
                     "security","cleaning","fit-out","project management","cafm","planned maintenance"],
        "departments": ["Facilities & Projects","Infrastructure & Support Division","Construction - Hard Services",
                        "Electrical - Hard Services","Soft Services - Soft Services","General Services"],
    },
    "Legal & Administration": {
        "keywords": ["legal","corporate law","contract law","compliance","regulatory affairs","litigation",
                     "intellectual property","legal counsel","memorandum","governance","board secretariat",
                     "administration","office management","executive assistant","corporate governance"],
        "departments": ["Administration - Legal","Director - Legal","Corporate Service","Consultant Internal"],
    },
    "UAV & Special Operations": {
        "keywords": ["uav","drone","unmanned","uas","rpas","ground control","payload","isr",
                     "autonomous systems","flight control","mission planning","counter-uav",
                     "multi-rotor","fixed wing","vtol"],
        "departments": ["Project - UAV","Operations - Uav"],
    },
}

# Flat lookup: dept name → cluster name
DEPT_TO_CLUSTER = {}
for cluster, data in DEPT_CLUSTERS.items():
    for d in data["departments"]:
        DEPT_TO_CLUSTER[d] = cluster


class NoJDAgent(BaseAgent):
    """
    Screens a CV without a Job Description.
    Returns the same result dict structure as MatchingAgent so the pipeline
    can store and display it identically — with NO_JD flags set.
    """

    def __init__(self, db):
        super().__init__("no_jd_screening", db)
        self.ollama = ollama_client.AsyncClient(host=settings.ollama_base_url)

    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        parsed_cv   = payload["parsed_cv"]
        cv_version_id = payload["cv_version_id"]
        job_id      = payload["job_id"]  # the "generic" job id

        cv_skills   = self._all_skills(parsed_cv)
        exp_years   = self._get_exp_years(parsed_cv)
        seniority   = self._seniority(parsed_cv, exp_years)

        # ── 1. Score against each cluster ─────────────────────────
        cluster_scores = self._score_clusters(cv_skills, parsed_cv)
        top_clusters   = sorted(cluster_scores.items(), key=lambda x: x[1], reverse=True)[:3]

        best_cluster, best_score = top_clusters[0]
        best_depts = DEPT_CLUSTERS[best_cluster]["departments"][:5]

        # ── 2. Sub-scores ─────────────────────────────────────────
        dept_fit_score   = min(best_score, 1.0)
        experience_score = self._score_experience(exp_years, seniority)
        breadth_score    = self._score_breadth(cluster_scores)

        # ── 3. Composite (capped at 0.72 — no JD precision limit) ─
        raw_composite = (
            dept_fit_score   * 0.50 +
            experience_score * 0.25 +
            breadth_score    * 0.25
        )
        composite = min(round(raw_composite, 4), 0.72)

        # ── 4. LLM rationale ─────────────────────────────────────
        llm_rationale, strengths, gaps = await self._llm_assess(
            parsed_cv, best_cluster, top_clusters, exp_years, seniority
        )

        # ── 5. Suggested departments list ─────────────────────────
        suggested_depts = []
        for cluster, score in top_clusters:
            for d in DEPT_CLUSTERS[cluster]["departments"][:3]:
                if d in ORG_DEPARTMENTS:
                    suggested_depts.append({"department": d, "cluster": cluster, "score": round(score, 2)})

        return {
            "composite_score":      composite,
            "relevance_score":      dept_fit_score,
            "semantic_similarity":  breadth_score,
            "potential_score":      experience_score,
            "no_jd_mode":           True,
            "best_cluster":         best_cluster,
            "suggested_departments": suggested_depts,
            "top_clusters":         [{"cluster": c, "score": round(s, 2)} for c, s in top_clusters],
            "seniority_band":       seniority,
            "years_of_experience":  exp_years,
            "strengths":            strengths,
            "gaps":                 gaps,
            "transferable_skills":  self._transferable(cv_skills),
            "value_add_insights":   self._insights(parsed_cv, best_cluster, exp_years),
            "llm_rationale":        llm_rationale,
            "ai_summary":           f"[NO JD] Best fit: {best_cluster} ({int(dept_fit_score*100)}%). {seniority} profile with {exp_years:.0f} yrs exp.",
            "decision":             self._decision(composite),
            "rejection_reason":     None,
            "score_breakdown":      {
                "dept_fit_score":    dept_fit_score,
                "experience_score":  experience_score,
                "breadth_score":     breadth_score,
                "composite_score":   composite,
                "no_jd_mode":        True,
            },
            "skill_scores":  [],
        }

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _all_skills(self, parsed_cv: dict) -> List[str]:
        skills = []
        for field in ["technical_skills","soft_skills","domain_expertise","certifications"]:
            v = parsed_cv.get(field) or []
            if isinstance(v, str):
                try: v = json.loads(v)
                except: v = [v]
            skills.extend([str(s).lower() for s in v if s])
        # also pull from experience descriptions
        for exp in (parsed_cv.get("experience") or []):
            desc = exp.get("description") or ""
            techs = exp.get("technologies") or []
            skills.extend([str(t).lower() for t in techs])
        return list(set(skills))

    def _get_exp_years(self, parsed_cv: dict) -> float:
        v = parsed_cv.get("total_years_exp")
        if v:
            try: return float(str(v).split()[0])
            except: pass
        # count from experience list
        months = sum(
            (e.get("duration_months") or 0)
            for e in (parsed_cv.get("experience") or [])
        )
        return round(months / 12, 1) if months else 3.0

    def _seniority(self, parsed_cv: dict, exp_years: float) -> str:
        title = (parsed_cv.get("cv_summary") or "").lower()
        exp_roles = " ".join(
            (e.get("role") or "").lower()
            for e in (parsed_cv.get("experience") or [])
        )
        combined = title + " " + exp_roles
        if any(k in combined for k in ["chief","vp","vice president","cxo","ceo","coo","cto","cfo","president","svp","evp"]):
            return "Executive (C-Suite / VP)"
        if any(k in combined for k in ["director","head of","general manager","gm"]):
            return "Director / Head"
        if any(k in combined for k in ["senior manager","manager","lead","principal","sr. manager"]):
            return "Manager / Senior Lead"
        if exp_years >= 8:
            return "Senior Professional"
        if exp_years >= 4:
            return "Mid-Level Professional"
        return "Junior / Graduate"

    def _score_clusters(self, cv_skills: List[str], parsed_cv: dict) -> Dict[str, float]:
        # Build a text blob from the full CV for richer matching
        text_blob = " ".join(cv_skills)
        for exp in (parsed_cv.get("experience") or []):
            text_blob += " " + (exp.get("role") or "").lower()
            text_blob += " " + (exp.get("description") or "").lower()
        text_blob += " " + (parsed_cv.get("cv_summary") or "").lower()

        scores = {}
        for cluster, data in DEPT_CLUSTERS.items():
            kws    = data["keywords"]
            hits   = sum(1 for kw in kws if kw in text_blob)
            # normalise: full score = matching all keywords (but realistic max ~40%)
            score  = min(hits / max(len(kws) * 0.35, 1), 1.0)
            scores[cluster] = round(score, 4)
        return scores

    def _score_experience(self, exp_years: float, seniority: str) -> float:
        # 0–2 yrs → 0.30, 3–5 → 0.50, 6–10 → 0.70, 11–15 → 0.85, 15+ → 0.95
        if exp_years >= 15: return 0.95
        if exp_years >= 11: return 0.85
        if exp_years >= 6:  return 0.70
        if exp_years >= 3:  return 0.50
        return 0.30

    def _score_breadth(self, cluster_scores: Dict[str, float]) -> float:
        """Multi-cluster transferability — how many clusters have >0.2 score."""
        strong = sum(1 for s in cluster_scores.values() if s >= 0.2)
        return min(strong / 5.0, 1.0)

    def _decision(self, composite: float) -> str:
        if composite >= 0.55: return "needs_review"   # can't auto-shortlist without JD
        if composite >= 0.35: return "needs_review"
        return "auto_rejected"

    def _transferable(self, skills: List[str]) -> List[str]:
        priority = ["project management","stakeholder management","data analysis","communication",
                    "leadership","problem solving","agile","strategic planning","risk management",
                    "process improvement","team management","cross-functional"]
        return [s for s in skills if any(p in s for p in priority)][:8]

    def _insights(self, parsed_cv: dict, best_cluster: str, exp_years: float) -> List[str]:
        insights = [
            f"Screened in No-JD mode — scores are generic and based on department taxonomy matching, not a specific role.",
            f"Best-fit cluster identified: {best_cluster}. Recommend reviewing against open roles in this cluster.",
            f"Candidate has approximately {exp_years:.0f} years of experience. Cross-reference with role seniority requirements.",
        ]
        certs = parsed_cv.get("certifications") or []
        if certs:
            insights.append(f"Holds certifications: {', '.join(str(c) for c in certs[:4])}. Verify currency and relevance.")
        return insights

    async def _llm_assess(
        self, parsed_cv: dict, best_cluster: str,
        top_clusters: List[Tuple], exp_years: float, seniority: str
    ) -> Tuple[str, List[str], List[str]]:
        """Generate rationale via LLM. Falls back gracefully."""

        name   = parsed_cv.get("full_name") or "the candidate"
        skills = (parsed_cv.get("technical_skills") or [])[:12]
        edu    = parsed_cv.get("education") or []
        edu_str = "; ".join(
            f"{e.get('degree','')} in {e.get('field','')} from {e.get('institution','')}"
            for e in edu[:2]
        ) or "Not specified"
        top3   = ", ".join(f"{c} ({int(s*100)}%)" for c, s in top_clusters[:3])
        exp_roles = "; ".join(
            (e.get("role") or "") + " at " + (e.get("company") or "")
            for e in (parsed_cv.get("experience") or [])[:3]
        )

        prompt = f"""You are a senior HR analyst at a UAE aerospace and defence company (Calidus).
You are evaluating a CV with NO specific job description — using the organisation's department taxonomy only.

CANDIDATE SUMMARY:
Name: {name}
Seniority: {seniority} | Experience: {exp_years:.0f} years
Education: {edu_str}
Recent Roles: {exp_roles}
Key Skills: {', '.join(str(s) for s in skills)}

DEPARTMENT FIT ANALYSIS (system-computed):
Best Fit: {best_cluster}
Top 3 matches: {top3}

TASK: Write a concise, professional HR assessment (max 200 words) covering:
1. Which department(s) in our organisation this person is most suitable for and why
2. Their strongest transferable skills for our aerospace/defence context
3. Key gaps or missing skills that would need to be verified against a real JD
4. A hiring recommendation (e.g., "Recommend for interview in [dept]" or "Hold until suitable role opens")

⚠️ Clearly note that this is a generic assessment because no JD was provided.
Be specific, honest, and reference the candidate's actual background.
Do NOT invent information not present in the CV summary above.

IMPORTANT: Start your response directly — no preamble like "Here is my assessment".
"""

        try:
            response = await self.ollama.chat(
                model=settings.ollama_model,
                messages=[{"role": "user", "content": prompt}],
                options={"temperature": 0.3, "num_predict": 350},
            )
            rationale = response["message"]["content"].strip()

            # Extract strengths and gaps with a follow-up structured call
            struct_prompt = f"""Based on this CV (same candidate as before):
Skills: {', '.join(str(s) for s in skills)}
Best fit department: {best_cluster}
Seniority: {seniority}

List EXACTLY:
STRENGTHS: (5 bullet points — concrete skills/experience this person brings)
GAPS: (5 bullet points — what is missing for a defence/aerospace role without knowing the JD)

Format strictly:
STRENGTHS:
- point 1
- point 2
- point 3
- point 4
- point 5
GAPS:
- point 1
- point 2
- point 3
- point 4
- point 5"""

            struct_resp = await self.ollama.chat(
                model=settings.ollama_model,
                messages=[{"role": "user", "content": struct_prompt}],
                options={"temperature": 0.2, "num_predict": 250},
            )
            struct_text = struct_resp["message"]["content"]
            strengths, gaps = self._parse_sg(struct_text)

        except Exception as e:
            logger.warning("no_jd_llm_failed", error=str(e))
            rationale = (
                f"[NO JD — GENERIC ASSESSMENT] {name} appears best suited for the "
                f"{best_cluster} cluster based on skill taxonomy matching. "
                f"With {exp_years:.0f} years of experience at {seniority} level, "
                f"this candidate warrants review against open positions in: "
                f"{', '.join(d['department'] for d in [{'department': DEPT_CLUSTERS[best_cluster]['departments'][0]}][:2])}. "
                f"A full assessment requires a Job Description."
            )
            strengths = [f"Relevant background in {best_cluster}", f"{seniority} seniority level",
                         f"{exp_years:.0f} years total experience"]
            gaps = ["No JD provided — specific skill gaps unknown",
                    "Mandatory requirements cannot be verified without JD",
                    "Domain depth not formally assessed"]

        return rationale, strengths[:6], gaps[:6]

    def _parse_sg(self, text: str) -> Tuple[List[str], List[str]]:
        strengths = []; gaps = []
        mode = None
        for line in text.split("\n"):
            line = line.strip()
            if "STRENGTHS" in line.upper(): mode = "s"; continue
            if "GAPS" in line.upper(): mode = "g"; continue
            if line.startswith("-") or (line and line[0].isdigit() and "." in line[:3]):
                clean = re.sub(r"^[-\d\.\*\s]+", "", line).strip()
                if clean:
                    if mode == "s": strengths.append(clean)
                    elif mode == "g": gaps.append(clean)
        return strengths[:6], gaps[:6]