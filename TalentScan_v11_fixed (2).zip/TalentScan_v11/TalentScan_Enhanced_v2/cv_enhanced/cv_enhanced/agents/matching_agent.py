"""
TalentScan v5 — Hybrid Matching Agent
======================================

FIXES vs v4:
  1. Zero-match bug: LLM fallback returned 0.3 even on total mismatch.
     Fix: hard filters gate the pipeline; LLM error fallback returns 0.0.
  2. Over-scored partial matches: weighted keyword overlap with no semantic check.
     Fix: must-have skill scoring uses embedding similarity PER skill, not keyword presence.
  3. Irrelevant CVs ranked too high: composite formula ignored domain mismatch.
     Fix: domain_alignment is a gating multiplier; severe domain mismatch triggers penalty.
  4. Keyword stuffing: no detection existed.
     Fix: density heuristic + LLM meta-analysis; stuffing triggers -0.25 penalty.

SCORING MODEL:
  composite = (
      must_have_score      × 0.40    # Non-negotiable — gates shortlisting
    + good_to_have_score   × 0.20    # Additive, moderate weight
    + semantic_similarity  × 0.25    # Embedding cosine, JD vs full CV
    + experience_score     × 0.15    # Alignment of total exp + role titles
  ) × domain_multiplier             # 0.5–1.0, domain/industry alignment
    - total_penalties                # keyword stuffing, domain mismatch, etc.

HARD FILTERS (instant rejection, score → 0):
  - Missing ANY mandatory skill (by semantic threshold < 0.35) → rejected
  - Years experience < 60% of required → heavy penalty; < 30% → rejected
"""

import json
import re
from typing import Any, Dict, List, Optional, Tuple

import ollama as ollama_client
import structlog
from sqlalchemy import text

from agents.base_agent import BaseAgent
from shared.models import (
    HardFilterResult, PenaltyRecord, RejectionReason,
    ScoreBreakdown, ScreeningDecision, SkillScore,
)
from shared.utils import (
    cosine_similarity, detect_keyword_stuffing,
    truncate_text, years_from_experience,
)
from config.settings import settings

logger = structlog.get_logger(__name__)

# Weights
W_MUST_HAVE = 0.40
W_GOOD_TO_HAVE = 0.20
W_SEMANTIC = 0.25
W_EXPERIENCE = 0.15

# Thresholds
SEMANTIC_SKILL_MATCH_THRESHOLD = 0.60  # Cosine sim for "skill present"
SEMANTIC_PARTIAL_THRESHOLD = 0.40      # Partial credit below full match
DOMAIN_MISMATCH_MULTIPLIER = 0.50      # Applied when wrong domain detected
KEYWORD_STUFFING_PENALTY = 0.20
DOMAIN_MISMATCH_PENALTY = 0.15
IRRELEVANT_EXP_PENALTY = 0.10


class MatchingAgent(BaseAgent):

    def __init__(self, db):
        super().__init__("matching", db)
        self.ollama = ollama_client.AsyncClient(host=settings.ollama_base_url)

    def _pgvec(self, vec: List[float]) -> str:
        return "[" + ",".join(str(float(x)) for x in vec) + "]"

    # ─────────────────────────────────────────────────────────────
    # MAIN EXECUTE
    # ─────────────────────────────────────────────────────────────

    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        cv_version_id = payload["cv_version_id"]
        job_id = payload["job_id"]
        parsed_cv = payload["parsed_cv"]
        job_description = payload["job_description"]
        candidate_id = payload["candidate_id"]
        jd_requirements = payload.get("jd_requirements", {})

        cv_text = self._cv_to_text(parsed_cv)
        cv_embed = await self._embed(cv_text)

        # ── Fetch or compute JD embedding ─────────────────────────
        jd_embed = await self._get_jd_embedding(job_id, job_description)

        # ── Store CV embedding ────────────────────────────────────
        await self._store_cv_embedding(cv_version_id, cv_embed)

        # ── Semantic similarity (JD vs CV) ────────────────────────
        semantic_similarity = cosine_similarity(cv_embed, jd_embed)

        # ── Extract requirements ──────────────────────────────────
        mandatory_skills = [s.lower().strip() for s in (jd_requirements.get("mandatory_skills") or [])]
        good_to_have = [s.lower().strip() for s in (jd_requirements.get("good_to_have_skills") or [])]
        min_years = jd_requirements.get("min_years_experience")
        jd_domain = (jd_requirements.get("domain") or "").lower()

        # ── Hard filter: mandatory skills ─────────────────────────
        hard_filter = await self._run_hard_filters(
            parsed_cv, mandatory_skills, min_years, jd_domain, cv_embed, jd_embed
        )

        if not hard_filter.passed:
            # Instant rejection — score is always 0
            return self._build_rejection_result(
                candidate_id, cv_version_id, job_id,
                semantic_similarity, hard_filter
            )

        # ── Per-skill scoring ─────────────────────────────────────
        all_cv_skills = [s.lower() for s in (
            (parsed_cv.get("technical_skills") or []) +
            (parsed_cv.get("soft_skills") or []) +
            (parsed_cv.get("domain_expertise") or [])
        )]
        skill_scores = await self._score_skills(
            mandatory_skills, good_to_have, all_cv_skills, cv_embed
        )

        must_have_score = self._aggregate_skill_score(
            [s for s in skill_scores if s.is_mandatory]
        )
        good_to_have_score = self._aggregate_skill_score(
            [s for s in skill_scores if not s.is_mandatory]
        )

        # ── Experience score ──────────────────────────────────────
        experience_score, exp_years = self._score_experience(parsed_cv, min_years)

        # ── Domain alignment ──────────────────────────────────────
        domain_multiplier, domain_score = self._score_domain(
            parsed_cv, jd_domain, semantic_similarity
        )

        # ── Detect penalties ──────────────────────────────────────
        penalties = self._compute_penalties(
            parsed_cv, cv_text, mandatory_skills + good_to_have,
            domain_multiplier, exp_years, min_years
        )
        total_penalty = sum(p.severity for p in penalties)

        # ── Composite score ───────────────────────────────────────
        raw_composite = (
            must_have_score * W_MUST_HAVE +
            good_to_have_score * W_GOOD_TO_HAVE +
            semantic_similarity * W_SEMANTIC +
            experience_score * W_EXPERIENCE
        ) * domain_multiplier
        composite_score = max(0.0, min(1.0, raw_composite - total_penalty))

        # ── LLM analysis ──────────────────────────────────────────
        llm = await self._llm_analyze(parsed_cv, job_description, jd_requirements)

        # ── Determine decision ────────────────────────────────────
        if composite_score >= settings.shortlist_threshold:
            decision = ScreeningDecision.AUTO_SHORTLISTED
        elif composite_score < settings.reject_threshold:
            decision = ScreeningDecision.AUTO_REJECTED
        else:
            decision = ScreeningDecision.NEEDS_REVIEW

        breakdown = ScoreBreakdown(
            must_have_score=round(must_have_score, 3),
            good_to_have_score=round(good_to_have_score, 3),
            semantic_similarity=round(semantic_similarity, 3),
            experience_score=round(experience_score, 3),
            domain_alignment=round(domain_score, 3),
            penalties=penalties,
            total_penalty=round(total_penalty, 3),
            composite_score=round(composite_score, 3),
            hard_filter=hard_filter,
            skill_scores=skill_scores,
        )

        self.log.info(
            "matching_complete",
            composite=round(composite_score, 3),
            must_have=round(must_have_score, 3),
            semantic=round(semantic_similarity, 3),
            penalties=round(total_penalty, 3),
            decision=decision,
        )

        return {
            "candidate_id": candidate_id,
            "cv_version_id": cv_version_id,
            "job_id": job_id,
            "semantic_similarity": round(semantic_similarity, 3),
            "relevance_score": round(must_have_score * 0.6 + good_to_have_score * 0.4, 3),
            "potential_score": llm.get("potential_score", 0.5),
            "composite_score": round(composite_score, 3),
            "score_breakdown": breakdown.model_dump(),
            "skill_scores": [s.model_dump() for s in skill_scores],
            "decision": decision.value,
            "rejection_reason": None,
            "strengths": llm.get("strengths", []),
            "gaps": llm.get("gaps", []),
            "risk_flags": llm.get("risk_flags", [p.description for p in penalties]),
            "transferable_skills": llm.get("transferable_skills", []),
            "value_add_insights": llm.get("value_add_insights", []),
            "llm_rationale": llm.get("rationale", ""),
            "ai_summary": llm.get("ai_summary", ""),
        }

    # ─────────────────────────────────────────────────────────────
    # HARD FILTERS
    # ─────────────────────────────────────────────────────────────

    async def _run_hard_filters(
        self,
        parsed_cv: dict,
        mandatory_skills: List[str],
        min_years: Optional[float],
        jd_domain: str,
        cv_embed: List[float],
        jd_embed: List[float],
    ) -> HardFilterResult:

        # ── Filter 1: Check mandatory skills semantically ─────────
        missing = []
        if mandatory_skills:
            cv_skills_text = " ".join(
                (parsed_cv.get("technical_skills") or []) +
                (parsed_cv.get("domain_expertise") or [])
            ).lower()

            for skill in mandatory_skills:
                # First: exact keyword check
                if skill in cv_skills_text:
                    continue
                # Second: semantic similarity of skill vs full CV
                skill_embed = await self._embed(skill)
                sim = cosine_similarity(skill_embed, cv_embed)
                if sim < SEMANTIC_SKILL_MATCH_THRESHOLD:
                    missing.append(skill)

            if missing:
                return HardFilterResult(
                    passed=False,
                    rejection_reason=RejectionReason.NO_MANDATORY_SKILLS,
                    missing_mandatory=missing,
                )

        # ── Filter 2: Experience gating ───────────────────────────
        if min_years and min_years > 0:
            exp_years = years_from_experience(parsed_cv.get("experience", []))
            if exp_years == 0:
                # Try total_years_exp field
                exp_years = parsed_cv.get("total_years_exp") or 0.0
            ratio = exp_years / min_years if min_years else 1.0
            if ratio < 0.30:
                return HardFilterResult(
                    passed=False,
                    rejection_reason=RejectionReason.INSUFFICIENT_EXPERIENCE,
                    years_required=min_years,
                    years_found=exp_years,
                )

        # ── Filter 3: Near-zero semantic similarity ───────────────
        sim = cosine_similarity(cv_embed, jd_embed)
        if sim < 0.10 and mandatory_skills:
            return HardFilterResult(
                passed=False,
                rejection_reason=RejectionReason.ZERO_SEMANTIC_MATCH,
            )

        return HardFilterResult(passed=True)

    # ─────────────────────────────────────────────────────────────
    # SKILL SCORING
    # ─────────────────────────────────────────────────────────────

    async def _score_skills(
        self,
        mandatory: List[str],
        good_to_have: List[str],
        cv_skills: List[str],
        cv_embed: List[float],
    ) -> List[SkillScore]:
        results = []
        cv_skills_text = " ".join(cv_skills)

        all_skills = [(s, True) for s in mandatory] + [(s, False) for s in good_to_have]

        for skill, is_mandatory in all_skills:
            weight = 0.9 if is_mandatory else 0.5

            # Step 1: exact keyword match
            if skill in cv_skills_text.lower():
                results.append(SkillScore(
                    skill=skill, present=True, is_mandatory=is_mandatory,
                    weight=weight, score=1.0, match_type="exact"
                ))
                continue

            # Step 2: semantic similarity of skill vs CV embedding
            skill_embed = await self._embed(skill)
            sim = cosine_similarity(skill_embed, cv_embed)

            if sim >= SEMANTIC_SKILL_MATCH_THRESHOLD:
                results.append(SkillScore(
                    skill=skill, present=True, is_mandatory=is_mandatory,
                    weight=weight, score=round(sim, 3), match_type="semantic"
                ))
            elif sim >= SEMANTIC_PARTIAL_THRESHOLD:
                results.append(SkillScore(
                    skill=skill, present=False, is_mandatory=is_mandatory,
                    weight=weight, score=round(sim * 0.6, 3), match_type="partial"
                ))
            else:
                results.append(SkillScore(
                    skill=skill, present=False, is_mandatory=is_mandatory,
                    weight=weight, score=0.0, match_type="none"
                ))

        return results

    def _aggregate_skill_score(self, scores: List[SkillScore]) -> float:
        if not scores:
            return 0.5  # No skills specified — neutral
        weighted_sum = sum(s.score * s.weight for s in scores)
        total_weight = sum(s.weight for s in scores)
        return weighted_sum / total_weight if total_weight else 0.0

    # ─────────────────────────────────────────────────────────────
    # EXPERIENCE SCORING
    # ─────────────────────────────────────────────────────────────

    def _score_experience(
        self, parsed_cv: dict, min_years: Optional[float]
    ) -> Tuple[float, float]:
        exp_years = years_from_experience(parsed_cv.get("experience", []))
        if exp_years == 0:
            exp_years = parsed_cv.get("total_years_exp") or 0.0

        if not min_years or min_years <= 0:
            # No requirement: score based on absolute experience (cap at 10 years)
            return min(1.0, exp_years / 10.0), exp_years

        ratio = exp_years / min_years
        if ratio >= 1.0:
            score = min(1.0, 0.8 + 0.2 * min(ratio - 1.0, 1.0))  # Bonus for extra exp
        elif ratio >= 0.60:
            score = 0.4 + 0.4 * (ratio - 0.60) / 0.40  # Graded penalty
        else:
            score = ratio * 0.6  # Heavy penalty

        return round(score, 3), exp_years

    # ─────────────────────────────────────────────────────────────
    # DOMAIN SCORING
    # ─────────────────────────────────────────────────────────────

    def _score_domain(
        self, parsed_cv: dict, jd_domain: str, semantic_sim: float
    ) -> Tuple[float, float]:
        if not jd_domain:
            return 1.0, 1.0

        cv_domains = [d.lower() for d in (parsed_cv.get("domain_expertise") or [])]
        cv_exp_text = " ".join(
            (e.get("description") or "") + " " + (e.get("company") or "")
            for e in (parsed_cv.get("experience") or [])
        ).lower()

        # Direct domain keyword match
        domain_keywords = jd_domain.split()
        direct_hit = any(
            kw in " ".join(cv_domains) or kw in cv_exp_text
            for kw in domain_keywords
        )

        if direct_hit:
            return 1.0, 1.0

        # Use semantic similarity as proxy for domain alignment
        # If overall semantic sim is high, domain is likely aligned
        if semantic_sim >= 0.50:
            return 0.85, semantic_sim
        elif semantic_sim >= 0.30:
            return 0.65, semantic_sim
        else:
            # Low semantic AND no domain keyword = likely wrong domain
            return DOMAIN_MISMATCH_MULTIPLIER, semantic_sim

    # ─────────────────────────────────────────────────────────────
    # PENALTY SYSTEM
    # ─────────────────────────────────────────────────────────────

    def _compute_penalties(
        self,
        parsed_cv: dict,
        cv_text: str,
        all_jd_skills: List[str],
        domain_multiplier: float,
        exp_years: float,
        min_years: Optional[float],
    ) -> List[PenaltyRecord]:
        penalties = []

        # Penalty 1: Keyword stuffing
        if detect_keyword_stuffing(cv_text, all_jd_skills):
            penalties.append(PenaltyRecord(
                penalty_type="keyword_stuffing",
                severity=KEYWORD_STUFFING_PENALTY,
                description="Suspicious keyword density detected — possible keyword stuffing",
                evidence=f"High skill-to-word-count ratio in short CV",
            ))

        # Penalty 2: Domain mismatch (if multiplier was applied)
        if domain_multiplier < 0.80:
            penalties.append(PenaltyRecord(
                penalty_type="domain_mismatch",
                severity=DOMAIN_MISMATCH_PENALTY,
                description="Candidate domain/industry appears misaligned with role requirements",
                evidence=f"Domain alignment multiplier: {domain_multiplier:.2f}",
            ))

        # Penalty 3: Insufficient experience (soft — hard rejection handled above)
        if min_years and exp_years < min_years * 0.60:
            deficit = min_years - exp_years
            penalty_val = min(0.20, deficit * settings.min_experience_penalty_factor)
            penalties.append(PenaltyRecord(
                penalty_type="insufficient_experience",
                severity=round(penalty_val, 3),
                description=f"Candidate has {exp_years:.1f} yrs vs {min_years:.1f} yrs required",
                evidence=f"Experience gap: {deficit:.1f} years",
            ))

        # Penalty 4: Very short experience descriptions (possible fabrication)
        exp_list = parsed_cv.get("experience") or []
        if exp_list:
            avg_desc_len = sum(
                len((e.get("description") or "")) for e in exp_list
            ) / len(exp_list)
            if avg_desc_len < 30 and len(exp_list) >= 3:
                penalties.append(PenaltyRecord(
                    penalty_type="sparse_experience",
                    severity=0.05,
                    description="Experience descriptions are unusually sparse",
                    evidence=f"Avg description length: {avg_desc_len:.0f} chars",
                ))

        return penalties

    # ─────────────────────────────────────────────────────────────
    # REJECTION RESULT BUILDER
    # ─────────────────────────────────────────────────────────────

    def _build_rejection_result(
        self,
        candidate_id: str,
        cv_version_id: str,
        job_id: str,
        semantic_similarity: float,
        hard_filter: HardFilterResult,
    ) -> Dict[str, Any]:
        """
        ALWAYS returns score=0, decision=auto_rejected for hard filter failures.
        """
        reason_text = hard_filter.rejection_reason.value if hard_filter.rejection_reason else "hard_filter_failed"

        breakdown = ScoreBreakdown(
            must_have_score=0.0,
            good_to_have_score=0.0,
            semantic_similarity=round(semantic_similarity, 3),
            experience_score=0.0,
            domain_alignment=0.0,
            composite_score=0.0,
            hard_filter=hard_filter,
        )

        gaps = []
        if hard_filter.missing_mandatory:
            gaps = [f"Missing mandatory skill: {s}" for s in hard_filter.missing_mandatory]
        if hard_filter.years_required:
            gaps.append(
                f"Insufficient experience: {hard_filter.years_found:.1f} yrs found, "
                f"{hard_filter.years_required:.1f} yrs required"
            )

        self.log.info(
            "hard_filter_rejection",
            reason=reason_text,
            missing=hard_filter.missing_mandatory,
        )

        return {
            "candidate_id": candidate_id,
            "cv_version_id": cv_version_id,
            "job_id": job_id,
            "semantic_similarity": round(semantic_similarity, 3),
            "relevance_score": 0.0,
            "potential_score": 0.0,
            "composite_score": 0.0,  # ← ALWAYS ZERO on hard reject
            "score_breakdown": breakdown.model_dump(),
            "skill_scores": [],
            "decision": ScreeningDecision.AUTO_REJECTED.value,
            "rejection_reason": reason_text,
            "strengths": [],
            "gaps": gaps,
            "risk_flags": [f"Hard filter: {reason_text}"],
            "transferable_skills": [],
            "value_add_insights": [],
            "llm_rationale": f"REJECTED: {reason_text}. {'; '.join(gaps)}",
            "ai_summary": f"This candidate does not meet the minimum requirements: {reason_text.replace('_', ' ')}.",
        }

    # ─────────────────────────────────────────────────────────────
    # EMBEDDING & HELPERS
    # ─────────────────────────────────────────────────────────────

    async def _embed(self, text: str) -> List[float]:
        response = await self.ollama.embeddings(
            model=settings.ollama_embed_model,
            prompt=text[:4000],
        )
        return response["embedding"]

    async def _get_jd_embedding(self, job_id: str, job_description: str) -> List[float]:
        jd_row = await self.db.execute(
            text("SELECT embedding::text FROM jobs WHERE id = :id"),
            {"id": job_id}
        )
        row = jd_row.fetchone()
        if row and row[0]:
            raw = row[0].strip("[]").split(",")
            return [float(x) for x in raw]
        return await self._embed(truncate_text(job_description, 4000))

    async def _store_cv_embedding(self, cv_version_id: str, cv_embed: List[float]):
        try:
            await self.db.execute(
                text("UPDATE cv_versions SET embedding = :emb WHERE id = :id"),
                {"emb": self._pgvec(cv_embed), "id": cv_version_id}
            )
        except Exception as e:
            self.log.warning("cv_embedding_store_failed", error=str(e))

    def _cv_to_text(self, parsed_cv: dict) -> str:
        parts = []
        if parsed_cv.get("cv_summary"):
            parts.append(f"Summary: {parsed_cv['cv_summary']}")
        tech = ", ".join(parsed_cv.get("technical_skills") or [])
        if tech:
            parts.append(f"Technical Skills: {tech}")
        domains = ", ".join(parsed_cv.get("domain_expertise") or [])
        if domains:
            parts.append(f"Domain: {domains}")
        for exp in (parsed_cv.get("experience") or [])[:5]:
            parts.append(
                f"{exp.get('role', '')} at {exp.get('company', '')}: {exp.get('description', '')}"
            )
        return "\n".join(parts)

    # ─────────────────────────────────────────────────────────────
    # LLM ANALYSIS
    # ─────────────────────────────────────────────────────────────

    async def _llm_analyze(
        self, parsed_cv: dict, job_description: str, jd_requirements: dict
    ) -> dict:
        cv_summary = self._cv_to_text(parsed_cv)
        mandatory = jd_requirements.get("mandatory_skills", [])
        good_to_have = jd_requirements.get("good_to_have_skills", [])

        prompt = f"""You are a strict JSON generator for an ATS recruitment system.

RULES:
- Output ONLY valid JSON, no markdown, no explanation
- Be precise and evidence-based
- Scores are floats 0.0-1.0

Return EXACTLY this schema:
{{
  "potential_score": number,
  "strengths": [string],
  "gaps": [string],
  "risk_flags": [string],
  "transferable_skills": [string],
  "value_add_insights": [string],
  "rationale": string,
  "ai_summary": string
}}

MANDATORY SKILLS TO CHECK: {mandatory}
GOOD-TO-HAVE SKILLS: {good_to_have}

JOB DESCRIPTION:
{truncate_text(job_description, 1500)}

CANDIDATE CV SUMMARY:
{cv_summary}"""

        try:
            response = await self.ollama.chat(
                model=settings.ollama_llm_model,
                messages=[{"role": "user", "content": prompt}],
                format="json",
                options={"temperature": 0.2},
            )

            raw = response["message"]["content"]
            if isinstance(raw, dict):
                return raw
            cleaned = re.sub(r"```json\s*|```\s*", "", raw).strip()
            return json.loads(cleaned)

        except Exception as e:
            self.log.error("llm_analysis_failed", error=str(e))
            # ← CRITICAL FIX: return 0.0 defaults, not 0.3
            return {
                "potential_score": 0.0,
                "strengths": [],
                "gaps": ["LLM analysis unavailable — manual review required"],
                "risk_flags": ["LLM unavailable"],
                "transferable_skills": [],
                "value_add_insights": [],
                "rationale": f"LLM analysis failed: {str(e)}",
                "ai_summary": "Automated analysis unavailable. Manual review required.",
            }