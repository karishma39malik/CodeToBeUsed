import hashlib
import math
import re
from pathlib import Path
from typing import List


def truncate_text(text: str, max_chars: int = 4000) -> str:
    if not text:
        return ""
    return text[:max_chars] if len(text) > max_chars else text


def get_file_extension(filename: str) -> str:
    return Path(filename).suffix.lstrip(".").lower() if filename else "unknown"


def sanitize_filename(filename: str) -> str:
    name = Path(filename).stem
    name = re.sub(r"[^\w\-.]", "_", name)
    return f"{name[:60]}{Path(filename).suffix}"


def compute_file_hash(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def cosine_similarity(a: List[float], b: List[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return max(0.0, min(1.0, dot / (norm_a * norm_b)))


def detect_keyword_stuffing(cv_text: str, skill_list: List[str]) -> bool:
    """
    Heuristic: if skills section is suspiciously dense relative to
    total text length, it may be keyword-stuffed.
    """
    if not cv_text or not skill_list:
        return False
    text_lower = cv_text.lower()
    word_count = len(text_lower.split())
    if word_count < 100:
        return False
    skill_hits = sum(1 for s in skill_list if s.lower() in text_lower)
    ratio = skill_hits / max(len(skill_list), 1)
    # If 85%+ of all skills are mentioned in a short CV, suspect stuffing
    density = skill_hits / max(word_count / 100, 1)
    return ratio > 0.85 and density > 15 and word_count < 600


def normalize_score(raw: float, min_val: float = 0.0, max_val: float = 1.0) -> float:
    """Clamp and normalize a score to [0, 1]."""
    return max(0.0, min(1.0, (raw - min_val) / max(max_val - min_val, 1e-9)))


def years_from_experience(experience_list: list) -> float:
    """Sum duration_months across experience entries, return years."""
    total_months = 0
    for exp in experience_list or []:
        dm = exp.get("duration_months") if isinstance(exp, dict) else getattr(exp, "duration_months", None)
        if dm:
            total_months += dm
    if total_months:
        return total_months / 12.0
    return 0.0