import hashlib
import math
import re
from pathlib import Path
from typing import List


def truncate_text(text: str, max_chars: int = 4000) -> str:
    if not text:
        return ""
    return text[:max_chars] if len(text) > max_chars else text


def get_file_extension(filename: str) -> str:
    return Path(filename).suffix.lstrip(".").lower() if filename else "unknown"


def sanitize_filename(filename: str) -> str:
    name = Path(filename).stem
    name = re.sub(r"[^\w\-.]", "_", name)
    return f"{name[:60]}{Path(filename).suffix}"


def compute_file_hash(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def cosine_similarity(a: List[float], b: List[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return max(0.0, min(1.0, dot / (norm_a * norm_b)))


def detect_keyword_stuffing(cv_text: str, skill_list: List[str]) -> bool:
    """
    Heuristic: if skills section is suspiciously dense relative to
    total text length, it may be keyword-stuffed.
    """
    if not cv_text or not skill_list:
        return False
    text_lower = cv_text.lower()
    word_count = len(text_lower.split())
    if word_count < 100:
        return False
    skill_hits = sum(1 for s in skill_list if s.lower() in text_lower)
    ratio = skill_hits / max(len(skill_list), 1)
    # If 85%+ of all skills are mentioned in a short CV, suspect stuffing
    density = skill_hits / max(word_count / 100, 1)
    return ratio > 0.85 and density > 15 and word_count < 600


def normalize_score(raw: float, min_val: float = 0.0, max_val: float = 1.0) -> float:
    """Clamp and normalize a score to [0, 1]."""
    return max(0.0, min(1.0, (raw - min_val) / max(max_val - min_val, 1e-9)))


def years_from_experience(experience_list: list) -> float:
    """Sum duration_months across experience entries, return years."""
    total_months = 0
    for exp in experience_list or []:
        dm = exp.get("duration_months") if isinstance(exp, dict) else getattr(exp, "duration_months", None)
        if dm:
            total_months += dm
    if total_months:
        return total_months / 12.0
    # FIX-6: Fallback to date-based calculation when duration_months unavailable
    return years_from_experience_dates(experience_list)


def years_from_experience_dates(experience_list: list) -> float:
    """FIX-6: Date-based fallback when duration_months is null on all entries."""
    from datetime import date
    total = 0.0
    for exp in (experience_list or []):
        if isinstance(exp, dict):
            start = exp.get("start_date", "")
            end = exp.get("end_date", "")
        else:
            start = getattr(exp, "start_date", "") or ""
            end = getattr(exp, "end_date", "") or ""
        try:
            sy = int(str(start)[:4])
            ey = date.today().year if str(end).lower() == "present" else int(str(end)[:4])
            total += max(0.0, float(ey - sy))
        except (ValueError, TypeError):
            pass
    return total

# ═══════════════════════════════════════════════════════════════════════════════
# CV GROUNDING VALIDATOR
# Every claim in output must be traceable to explicit CV text.
# ═══════════════════════════════════════════════════════════════════════════════

def build_cv_evidence_blob(parsed_cv: dict) -> str:
    """
    Builds a single lowercase text blob from every field in the parsed CV.
    Used as the ground-truth source for all evidence checks.
    """
    parts = []
    for field in ["full_name","email","phone","location","cv_summary"]:
        v = parsed_cv.get(field) or ""
        parts.append(str(v).lower())
    for lst_field in ["technical_skills","soft_skills","domain_expertise",
                       "certifications","languages"]:
        for item in (parsed_cv.get(lst_field) or []):
            parts.append(str(item).lower())
    for exp in (parsed_cv.get("experience") or []):
        for f in ["company","role","description"]:
            parts.append(str(exp.get(f) or "").lower())
        for t in (exp.get("technologies") or []):
            parts.append(str(t).lower())
    for edu in (parsed_cv.get("education") or []):
        for f in ["institution","degree","field"]:
            parts.append(str(edu.get(f) or "").lower())
    return " ".join(parts)


def skill_in_cv(skill: str, cv_blob: str) -> bool:
    """
    Word-boundary check — skill must appear as a whole token sequence in the CV.
    Prevents "erp" matching inside "interpersonal", "hr" inside "their", etc.
    Multi-word skills (e.g. "machine learning") are checked as a phrase.
    """
    import re as _re
    skill_clean = skill.lower().strip()
    if not skill_clean:
        return False
    # Use word boundary pattern so "hr" does not match inside "their"
    pattern = r'(?<![a-z0-9])' + _re.escape(skill_clean) + r'(?![a-z0-9])'
    return bool(_re.search(pattern, cv_blob))


def filter_to_cv_grounded(items: list, cv_blob: str, min_word_len: int = 3) -> list:
    """
    From a list of strings (strengths, skills, gaps etc.), keep only those
    that contain at least one word that appears in the CV blob.
    Removes hallucinated items that reference things not in the CV.
    """
    kept = []
    for item in (items or []):
        words = [w.lower().strip(".,;:()") for w in str(item).split()
                 if len(w) >= min_word_len]
        if any(w in cv_blob for w in words):
            kept.append(item)
    return kept


def validate_output_against_cv(result: dict, parsed_cv: dict) -> dict:
    """
    Post-generation validation layer.
    Strips any strengths/transferable_skills that are not grounded in CV text.
    Gaps are allowed to reference things NOT in the CV (they are absences).
    Adds a grounding_report to the result for auditability.
    """
    cv_blob = build_cv_evidence_blob(parsed_cv)

    original_strengths = result.get("strengths") or []
    original_transferable = result.get("transferable_skills") or []

    grounded_strengths    = filter_to_cv_grounded(original_strengths, cv_blob)
    grounded_transferable = filter_to_cv_grounded(original_transferable, cv_blob)

    removed_strengths    = [s for s in original_strengths    if s not in grounded_strengths]
    removed_transferable = [s for s in original_transferable if s not in grounded_transferable]

    result["strengths"]         = grounded_strengths
    result["transferable_skills"] = grounded_transferable
    result["grounding_report"]  = {
        "removed_hallucinated_strengths":    removed_strengths,
        "removed_hallucinated_transferable": removed_transferable,
        "cv_grounded": len(removed_strengths) == 0 and len(removed_transferable) == 0,
    }
    return result


def dept_from_cv_evidence(parsed_cv: dict, org_dept_clusters: dict) -> str:
    """
    Deterministic department suggestion based solely on CV keywords.
    Returns the cluster name with the most keyword hits, or 'General'.
    No LLM — pure keyword overlap with the org taxonomy.
    """
    cv_blob = build_cv_evidence_blob(parsed_cv)
    best_cluster = "General"
    best_hits = 0
    for cluster, data in org_dept_clusters.items():
        hits = sum(1 for kw in data.get("keywords", []) if kw in cv_blob)
        if hits > best_hits:
            best_hits = hits
            best_cluster = cluster
    return best_cluster if best_hits > 0 else "General"
