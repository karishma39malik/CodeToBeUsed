import structlog
from typing import Any, Dict
 
 
class BaseAgent:
    def __init__(self, name: str, db):
        self.name = name
        self.db = db
        self.log = structlog.get_logger(f"agent.{name}")
 
    async def run(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        self.log = self.log.bind(correlation_id=correlation_id)
        try:
            result = await self.execute(payload, correlation_id)
            return result
        except Exception as e:
            self.log.error(f"{self.name}_agent_error", error=str(e), exc_info=True)
            raise
 
    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        raise NotImplementedError