import json
import re
from typing import Any, Dict

import ollama as ollama_client
import structlog

from agents.base_agent import BaseAgent
from shared.utils import truncate_text, years_from_experience
from config.settings import settings

logger = structlog.get_logger(__name__)


class PotentialAgent(BaseAgent):
    """
    Assesses candidate growth potential and career trajectory.
    Never fails the pipeline — returns safe defaults on error.
    """

    def __init__(self, db):
        super().__init__("potential", db)
        self.ollama = ollama_client.AsyncClient(host=settings.ollama_base_url)

    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        parsed_cv = payload["parsed_cv"]

        # Quick heuristic-based trajectory score
        heuristic_score = self._heuristic_potential(parsed_cv)

        # LLM deep assessment
        llm_result = await self._llm_assess(parsed_cv)

        # Blend: 40% heuristic, 60% LLM (LLM is more nuanced)
        blended = round(heuristic_score * 0.4 + llm_result.get("potential_score", 0.5) * 0.6, 3)

        return {
            "potential_score": blended,
            "value_add_insights": llm_result.get("value_add_insights", []),
            "career_trajectory": llm_result.get("career_trajectory", "unknown"),
            "growth_potential_label": self._label(blended),
        }

    def _heuristic_potential(self, parsed_cv: dict) -> float:
        score = 0.5
        exp_list = parsed_cv.get("experience") or []
        total_years = years_from_experience(exp_list)

        # Certifications
        certs = parsed_cv.get("certifications") or []
        score += min(0.10, len(certs) * 0.03)

        # Total skills breadth
        tech_skills = parsed_cv.get("technical_skills") or []
        score += min(0.10, len(tech_skills) * 0.01)

        # Career progression (role count)
        score += min(0.10, len(exp_list) * 0.02)

        # Education
        edu = parsed_cv.get("education") or []
        if any("mba" in (e.get("degree") or "").lower() or "msc" in (e.get("degree") or "").lower() for e in edu):
            score += 0.05

        return min(1.0, score)

    async def _llm_assess(self, parsed_cv: dict) -> dict:
        prompt = f"""You are a strict JSON generator for HR analytics.

Evaluate career growth potential of this candidate.

Return ONLY valid JSON:
{{
  "potential_score": float 0.0-1.0,
  "value_add_insights": [string],
  "career_trajectory": "ascending|lateral|descending|insufficient_data"
}}

CV SUMMARY:
{truncate_text(str(parsed_cv), 1500)}"""

        try:
            response = await self.ollama.chat(
                model=settings.ollama_llm_model,
                messages=[{"role": "user", "content": prompt}],
                format="json",
                options={"temperature": 0.2},
            )
            raw = response["message"]["content"]
            if isinstance(raw, dict):
                return raw
            return json.loads(re.sub(r"```json\s*|```\s*", "", raw).strip())
        except Exception as e:
            logger.warning("potential_llm_failed", error=str(e))
            return {"potential_score": 0.5, "value_add_insights": [], "career_trajectory": "insufficient_data"}

    def _label(self, score: float) -> str:
        if score >= 0.75:
            return "High Growth Potential"
        elif score >= 0.55:
            return "Moderate Growth Potential"
        elif score >= 0.35:
            return "Limited Growth Signals"
        return "Insufficient Data"