import json
from typing import Any, Dict, List

from sqlalchemy import text
import structlog

from agents.base_agent import BaseAgent
from shared.utils import detect_keyword_stuffing

logger = structlog.get_logger(__name__)


class ValidationAgent(BaseAgent):
    """
    Validates CVs and screenings. Flags issues for HR review.
    Never auto-decides — raises flags only.
    """

    def __init__(self, db):
        super().__init__("validation", db)

    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        self.log.info("validation_started",
                      candidate_id=payload.get("candidate_id"),
                      job_id=payload.get("job_id"))
        anomalies = []

        anomalies += await self._check_duplicate_file(payload)
        anomalies += await self._check_duplicate_application(payload)
        anomalies += await self._check_parse_confidence(payload)
        anomalies += await self._check_employment_gaps(payload)
        anomalies += await self._check_date_consistency(payload)
        anomalies += await self._check_borderline_score(payload)
        anomalies += self._check_keyword_stuffing(payload)

        for anomaly in anomalies:
            try:
                await self.db.execute(
                    text("""
                        INSERT INTO anomalies
                            (cv_version_id, candidate_id, job_id, anomaly_type, severity, description, raw_evidence)
                        VALUES
                            (:cv_id, :cand_id, :job_id, :atype, :severity, :desc, CAST(:evidence AS jsonb))
                    """),
                    {
                        "cv_id": payload["cv_version_id"],
                        "cand_id": payload["candidate_id"],
                        "job_id": payload["job_id"],
                        "atype": anomaly["type"],
                        "severity": anomaly["severity"],
                        "desc": anomaly["description"],
                        "evidence": json.dumps(anomaly.get("evidence", {})),
                    },
                )
            except Exception as e:
                self.log.warning("anomaly_insert_failed", error=str(e))

        self.log.info("validation_complete", anomaly_count=len(anomalies))

        return {
            "anomalies": anomalies,
            "requires_review": any(a["severity"] in ["high", "critical"] for a in anomalies),
            "anomaly_count": len(anomalies),
        }

    async def _check_duplicate_file(self, payload: dict) -> List[dict]:
        result = await self.db.execute(
            text("""
                SELECT id, candidate_id, uploaded_at
                FROM cv_versions
                WHERE file_hash = :hash AND id != :cv_id
                LIMIT 1
            """),
            {"hash": payload["file_hash"], "cv_id": payload["cv_version_id"]},
        )
        row = result.fetchone()
        if row:
            return [{
                "type": "duplicate_cv",
                "severity": "high",
                "description": f"This CV file was previously uploaded on {row.uploaded_at.date()}.",
                "evidence": {"duplicate_cv_id": str(row.id)},
            }]
        return []

    async def _check_duplicate_application(self, payload: dict) -> List[dict]:
        result = await self.db.execute(
            text("""
                SELECT s.id, s.screened_at
                FROM screenings s
                WHERE s.candidate_id = :cand_id AND s.job_id = :job_id
                LIMIT 1
            """),
            {"cand_id": payload["candidate_id"], "job_id": payload["job_id"]},
        )
        row = result.fetchone()
        if row:
            return [{
                "type": "duplicate_cv",
                "severity": "medium",
                "description": f"Candidate already screened for this role on {row.screened_at.date()}.",
                "evidence": {"prior_screening_id": str(row.id)},
            }]
        return []

    async def _check_parse_confidence(self, payload: dict) -> List[dict]:
        confidence = payload.get("parse_confidence", 1.0)
        if confidence < 0.35:
            return [{
                "type": "low_parse_confidence",
                "severity": "high",
                "description": f"CV parse confidence is very low ({confidence:.0%}). May be scanned/image-based.",
                "evidence": {"confidence": confidence},
            }]
        elif confidence < 0.55:
            return [{
                "type": "low_parse_confidence",
                "severity": "medium",
                "description": f"CV parse confidence moderate ({confidence:.0%}). Some fields may be incomplete.",
                "evidence": {"confidence": confidence},
            }]
        return []

    async def _check_employment_gaps(self, payload: dict) -> List[dict]:
        experience = payload.get("parsed_cv", {}).get("experience", [])
        if len(experience) < 2:
            return []
        anomalies = []
        try:
            sorted_exp = sorted(
                [e for e in experience if e.get("start_date") and e.get("end_date")],
                key=lambda x: x["start_date"],
            )
            for i in range(1, len(sorted_exp)):
                prev_end = sorted_exp[i - 1]["end_date"]
                curr_start = sorted_exp[i]["start_date"]
                if str(prev_end).lower() == "present":
                    continue
                try:
                    prev_year = int(str(prev_end)[:4])
                    curr_year = int(str(curr_start)[:4])
                    gap_months = (curr_year - prev_year) * 12
                    if gap_months > 12:
                        anomalies.append({
                            "type": "employment_gap",
                            "severity": "low",
                            "description": f"Employment gap of ~{gap_months//12} year(s) between "
                                           f"{sorted_exp[i-1].get('company','')} and {sorted_exp[i].get('company','')}.",
                            "evidence": {"gap_months": gap_months},
                        })
                except (ValueError, TypeError):
                    pass
        except Exception as e:
            self.log.warning("gap_analysis_error", error=str(e))
        return anomalies

    async def _check_date_consistency(self, payload: dict) -> List[dict]:
        experience = payload.get("parsed_cv", {}).get("experience", [])
        active = [e for e in experience if str(e.get("end_date", "")).lower() == "present"]
        if len(active) > 1:
            return [{
                "type": "inconsistent_dates",
                "severity": "medium",
                "description": f"CV shows {len(active)} simultaneous 'current' positions.",
                "evidence": {"active_roles": [r.get("role") for r in active]},
            }]
        return []

    async def _check_borderline_score(self, payload: dict) -> List[dict]:
        score = payload.get("composite_score", 0)
        if 0.38 <= score <= 0.52:
            return [{
                "type": "borderline_score",
                "severity": "medium",
                "description": f"Composite score ({score:.2f}) is borderline (0.38–0.52). Human judgment required.",
                "evidence": {"composite_score": score},
            }]
        return []

    def _check_keyword_stuffing(self, payload: dict) -> List[dict]:
        raw_text = payload.get("raw_text", "")
        jd_skills = payload.get("jd_skills", [])
        if raw_text and jd_skills and detect_keyword_stuffing(raw_text, jd_skills):
            return [{
                "type": "suspicious_pattern",
                "severity": "high",
                "description": "Potential keyword stuffing detected. CV has unusually high JD skill density.",
                "evidence": {"jd_skills_count": len(jd_skills)},
            }]
        return []