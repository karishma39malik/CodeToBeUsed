"""
TalentScan — No-JD Screening Agent
====================================
When no Job Description exists, this agent evaluates a CV purely against
the organisation's known department taxonomy using:
  1. Skill-to-department keyword mapping (industry best-practice skill clusters)
  2. LLM rationale generation (department fit reasoning)
  3. A transparent scoring model with GENERIC caveats clearly surfaced in output

The composite score produced here is deliberately conservative (max ~0.72)
because without a JD we cannot validate must-have requirements.
The output always carries a NO_JD flag so the UI can surface the right caveats.

Scoring model (No-JD mode):
  dept_fit_score   × 0.50   — how well CV skills map to the best-fit department(s)
  experience_score × 0.25   — seniority / years of experience signal
  breadth_score    × 0.25   — cross-functional transferability

MAX possible composite in no-JD mode: ~0.72  (capped to prevent false precision)
"""

import json
import re
from typing import Any, Dict, List, Optional, Tuple

import structlog
import ollama as ollama_client

from agents.base_agent import BaseAgent
from config.settings import settings
from shared.utils import (
    build_cv_evidence_blob, skill_in_cv,
    filter_to_cv_grounded, validate_output_against_cv,
)

logger = structlog.get_logger(__name__)

# ── Organisation department taxonomy (read from images) ──────────────────────
# Grouped into parent clusters for scoring purposes.
ORG_DEPARTMENTS = [
    # Finance & Corporate
    "Finance & Accounts",
    "Accounting And Reporting",
    "Director - Finance & Accounts",
    "Finance",
    # Engineering (Aero / Core)
    "Engineering",
    "Engineering Systems",
    "Design - Engineering",
    "Flight Science - Engineering",
    "Structural Integrity - Engineering",
    "System Engineering - Engineering",
    "Chief Engineer Office - Engineering",
    "Avionics - Engineering",
    "Avionics And Mission",
    "Electrical Systems",
    # Flight Test & Prototypes
    "Flight Test And Prototypes",
    "Fti - Flight Test And Prototypes",
    "Maintenance - Flight Test And Prototypes",
    "Prototype & Testing",
    "Prototype & Testing - M4",
    "Flight Test and Prototype - CLS",
    # Aerospace / Safety
    "Aerospace",
    "Safety (Aero)",
    "Safety (Land)",
    "Director - Airworthiness & Certification",
    "Certification /Continued / Continuing Airworthiness",
    # Manufacturing & Industrial
    "Industrial Operations",
    "Manufacturing - Industrial Operations",
    "Production - Industrial Operations",
    "Advanced Industries Machining",
    "Fabrication - CLS",
    "Production",
    "Production - CLS",
    # Mechanical Systems / M4
    "Mechanical Systems - M4",
    "Mechanical - Hard Services",
    "Protection - M4",
    "Production - M4",
    # Missiles & Development (M&D)
    "Missiles And Technology - M&D",
    "Research And Development - M&D",
    "Research and Development - M&D",
    "System Integraion - M&D",
    "Project/Engineering/Store - M&D",
    "Business Support Services M & D",
    "Program Managers - M&D",
    "Program Managers - M&D 1",
    "Head Of M & D",
    "Project Management Office M&D",
    # CLS (Customer & Lifecycle Support)
    "CLS Office",
    "Chief - Land System - CLS",
    "Head - Scm - CLS",
    "Field Support",
    "Product Quality (Land) - CLS",
    "Governance Risk & Compliance - CLS",
    "Infrastructure & Support Division- CLS",
    "Lead - Land System Engineering - CLS",
    "Design - Engineering - CLS",
    "Prototype & Testing - CLS",
    "Warehouse - CLS",
    "Purchasing - Scm - CLS",
    "Project Management Office - Programs - CLS",
    "Lead - Protection - CLS",
    "Protection - CLS",
    # Land Systems Engineering
    "Head - Land System Engineering",
    "Lead - Land System Engineering",
    # Digital / IT / Cyber
    "Cybersecurity & Network",
    "Cyber",
    "Digital Transformation",
    "Director - Digital Transformation",
    "ERP & Applications Division",
    "Ai",
    # Programs / PMO
    "Program Management",
    "Project Management Office - Programs",
    "Director - Program Management",
    "PMO",
    # People & Culture / HR
    "People & Culture",
    "Director - People & Culture",
    "Employee Relations",
    "Strategic People Management",
    "Training &Development",
    "Emiratisation",
    # Marketing & Comms
    "Marketing & Communications",
    "Manager - Marketing & Communications",
    "Director - Marketing & Communications",
    "Branding & Design",
    "Public Relations",
    "Exhibitions & Corp Events",
    # Business Development / Sales
    "Director - Business Development",
    "International Market (Gcc,Mena,Europe)",
    "Mod & Governmental Contracts",
    # Operations / Supply Chain
    "Operations - Uav",
    "Procurement",
    "Purchasing - SCM",
    "Supplier Contracts Management",
    "Transportation Services",
    "Warehouse",
    "Product Support",
    # Quality / Compliance
    "Product Quality (Aero)",
    "Governance Risk & Compliance",
    "Compliance & Audit Team",
    "Director - Qhse",
    # Legal / Admin
    "Administration - Legal",
    "Director - Legal",
    "Director - Strategic Planning",
    "Corporate Service",
    # Facilities / Infrastructure
    "Facilities & Projects",
    "Director - Facilities & Projects",
    "Admin - Facilities & Projects",
    "Infrastructure & Support Division",
    "Construction - Hard Services",
    "Electrical - Hard Services",
    "Hard Services Maintenance - Hard Services",
    "Soft Services - Soft Services",
    "Security Section - Soft Services",
    "Operation - Soft Services",
    "General Services",
    "Director - General Services",
    "Admin - General Services",
    "Travel Desk",
    # Executive / Strategy
    "CEO Office",
    "Chairman",
    "Director - Strategic Planning",
    "Consultant Internal",
    # UAV / Special Projects
    "Project - UAV",
    "Operations - Uav",
]

# ── Department clusters with skill keywords ──────────────────────────────────
DEPT_CLUSTERS = {
    "Finance & Accounts": {
        "keywords": ["finance","accounting","accounts","ifrs","gaap","audit","tax","treasury","budgeting",
                     "financial reporting","erp","sap","oracle financials","cost control","variance analysis",
                     "cash flow","balance sheet","p&l","forecasting","financial analysis","cpa","acca","cma"],
        "departments": ["Finance & Accounts","Accounting And Reporting","Director - Finance & Accounts","Finance"],
    },
    "Engineering & Design": {
        "keywords": ["mechanical engineering","electrical engineering","structural engineering","systems engineering",
                     "autocad","catia","solidworks","matlab","ansys","fea","cfd","tolerance analysis",
                     "technical drawings","design review","engineering change","airworthiness","DO-178","DO-254",
                     "avionics","aerodynamics","flight mechanics","propulsion","stress analysis"],
        "departments": ["Engineering","Engineering Systems","Design - Engineering","Flight Science - Engineering",
                        "Structural Integrity - Engineering","System Engineering - Engineering","Avionics - Engineering",
                        "Avionics And Mission","Electrical Systems","Chief Engineer Office - Engineering"],
    },
    "Flight Test & Prototypes": {
        "keywords": ["flight test","prototype","test pilot","flight dynamics","telemetry","test planning",
                     "ground testing","rig testing","airworthiness testing","data acquisition","fti",
                     "flight envelope","test reports","flight safety","certification testing"],
        "departments": ["Flight Test And Prototypes","Fti - Flight Test And Prototypes",
                        "Prototype & Testing","Flight Test and Prototype - CLS"],
    },
    "Manufacturing & Production": {
        "keywords": ["manufacturing","production","machining","fabrication","cnc","lean","six sigma",
                     "quality control","assembly","industrial engineering","process improvement","tooling",
                     "jig","fixture","welding","composites","5s","kaizen","production planning"],
        "departments": ["Industrial Operations","Manufacturing - Industrial Operations","Production - Industrial Operations",
                        "Advanced Industries Machining","Fabrication - CLS","Production","Production - CLS"],
    },
    "Digital & IT": {
        "keywords": ["software","python","java","cloud","azure","aws","gcp","cybersecurity","network",
                     "erp","sap","oracle","digital transformation","it infrastructure","database","sql",
                     "devops","agile","scrum","ai","machine learning","data analytics","power bi",
                     "tableau","information security","iso 27001","penetration testing","siem","it governance"],
        "departments": ["Cybersecurity & Network","Cyber","Digital Transformation","ERP & Applications Division","Ai"],
    },
    "Program & Project Management": {
        "keywords": ["project management","program management","pmp","prince2","agile","scrum","stakeholder",
                     "milestone","risk management","schedule","budget management","pmo","earned value",
                     "change management","delivery management","msp","pgmp","program director"],
        "departments": ["Program Management","Project Management Office - Programs","Director - Program Management",
                        "Program Managers - M&D","Program Managers - M&D 1"],
    },
    "Missiles & Defence R&D": {
        "keywords": ["missiles","weapons systems","defence","munitions","guided systems","propulsion systems",
                     "warhead","guidance navigation","target acquisition","electronic warfare","countermeasures",
                     "radar","sensor fusion","defence procurement","mil-std","nato","research and development",
                     "systems integration","combat systems","armaments"],
        "departments": ["Missiles And Technology - M&D","Research And Development - M&D","System Integraion - M&D",
                        "Project/Engineering/Store - M&D","Head Of M & D"],
    },
    "Quality, Safety & Compliance": {
        "keywords": ["quality management","qms","iso 9001","as9100","safety management","sms","qhse",
                     "audit","compliance","regulatory","risk assessment","root cause analysis","ncr",
                     "corrective action","airworthiness","easa","gcaa","faa","iso 45001","hse",
                     "governance","risk and compliance","grc"],
        "departments": ["Product Quality (Aero)","Governance Risk & Compliance","Compliance & Audit Team",
                        "Director - Qhse","Safety (Aero)","Safety (Land)"],
    },
    "Supply Chain & Procurement": {
        "keywords": ["supply chain","procurement","purchasing","scm","vendor management","sourcing",
                     "logistics","warehouse","inventory","erp","sap mm","contract management",
                     "supplier evaluation","import export","customs","freight","material planning",
                     "demand planning","bom","mrp"],
        "departments": ["Procurement","Purchasing - SCM","Supplier Contracts Management",
                        "Warehouse","Transportation Services","Product Support"],
    },
    "People & Culture / HR": {
        "keywords": ["human resources","hr","recruitment","talent acquisition","talent management",
                     "learning and development","performance management","compensation","benefits",
                     "employee relations","hr policies","payroll","emiratisation","nationalization",
                     "organizational development","hris","succession planning","workforce planning"],
        "departments": ["People & Culture","Director - People & Culture","Employee Relations",
                        "Strategic People Management","Training &Development","Emiratisation"],
    },
    "Marketing & Communications": {
        "keywords": ["marketing","communications","brand","digital marketing","social media","public relations",
                     "content","campaign","seo","advertising","events","exhibitions","media relations",
                     "corporate communications","market research","product marketing","b2b","b2g"],
        "departments": ["Marketing & Communications","Branding & Design","Public Relations",
                        "Exhibitions & Corp Events","Director - Marketing & Communications"],
    },
    "Business Development & Sales": {
        "keywords": ["business development","sales","commercial","contracts","government contracts",
                     "mod","tenders","rfp","rfq","account management","customer relations","crm",
                     "revenue growth","international sales","gcc","mena","defence contracts",
                     "offset","industrial participation"],
        "departments": ["Director - Business Development","International Market (Gcc,Mena,Europe)",
                        "Mod & Governmental Contracts"],
    },
    "Facilities & Infrastructure": {
        "keywords": ["facilities management","fm","building services","maintenance","hvac","electrical",
                     "plumbing","construction","infrastructure","hard services","soft services",
                     "security","cleaning","fit-out","project management","cafm","planned maintenance"],
        "departments": ["Facilities & Projects","Infrastructure & Support Division","Construction - Hard Services",
                        "Electrical - Hard Services","Soft Services - Soft Services","General Services"],
    },
    "Legal & Administration": {
        "keywords": ["legal","corporate law","contract law","compliance","regulatory affairs","litigation",
                     "intellectual property","legal counsel","memorandum","governance","board secretariat",
                     "administration","office management","executive assistant","corporate governance"],
        "departments": ["Administration - Legal","Director - Legal","Corporate Service","Consultant Internal"],
    },
    "UAV & Special Operations": {
        "keywords": ["uav","drone","unmanned","uas","rpas","ground control","payload","isr",
                     "autonomous systems","flight control","mission planning","counter-uav",
                     "multi-rotor","fixed wing","vtol"],
        "departments": ["Project - UAV","Operations - Uav"],
    },
}

# Flat lookup: dept name → cluster name
DEPT_TO_CLUSTER = {}
for cluster, data in DEPT_CLUSTERS.items():
    for d in data["departments"]:
        DEPT_TO_CLUSTER[d] = cluster


# ── Defence-relevance weights per cluster ────────────────────────────────────
# Clusters directly relevant to a defence/aerospace org score higher.
# Weight 1.0 = core defence; 0.75 = adjacent; 0.5 = support; 0.35 = generic.
DEFENCE_RELEVANCE = {
    "Missiles & Defence R&D":        1.00,
    "Engineering & Design":          0.90,
    "Flight Test & Prototypes":      0.90,
    "UAV & Special Operations":      0.90,
    "Manufacturing & Production":    0.75,
    "Quality, Safety & Compliance":  0.75,
    "Program & Project Management":  0.70,
    "Digital & IT":                  0.65,
    "Supply Chain & Procurement":    0.60,
    "Business Development & Sales":  0.55,
    "Finance & Accounts":            0.50,
    "People & Culture / HR":         0.45,
    "Marketing & Communications":    0.40,
    "Facilities & Infrastructure":   0.40,
    "Legal & Administration":        0.40,
}

# Signals that indicate direct defence/military background (big bonus)
DEFENCE_BACKGROUND_SIGNALS = [
    "defence","defense","military","armed forces","navy","army","air force",
    "aerospace","aviation","weapons","missiles","munitions","nato","mil-std",
    "dod","mod","ministry of defence","ministry of defense","combat","tactical",
    "surveillance","isr","radar","sonar","electronic warfare","counter-uav",
    "airworthiness","gcaa","easa","faa","uav","uas","rpas","drone","unmanned",
    "flight test","propulsion","avionics","guided systems","warhead",
    "systems integration","defence contractor","calidus","edge group",
    "baesystems","bae systems","lockheed","boeing defence","raytheon",
    "thales","saab","rheinmetall","mbda","leonardo","l3harris",
]

class NoJDAgent(BaseAgent):
    """
    Screens a CV without a Job Description.
    Returns the same result dict structure as MatchingAgent so the pipeline
    can store and display it identically — with NO_JD flags set.
    """

    def __init__(self, db):
        super().__init__("no_jd_screening", db)
        self.ollama = ollama_client.AsyncClient(host=settings.ollama_base_url)

    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        parsed_cv     = payload["parsed_cv"]
        cv_version_id = payload["cv_version_id"]
        job_id        = payload["job_id"]

        cv_skills    = self._all_skills(parsed_cv)
        exp_years    = self._get_exp_years(parsed_cv)
        seniority    = self._seniority(parsed_cv, exp_years)

        # ── 1. Score every cluster; also get matched ORG departments ──────────
        cluster_scores, matched_depts = self._score_clusters_and_depts(cv_skills, parsed_cv)
        top_clusters  = sorted(cluster_scores.items(), key=lambda x: x[1], reverse=True)[:5]
        best_cluster, best_score = top_clusters[0]

        # ── 2. Placement breadth: how many ORG departments this CV can fill ───
        # Core scoring signal: candidate matched against the real org dept list.
        total_depts   = len(ORG_DEPARTMENTS)
        n_matched     = len(matched_depts)
        placement_score = min(n_matched / max(total_depts * 0.15, 1), 1.0)  # 15% match = full score

        # ── 3. Defence background ─────────────────────────────────────────────
        defence_score, defence_signals = self._defence_background_score(parsed_cv)

        # ── 4. Support-function flag ──────────────────────────────────────────
        # IT, HR, Finance, Legal, Marketing can be filled without defence background.
        # For these clusters the defence_score is not penalised.
        SUPPORT_CLUSTERS = {
            "Digital & IT", "People & Culture / HR", "Finance & Accounts",
            "Legal & Administration", "Marketing & Communications",
            "Facilities & Infrastructure",
        }
        is_support_function = best_cluster in SUPPORT_CLUSTERS

        experience_score = self._score_experience(exp_years, seniority)
        breadth_score    = self._score_breadth(cluster_scores)

        # ── 5. Composite — org-fit score ──────────────────────────────────────
        # For CORE defence clusters:   defence background matters a lot
        # For SUPPORT function clusters: placement breadth & experience dominate
        if is_support_function:
            # Support functions: defence background is a nice-to-have, not required
            raw_composite = (
                placement_score  * 0.40 +
                experience_score * 0.35 +
                breadth_score    * 0.20 +
                defence_score    * 0.05
            )
            cap = 0.78  # support candidates can score well without defence exp
        else:
            # Core defence/engineering clusters: defence background is the key signal
            raw_composite = (
                defence_score    * 0.30 +
                placement_score  * 0.25 +
                experience_score * 0.25 +
                breadth_score    * 0.20
            )
            if defence_score >= 0.30:
                cap = 0.85
            elif defence_score >= 0.15:
                cap = 0.75
            else:
                cap = 0.65

        if defence_score >= 0.30:   defence_label = "Strong"
        elif defence_score >= 0.15: defence_label = "Moderate"
        else:                       defence_label = "Limited"

        composite = min(round(raw_composite, 4), cap)

        # ── 6. LLM rationale ──────────────────────────────────────────────────
        llm_rationale, strengths, gaps = await self._llm_assess(
            parsed_cv, best_cluster, top_clusters, exp_years, seniority,
            defence_score, defence_label, matched_depts, is_support_function, defence_signals
        )

        # ── 7. Build suggested departments from actual ORG_DEPARTMENTS ─────────
        suggested_depts = []
        for dept in matched_depts[:12]:
            cluster = DEPT_TO_CLUSTER.get(dept, best_cluster)
            c_score = cluster_scores.get(cluster, 0.0)
            suggested_depts.append({"department": dept, "cluster": cluster, "score": round(c_score, 2)})
        # sort by cluster score descending
        suggested_depts.sort(key=lambda x: x["score"], reverse=True)

        return {
            "composite_score":       composite,
            "relevance_score":       placement_score,
            "semantic_similarity":   breadth_score,
            "potential_score":       experience_score,
            "no_jd_mode":            True,
            "best_cluster":          best_cluster,
            "suggested_departments": suggested_depts,
            "top_clusters":          [{"cluster": c, "score": round(s, 2)} for c, s in top_clusters],
            "seniority_band":        seniority,
            "years_of_experience":   exp_years,
            "matched_dept_count":    n_matched,
            "strengths":             strengths,
            "gaps":                  gaps,
            "transferable_skills":   self._transferable(cv_skills),
            "value_add_insights":    self._insights(parsed_cv, best_cluster, exp_years, n_matched, is_support_function),
            "llm_rationale":         llm_rationale,
            "ai_summary":            (
                f"[CV SCAN] Org-fit: {int(composite*100)}%. "
                f"CV keywords match {n_matched} of {total_depts} org departments. "
                f"Defence background in CV: {defence_label} "
                f"({'signals: ' + ', '.join(defence_signals[:4]) if defence_signals else 'no defence signals found'}). "
                f"Best fit: {best_cluster}. {seniority}, {exp_years:.0f} yrs."
            ),
            "evidence_map": {
                "defence_signals_found":  defence_signals,
                "matched_departments":    matched_depts,
                "cv_skills_used":         cv_skills[:20],
                "scoring_basis":          "keyword_overlap_only_no_inference",
            },
            "decision":              self._decision(composite),
            "rejection_reason":      None,
            "score_breakdown":       {
                "placement_score":   placement_score,
                "experience_score":  experience_score,
                "breadth_score":     breadth_score,
                "defence_score":     defence_score,
                "defence_label":     defence_label,
                "composite_score":   composite,
                "matched_depts":     n_matched,
                "total_org_depts":   total_depts,
                "is_support_function": is_support_function,
                "no_jd_mode":        True,
                "scoring_basis":     "org_fit_dept_match",
            },
            "skill_scores": [],
        }

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _all_skills(self, parsed_cv: dict) -> List[str]:
        skills = []
        for field in ["technical_skills","soft_skills","domain_expertise","certifications"]:
            v = parsed_cv.get(field) or []
            if isinstance(v, str):
                try: v = json.loads(v)
                except: v = [v]
            skills.extend([str(s).lower() for s in v if s])
        # also pull from experience descriptions
        for exp in (parsed_cv.get("experience") or []):
            desc = exp.get("description") or ""
            techs = exp.get("technologies") or []
            skills.extend([str(t).lower() for t in techs])
        return list(set(skills))

    def _get_exp_years(self, parsed_cv: dict) -> float:
        v = parsed_cv.get("total_years_exp")
        if v:
            try: return float(str(v).split()[0])
            except: pass
        # count from experience list
        months = sum(
            (e.get("duration_months") or 0)
            for e in (parsed_cv.get("experience") or [])
        )
        return round(months / 12, 1) if months else 3.0

    def _seniority(self, parsed_cv: dict, exp_years: float) -> str:
        title = (parsed_cv.get("cv_summary") or "").lower()
        exp_roles = " ".join(
            (e.get("role") or "").lower()
            for e in (parsed_cv.get("experience") or [])
        )
        combined = title + " " + exp_roles
        if any(k in combined for k in ["chief","vp","vice president","cxo","ceo","coo","cto","cfo","president","svp","evp"]):
            return "Executive (C-Suite / VP)"
        if any(k in combined for k in ["director","head of","general manager","gm"]):
            return "Director / Head"
        if any(k in combined for k in ["senior manager","manager","lead","principal","sr. manager"]):
            return "Manager / Senior Lead"
        if exp_years >= 8:
            return "Senior Professional"
        if exp_years >= 4:
            return "Mid-Level Professional"
        return "Junior / Graduate"

    def _defence_background_score(self, parsed_cv: dict) -> tuple:
        """
        Returns (score 0.0-1.0, matched_signals list).
        Checks company names, roles, descriptions, domain_expertise, certifications.
        """
        blob = ""
        for exp in (parsed_cv.get("experience") or []):
            blob += " " + (exp.get("company") or "").lower()
            blob += " " + (exp.get("role") or "").lower()
            blob += " " + (exp.get("description") or "").lower()
            for t in (exp.get("technologies") or []):
                blob += " " + str(t).lower()
        for field in ["cv_summary", "domain_expertise", "certifications", "technical_skills"]:
            v = parsed_cv.get(field) or ""
            if isinstance(v, list):
                blob += " " + " ".join(str(x).lower() for x in v)
            else:
                blob += " " + str(v).lower()

        matched = [sig for sig in DEFENCE_BACKGROUND_SIGNALS if sig in blob]
        score   = min(len(matched) / 10.0, 0.60)
        return score, matched

    def _score_clusters_and_depts(
        self, cv_skills: List[str], parsed_cv: dict
    ) -> tuple:
        """
        Score the CV against every DEPT_CLUSTER and also return the list of
        actual ORG_DEPARTMENTS that the candidate plausibly matches.

        Returns:
            cluster_scores  — {cluster_name: float 0-1}
            matched_depts   — [dept_name, ...] from ORG_DEPARTMENTS
        """
        text_blob = " ".join(cv_skills)
        for exp in (parsed_cv.get("experience") or []):
            text_blob += " " + (exp.get("role") or "").lower()
            text_blob += " " + (exp.get("description") or "").lower()
            for t in (exp.get("technologies") or []):
                text_blob += " " + str(t).lower()
        for field in ["cv_summary", "domain_expertise", "certifications"]:
            v = parsed_cv.get(field) or ""
            if isinstance(v, list):
                text_blob += " " + " ".join(str(x).lower() for x in v)
            else:
                text_blob += " " + str(v).lower()

        cluster_scores: Dict[str, float] = {}
        for cluster, data in DEPT_CLUSTERS.items():
            kws      = data["keywords"]
            hits     = sum(1 for kw in kws if kw in text_blob)
            kw_score = min(hits / max(len(kws) * 0.35, 1), 1.0)
            weight   = DEFENCE_RELEVANCE.get(cluster, 0.5)
            cluster_scores[cluster] = round(kw_score * weight, 4)

        # Map matched clusters → actual org departments
        threshold = 0.10  # cluster score must exceed this to count as a match
        matched_depts: List[str] = []
        for cluster, score in cluster_scores.items():
            if score >= threshold:
                for dept in DEPT_CLUSTERS[cluster]["departments"]:
                    if dept in ORG_DEPARTMENTS and dept not in matched_depts:
                        matched_depts.append(dept)

        return cluster_scores, matched_depts

    def _score_experience(self, exp_years: float, seniority: str) -> float:
        # 0–2 yrs → 0.30, 3–5 → 0.50, 6–10 → 0.70, 11–15 → 0.85, 15+ → 0.95
        if exp_years >= 15: return 0.95
        if exp_years >= 11: return 0.85
        if exp_years >= 6:  return 0.70
        if exp_years >= 3:  return 0.50
        return 0.30

    def _score_breadth(self, cluster_scores: Dict[str, float]) -> float:
        """Multi-cluster transferability — how many clusters have >0.2 score."""
        strong = sum(1 for s in cluster_scores.values() if s >= 0.2)
        return min(strong / 5.0, 1.0)

    def _decision(self, composite: float) -> str:
        if composite >= 0.55: return "needs_review"   # can't auto-shortlist without JD
        if composite >= 0.35: return "needs_review"
        return "auto_rejected"

    def _transferable(self, skills: List[str]) -> List[str]:
        priority = ["project management","stakeholder management","data analysis","communication",
                    "leadership","problem solving","agile","strategic planning","risk management",
                    "process improvement","team management","cross-functional"]
        return [s for s in skills if any(p in s for p in priority)][:8]

    def _insights(self, parsed_cv: dict, best_cluster: str, exp_years: float,
                  n_matched: int = 0, is_support: bool = False) -> List[str]:
        insights = [
            f"CV scan (no JD) — score reflects org-fit across {n_matched} matching department(s), not a specific role.",
            f"Best-fit cluster: {best_cluster}. {'Defence background not required for this function.' if is_support else 'Prioritise candidates with direct aerospace/defence experience.'}",
            f"Candidate has ~{exp_years:.0f} yrs experience. Cross-reference with seniority level of open roles.",
        ]
        certs = parsed_cv.get("certifications") or []
        if certs:
            insights.append(f"Certifications: {', '.join(str(c) for c in certs[:4])}. Verify currency and relevance.")
        return insights

    async def _llm_assess(
        self, parsed_cv: dict, best_cluster: str,
        top_clusters: List[Tuple], exp_years: float, seniority: str,
        defence_score: float = 0.0, defence_label: str = "Limited",
        matched_depts: Optional[List[str]] = None,
        is_support_function: bool = False,
        defence_signals: Optional[List[str]] = None,
    ) -> Tuple[str, List[str], List[str]]:
        """Generate dept-matched org-fit rationale via LLM. Falls back gracefully."""

        matched_depts    = matched_depts or []
        defence_signals  = defence_signals or []
        name             = parsed_cv.get("full_name") or "the candidate"
        skills           = (parsed_cv.get("technical_skills") or [])[:12]
        edu              = parsed_cv.get("education") or []
        edu_str          = "; ".join(
            f"{e.get('degree','')} in {e.get('field','')} from {e.get('institution','')}"
            for e in edu[:2]
        ) or "Not specified"
        exp_roles = "; ".join(
            (e.get("role") or "") + " at " + (e.get("company") or "")
            for e in (parsed_cv.get("experience") or [])[:4]
        )
        # Surface the actual org departments that matched — this is the core input
        dept_list_str = (
            "\n".join(f"  - {d}" for d in matched_depts[:15])
            if matched_depts
            else "  (none matched — very limited overlap with org taxonomy)"
        )
        top3_str = ", ".join(f"{c} ({int(s*100)}%)" for c, s in top_clusters[:3])
        signals_str = ", ".join(defence_signals[:8]) if defence_signals else "none detected"
        function_note = (
            "NOTE: This candidate's best-fit cluster is a SUPPORT FUNCTION "
            f"({best_cluster}). Defence/aerospace sector experience is beneficial "
            "but NOT a prerequisite — candidates from any industry can succeed here."
            if is_support_function else
            f"NOTE: This candidate's best-fit cluster is a CORE DEFENCE/TECHNICAL function "
            f"({best_cluster}). Sector-specific experience is important."
        )

        # ── Build literal CV text to give to the LLM (no inferences) ──────
        cv_blob = build_cv_evidence_blob(parsed_cv)
        cv_roles_literal = [
            f"{e.get('role','')} at {e.get('company','')} ({e.get('start_date','')}–{e.get('end_date','')})"
            for e in (parsed_cv.get("experience") or [])
        ]
        cv_skills_literal = (
            (parsed_cv.get("technical_skills") or []) +
            (parsed_cv.get("soft_skills") or []) +
            (parsed_cv.get("domain_expertise") or []) +
            (parsed_cv.get("certifications") or [])
        )

        prompt = f"""You are a strict HR analyst at Calidus, a UAE aerospace and defence manufacturer.
This is a PURE CV SCAN — no job description. Assess org fit based ONLY on the literal CV content below.

CRITICAL RULES:
- Every claim you make MUST cite a specific item from the CV FACTS section below.
- Do NOT mention any technology, department, or industry not explicitly in the CV.
- Do NOT infer skills. If it is not written in the CV, it does not exist.
- Strengths must quote or paraphrase actual CV content — no generalising.

━━ CV FACTS (use ONLY this — do not add or infer) ━━━━━━━━━
Roles held: {chr(10).join(cv_roles_literal) or "None listed"}
Explicit skills: {", ".join(str(s) for s in cv_skills_literal) or "None listed"}
Education: {edu_str}
Defence signals found by system: {signals_str if signals_str != "none detected" else "NONE — no defence background detected"}

━━ SYSTEM PRE-ANALYSIS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Defence background level: {defence_label} (based on keyword scan of CV)
Matched org departments ({len(matched_depts)} matched from {len(ORG_DEPARTMENTS)} total — based on CV keywords):
{dept_list_str}
{function_note}

━━ YOUR TASK ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Write a structured HR assessment (max 200 words):

1. SECTOR FIT: Does the CV show aerospace/defence background? Quote specific companies or roles. If none, state: "No defence background evidenced in CV."
2. DEPARTMENT PLACEMENT: Which 1-2 departments from the matched list above fit this CV? Justify using only CV facts.
3. TRANSFERABLE VALUE: What skills explicitly listed in the CV transfer to our org? Quote the CV.
4. GAPS: What is absent from the CV that would be needed for a defence role?
5. RECOMMENDATION: "Pipeline for [dept]" / "Hold — suitable for [dept] when open" / "Not aligned"

Do NOT mention any skill, technology, or department not in the CV FACTS or matched list.
"""

        try:
            response = await self.ollama.chat(
                model=settings.ollama_llm_model,
                messages=[{"role": "user", "content": prompt}],
                options={"temperature": 0.25, "num_predict": 400},
            )
            rationale = response["message"]["content"].strip()

            # Structured strengths/gaps pass
            struct_prompt = f"""You are a strict HR analyst. List only what is explicitly in the CV below.

CV SKILLS (literal): {", ".join(str(s) for s in cv_skills_literal) or "none listed"}
CV ROLES (literal): {"; ".join(cv_roles_literal) or "none listed"}
Matched org departments: {", ".join(matched_depts[:8]) or "none — very limited CV-org overlap"}
Defence background detected: {defence_label}
Is support function: {is_support_function}

RULES:
- STRENGTHS must each cite a specific skill or role FROM THE CV ABOVE.
- GAPS must cite something required for defence/these departments but ABSENT from the CV.
- Do NOT mention anything not in the CV skills or roles listed above.

List EXACTLY (no preamble, no extra text):
STRENGTHS:
- [strength directly evidenced by CV skill or role above]
- [repeat, 4 more]
GAPS:
- [gap: something absent from CV that the matched departments require]
- [repeat, 4 more]"""

            struct_resp = await self.ollama.chat(
                model=settings.ollama_llm_model,
                messages=[{"role": "user", "content": struct_prompt}],
                options={"temperature": 0.2, "num_predict": 300},
            )
            strengths, gaps = self._parse_sg(struct_resp["message"]["content"])

            # ── Post-generation grounding: strip hallucinated strengths ───────
            strengths = filter_to_cv_grounded(strengths, cv_blob)

        except Exception as e:
            logger.warning("no_jd_llm_failed", error=str(e))
            dept_sample = ", ".join(matched_depts[:3]) if matched_depts else best_cluster
            rationale = (
                f"[CV SCAN — NO JD] {name} — Defence background: {defence_label}. "
                f"Matched {len(matched_depts)} org departments including: {dept_sample}. "
                f"Best cluster: {best_cluster}. "
                f"{'Support function — defence experience not required.' if is_support_function else 'Core defence/technical role — sector experience is important.'} "
                f"{seniority} with {exp_years:.0f} yrs experience. "
                f"A Job Description is required for role-specific assessment."
            )
            strengths = [
                f"Matched {len(matched_depts)} org departments — viable placement options exist",
                f"{seniority} level — appropriate for mid/senior openings",
                f"{exp_years:.0f} years of professional experience",
            ]
            gaps = [
                "No JD — specific mandatory requirements cannot be verified",
                f"{'Defence sector exposure not evidenced' if defence_label == 'Limited' else 'Defence background present but depth unverified without JD'}",
                "Role-level fit unknown without position specification",
            ]

        return rationale, strengths[:6], gaps[:6]

    def _parse_sg(self, text: str) -> Tuple[List[str], List[str]]:
        strengths = []; gaps = []
        mode = None
        for line in text.split("\n"):
            line = line.strip()
            if "STRENGTHS" in line.upper(): mode = "s"; continue
            if "GAPS" in line.upper(): mode = "g"; continue
            if line.startswith("-") or (line and line[0].isdigit() and "." in line[:3]):
                clean = re.sub(r"^[-\d\.\*\s]+", "", line).strip()
                if clean:
                    if mode == "s": strengths.append(clean)
                    elif mode == "g": gaps.append(clean)
        return strengths[:6], gaps[:6]