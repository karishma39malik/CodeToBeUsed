from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from database.connection import get_db

router = APIRouter()


@router.get("/")
async def list_candidates(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("SELECT id, full_name, email, current_status, is_returning, first_seen_at FROM candidates ORDER BY first_seen_at DESC LIMIT 200")
    )
    return [dict(row._mapping) for row in result.fetchall()]


@router.get("/{candidate_id}")
async def get_candidate(candidate_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("SELECT * FROM candidates WHERE id = :id"),
        {"id": candidate_id}
    )
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Candidate not found")
    return dict(row._mapping)


@router.get("/{candidate_id}/history")
async def candidate_history(candidate_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("""
            SELECT s.id, s.job_id, j.title AS job_title, s.composite_score,
                   s.decision, s.rejection_reason, s.screened_at
            FROM screenings s
            JOIN jobs j ON j.id = s.job_id
            WHERE s.candidate_id = :id
            ORDER BY s.screened_at DESC
        """),
        {"id": candidate_id}
    )
    return [dict(row._mapping) for row in result.fetchall()]