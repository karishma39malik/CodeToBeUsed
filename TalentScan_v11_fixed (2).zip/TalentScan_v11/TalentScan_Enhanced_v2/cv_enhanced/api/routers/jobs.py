"""
TalentScan — Jobs Router v10 (FIXED)
=====================================
Fixes applied:
  1. no_jd received as string "true"/"false" from Streamlit multipart form —
     was typed as Optional[bool] but FastAPI won't parse "true" string → bool
     in multipart. Now typed as Optional[str] + _parse_bool_form() helper.
  2. Embedding failure is now non-fatal (warning only) — job still created
     without embedding so Ollama slowness never causes a 500.
  3. All unhandled exceptions caught and re-raised as HTTP 500 with detail,
     replacing the opaque FastAPI traceback.
  4. DB rollback on error to prevent dangling transactions.
"""

import json
import uuid
import io
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Form, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
import ollama as ollama_client
import structlog
import pdfplumber

from database.connection import get_db
from shared.models import JobResponse
from config.settings import settings

router = APIRouter()
logger = structlog.get_logger(__name__)


def _parse_bool_form(value) -> bool:
    """
    Coerce a multipart form value to bool.
    Streamlit sends Form bools as the string "true" / "false" inside
    multipart/form-data. FastAPI's Optional[bool] Form field silently stays
    False because it cannot parse the bare string "true". We accept the field
    as Optional[str] and convert here.
    Truthy: "true", "1", "yes", "on"  (case-insensitive).
    """
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in ("true", "1", "yes", "on")


@router.post("/", response_model=dict)
async def create_job(
    title: str = Form(...),
    department: str = Form(...),
    location: str = Form(...),
    created_by: str = Form(...),
    description: Optional[str] = Form(None),
    jd_file: Optional[UploadFile] = File(None),
    # Typed as Optional[str] — parsed manually to bool below (see fix note #1)
    no_jd: Optional[str] = Form(None),
    db: AsyncSession = Depends(get_db),
):
    try:
        job_id = str(uuid.uuid4())

        # ── Parse no_jd flag (string → bool) ──────────────────────────────────
        no_jd_flag = _parse_bool_form(no_jd)

        # ── Extract JD text ────────────────────────────────────────────────────
        description_raw = ""
        if jd_file and jd_file.filename:
            file_bytes = await jd_file.read()
            try:
                with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                    description_raw = "\n".join(
                        page.extract_text() or "" for page in pdf.pages
                    ).strip()
            except Exception as e:
                logger.warning("pdf_extraction_failed", error=str(e))
                description_raw = description or ""
        else:
            description_raw = (description or "").strip()

        # ── Determine no-JD mode ───────────────────────────────────────────────
        is_no_jd = no_jd_flag or (not description_raw)

        if is_no_jd:
            description_raw = ""
            requirements = {"no_jd": True, "mandatory_skills": [], "good_to_have_skills": []}
            embed_str = None
            logger.info("job_created_no_jd", title=title, department=department)
        else:
            if len(description_raw) < 50:
                raise HTTPException(
                    status_code=400,
                    detail="Job description is too short (< 50 chars). Provide a fuller JD or switch to No-JD mode.",
                )
            requirements = {}

            # ── Generate JD embedding — NON-FATAL if Ollama is unavailable ────
            embed_str = None
            try:
                ollama = ollama_client.AsyncClient(host=settings.ollama_base_url)
                emb_response = await ollama.embeddings(
                    model=settings.ollama_embed_model,
                    prompt=description_raw[:4000],
                )
                jd_embed = emb_response["embedding"]
                embed_str = "[" + ",".join(str(float(x)) for x in jd_embed) + "]"
            except Exception as e:
                logger.warning(
                    "jd_embedding_skipped_non_fatal",
                    error=str(e),
                    note="Job created without embedding; screening uses keyword matching only.",
                )

        await db.execute(
            text("""
                INSERT INTO jobs
                    (id, title, department, location, description_raw,
                     requirements, embedding, created_by)
                VALUES
                    (:id, :title, :dept, :loc, :desc,
                     CAST(:req AS jsonb),
                     CAST(:emb AS vector),
                     :by)
            """),
            {
                "id":    job_id,
                "title": title,
                "dept":  department,
                "loc":   location,
                "desc":  description_raw,
                "req":   json.dumps(requirements),
                "emb":   embed_str,
                "by":    created_by,
            },
        )
        await db.commit()

        mode = "no_jd" if is_no_jd else "with_jd"
        return {
            "id":      job_id,
            "title":   title,
            "mode":    mode,
            "message": f"Job created ({'no JD — generic dept screening' if is_no_jd else 'with JD'})",
        }

    except HTTPException:
        raise
    except Exception as exc:
        await db.rollback()
        logger.error("create_job_endpoint_failed", error=str(exc), exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to create job: {exc}") from exc


@router.get("/")
async def list_jobs(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("""
            SELECT id, title, department, location, description_raw, requirements,
                   is_active, created_at, created_by
            FROM jobs WHERE is_active = TRUE
            ORDER BY created_at DESC
        """)
    )
    rows = []
    for row in result.fetchall():
        d = dict(row._mapping)
        req = d.get("requirements") or {}
        if isinstance(req, str):
            try:
                req = json.loads(req)
            except Exception:
                req = {}
        d["no_jd"] = bool(req.get("no_jd"))
        rows.append(d)
    return rows


@router.get("/{job_id}")
async def get_job(job_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("SELECT * FROM jobs WHERE id=:id"), {"id": job_id}
    )
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Job not found")
    d = dict(row._mapping)
    req = d.get("requirements") or {}
    if isinstance(req, str):
        try:
            req = json.loads(req)
        except Exception:
            req = {}
    d["no_jd"] = bool(req.get("no_jd"))
    return d


@router.get("/{job_id}/pipeline")
async def get_pipeline(job_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("""
            SELECT
                COUNT(*)                                                     AS total_screened,
                SUM(CASE WHEN s.decision='needs_review' THEN 1 ELSE 0 END)  AS pending_review,
                SUM(CASE WHEN s.decision IN ('auto_shortlisted','hr_approved')
                         THEN 1 ELSE 0 END)                                  AS shortlisted,
                AVG(s.composite_score)                                       AS avg_score
            FROM screenings s WHERE s.job_id=:jid
        """),
        {"jid": job_id},
    )
    row = result.fetchone()
    return dict(row._mapping) if row else {}