"""
TalentScan — Screening Router v10 (FIXED)
==========================================
Fixes applied:
  1. candidates INSERT used column "created_at" — schema has NO such column on
     candidates table (it uses first_seen_at). Fixed both INSERT statements.
  2. ON CONFLICT DO NOTHING on candidates uses email as unique key — but we're
     inserting with NULL email. Added a separate upsert path that only uses the
     unique constraint when email is non-NULL, preventing silent row skips.
  3. Candidate lookup by full_name is fragile (multiple people can share a name).
     Now we INSERT first, capture lastval via RETURNING id, so we always have
     the exact row we just created.
  4. get_screening_results pulls all parsed_data fields including no-JD fields
     (suggested_departments, best_cluster, top_clusters).
  5. parse_confidence pulled from cv_versions.
"""

import asyncio
import json
import logging
import time
import uuid
from pathlib import Path

import structlog
from fastapi import APIRouter, Depends, Form, HTTPException, UploadFile, File, BackgroundTasks
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from agents.ingestion_agent import IngestionAgent
from agents.matching_agent import MatchingAgent
from agents.no_jd_agent import NoJDAgent
from agents.potential_agent import PotentialAgent
from agents.validation_agent import ValidationAgent
from database.connection import get_db
from shared.models import BulkUploadResponse

log = structlog.get_logger()
router = APIRouter()

UPLOAD_DIR = Path("/tmp/cv_uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

ALLOWED_EXTS = {".pdf", ".docx", ".txt"}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB


# =====================================================
# UPLOAD CVs
# =====================================================
@router.post("/upload/{job_id}", response_model=BulkUploadResponse)
async def upload_cvs(
    job_id: str,
    background_tasks: BackgroundTasks,
    files: list[UploadFile] = File(...),
    db: AsyncSession = Depends(get_db),
):
    queued, failed, errors, cids = [], [], [], []

    for f in files:
        ext = Path(f.filename).suffix.lower()
        if ext not in ALLOWED_EXTS:
            failed.append(f.filename)
            errors.append({"file": f.filename, "reason": f"Unsupported format: {ext}"})
            continue

        raw = await f.read()
        if len(raw) > MAX_FILE_SIZE:
            failed.append(f.filename)
            errors.append({"file": f.filename, "reason": "File too large (max 10 MB)"})
            continue

        stored = UPLOAD_DIR / f"{uuid.uuid4()}_{f.filename}"
        stored.write_bytes(raw)

        cv_version_id = str(uuid.uuid4())

        try:
            # ── FIX: INSERT candidate using RETURNING id so we never need a
            #   follow-up SELECT that could match the wrong row.
            #   The candidates table unique constraint is on email — when email
            #   is NULL we cannot use ON CONFLICT(email), so we always INSERT
            #   a fresh row at upload time and update it after parsing.
            cand_result = await db.execute(
                text("""
                    INSERT INTO candidates
                        (id, full_name, email, current_status)
                    VALUES
                        (uuid_generate_v4(), :name, NULL, 'new')
                    RETURNING id
                """),
                {"name": f.filename},
            )
            candidate_id = str(cand_result.fetchone()[0])

            await db.execute(
                text("""
                    INSERT INTO cv_versions
                        (id, candidate_id, job_id, original_filename, stored_path,
                         file_format, file_size_bytes, file_hash, ingestion_status, uploaded_at)
                    VALUES
                        (:id, :cid, :jid, :fname, :path,
                         :fmt, :size, :hash, 'pending', NOW())
                """),
                {
                    "id":    cv_version_id,
                    "cid":   candidate_id,
                    "jid":   job_id,
                    "fname": f.filename,
                    "path":  str(stored),
                    "fmt":   ext.lstrip(".") or "unknown",
                    "size":  len(raw),
                    "hash":  str(hash(raw)),
                },
            )
            await db.commit()
            queued.append(f.filename)
            cids.append(cv_version_id)
            background_tasks.add_task(
                process_cv_pipeline, cv_version_id, job_id, str(stored), f.filename,
                candidate_id, str(hash(raw))
            )
        except Exception as e:
            await db.rollback()
            failed.append(f.filename)
            errors.append({"file": f.filename, "reason": str(e)})
            log.error("upload_failed", file=f.filename, error=str(e))

    return BulkUploadResponse(
        total_received=len(files),
        queued=len(queued),
        failed=len(failed),
        correlation_ids=cids,
        errors=errors,
    )


# =====================================================
# PIPELINE (background task)
# =====================================================
async def process_cv_pipeline(cv_version_id: str, job_id: str, file_path: str, filename: str,
                              candidate_id: str = "", file_hash: str = ""):
    """Full pipeline: ingest → validate → match/no-jd → potential → store result."""
    from database.connection import AsyncSessionLocal
    async with AsyncSessionLocal() as db:
        try:
            await db.execute(
                text("UPDATE cv_versions SET ingestion_status='processing' WHERE id=:id"),
                {"id": cv_version_id},
            )
            await db.commit()

            # ── Step 1: Ingestion ──────────────────────────────────────────────
            ingestion = IngestionAgent(db)
            try:
                ingestion_result = await ingestion.execute(
                    {"file_path": file_path, "filename": filename}, cv_version_id
                )
                # IngestionAgent returns {"parsed_cv": <fields>, "raw_text": ..., "file_hash": ...}
                # Unpack here — every downstream reference to parsed_cv must be the flat CV fields dict
                parsed_cv = ingestion_result.get("parsed_cv") or {}
                raw_text  = ingestion_result.get("raw_text", "")
                file_hash = ingestion_result.get("file_hash", file_hash)
            except Exception as e:
                log.error("ingestion_failed", cv=cv_version_id, error=str(e))
                await db.execute(
                    text("UPDATE cv_versions SET ingestion_status='failed' WHERE id=:id"),
                    {"id": cv_version_id},
                )
                await db.commit()
                return

            # ── Step 1b: Update candidate with parsed info ─────────────────────
            full_name = parsed_cv.get("full_name") or filename
            email     = parsed_cv.get("email")

            try:
                # Merge duplicate candidates by email when we now have one.
                # If another candidate already exists with this email, update
                # the cv_version to point to that existing candidate instead.
                if email:
                    existing = await db.execute(
                        text("SELECT id FROM candidates WHERE email = :email LIMIT 1"),
                        {"email": email},
                    )
                    existing_row = existing.fetchone()
                    if existing_row:
                        existing_cand_id = str(existing_row[0])
                        # Reroute cv_version to the existing candidate
                        await db.execute(
                            text("UPDATE cv_versions SET candidate_id=:cid WHERE id=:cvid"),
                            {"cid": existing_cand_id, "cvid": cv_version_id},
                        )
                        # Mark old placeholder candidate as duplicate (soft)
                        await db.execute(
                            text("""
                                DELETE FROM candidates
                                WHERE id = (
                                    SELECT candidate_id FROM cv_versions WHERE id=:cvid
                                )
                                AND email IS NULL
                            """),
                            {"cvid": cv_version_id},
                        )

                await db.execute(
                    text("""
                        UPDATE candidates
                        SET full_name = :name,
                            email     = COALESCE(email, :email),
                            last_updated_at = NOW()
                        WHERE id = (
                            SELECT candidate_id FROM cv_versions WHERE id=:cvid
                        )
                    """),
                    {"name": full_name, "email": email, "cvid": cv_version_id},
                )

                await db.execute(
                    text("""
                        UPDATE cv_versions
                        SET parsed_data      = CAST(:data AS jsonb),
                            parse_confidence = :conf,
                            ingestion_status = 'parsed',
                            processed_at     = NOW()
                        WHERE id = :id
                    """),
                    {
                        "data": json.dumps(parsed_cv),
                        "conf": parsed_cv.get("parse_confidence", 0.8),
                        "id":   cv_version_id,
                    },
                )
                await db.commit()
            except Exception as e:
                await db.rollback()
                log.error("candidate_update_failed", error=str(e))

            # ── Step 2: Validation ─────────────────────────────────────────────
            validator = ValidationAgent(db)
            try:
                await validator.execute({
                    "parsed_cv":      parsed_cv,
                    "cv_version_id":  cv_version_id,
                    "candidate_id":   candidate_id,
                    "job_id":         job_id,
                    "file_hash":      file_hash,
                    "parse_confidence": parsed_cv.get("parse_confidence", 0.8),
                    "raw_text":       raw_text,
                }, cv_version_id)
            except Exception as e:
                log.warning("validation_failed", cv=cv_version_id, error=str(e))

            # ── Step 3: Job fetch ──────────────────────────────────────────────
            jd_result = await db.execute(
                text("SELECT description_raw, requirements FROM jobs WHERE id=:id"),
                {"id": job_id},
            )
            jd_row = jd_result.fetchone()
            if not jd_row:
                log.error("job_not_found", job_id=job_id)
                await db.execute(
                    text("UPDATE cv_versions SET ingestion_status='failed' WHERE id=:id"),
                    {"id": cv_version_id},
                )
                await db.commit()
                return

            jd_text      = jd_row[0] or ""
            requirements = jd_row[1] or {}
            if isinstance(requirements, str):
                try:
                    requirements = json.loads(requirements)
                except Exception:
                    requirements = {}

            is_no_jd = bool(requirements.get("no_jd")) or not jd_text.strip()

            # ── Step 4: Matching — route to NoJDAgent or MatchingAgent ─────────
            if is_no_jd:
                log.info("routing_to_no_jd_agent", cv=cv_version_id)
                try:
                    match = await NoJDAgent(db).execute(
                        {
                            "parsed_cv":     parsed_cv,
                            "job_id":        job_id,
                            "cv_version_id": cv_version_id,
                        },
                        cv_version_id,
                    )
                except Exception as e:
                    log.error("no_jd_agent_failed", cv=cv_version_id, error=str(e))
                    await db.execute(
                        text("UPDATE cv_versions SET ingestion_status='failed' WHERE id=:id"),
                        {"id": cv_version_id},
                    )
                    await db.commit()
                    return
            else:
                log.info("routing_to_matching_agent", cv=cv_version_id)
                try:
                    match = await MatchingAgent(db).execute(
                        {
                            "parsed_cv":       parsed_cv,
                            "job_description": jd_text,
                            "requirements":    requirements,
                            "job_id":          job_id,
                            "cv_version_id":   cv_version_id,
                        },
                        cv_version_id,
                    )
                except Exception as e:
                    log.error("matching_failed", cv=cv_version_id, error=str(e))
                    await db.execute(
                        text("UPDATE cv_versions SET ingestion_status='failed' WHERE id=:id"),
                        {"id": cv_version_id},
                    )
                    await db.commit()
                    return

            log.info("matching_done", composite=match.get("composite_score"), no_jd=is_no_jd)

            # ── Step 5: Potential ──────────────────────────────────────────────
            if is_no_jd:
                # NoJDAgent already computes a potential-equivalent; reuse it
                pot = {
                    "potential_score":        match.get("potential_score", 0.5),
                    "growth_potential_label": "Generic (No JD)",
                }
            else:
                potential = PotentialAgent(db)
                try:
                    pot = await potential.run(
                        parsed_cv       = parsed_cv,
                        job_description = jd_text,
                        composite_score = match.get("composite_score", 0),
                    )
                except Exception as e:
                    log.error("potential_failed", error=str(e))
                    pot = {"potential_score": 0.5, "growth_potential_label": "Insufficient data"}

            log.info("potential_done")

            # ── Step 6: Get canonical candidate ID ────────────────────────────
            cand_result = await db.execute(
                text("SELECT candidate_id FROM cv_versions WHERE id=:id"),
                {"id": cv_version_id},
            )
            cand_row = cand_result.fetchone()
            if not cand_row:
                log.error("cv_version_missing_after_pipeline", cv=cv_version_id)
                return
            candidate_id = str(cand_row[0])

            # ── Step 7: Compute decision ───────────────────────────────────────
            composite           = match["composite_score"]
            semantic_similarity = match.get("semantic_similarity", 0)
            relevance_score     = match.get("relevance_score", 0)
            potential_score     = pot.get("potential_score", 0.5)

            if is_no_jd:
                # Never auto-shortlist without a JD — always needs human review
                decision         = match.get("decision", "needs_review")
                rejection_reason = None
            else:
                hard_filter = (match.get("score_breakdown") or {}).get("hard_filter", {})
                if hard_filter and not hard_filter.get("passed", True):
                    decision         = "auto_rejected"
                    rejection_reason = hard_filter.get("rejection_reason", "below_score_threshold")
                elif composite >= 0.65:
                    decision         = "auto_shortlisted"
                    rejection_reason = None
                elif composite < 0.35:
                    decision         = "auto_rejected"
                    rejection_reason = "below_score_threshold"
                else:
                    decision         = "needs_review"
                    rejection_reason = None

            # ── Step 8: Build score_breakdown with No-JD metadata ─────────────
            score_breakdown = match.get("score_breakdown") or {}
            if is_no_jd:
                score_breakdown["no_jd_mode"]            = True
                score_breakdown["suggested_departments"] = match.get("suggested_departments", [])
                score_breakdown["best_cluster"]          = match.get("best_cluster", "")
                score_breakdown["top_clusters"]          = match.get("top_clusters", [])
                score_breakdown["seniority_band"]        = match.get("seniority_band", "")

            skill_scores = match.get("skill_scores") or []

            # ── Step 9: Store screening result ────────────────────────────────
            screening_id = str(uuid.uuid4())
            await db.execute(
                text("""
                    INSERT INTO screenings (
                        id, cv_version_id, job_id, candidate_id,
                        semantic_similarity, relevance_score, potential_score, composite_score,
                        score_breakdown, skill_scores,
                        decision, rejection_reason,
                        strengths, gaps, transferable_skills, value_add_insights,
                        llm_rationale, ai_summary, screened_at
                    ) VALUES (
                        :sid, :cvid, :jid, :cid,
                        :sem, :rel, :pot, :comp,
                        CAST(:sb AS jsonb), CAST(:ss AS jsonb),
                        CAST(:dec AS screening_decision), :rr,
                        CAST(:str AS jsonb), CAST(:gap AS jsonb),
                        CAST(:trf AS jsonb), CAST(:vai AS jsonb),
                        :rat, :ais, NOW()
                    )
                    ON CONFLICT DO NOTHING
                """),
                {
                    "sid":  screening_id,
                    "cvid": cv_version_id,
                    "jid":  job_id,
                    "cid":  candidate_id,
                    "sem":  semantic_similarity,
                    "rel":  relevance_score,
                    "pot":  potential_score,
                    "comp": composite,
                    "sb":   json.dumps(score_breakdown),
                    "ss":   json.dumps(skill_scores),
                    "dec":  decision,
                    "rr":   rejection_reason,
                    "str":  json.dumps(match.get("strengths", [])),
                    "gap":  json.dumps(match.get("gaps", [])),
                    "trf":  json.dumps(match.get("transferable_skills", [])),
                    "vai":  json.dumps(match.get("value_add_insights", [])),
                    "rat":  match.get("llm_rationale", ""),
                    "ais":  match.get("ai_summary", ""),
                },
            )

            await db.execute(
                text("""
                    UPDATE candidates
                    SET current_status='screened', last_updated_at=NOW()
                    WHERE id=:cid
                """),
                {"cid": candidate_id},
            )
            await db.execute(
                text("UPDATE cv_versions SET ingestion_status='done', processed_at=NOW() WHERE id=:id"),
                {"id": cv_version_id},
            )
            await db.commit()

            log.info(
                "pipeline_complete",
                screening_id=screening_id,
                composite=composite,
                decision=decision,
                no_jd=is_no_jd,
            )

        except Exception as e:
            await db.rollback()
            log.error("pipeline_error", cv=cv_version_id, error=str(e), exc_info=True)
            try:
                await db.execute(
                    text("UPDATE cv_versions SET ingestion_status='failed' WHERE id=:id"),
                    {"id": cv_version_id},
                )
                await db.commit()
            except Exception:
                pass


# =====================================================
# GET SCREENING RESULTS
# =====================================================
@router.get("/results/{job_id}")
async def get_screening_results(
    job_id: str,
    min_score: float = 0.0,
    limit: int = 500,
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        text("""
            SELECT
                s.id                                                    AS screening_id,
                s.candidate_id,
                s.cv_version_id,
                s.job_id,
                s.semantic_similarity,
                s.relevance_score,
                s.potential_score,
                s.composite_score,
                s.score_breakdown,
                s.skill_scores,
                s.strengths,
                s.gaps,
                s.transferable_skills,
                s.value_add_insights,
                s.llm_rationale,
                s.ai_summary,
                s.decision,
                s.decision_by,
                s.rejection_reason,
                s.screened_at,
                c.full_name,
                c.email,
                c.phone,
                c.is_returning,
                cv.original_filename,
                cv.parse_confidence,
                cv.parsed_data,
                -- Flattened parsed_data fields
                cv.parsed_data->>'location'                             AS location,
                cv.parsed_data->>'nationality'                          AS nationality,
                cv.parsed_data->>'gender'                               AS gender,
                CAST(cv.parsed_data->>'total_years_exp' AS FLOAT)       AS years_of_experience,
                cv.parsed_data->'experience'->0->>'company'             AS current_employer,
                cv.parsed_data->'experience'->0->>'role'                AS current_designation,
                cv.parsed_data->'education'->0->>'degree'               AS degree,
                cv.parsed_data->'education'->0->>'field'                AS major,
                cv.parsed_data->>'cv_summary'                           AS cv_summary,
                cv.parsed_data->'technical_skills'                      AS technical_skills,
                cv.parsed_data->'soft_skills'                           AS soft_skills,
                cv.parsed_data->'certifications'                        AS certifications,
                -- No-JD specific fields extracted from score_breakdown
                s.score_breakdown->>'best_cluster'                      AS no_jd_best_cluster,
                s.score_breakdown->'suggested_departments'              AS no_jd_suggested_depts,
                s.score_breakdown->'top_clusters'                       AS no_jd_top_clusters,
                s.score_breakdown->>'seniority_band'                    AS no_jd_seniority_band,
                CAST(s.score_breakdown->>'no_jd_mode' AS BOOLEAN)       AS is_no_jd,
                (
                    SELECT COUNT(*) FROM anomalies a
                    WHERE a.cv_version_id = s.cv_version_id
                )                                                       AS anomaly_count
            FROM screenings s
            JOIN candidates c   ON c.id  = s.candidate_id
            JOIN cv_versions cv ON cv.id = s.cv_version_id
            WHERE s.job_id = :id
              AND s.composite_score >= :min_score
            ORDER BY s.composite_score DESC
            LIMIT :limit
        """),
        {"id": job_id, "min_score": min_score, "limit": limit},
    )

    rows = []
    for row in result.fetchall():
        d = dict(row._mapping)
        for jf in [
            "score_breakdown", "skill_scores", "strengths", "gaps",
            "transferable_skills", "value_add_insights",
            "technical_skills", "soft_skills", "certifications",
            "parsed_data",
            "no_jd_suggested_depts", "no_jd_top_clusters",
        ]:
            v = d.get(jf)
            if isinstance(v, str):
                try:
                    d[jf] = json.loads(v)
                except Exception:
                    d[jf] = [] if jf != "score_breakdown" else {}
        for lf in [
            "strengths", "gaps", "transferable_skills",
            "value_add_insights", "technical_skills", "soft_skills",
            "certifications", "no_jd_suggested_depts", "no_jd_top_clusters",
        ]:
            if not isinstance(d.get(lf), list):
                d[lf] = []
        rows.append(d)

    return rows


# =====================================================
# PIPELINE STATUS
# =====================================================
@router.get("/status/{job_id}")
async def get_pipeline_status(job_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("""
            SELECT
                COUNT(*) FILTER (WHERE ingestion_status='pending')    AS pending,
                COUNT(*) FILTER (WHERE ingestion_status='processing') AS processing,
                COUNT(*) FILTER (WHERE ingestion_status='done')       AS done,
                COUNT(*) FILTER (WHERE ingestion_status='failed')     AS failed,
                COUNT(*)                                               AS total
            FROM cv_versions WHERE job_id=:jid
        """),
        {"jid": job_id},
    )
    row = result.fetchone()
    return dict(row._mapping) if row else {}


# =====================================================
# UPDATE DECISION
# =====================================================
@router.patch("/{screening_id}/decision")
async def update_decision(
    screening_id: str,
    decision: str = Form(...),
    decision_by: str = Form(None),
    db: AsyncSession = Depends(get_db),
):
    valid_decisions = {
        "auto_shortlisted", "auto_rejected", "needs_review",
        "hr_approved", "hr_rejected", "hr_hold", "forwarded",
    }
    if decision not in valid_decisions:
        raise HTTPException(status_code=422, detail=f"Invalid decision: {decision!r}")

    result = await db.execute(
        text("SELECT id FROM screenings WHERE id=:sid"),
        {"sid": screening_id},
    )
    if not result.fetchone():
        raise HTTPException(status_code=404, detail="Screening not found")

    await db.execute(
        text("""
            UPDATE screenings
            SET decision    = CAST(:dec AS screening_decision),
                decision_by = :by,
                decision_at = NOW()
            WHERE id = :sid
        """),
        {"dec": decision, "by": decision_by, "sid": screening_id},
    )
    await db.commit()
    return {"message": "updated"}