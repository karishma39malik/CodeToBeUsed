from branding import BRAND_NAME, BRAND_ICON
import streamlit as st
import requests
import pandas as pd
import os
import time
import plotly.graph_objects as go
import sys
sys.path.insert(0, "/app/frontend")
from shared_style import CSS, topnav, sidebar_nav, page_header, sidebar_status_footer, badge_html, parse_list, initials, PLOTLY_CFG, score_color, donut, score_trend, score_dist, pool_bar, hbar, FB_BLUE, FB_GREEN, FB_ORANGE, FB_RED, FB_GREY

st.set_page_config(page_title="Candidate History · TalentScan", page_icon="📁", layout="wide")
st.markdown(CSS, unsafe_allow_html=True)

API_BASE = os.getenv("API_URL", "http://api:8000")
API      = f"{API_BASE}/api/v1"

st.markdown(topnav("Candidate History · Audit Trail"), unsafe_allow_html=True)
st.markdown(page_header("Candidate History", subtitle="Track every candidate's journey and HR decisions over time.", icon="📁"), unsafe_allow_html=True)

# ── Sidebar ───────────────────────────────────────────────────
sidebar_nav()

# ── Fetch data ─────────────────────────────────────────────────
if not jobs:
    st.markdown("""<div class="fb-card" style="text-align:center;padding:3rem;">
      <div style="font-size:2rem;margin-bottom:0.5rem;">📁</div>
      <div style="font-weight:700;margin-bottom:4px;">No jobs posted yet</div>
      <div style="font-size:0.82rem;color:#65676B;">Post a job and upload CVs to see the candidate history here.</div>
    </div>""", unsafe_allow_html=True)
    st.stop()

all_results = []
jobs_to_fetch = [j for j in jobs if selected_job_id is None or j["id"] == selected_job_id]
for job in jobs_to_fetch:
    try:
        r = requests.get(f"{API}/screenings/results/{job['id']}",
                         params={"min_score":min_score_h,"limit":500}, timeout=10).json()
        if isinstance(r, list):
            for item in r: item["_job_title"] = job["title"]
            all_results.extend(r)
    except Exception:
        pass

if decision_filter != "All":
    all_results = [r for r in all_results if r.get("decision") == decision_filter]
if search_name:
    all_results = [r for r in all_results if search_name.lower() in (r.get("full_name") or "").lower()]
all_results.sort(key=lambda x: x.get("screened_at") or "", reverse=True)

# ── Metrics ───────────────────────────────────────────────────
total     = len(all_results)
approved  = sum(1 for r in all_results if r.get("decision") in ["hr_approved","auto_shortlisted","forwarded"])
rejected  = sum(1 for r in all_results if r.get("decision") in ["hr_rejected","auto_rejected"])
returning = sum(1 for r in all_results if r.get("is_returning"))
avg_s     = (sum(r.get("composite_score",0) for r in all_results)/total) if total else 0

m1,m2,m3,m4,m5 = st.columns(5)
m1.metric("Total Records",    total)
m2.metric("Approved/Fwd",     approved)
m3.metric("Rejected",         rejected)
m4.metric("Returning",        returning)
m5.metric("Avg Score",        f"{avg_s:.0%}" if avg_s else "—")

if not all_results:
    st.markdown("""<div class="fb-card" style="text-align:center;padding:2.5rem;margin-top:1rem;">
      <div style="font-size:2rem;margin-bottom:0.5rem;">🔍</div>
      <div style="font-weight:700;margin-bottom:4px;">No records found</div>
      <div style="font-size:0.82rem;color:#65676B;">Try adjusting the filters in the sidebar.</div>
    </div>""", unsafe_allow_html=True)
    st.stop()

st.markdown('<div class="divider"></div>', unsafe_allow_html=True)

# ── Analytics charts ──────────────────────────────────────────
ch1, ch2, ch3 = st.columns(3, gap="medium")
with ch1:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Decision Distribution</div>', unsafe_allow_html=True)
    fig = donut(all_results)
    if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
    st.markdown('</div>', unsafe_allow_html=True)

with ch2:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Score Distribution</div>', unsafe_allow_html=True)
    fig = score_dist(all_results)
    if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
    st.markdown('</div>', unsafe_allow_html=True)

with ch3:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Score Timeline</div>', unsafe_allow_html=True)
    sorted_r = sorted(all_results, key=lambda x: x.get("screened_at") or "")
    fig = score_trend(sorted_r[-15:])
    if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
    st.markdown('</div>', unsafe_allow_html=True)

# Top candidates bar
st.markdown('<div class="fb-card-lg"><div class="sec-label">Top Candidates by Score</div>', unsafe_allow_html=True)
top20 = sorted(all_results, key=lambda x: x.get("composite_score",0), reverse=True)[:20]
fig = pool_bar(top20)
if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
st.markdown('</div>', unsafe_allow_html=True)

st.markdown('<div class="divider"></div>', unsafe_allow_html=True)

# ── Table + export ────────────────────────────────────────────
st.markdown(f'<div class="sec-label">Records ({total})</div>', unsafe_allow_html=True)

table = []
for r in all_results:
    email  = r.get("email") or ""
    masked = (email[:2]+"***@"+email.split("@")[-1]) if "@" in email else "—"
    score  = r.get("composite_score", 0)
    table.append({
        "Name":       r.get("full_name") or "Unknown",
        "Email":      masked,
        "Role":       r.get("_job_title","—"),
        "Score":      f"{score:.0%}",
        "Relevance":  f"{r.get('relevance_score',0):.0%}",
        "Semantic":   f"{r.get('semantic_similarity',0):.0%}",
        "Potential":  f"{r.get('potential_score',0):.0%}",
        "Decision":   (r.get("decision") or "—").replace("_"," ").title(),
        "Returning":  "Yes" if r.get("is_returning") else "No",
        "Flags":      r.get("anomaly_count", 0),
        "Screened":   (r.get("screened_at") or "")[:10],
    })

df = pd.DataFrame(table)
st.dataframe(df, use_container_width=True, hide_index=True, height=min(36*len(table)+38, 500))

ea, eb = st.columns([1,4])
with ea:
    csv = df.to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Export CSV", data=csv,
                       file_name=f"candidate_history_{int(time.time())}.csv",
                       mime="text/csv", use_container_width=True)

st.markdown('<div class="divider"></div>', unsafe_allow_html=True)

# ── Detailed candidate cards ──────────────────────────────────
st.markdown('<div class="sec-label">Candidate Detail View</div>', unsafe_allow_html=True)

for r in all_results[:30]:
    name    = r.get("full_name") or "Unknown"
    score   = r.get("composite_score", 0)
    rel     = r.get("relevance_score", 0)
    sem     = r.get("semantic_similarity", 0)
    pot     = r.get("potential_score", 0)
    dec     = r.get("decision") or "needs_review"
    date    = (r.get("screened_at") or "")[:10]
    job_ttl = r.get("_job_title","—")
    email   = r.get("email") or ""
    masked  = (email[:2]+"***@"+email.split("@")[-1]) if "@" in email else "Not extracted"
    fname   = r.get("original_filename","—")
    rationale = r.get("llm_rationale") or ""
    returning = r.get("is_returning", False)
    anoms   = r.get("anomaly_count", 0)
    ini     = initials(name)
    comp_color = score_color(score)

    with st.expander(f"{'↩ ' if returning else ''}{name}  ·  {job_ttl}  ·  {int(score*100)}%"):
        hc1, hc2 = st.columns([2, 3], gap="medium")

        with hc1:
            st.markdown(f"""<div class="fb-card">
              <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
                <div style="width:44px;height:44px;border-radius:50%;background:#1877F2;color:white;font-weight:700;font-size:0.9rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;">{ini}</div>
                <div>
                  <div style="font-weight:700;font-size:0.95rem;color:#050505;">{name}</div>
                  <div style="font-size:0.75rem;color:#65676B;">{masked}</div>
                </div>
              </div>
              <div style="font-size:0.78rem;color:#65676B;line-height:2.0;">
                <b>Role:</b> {job_ttl}<br>
                <b>File:</b> {fname}<br>
                <b>Screened:</b> {date}<br>
                <b>Flags:</b> {'⚑ '+str(anoms) if anoms else '✓ None'}
              </div>
              <div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap;">
                {badge_html(dec)}
                {"<span class='badge badge-orange'>↩ Returning</span>" if returning else ""}
              </div>
            </div>""", unsafe_allow_html=True)

        with hc2:
            # Mini score bars
            st.markdown(f"""<div class="fb-card">
              <div class="sec-label">Score Breakdown</div>
              <div style="margin:8px 0;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
                  <span style="font-size:0.78rem;font-weight:600;color:#050505;">Composite</span>
                  <span style="font-size:0.85rem;font-weight:700;color:{comp_color};">{int(score*100)}%</span>
                </div>
                <div style="height:8px;background:#F0F2F5;border-radius:4px;overflow:hidden;">
                  <div style="width:{int(score*100)}%;height:100%;background:{'linear-gradient(90deg,#42B72A,#66BB6A)' if score>=0.65 else ('linear-gradient(90deg,#F5A623,#FFB74D)' if score>=0.45 else 'linear-gradient(90deg,#FA3E3E,#EF5350)')};border-radius:4px;"></div>
                </div>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:10px;">
                <div style="text-align:center;">
                  <div style="font-size:1rem;font-weight:700;color:#1877F2;">{int(rel*100)}%</div>
                  <div style="font-size:0.65rem;color:#65676B;text-transform:uppercase;letter-spacing:0.06em;">Relevance</div>
                </div>
                <div style="text-align:center;">
                  <div style="font-size:1rem;font-weight:700;color:#42B72A;">{int(sem*100)}%</div>
                  <div style="font-size:0.65rem;color:#65676B;text-transform:uppercase;letter-spacing:0.06em;">Semantic</div>
                </div>
                <div style="text-align:center;">
                  <div style="font-size:1rem;font-weight:700;color:#F5A623;">{int(pot*100)}%</div>
                  <div style="font-size:0.65rem;color:#65676B;text-transform:uppercase;letter-spacing:0.06em;">Potential</div>
                </div>
              </div>
            </div>""", unsafe_allow_html=True)

        if rationale:
            st.markdown(f"""<div style="background:#F0F2F5;border-left:3px solid #1877F2;border-radius:0 6px 6px 0;padding:10px 14px;font-size:0.8rem;color:#050505;line-height:1.7;font-style:italic;margin-top:4px;">
              <div style="font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:#1877F2;margin-bottom:4px;">AI Rationale</div>
              {rationale[:400]}{"…" if len(rationale)>400 else ""}
            </div>""", unsafe_allow_html=True)

st.markdown('<div style="height:2rem;"></div>', unsafe_allow_html=True)
