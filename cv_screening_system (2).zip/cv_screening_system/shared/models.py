from pydantic import BaseModel, Field, field_validator
from typing import Optional, List, Dict, Any
from datetime import datetime
from uuid import UUID
from enum import Enum


class FileFormat(str, Enum):
    PDF = "pdf"
    DOCX = "docx"
    TXT = "txt"
    UNKNOWN = "unknown"


class IngestionStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    DONE = "done"
    FAILED = "failed"


class ScreeningDecision(str, Enum):
    AUTO_SHORTLISTED = "auto_shortlisted"
    AUTO_REJECTED = "auto_rejected"
    NEEDS_REVIEW = "needs_review"
    HR_APPROVED = "hr_approved"
    HR_REJECTED = "hr_rejected"
    HR_HOLD = "hr_hold"
    FORWARDED = "forwarded"


class RejectionReason(str, Enum):
    NO_MANDATORY_SKILLS = "no_alignment_with_mandatory_skills"
    WRONG_DOMAIN = "wrong_domain"
    INSUFFICIENT_EXPERIENCE = "insufficient_experience"
    KEYWORD_STUFFING = "keyword_stuffing_detected"
    ZERO_SEMANTIC_MATCH = "zero_semantic_match"
    BELOW_THRESHOLD = "below_score_threshold"


# ── CV Parsing Models ─────────────────────────────────────────

class ExperienceEntry(BaseModel):
    company: Optional[str] = None
    role: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    duration_months: Optional[int] = None
    description: Optional[str] = None
    technologies: List[str] = Field(default_factory=list)


class EducationEntry(BaseModel):
    institution: Optional[str] = None
    degree: Optional[str] = None
    field: Optional[str] = None
    graduation_year: Optional[int] = None
    grade: Optional[str] = None
    status: Optional[str] = None  # FIX-3: "completed" | "in_progress" | null


class ParsedCV(BaseModel):
    full_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    linkedin_url: Optional[str] = None
    location: Optional[str] = None
    technical_skills: List[str] = Field(default_factory=list)
    soft_skills: List[str] = Field(default_factory=list)
    domain_expertise: List[str] = Field(default_factory=list)
    certifications: List[str] = Field(default_factory=list)
    languages: List[str] = Field(default_factory=list)
    is_uae_national: Optional[bool] = None  # FIX-7: UAE nationality flag for Emiratization tracking
    experience: List[ExperienceEntry] = Field(default_factory=list)
    education: List[EducationEntry] = Field(default_factory=list)
    total_years_exp: Optional[float] = None
    cv_summary: Optional[str] = None
    parse_confidence: float = Field(ge=0.0, le=1.0, default=0.5)
    parse_warnings: List[str] = Field(default_factory=list)

    @field_validator('parse_confidence', mode='before')
    @classmethod
    def _coerce_confidence(cls, v):
        """Accept null/None from LLM — default to 0.5. Uses Pydantic v2 field_validator."""
        if v is None: return 0.5
        try: return float(v)
        except (TypeError, ValueError): return 0.5


# ── Scoring Models ────────────────────────────────────────────

class SkillScore(BaseModel):
    skill: str
    present: bool
    is_mandatory: bool
    weight: float
    score: float  # 0.0–1.0
    match_type: str  # exact, semantic, partial, none


class PenaltyRecord(BaseModel):
    penalty_type: str
    severity: float  # 0.0–1.0
    description: str
    evidence: str


class HardFilterResult(BaseModel):
    passed: bool
    rejection_reason: Optional[RejectionReason] = None
    missing_mandatory: List[str] = Field(default_factory=list)
    years_required: Optional[float] = None
    years_found: Optional[float] = None


class ScoreBreakdown(BaseModel):
    # Raw sub-scores (before weights)
    must_have_score: float = 0.0         # Mandatory skills coverage
    good_to_have_score: float = 0.0      # Nice-to-have skills coverage
    semantic_similarity: float = 0.0     # Embedding cosine similarity
    experience_score: float = 0.0        # Experience alignment
    domain_alignment: float = 0.0        # Domain/industry match

    # Penalties applied
    penalties: List[PenaltyRecord] = Field(default_factory=list)
    total_penalty: float = 0.0

    # Final weighted composite
    composite_score: float = 0.0

    # Hard filter result
    hard_filter: HardFilterResult = Field(default_factory=HardFilterResult)

    # Per-skill breakdown
    skill_scores: List[SkillScore] = Field(default_factory=list)


class ScreeningResult(BaseModel):
    candidate_id: str
    cv_version_id: str
    job_id: str

    # Score data
    score_breakdown: ScoreBreakdown
    composite_score: float = Field(ge=0.0, le=1.0)
    semantic_similarity: float = Field(ge=0.0, le=1.0)
    relevance_score: float = Field(ge=0.0, le=1.0)
    potential_score: float = Field(ge=0.0, le=1.0)

    # Decision & explainability
    decision: ScreeningDecision
    rejection_reason: Optional[str] = None
    strengths: List[str] = Field(default_factory=list)
    gaps: List[str] = Field(default_factory=list)
    risk_flags: List[str] = Field(default_factory=list)
    transferable_skills: List[str] = Field(default_factory=list)
    llm_rationale: str = ""
    ai_summary: str = ""  # Human-readable summary for HR

    screened_at: datetime = Field(default_factory=datetime.utcnow)


# ── API Request/Response Models ───────────────────────────────

class JobRequirements(BaseModel):
    mandatory_skills: List[str] = Field(default_factory=list)
    good_to_have_skills: List[str] = Field(default_factory=list)
    min_years_experience: Optional[float] = None
    domain: Optional[str] = None
    location: Optional[str] = None


class JobCreateRequest(BaseModel):
    title: str
    department: Optional[str] = None
    location: Optional[str] = None
    description: str
    requirements: Optional[JobRequirements] = None
    created_by: str


class JobResponse(BaseModel):
    id: str
    title: str
    department: Optional[str]
    description_raw: str
    requirements: Optional[Dict[str, Any]]
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class BulkUploadResponse(BaseModel):
    total_received: int
    queued: int
    failed: int
    correlation_ids: List[str]
    errors: List[Dict[str, Any]]  # Any — errors can contain bool (is_duplicate) or str


class HealthResponse(BaseModel):
    status: str
    database: bool
    ollama: bool
    version: str = "5.0.0"