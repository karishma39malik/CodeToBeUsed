"""
TalentScan — Potential Agent (Fast Heuristic Mode)
====================================================
PERFORMANCE REWRITE: Removed LLM call entirely.
The potential score is computed in microseconds using pure heuristics.
The original LLM call added ~60-90s per CV with minimal accuracy gain
over a well-tuned heuristic — the blend was 40% heuristic + 60% LLM anyway.

Scoring signals (all heuristic, zero LLM calls):
  - Career progression (ascending titles = high potential)
  - Certification breadth
  - Technical skills count
  - Education level
  - Total experience band
  - Role diversity (different companies / sectors)
"""

import re
from typing import Any, Dict, List

import structlog

from agents.base_agent import BaseAgent
from shared.utils import years_from_experience

logger = structlog.get_logger(__name__)

# Keywords that signal career ascent
SENIOR_TITLE_KEYWORDS = [
    "head", "director", "vp", "vice president", "chief", "president",
    "lead", "principal", "senior", "sr.", "manager", "svp", "evp", "cto",
    "cfo", "ceo", "coo", "partner", "gm", "general manager",
]
POSTGRAD_KEYWORDS = ["mba", "msc", "meng", "phd", "doctorate", "master", "m.s.", "m.eng"]
HIGH_VALUE_CERTS = [
    "pmp", "prince2", "cissp", "cpa", "acca", "cfa", "aws", "azure",
    "google cloud", "cism", "ceh", "six sigma", "lean", "agile", "scrum",
    "iso", "togaf", "itil",
]


class PotentialAgent(BaseAgent):
    """
    Fast heuristic-only potential scorer.
    No LLM calls — completes in < 1ms per CV.
    """

    def __init__(self, db):
        super().__init__("potential", db)

    async def run(self, parsed_cv: dict, job_description: str = "", composite_score: float = 0.0) -> Dict[str, Any]:
        """Public interface used by screening.py"""
        return await self.execute(
            {"parsed_cv": parsed_cv, "job_description": job_description, "composite_score": composite_score},
            correlation_id="",
        )

    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        parsed_cv = payload.get("parsed_cv") or payload  # support both call styles

        score = self._compute_potential(parsed_cv)

        return {
            "potential_score":        round(score, 3),
            "value_add_insights":     self._insights(parsed_cv, score),
            "career_trajectory":      self._trajectory(parsed_cv),
            "growth_potential_label": self._label(score),
        }

    # ── Core scoring ──────────────────────────────────────────────────────────

    def _compute_potential(self, cv: dict) -> float:
        score = 0.0   # FIXED: baseline was 0.40, causing blank CVs to score 40%+

        exp_list   = cv.get("experience") or []
        exp_years  = years_from_experience(exp_list) or (cv.get("total_years_exp") or 0)
        tech_skills = cv.get("technical_skills") or []
        certs       = cv.get("certifications") or []
        edu         = cv.get("education") or []

        # ── Experience band (0–0.15) ──────────────────────────────────────────
        if exp_years >= 15:   score += 0.15
        elif exp_years >= 10: score += 0.12
        elif exp_years >= 6:  score += 0.09
        elif exp_years >= 3:  score += 0.05
        else:                 score += 0.02

        # ── Career progression — ascending titles signal high potential (0–0.15)
        # FIXED: Check role field specifically (not description) to prevent
        # "customer service" matching "senior" from a different concatenated field
        roles = [str(e.get("role") or "").lower() for e in exp_list]
        senior_count = sum(1 for r in roles
                          if any(r.startswith(k) or f" {k}" in r or f"{k} " in r
                                 for k in SENIOR_TITLE_KEYWORDS))
        if len(roles) >= 2:
            later_half  = roles[len(roles)//2:]
            senior_late = sum(1 for r in later_half
                             if any(r.startswith(k) or f" {k}" in r or f"{k} " in r
                                    for k in SENIOR_TITLE_KEYWORDS))
            if senior_late > 0 and len(later_half) > 0:
                score += min(0.15, senior_late / len(later_half) * 0.15)
        score += min(0.05, senior_count * 0.02)

        # ── Skills breadth (0–0.10) ───────────────────────────────────────────
        score += min(0.10, len(tech_skills) * 0.008)

        # ── Company diversity (0–0.05) ────────────────────────────────────────
        companies = set(str(e.get("company") or "").lower() for e in exp_list if e.get("company"))
        score += min(0.05, len(companies) * 0.01)

        # ── Certifications (0–0.10) ───────────────────────────────────────────
        cert_text = " ".join(str(c).lower() for c in certs)
        high_val  = sum(1 for k in HIGH_VALUE_CERTS if k in cert_text)
        score += min(0.10, len(certs) * 0.02 + high_val * 0.03)

        # ── Education bonus (0–0.05) ──────────────────────────────────────────
        edu_text = " ".join(
            (e.get("degree") or "") + " " + (e.get("field") or "")
            for e in edu
        ).lower()
        if any(k in edu_text for k in POSTGRAD_KEYWORDS):
            score += 0.05

        return min(1.0, score)

    def _trajectory(self, cv: dict) -> str:
        exp_list = cv.get("experience") or []
        if len(exp_list) < 2:
            return "insufficient_data"
        roles = [str(e.get("role") or "").lower() for e in exp_list]
        first_half  = roles[:len(roles)//2]
        second_half = roles[len(roles)//2:]
        s1 = sum(1 for r in first_half  if any(k in r for k in SENIOR_TITLE_KEYWORDS))
        s2 = sum(1 for r in second_half if any(k in r for k in SENIOR_TITLE_KEYWORDS))
        if s2 > s1:   return "ascending"
        if s2 == s1:  return "lateral"
        return "descending"

    def _label(self, score: float) -> str:
        # FIXED: Thresholds adjusted after removing 0.40 baseline inflation
        if score >= 0.55: return "High Growth Potential"
        if score >= 0.35: return "Moderate Growth Potential"
        if score >= 0.15: return "Limited Growth Signals"
        return "Insufficient Data"

    def _insights(self, cv: dict, score: float) -> List[str]:
        insights = []
        exp_years = years_from_experience(cv.get("experience") or []) or (cv.get("total_years_exp") or 0)
        certs     = cv.get("certifications") or []
        tech      = cv.get("technical_skills") or []

        if score >= 0.70:
            insights.append("Strong career trajectory with progressive seniority.")
        elif score >= 0.50:
            insights.append("Solid mid-career profile with growth indicators.")
        else:
            insights.append("Early-stage or lateral career — monitor for development trajectory.")

        if certs:
            insights.append(f"Holds {len(certs)} certification(s): {', '.join(str(c) for c in certs[:3])}.")
        if len(tech) >= 8:
            insights.append(f"Broad technical toolkit ({len(tech)} skills) signals adaptability.")
        if exp_years >= 10:
            insights.append(f"{exp_years:.0f} years of experience — suitable for senior/lead roles.")

        return insights[:4]
