﻿import psycopg2, os
conn = psycopg2.connect(os.getenv('DATABASE_URL'))
cur = conn.cursor()
cur.execute("SELECT raw_text FROM cv_versions LIMIT 1")
row = cur.fetchone()
print(repr(row[0][:2000]) if row else "No data")
