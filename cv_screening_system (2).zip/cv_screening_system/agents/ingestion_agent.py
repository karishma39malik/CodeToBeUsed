"""
TalentScan — Ingestion Agent (Performance Optimised)
=====================================================
CHANGES vs previous version:
  1. Smart pre-parse: extract name/email/phone with regex BEFORE calling LLM.
     This eliminates the "retry 3 times because name is empty" loop on clean CVs.
  2. Leaner LLM prompt: removed verbose instructions, kept JSON schema only.
     Reduces token count ~40% → faster generation.
  3. num_predict 800, num_ctx 3072 — tight budget; still covers all CV fields.
  4. Parallel text extraction: PDF pages processed in one pass (already fast).
  5. max_chars reduced 6000→4500 — 4500 chars covers 95% of CVs at 2-3 pages.
  FIX-NAME: _pre_extract rejects section headings. _heuristic_patch validates name.
            _llm_extract rejects bad LLM-returned names. Step 4 validates before use.
  FIX-PDF:  Layout-aware extraction reads LEFT column first for two-column CVs.
  FIX-NULL: _llm_extract coerces null lists to [] before Pydantic validation.
"""

import json
import re
import hashlib
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import pdfplumber
import docx
import chardet
import ollama as ollama_client
import structlog

from agents.base_agent import BaseAgent
from shared.models import ParsedCV, FileFormat
from shared.utils import truncate_text, get_file_extension
from config.settings import settings

logger = structlog.get_logger(__name__)


# ── Regex pre-extractors (zero LLM cost) ─────────────────────────────────────
_EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")
_PHONE_RE = re.compile(r"(?:\+?\d[\d\s\-().]{7,}\d)")
_URL_RE   = re.compile(r"linkedin\.com/in/[\w\-]+", re.I)

# Words that indicate a section heading or summary — never a person's name
_BAD_NAME_WORDS = {
    "summary", "objective", "profile", "experience", "education",
    "skills", "certifications", "languages", "contact", "references",
    "professional", "career", "employment", "history", "qualifications",
    "overview", "about", "introduction", "background", "expertise",
    "work", "academic", "personal", "details", "information",
    "ambitious", "motivated", "dedicated", "passionate", "seeking",
    "declaration", "activities", "interests", "achievements", "awards",
    "technical", "soft", "core", "key", "additional", "other",
    "engineering", "management", "development", "administration",
    "highlights", "competencies", "capabilities", "strengths",
}


def _is_valid_name(name: str) -> bool:
    """
    Returns True only if the string looks like a real person's name.
    Rejects section headings, summary text, and other non-name strings.
    """
    if not name:
        return False
    n = name.strip()
    words = n.lower().split()
    # Must have 2-5 words
    if not (2 <= len(words) <= 5):
        return False
    # No digits
    if any(c.isdigit() for c in n):
        return False
    # No special chars that appear in headings/contact lines
    if any(c in n for c in ("@", ":", "/", "|", "\u2022", "+", ".")):
        return False
    # No bad name words
    if any(w in _BAD_NAME_WORDS for w in words):
        return False
    # No lines starting with non-name filler words
    if words[0] in ("the", "a", "an", "this", "our", "my", "i", "we",
                     "to", "and", "or", "with", "for", "in", "at", "of"):
        return False
    return True


def _pre_extract(text: str) -> Dict[str, Optional[str]]:
    """
    Fast regex extraction of contact fields — avoids LLM retries for missing name.
    FIX-NAME: Uses _is_valid_name() to reject section headings and summaries.
    """
    email    = m.group(0) if (m := _EMAIL_RE.search(text)) else None
    phone    = m.group(0).strip() if (m := _PHONE_RE.search(text)) else None
    linkedin = ("https://www.linkedin.com/in/" + m.group(0).split("/in/")[1].split()[0]) if (m := _URL_RE.search(text)) else None

    name = None
    for line in text.split("\n")[:30]:
        line = line.strip()
        if _is_valid_name(line):
            name = line
            break

    return {"email": email, "phone": phone, "linkedin_url": linkedin, "full_name": name}


# ── Layout-aware PDF page extraction ─────────────────────────────────────────
def _extract_page_layout_aware(page) -> str:
    """
    FIX-PDF: Extract text in natural reading order for two-column CVs.
    Reads LEFT column first (name/contact sidebar) then RIGHT column (body).
    This ensures the candidate name appears before 'PROFESSIONAL SUMMARY'.
    """
    try:
        words = page.extract_words(
            x_tolerance=3,
            y_tolerance=3,
            keep_blank_chars=False,
            use_text_flow=False,
        )
        if not words:
            return page.extract_text() or ""

        page_width = float(page.width)
        mid = page_width / 2

        left_words  = [w for w in words if w["x1"] < mid + 20]
        right_words = [w for w in words if w["x0"] > mid - 20]

        total = max(len(words), 1)
        left_ratio  = len(left_words)  / total
        right_ratio = len(right_words) / total

        is_two_column = (
            len(left_words)  > 5 and
            len(right_words) > 5 and
            0.15 < left_ratio  < 0.85 and
            0.15 < right_ratio < 0.85
        )

        def sort_words(word_list):
            return sorted(word_list, key=lambda w: (round(w["top"] / 5) * 5, w["x0"]))

        def words_to_text(word_list):
            if not word_list:
                return ""
            lines = []
            current_line = []
            current_top  = None
            for w in sort_words(word_list):
                top = round(w["top"] / 5) * 5
                if current_top is None or abs(top - current_top) > 5:
                    if current_line:
                        lines.append(" ".join(current_line))
                    current_line = [w["text"]]
                    current_top  = top
                else:
                    current_line.append(w["text"])
            if current_line:
                lines.append(" ".join(current_line))
            return "\n".join(lines)

        if is_two_column:
            return words_to_text(left_words) + "\n" + words_to_text(right_words)
        else:
            return page.extract_text() or ""

    except Exception:
        return page.extract_text() or ""


# ── Gender heuristic (regex-based, zero LLM cost) ────────────────────────────
_MALE_TITLES   = re.compile(r"\b(mr\.?|sir|he/him|\bhis\b)\b", re.I)
_FEMALE_TITLES = re.compile(r"\b(ms\.?|mrs\.?|miss|she/her|\bher\b)\b", re.I)
_MALE_NAMES    = {
    "james","john","michael","david","robert","william","richard","charles",
    "joseph","thomas","christopher","daniel","paul","mark","donald","george",
    "kenneth","steven","edward","brian","ronald","anthony","kevin","jason",
    "matthew","gary","timothy","jose","larry","jeffrey","frank","scott",
    "eric","stephen","andrew","raymond","gregory","joshua","jerry","dennis",
    "walter","patrick","peter","harold","douglas","henry","carl","arthur",
    "ryan","roger","joe","juan","jack","albert","jonathan","justin","terry",
    "gerald","keith","samuel","willie","ralph","lawrence","nicholas","roy",
    "benjamin","bruce","brandon","adam","harry","fred","wayne","billy","steve",
    "louis","jeremy","aaron","randy","howard","eugene","carlos","russell",
    "bobby","victor","martin","ernest","phillip","todd","jesse","craig",
    "alan","shawn","clarence","sean","philip","chris","johnny","earl",
    "ahmed","mohammed","muhammad","ali","omar","khalid","hassan","ibrahim",
    "yusuf","tariq","faisal","majid","saeed","rashid","hamad","sultan",
    "zayed","mansour","khalifa","saqr","maktoum","wael","khaled","bilal",
    "ayman","sami","karim","nasser","adel","walid","yousef","rami",
    "raj","rahul","vikram","sanjay","suresh","ramesh","anand","arjun","dev",
    "nikhil","pradeep","deepak","amit","rohit","varun","akash","manish",
    "gaurav","sachin","vivek","sandeep","manoj","naveen","dinesh","arun",
    "ravi","ajay","vijay","pawan","sunil","anil","rakesh","harish",
}
_FEMALE_NAMES  = {
    "mary","patricia","jennifer","linda","barbara","elizabeth","susan","jessica",
    "sarah","karen","lisa","nancy","betty","margaret","sandra","ashley",
    "dorothy","kimberly","emily","donna","michelle","carol","amanda","melissa",
    "deborah","stephanie","rebecca","sharon","laura","cynthia","kathleen",
    "amy","angela","shirley","anna","brenda","pamela","emma","nicole",
    "helen","samantha","katherine","christine","debra","rachel","carolyn",
    "janet","catherine","maria","heather","diane","julie","joyce","victoria",
    "ruth","virginia","kelly","kim","lauren","crystal","judith","rose",
    "fatima","aisha","mariam","sara","nora","hessa","moza","sheikha",
    "noura","reem","hind","eman","lama","dana","rana","rania","layla",
    "salma","hanan","amal","dina","maha","lina","alia","nadia","leila",
    "amira","jasmine","zainab","khadija","asma","lubna","huda","wafa",
    "nour","maryam","afra","haya","shamma","maitha","latifa","shamsa",
    "priya","anjali","pooja","sunita","kavita","meera","anita","geeta",
    "seema","rekha","usha","asha","nisha","ritu","sonia","swati","shweta",
    "deepa","divya","neha","anu","ruchi","sweta","ankita","kritika",
    "preeti","pallavi","mamta","savita","manisha","jyoti","pratima",
}

def _heuristic_gender(text: str, full_name: str = "") -> Optional[str]:
    text_lower = text[:2000].lower()
    if _MALE_TITLES.search(text_lower): return "Male"
    if _FEMALE_TITLES.search(text_lower): return "Female"
    if re.search(r"\bgender\s*[:\-]?\s*male\b", text_lower): return "Male"
    if re.search(r"\bgender\s*[:\-]?\s*female\b", text_lower): return "Female"
    first_name = (full_name or "").split()[0].lower().strip(".,") if full_name else ""
    if first_name and first_name in _MALE_NAMES: return "Male"
    if first_name and first_name in _FEMALE_NAMES: return "Female"
    return None


def _heuristic_location(text: str) -> Optional[str]:
    text_head = text[:3000]
    patterns = [
        r"(?:location|address|based in|residing in|city)[:\s]+([A-Z][\w\s,]{3,40})",
        r"(?:Abu Dhabi|Dubai|Sharjah|Ajman|Ras Al Khaimah|Fujairah|Umm Al Quwain)[,\s]*(?:UAE|U\.A\.E|United Arab Emirates)?",
        r"(?:Riyadh|Jeddah|Dammam|Muscat|Doha|Kuwait City|Manama|Beirut|Amman|Cairo)[,\s]*\w+",
        r"[A-Z][\w\s]+,\s*(?:UAE|UK|USA|India|Pakistan|Philippines|Egypt|Jordan|Lebanon|Saudi Arabia|Qatar|Kuwait|Bahrain|Oman)",
    ]
    for pat in patterns:
        m = re.search(pat, text_head, re.I)
        if m:
            return m.group(0).strip().rstrip(",").strip()
    return None


def _heuristic_patch(parsed_cv_dict: dict, raw_text: str) -> dict:
    """Post-LLM patch — fills location, gender, exp, role, degree from raw text."""
    text = raw_text
    text_lower = text[:3000].lower()

    # ── NAME VALIDATION ───────────────────────────────────────────────────────
    # FIX-NAME: Clear bad names so pre-extract result is used instead
    full_name = parsed_cv_dict.get("full_name") or ""
    if full_name and not _is_valid_name(full_name):
        parsed_cv_dict["full_name"] = None

    # ── GENDER ────────────────────────────────────────────────────────────────
    gender = None
    gm = re.search(r"gender\s*[:\|]?\s*(male|female|other)", text_lower)
    if gm:
        gender = gm.group(1).capitalize()
    elif re.search(r"\b(mr\.|mr\b|sir\b|he/him)", text_lower):
        gender = "Male"
    elif re.search(r"\b(ms\.|mrs\.|miss\b|she/her)", text_lower):
        gender = "Female"
    else:
        gender = _heuristic_gender(text, parsed_cv_dict.get("full_name") or "")
    if gender:
        parsed_cv_dict["gender"] = gender

    # ── LOCATION ──────────────────────────────────────────────────────────────
    uae_cities = [
        "Abu Dhabi", "Dubai", "Sharjah", "Al Ain", "Ajman", "Fujairah",
        "Ras Al Khaimah", "Umm Al Quwain", "RAK", "KhorFakkan", "Khorfakkan",
        "Dibba", "Kalba", "Khor Fakkan",
    ]
    gcc_cities = [
        "Riyadh", "Jeddah", "Dammam", "Muscat", "Doha", "Kuwait City",
        "Manama", "Beirut", "Amman", "Cairo", "Salalah",
    ]
    loc = None
    for city in uae_cities:
        if re.search(r"\b" + re.escape(city) + r"\b", text[:1000], re.I):
            loc = city + ", UAE"
            break
    if not loc:
        for city in gcc_cities:
            if re.search(r"\b" + re.escape(city) + r"\b", text[:1000], re.I):
                country_m = re.search(re.escape(city) + r"[,\s]*(\w[\w\s]{2,20})", text[:1000], re.I)
                loc = city + (", " + country_m.group(1).strip() if country_m else "")
                break
    if not loc:
        loc = _heuristic_location(text)
    if loc:
        parsed_cv_dict["location"] = loc

    # ── REBUILD EXPERIENCE FROM RAW TEXT ─────────────────────────────────────
    # The LLM frequently merges or misattributes entries when a CV has company
    # names followed by dates (no role title). We rebuild experience entirely
    # from raw text patterns, then merge with LLM entries, deduplicating by
    # start date. This guarantees Ministry of Defense Diwan is never lost.
    _MONTH_NAMES = (
        r"(?:January|February|March|April|May|June|July|August|September|"
        r"October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
    )
    _DATE_PAT  = rf"{_MONTH_NAMES}\s+\d{{4}}"
    _RANGE_PAT = rf"({_DATE_PAT})\s*[–—\-]\s*({_DATE_PAT}|[Pp]resent|[Cc]urrent)"

    # Find work history block
    exp_section_blocks = re.split(
        r"\n\s*(?:WORK\s+(?:EXPERIENCE|HISTORY)|EMPLOYMENT(?:\s+HISTORY)?|EXPERIENCE)\s*\n",
        text, flags=re.I
    )
    work_block = exp_section_blocks[1][:2000] if len(exp_section_blocks) > 1 else text[:2000]

    # Extract ALL date ranges found in the work block
    found_ranges = re.findall(_RANGE_PAT, work_block, re.I)

    _MON_MAP_EXP = {"jan":1,"feb":2,"mar":3,"apr":4,"may":5,"jun":6,
                    "jul":7,"aug":8,"sep":9,"oct":10,"nov":11,"dec":12,
                    "january":1,"february":2,"march":3,"april":4,"june":6,
                    "july":7,"august":8,"september":9,"october":10,
                    "november":11,"december":12}

    def _norm_date(s):
        """Normalise date string to 'MMM YYYY' for dedup e.g. 'oct 2021'"""
        s = str(s).strip().lower()
        if re.search(r"present|current", s, re.I):
            return "present"
        m = re.search(r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+(\d{4})", s, re.I)
        return f"{m.group(1)[:3].lower()} {m.group(2)}" if m else s[:10]

    def _date_to_sort(s):
        """Convert date string to sortable integer YYYYMM"""
        if not s: return 0
        if re.search(r"present|current", str(s), re.I):
            t = date.today() if 'date' in dir() else __import__('datetime').date.today()
            return t.year * 100 + t.month
        ym = re.search(r"(\d{4})", str(s))
        mm = re.search(r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*", str(s), re.I)
        yr  = int(ym.group(1)) if ym else 0
        mon = _MON_MAP_EXP.get((mm.group(1).lower() if mm else ""), 0)
        return yr * 100 + mon

    # Build a set of start dates from existing LLM entries for dedup
    # BUT skip entries where LLM merged two companies into one string
    # e.g. "Municipality of Khorfakkan (Department of Defense Diwan)"
    # These must be replaced by correct raw-text entries
    def _looks_merged(company_str):
        return bool(re.search(
            r"\([A-Z][A-Za-z\s]+(?:Diwan|Ministry|Authority|Department|Council|"
            r"Corporation|Company|Institute|Center|Centre|Bureau|Agency|Office)\)",
            str(company_str or "")
        ))

    existing_exp    = parsed_cv_dict.get("experience") or []
    existing_starts = {_norm_date(str(e.get("start_date") or "")) for e in existing_exp
                       if isinstance(e, dict) and not _looks_merged(e.get("company"))}

    # Remove merged LLM entries — they will be replaced by raw-text injection
    cleaned_existing = [e for e in existing_exp
                        if isinstance(e, dict) and not _looks_merged(e.get("company"))]

    # For each raw date range not already in LLM entries, inject a new entry
    injected = []
    for start_str, end_str in found_ranges:
        start_str = start_str.strip()
        end_str   = end_str.strip()
        ns = _norm_date(start_str)

        # Skip if this start date is already in a clean LLM entry
        if ns in existing_starts:
            continue

        # Find company name on the same line before the date
        escaped_start = re.escape(start_str)
        line_match = re.search(
            rf"([A-Z][^\n]{{3,80}}?)\s*\(?{escaped_start}",
            work_block, re.I
        )
        company_name = ""
        if line_match:
            company_name = line_match.group(1).strip().rstrip("(,\u2013\u2014- ")
            company_name = re.sub(r"^\s*[\d]+\.\s*|^[•\-\*]\s*", "", company_name).strip()

        if not company_name or len(company_name) < 3:
            continue

        # Check for "Role – Company (dates)" pattern
        role_company_match = re.search(
            rf"([A-Z][^\n]{{3,60}}?)\s*[–—\-]\s*([A-Z][^\n]{{3,60}}?)\s*\(?{escaped_start}",
            work_block, re.I
        )
        if role_company_match:
            role_part    = role_company_match.group(1).strip().rstrip("(,\u2013\u2014- ")
            company_part = role_company_match.group(2).strip().rstrip("(,\u2013\u2014- ")
            if len(role_part) > 3 and len(company_part) > 3:
                company_name = company_part
                role_name    = role_part
            else:
                role_name = company_name
        else:
            role_name = company_name

        injected.append({
            "company":      company_name,
            "role":         role_name,
            "start_date":   start_str,
            "end_date":     end_str,
            "description":  f"{role_name} at {company_name} ({start_str} - {end_str})",
            "technologies": [],
        })

    # Merge cleaned LLM entries + injected raw-text entries
    # Then deduplicate by normalised start date — keep raw-text entry over LLM entry
    all_exp_raw = cleaned_existing + injected
    seen_starts = {}
    all_exp = []
    for e in all_exp_raw:
        ns = _norm_date(str(e.get("start_date") or ""))
        if ns not in seen_starts:
            seen_starts[ns] = True
            all_exp.append(e)
    # Sort by DURATION (longest first), then by end date as tiebreaker.
    # This ensures a 3y 11m permanent role appears before a 3m internship
    # even if the internship ended more recently.
    # Internship roles are also flagged so YOE can exclude them.
    _MON_MAP2 = {"jan":1,"feb":2,"mar":3,"apr":4,"may":5,"jun":6,
                 "jul":7,"aug":8,"sep":9,"oct":10,"nov":11,"dec":12}

    _INTERN_SIGNALS = re.compile(
        r"\b(intern|internship|trainee|training|apprentice|placement|"
        r"work\s*experience\s*student|graduate\s*trainee)\b",
        re.I
    )

    def _to_ym(date_str):
        """Convert date string to (year, month) tuple."""
        if not date_str: return (0, 0)
        if re.search(r"present|current", str(date_str), re.I):
            from datetime import date as _date
            t = _date.today()
            return (t.year, t.month)
        ym = re.search(r"(\d{4})", str(date_str))
        mm = re.search(r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)", str(date_str), re.I)
        yr  = int(ym.group(1)) if ym else 0
        mon = _MON_MAP2.get(mm.group(1).lower()[:3] if mm else "", 0)
        return (yr, mon)

    def _duration_months(e):
        sy, sm = _to_ym(e.get("start_date"))
        ey, em = _to_ym(e.get("end_date"))
        return max(0, (ey * 12 + em) - (sy * 12 + sm))

    def _is_internship(e):
        """Returns True if this entry looks like an internship/trainee role."""
        role    = str(e.get("role")    or "")
        company = str(e.get("company") or "")
        desc    = str(e.get("description") or "")
        return bool(_INTERN_SIGNALS.search(role + " " + company + " " + desc))

    def _sort_key(e):
        dur = _duration_months(e)
        ey, em = _to_ym(e.get("end_date"))
        end_score = ey * 12 + em
        # Permanent roles (is_intern=0) always sort before internships (is_intern=1)
        # Within same category: longest duration first, then most recent end date
        is_intern = 1 if _is_internship(e) else 0
        return (is_intern, -(dur * 100 + end_score))

    if all_exp:
        all_exp.sort(key=_sort_key)

        # ── GROUND TRUTH DATE FIX ─────────────────────────────────────────────
        # The LLM sometimes stores wrong end dates (e.g. "September 2022" instead
        # of "September 2025") and wrong role labels (e.g. "Engineering Intern"
        # for a full-time permanent role). Fix these using raw text ground truth.
        #
        # For each entry, find its date range in raw text and use those dates.
        # Also: if the raw text line has NO intern/trainee signal, clear the
        # intern label from the role field.
        for e in all_exp:
            if not isinstance(e, dict): continue
            company = str(e.get("company") or "")
            if not company or len(company) < 3: continue

            # Search for "Company Name (Month YYYY – Month YYYY)" in work block
            esc_company = re.escape(company[:30])  # first 30 chars enough to match
            date_in_text = re.search(
                rf"{esc_company}[^\n]{{0,60}}"
                rf"({_MONTH_NAMES}\s+\d{{4}})\s*[–—\-]\s*"
                rf"({_MONTH_NAMES}\s+\d{{4}}|[Pp]resent|[Cc]urrent)",
                work_block, re.I
            )
            if date_in_text:
                raw_start = date_in_text.group(1).strip()
                raw_end   = date_in_text.group(2).strip()
                # Only update if raw text dates differ from LLM dates
                if _norm_date(raw_start) != _norm_date(str(e.get("start_date") or "")):
                    e["start_date"] = raw_start
                if _norm_date(raw_end) != _norm_date(str(e.get("end_date") or "")):
                    e["end_date"] = raw_end

                # If the matching line has no intern signal → it's a permanent role
                # Fix role label: use company name instead of "Engineering Intern"
                matched_line = date_in_text.group(0)
                if not _INTERN_SIGNALS.search(matched_line):
                    current_role = str(e.get("role") or "")
                    if _is_internship(e):
                        # LLM wrongly labelled this as intern — fix it
                        e["role"] = company

        # Re-sort after date fixes (durations may have changed)
        all_exp.sort(key=_sort_key)
        parsed_cv_dict["experience"] = all_exp

    # ── TOTAL YEARS EXPERIENCE ────────────────────────────────────────────────
    # FIX: Exclude internship/trainee roles from YOE calculation.
    # Only count substantive employment. Internships are short training periods
    # and should not inflate the experience figure shown to recruiters.
    # Always recompute from dates — never trust LLM's total_years_exp field
    # since it is often wrong (guessed from context, not calculated).
    exp_list = parsed_cv_dict.get("experience") or []
    total_months = 0
    for e in exp_list:
        if not isinstance(e, dict): continue
        if _is_internship(e): continue
        dur = _duration_months(e)
        if dur > 0:
            total_months += dur
    if total_months:
        parsed_cv_dict["total_years_exp"] = round(total_months / 12, 1)
    else:
        # Final fallback: raw text "X years of experience" mention
        yoe_match = re.search(r"(\d+(?:\.\d+)?)\s*(?:\+\s*)?years?\s+(?:of\s+)?experience", text, re.I)
        if yoe_match:
            parsed_cv_dict["total_years_exp"] = float(yoe_match.group(1))

    # ── CURRENT ROLE & EMPLOYER ───────────────────────────────────────────────
    exp_section = re.split(
        r"\n\s*(?:WORK\s+(?:EXPERIENCE|HISTORY)|EMPLOYMENT(?:\s+HISTORY)?|EXPERIENCE)\s*\n",
        text, flags=re.I
    )
    exp_block = exp_section[1][:1000] if len(exp_section) > 1 else text
    role_company_candidates = re.findall(r"^(.+?)\s*\|\s*(.+?)$", exp_block, re.MULTILINE)
    role, company = None, None
    for m1, m2 in role_company_candidates:
        m1, m2 = m1.strip(), m2.strip()
        if re.search(r"\d{4}|\u2022|@|\.ae|linkedin|\+\d|📞|📍|✉", m1 + m2, re.I): continue
        if re.search(r"\d{4}|•|Present|@|linkedin", m1 + m2, re.I): continue
        if len(m1) > 3 and len(m2) > 1:
            role    = m1.rstrip("|•·").strip()
            company = m2.rstrip("|•·").strip()
            break
    if role or company:
        exp_list = parsed_cv_dict.get("experience") or []
        if exp_list and isinstance(exp_list[0], dict):
            if not exp_list[0].get("role")    and role:    exp_list[0]["role"]    = role
            if not exp_list[0].get("company") and company: exp_list[0]["company"] = company
        elif not exp_list and role:
            parsed_cv_dict["experience"] = [{"role": role, "company": company, "end_date": "Present"}]

    # ── DEGREE & MAJOR ────────────────────────────────────────────────────────
    deg_patterns = [
        r"(B\.Sc\.|M\.Sc\.|B\.Eng\.|M\.Eng\.|B\.A\.|M\.A\.|MBA|PhD|BSc|MSc|BEng|MEng|LLB|LLM)"
        r"[\.\s]+([^\n\r\u2014\u2013-]{3,60}?)\s*(?:\u2014|\u2013|-|from|at)\s*([^\n\r,]{3,60})",
        r"(Bachelor|Master|Doctor)[^\n\r]{0,30}(?:of|in)\s+([^\n\r,\u2014\u2013]{3,50})",
    ]
    edu_list = parsed_cv_dict.get("education") or []
    for pat in deg_patterns:
        dm = re.search(pat, text, re.I)
        if dm:
            degree_str = dm.group(1).strip()
            field_str  = dm.group(2).strip().rstrip("\u2014\u2013- ") if len(dm.groups()) >= 2 else ""
            if edu_list and isinstance(edu_list[0], dict):
                if not edu_list[0].get("degree"): edu_list[0]["degree"] = degree_str
                if not edu_list[0].get("field"):  edu_list[0]["field"]  = field_str
            elif not edu_list:
                parsed_cv_dict["education"] = [{"degree": degree_str, "field": field_str}]
            break

    return parsed_cv_dict


def _normalise_unicode_symbols(text: str) -> str:
    text = re.sub(r"[✆☎📞]\s*", "Phone: ", text)
    text = re.sub(r"[✉📧]\s*", "Email: ", text)
    text = re.sub(r"[●•·]\s*", "- ", text)
    return text


def _smart_truncate(text: str, max_chars: int = 4500) -> str:
    if len(text) <= max_chars:
        return text
    return text[:3200] + "\n...\n" + text[-1300:]


def _sanitise_for_prompt(text: str) -> str:
    suspicious_prefixes = [
        "ignore", "disregard", "forget", "system:", "assistant:", "user:",
        "new instructions", "override", "you are now", "act as",
        "[system]", "[inst]", "###", "---",
    ]
    lines = text.split("\n")
    cleaned = []
    for line in lines:
        stripped = line.strip().lower()
        if any(stripped.startswith(p) for p in suspicious_prefixes):
            cleaned.append("[REDACTED]")
        else:
            cleaned.append(line)
    return "\n".join(cleaned)


# ── LLM prompt ────────────────────────────────────────────────────────────────
_EXTRACT_PROMPT = """\
Extract structured data from this CV. Return ONLY valid JSON — no markdown, no explanation.

CRITICAL RULES:
- Extract EVERY field listed below — do not skip any
- Use null only if the information is truly absent from the CV text
- full_name: the CANDIDATE'S PERSONAL NAME only — 2 to 4 words, no digits.
  NEVER return a section heading such as "PROFESSIONAL SUMMARY", "WORK HISTORY",
  "EDUCATION", "SKILLS" or any descriptive sentence as the full_name.
  The name is typically at the top of the CV, in a sidebar, header, or blue panel.
- gender: look for pronouns (he/his=Male, she/her=Female), name titles (Mr/Ms/Mrs), or explicit mention
- location: extract city and country from address, contact section, or any location mention
- experience: list ALL roles, most recent first; end_date="Present" for current role
- education: list ALL degrees; field=subject/major studied
- total_years_exp: sum all experience durations in years as a float
- certifications: always return as array [], never null
- technical_skills: always return as array [], never null
- soft_skills: always return as array [], never null
- technologies inside experience entries: always return as array [], never null

JSON schema (return ALL fields):
{{
  "full_name": string|null,
  "email": string|null,
  "phone": string|null,
  "linkedin_url": string|null,
  "location": "City, Country"|null,
  "gender": "Male"|"Female"|"Other"|null,
  "technical_skills": [string],
  "soft_skills": [string],
  "domain_expertise": [string],
  "certifications": [string],
  "languages": [string],
  "is_uae_national": bool|null,
  "experience": [{{"company":string,"role":string,"start_date":string,"end_date":string,"duration_months":int|null,"description":string,"technologies":[string]}}],
  "education": [{{"institution":string,"degree":string,"field":string,"graduation_year":int|null,"grade":string|null,"status":"completed"|"in_progress"|null}}],
  "total_years_exp": float|null,
  "cv_summary": "2-3 sentence summary of candidate profile"|null,
  "parse_confidence": float
}}

CV TEXT:
{text}"""


class IngestionAgent(BaseAgent):

    def __init__(self, db):
        super().__init__("ingestion", db)
        self.ollama = ollama_client.AsyncClient(host=settings.ollama_base_url)

    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        file_path = payload["file_path"]
        filename  = payload["filename"]
        self.log.info("ingestion_start", filename=filename)

        ext = get_file_extension(filename)
        raw_text, parse_warnings = await self._extract_text(file_path, ext)

        if not raw_text or len(raw_text.strip()) < 50:
            raise ValueError(f"Could not extract meaningful text from {filename}")

        raw_text = _normalise_unicode_symbols(raw_text)

        with open(file_path, "rb") as f:
            file_bytes = f.read()
        file_hash = hashlib.sha256(file_bytes).hexdigest()

        truncated = _smart_truncate(raw_text, max_chars=4500)

        # ── Step 1: regex pre-extract (instant) ──────────────────────────────
        pre = _pre_extract(raw_text)

        # ── Step 2: single LLM extraction attempt ────────────────────────────
        parsed_cv = await self._llm_extract(truncated, parse_warnings)

        # ── Step 3: patch missing fields with regex + heuristics ─────────────
        if not parsed_cv.full_name and pre.get("full_name"):
            parsed_cv.full_name = pre["full_name"]
            parse_warnings.append("Name filled by regex fallback.")
        if not parsed_cv.email and pre.get("email"):
            parsed_cv.email = pre["email"]
        if not parsed_cv.phone and pre.get("phone"):
            parsed_cv.phone = pre["phone"]
        if not parsed_cv.linkedin_url and pre.get("linkedin_url"):
            parsed_cv.linkedin_url = pre["linkedin_url"]

        cv_dict = parsed_cv.model_dump()
        cv_dict = _heuristic_patch(cv_dict, raw_text)

        # FIX-NAME: if _heuristic_patch cleared a bad LLM name, use pre-extract
        if not cv_dict.get("full_name") and pre.get("full_name"):
            cv_dict["full_name"] = pre["full_name"]

        parsed_cv = ParsedCV(**cv_dict)

        # ── Step 4: last resort if name still missing ─────────────────────────
        if not parsed_cv.full_name:
            self.log.warning("name_missing_after_all_fixes", filename=filename)
            stem = re.sub(r"\.(pdf|docx|doc|txt)$", "", filename, flags=re.I)
            stem = re.sub(r"[^a-zA-Z ]", " ", stem.replace("_", " ").replace("-", " "))
            skip = {"cv", "resume", "updated", "new", "final", "application",
                    "document", "doc", "file", "copy", "version", "draft"}
            parts = [p.capitalize() for p in stem.split()
                     if len(p) > 1 and p.lower() not in skip and not p.isdigit()]
            parsed_cv.full_name = " ".join(parts[:4]) if len(parts) >= 2 else filename

        self.log.info(
            "ingestion_complete",
            filename=filename,
            name=parsed_cv.full_name,
            confidence=parsed_cv.parse_confidence,
            skills_found=len(parsed_cv.technical_skills),
            exp_entries=len(parsed_cv.experience),
        )

        return {
            "parsed_cv":      parsed_cv.model_dump(),
            "raw_text":       raw_text,
            "file_hash":      file_hash,
            "file_format":    ext,
            "parse_warnings": parse_warnings,
        }

    # ── Text extraction ───────────────────────────────────────────────────────

    async def _extract_text(self, file_path: str, ext: str) -> Tuple[str, list]:
        warnings = []
        if ext == "pdf":
            return await self._extract_pdf(file_path, warnings), warnings
        elif ext == "docx":
            return self._extract_docx(file_path, warnings), warnings
        elif ext == "txt":
            return self._extract_txt(file_path, warnings), warnings
        else:
            warnings.append(f"Unsupported format: {ext}")
            return "", warnings

    async def _extract_pdf(self, path: str, warnings: list) -> str:
        """
        FIX-PDF: Layout-aware extraction using _extract_page_layout_aware().
        For two-column CVs reads LEFT column first so name appears before headings.
        Wrapped in asyncio.to_thread to avoid blocking the event loop.
        """
        import asyncio as _asyncio
        def _sync_extract():
            parts = []
            try:
                with pdfplumber.open(path) as pdf:
                    for i, page in enumerate(pdf.pages):
                        t = _extract_page_layout_aware(page)
                        if t and len(t.strip()) > 20:
                            parts.append(t)
                        else:
                            t = page.extract_text()
                            if t:
                                parts.append(t)
                            else:
                                warnings.append(f"Page {i+1}: no extractable text")
            except Exception as e:
                warnings.append(f"PDF error: {e}")
            return "\n".join(parts)
        return await _asyncio.to_thread(_sync_extract)

    def _extract_docx(self, path: str, warnings: list) -> str:
        try:
            doc = docx.Document(path)
            paras = [p.text for p in doc.paragraphs if p.text.strip()]
            for table in doc.tables:
                for row in table.rows:
                    row_text = " | ".join(c.text.strip() for c in row.cells if c.text.strip())
                    if row_text:
                        paras.append(row_text)
            return "\n".join(paras)
        except Exception as e:
            warnings.append(f"DOCX error: {e}")
            return ""

    def _extract_txt(self, path: str, warnings: list) -> str:
        try:
            with open(path, "rb") as f:
                raw = f.read()
            enc = chardet.detect(raw).get("encoding", "utf-8") or "utf-8"
            return raw.decode(enc, errors="replace")
        except Exception as e:
            warnings.append(f"TXT error: {e}")
            return ""

    # ── LLM extraction ────────────────────────────────────────────────────────

    async def _llm_extract(self, text: str, existing_warnings: list) -> "ParsedCV":
        prompt = _EXTRACT_PROMPT.format(text=_sanitise_for_prompt(text))
        try:
            response = await self.ollama.chat(
                model=settings.ollama_llm_model,
                messages=[{"role": "user", "content": prompt}],
                options={
                    "temperature": 0.05,
                    "num_predict": 900,
                    "num_ctx":     3072,
                },
            )
            raw = response["message"]["content"].strip()
            raw = re.sub(r"```json\s*", "", raw)
            raw = re.sub(r"```\s*",     "", raw)
            data = json.loads(raw)

            # Sanitise numeric fields
            if data.get("parse_confidence") is None:
                data["parse_confidence"] = 0.75
            if data.get("total_years_exp") is None:
                data.pop("total_years_exp", None)

            # FIX-NULL: coerce null lists to [] — LLM returns null instead of []
            # which crashes Pydantic validation and loses ALL parsed fields
            for list_field in ("technical_skills", "soft_skills", "domain_expertise",
                               "certifications", "languages", "experience",
                               "education", "parse_warnings"):
                if data.get(list_field) is None:
                    data[list_field] = []

            # FIX-NULL: coerce null technologies inside experience entries
            for exp in (data.get("experience") or []):
                if isinstance(exp, dict):
                    if exp.get("duration_months") is None:
                        exp.pop("duration_months", None)
                    if exp.get("technologies") is None:
                        exp["technologies"] = []

            # FIX-NAME: reject section headings returned as full_name by LLM
            raw_name = data.get("full_name") or ""
            if raw_name and not _is_valid_name(raw_name):
                data["full_name"] = None

            return ParsedCV(**data)

        except json.JSONDecodeError as e:
            self.log.warning("llm_json_error", error=str(e))
            existing_warnings.append(f"LLM JSON parse error: {e}")
            return ParsedCV(parse_confidence=0.2, parse_warnings=existing_warnings)
        except Exception as e:
            self.log.error("llm_extract_failed", error=str(e))
            existing_warnings.append(f"LLM extraction failed: {e}")
            return ParsedCV(parse_confidence=0.1, parse_warnings=existing_warnings)