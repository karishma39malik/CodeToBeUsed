﻿content = open('ingestion_agent.py', encoding='utf-8').read()
idx = content.find('name = None')
print(repr(content[idx-4:idx+300]))
