﻿content = open('/app/agents/ingestion_agent.py').read()
idx = content.find('    name = None')
print(repr(content[idx:idx+300]))
