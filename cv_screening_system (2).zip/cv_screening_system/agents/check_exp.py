﻿import psycopg2, os
conn = psycopg2.connect(os.getenv('DATABASE_URL'))
cur = conn.cursor()
cur.execute("SELECT parsed_data FROM cv_versions LIMIT 1")
row = cur.fetchone()
p = row[0] if row else {}
print('total_years_exp:', p.get('total_years_exp'))
print('experience:')
for i,e in enumerate(p.get('experience') or []):
    print(i, '|', e.get('company'))
    print('   role:', e.get('role'))
    print('   start:', e.get('start_date'), 'end:', e.get('end_date'))
