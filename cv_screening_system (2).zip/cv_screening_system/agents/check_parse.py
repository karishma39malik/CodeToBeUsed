﻿import psycopg2, os
conn = psycopg2.connect(os.getenv('DATABASE_URL'))
cur = conn.cursor()
cur.execute("SELECT parse_confidence, parse_errors, parsed_data FROM cv_versions LIMIT 1")
row = cur.fetchone()
if row:
    print('confidence:', row[0])
    print('parse_errors:', row[1])
    p = row[2] or {}
    print('parse_warnings:', p.get('parse_warnings'))
    print('full_name:', p.get('full_name'))
    print('total_years_exp:', p.get('total_years_exp'))
    print('experience count:', len(p.get('experience') or []))
