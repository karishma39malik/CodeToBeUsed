"""
TalentScan — Hybrid Matching Agent (Speed-First Rewrite)
=========================================================
PERFORMANCE TARGET: 20 CVs < 60 seconds

ROOT CAUSE OF SLOWNESS (fixed here):
  OLD: 8-15 embed HTTP calls per CV (1 CV embed + 1 JD embed + N skill embeds)
       Each Ollama embed call = ~1-2s serial → 15-30s just in embeddings
  NEW: EXACTLY 2 embed calls per CV (CV text + JD text, JD cached after first CV)
       Skill matching uses fuzzy string matching (microseconds, not HTTP calls)

SCORING MODEL (unchanged accuracy):
  composite = (
      must_have_score    × 0.40
    + good_to_have_score × 0.20
    + semantic_sim       × 0.25
    + experience_score   × 0.15
  ) × domain_multiplier - penalties

LLM CALLS: 1 per CV (rationale/summary only, compact prompt)
EMBED CALLS: 2 per CV (CV + JD), JD cached globally after first CV of each job
FUZZY CALLS: microseconds (difflib, no network)
"""

import asyncio
import json
import re
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional, Tuple

import ollama as ollama_client
import structlog
from sqlalchemy import text

from agents.base_agent import BaseAgent
from shared.models import (
    HardFilterResult, PenaltyRecord, RejectionReason,
    ScoreBreakdown, ScreeningDecision, SkillScore,
)
from shared.utils import (
    cosine_similarity, detect_keyword_stuffing,
    truncate_text, years_from_experience,
    build_cv_evidence_blob, skill_in_cv,
    filter_to_cv_grounded,
)
from config.settings import settings

logger = structlog.get_logger(__name__)

# ── Scoring weights ───────────────────────────────────────────────────────────
W_MUST_HAVE    = 0.40
W_GOOD_TO_HAVE = 0.20
W_SEMANTIC     = 0.25
W_EXPERIENCE   = 0.15

# ── Thresholds ────────────────────────────────────────────────────────────────
FUZZY_MATCH_THRESHOLD   = 0.72   # SequenceMatcher ratio for "skill present"
FUZZY_PARTIAL_THRESHOLD = 0.50   # Partial credit
DOMAIN_MISMATCH_MULTIPLIER = 0.50
KEYWORD_STUFFING_PENALTY   = 0.20
DOMAIN_MISMATCH_PENALTY    = 0.15

# ── Global JD embedding cache (keyed by job_id) ───────────────────────────────
# Avoids re-embedding the same JD for every CV in a batch
_JD_EMBED_CACHE: Dict[str, List[float]] = {}

# ── Global CV embedding cache (keyed by short text hash) ─────────────────────
_CV_EMBED_CACHE: Dict[str, List[float]] = {}


def _fuzzy_skill_match(skill: str, cv_text: str) -> Tuple[float, str]:
    """
    Fast fuzzy match of a skill against CV text.
    Returns (score 0-1, match_type).
    Uses difflib.SequenceMatcher — runs in microseconds, zero network calls.

    THRESHOLDS:
      - Single-word skills (<=10 chars): 0.88 — prevents Java↔JavaScript false match
      - Multi-word skills: 0.72 — more lenient for phrase-level matching
    """
    skill_lower = skill.lower().strip()
    cv_lower    = cv_text.lower()

    # 1. Exact substring match with word-boundary check (fastest, most accurate)
    import re as _re
    pattern = r'(?<![a-z0-9])' + _re.escape(skill_lower) + r'(?![a-z0-9])'
    if _re.search(pattern, cv_lower):
        return 1.0, "exact"

    # 2. All words of multi-word skill present (handles "project management"→"manage projects")
    words = skill_lower.split()
    if len(words) > 1 and all(w in cv_lower for w in words if len(w) > 3):
        return 0.90, "word_match"

    # 3. Fuzzy ratio — use HIGHER threshold for short single-word skills
    #    to prevent Java↔JavaScript, Python↔Cython, etc.
    is_single_word = len(words) == 1
    match_threshold = 0.88 if is_single_word else FUZZY_MATCH_THRESHOLD

    window = len(skill_lower) + 15
    best   = 0.0
    step   = max(1, len(skill_lower) // 2)
    for i in range(0, min(len(cv_lower), 1500), step):  # cap at 1500 for speed
        chunk = cv_lower[i:i + window]
        r = SequenceMatcher(None, skill_lower, chunk, autojunk=False).ratio()
        if r > best:
            best = r
        if best >= match_threshold:
            break

    if best >= match_threshold:
        return best, "fuzzy"
    if best >= FUZZY_PARTIAL_THRESHOLD and not is_single_word:
        return best * 0.6, "partial"
    return 0.0, "none"


class MatchingAgent(BaseAgent):

    def __init__(self, db):
        super().__init__("matching", db)
        self.ollama = ollama_client.AsyncClient(host=settings.ollama_base_url)

    def _pgvec(self, vec: List[float]) -> str:
        return "[" + ",".join(str(float(x)) for x in vec) + "]"

    # ─────────────────────────────────────────────────────────────────────────
    # MAIN EXECUTE
    # ─────────────────────────────────────────────────────────────────────────

    async def execute(self, payload: Dict[str, Any], correlation_id: str) -> Dict[str, Any]:
        cv_version_id   = payload["cv_version_id"]
        job_id          = payload["job_id"]
        parsed_cv       = payload["parsed_cv"]
        job_description = payload["job_description"]
        candidate_id    = payload["candidate_id"]
        jd_requirements = payload.get("jd_requirements") or payload.get("requirements") or {}

        cv_text = self._cv_to_text(parsed_cv)

        # ── Build full CV text for fuzzy matching ─────────────────────────────
        cv_full_text = self._cv_full_text(parsed_cv)

        # ── Only 2 embed calls per CV (both fire concurrently) ────────────────
        cv_embed, jd_embed = await asyncio.gather(
            self._embed_cached(cv_text, f"cv:{cv_version_id}"),
            self._get_jd_embedding(job_id, job_description),
        )

        # ── Store CV embedding (fire-and-forget, don't await) ─────────────────
        _task = asyncio.create_task(self._store_cv_embedding(cv_version_id, cv_embed))
        _task.add_done_callback(
            lambda t: self.log.error("embed_store_failed", error=str(t.exception()))
            if t.exception() else None
        )

        # ── Semantic similarity ───────────────────────────────────────────────
        semantic_similarity = cosine_similarity(cv_embed, jd_embed)

        # ── Requirements ──────────────────────────────────────────────────────
        mandatory_skills = [s.lower().strip() for s in (jd_requirements.get("mandatory_skills") or [])]
        good_to_have     = [s.lower().strip() for s in (jd_requirements.get("good_to_have_skills") or [])]
        min_years        = jd_requirements.get("min_years_experience")
        jd_domain        = (jd_requirements.get("domain") or "").lower()

        # ── Hard filter (fuzzy, no embeds) ───────────────────────────────────
        hard_filter = self._run_hard_filters_fuzzy(
            parsed_cv, mandatory_skills, min_years, jd_domain,
            cv_full_text, semantic_similarity
        )

        if not hard_filter.passed:
            return self._build_rejection_result(
                candidate_id, cv_version_id, job_id, semantic_similarity, hard_filter
            )

        # ── Per-skill scoring (fuzzy, no embeds) ─────────────────────────────
        skill_scores = self._score_skills_fuzzy(mandatory_skills, good_to_have, cv_full_text)

        must_have_score    = self._aggregate_skill_score([s for s in skill_scores if s.is_mandatory])
        good_to_have_score = self._aggregate_skill_score([s for s in skill_scores if not s.is_mandatory])

        # ── Experience & domain ───────────────────────────────────────────────
        experience_score, exp_years = self._score_experience(parsed_cv, min_years)
        domain_multiplier, domain_score = self._score_domain(parsed_cv, jd_domain, semantic_similarity)

        # ── Penalties ─────────────────────────────────────────────────────────
        all_jd_skills = mandatory_skills + good_to_have
        penalties     = self._compute_penalties(
            parsed_cv, cv_full_text, all_jd_skills,
            domain_multiplier, exp_years, min_years
        )
        total_penalty = sum(p.severity for p in penalties)

        # ── Composite score ───────────────────────────────────────────────────
        raw_composite = (
            must_have_score    * W_MUST_HAVE +
            good_to_have_score * W_GOOD_TO_HAVE +
            semantic_similarity * W_SEMANTIC +
            experience_score   * W_EXPERIENCE
        ) * domain_multiplier
        composite_score = max(0.0, min(1.0, raw_composite - total_penalty))

        # ── Decision (before LLM, so we can skip LLM for clear rejects) ──────
        if composite_score < settings.reject_threshold * 0.5:
            # Very clear rejection — skip LLM entirely, use rule-based summary
            llm = self._rule_based_summary(
                parsed_cv, mandatory_skills, good_to_have,
                must_have_score, composite_score
            )
        else:
            # LLM only for borderline/shortlist candidates
            llm = await self._llm_analyze(parsed_cv, job_description, jd_requirements,
                                           must_have_score, mandatory_skills, good_to_have)

        # ── Final decision ────────────────────────────────────────────────────
        if composite_score >= settings.shortlist_threshold:
            decision = ScreeningDecision.AUTO_SHORTLISTED
        elif composite_score < settings.reject_threshold:
            decision = ScreeningDecision.AUTO_REJECTED
        else:
            decision = ScreeningDecision.NEEDS_REVIEW

        breakdown = ScoreBreakdown(
            must_have_score    = round(must_have_score, 3),
            good_to_have_score = round(good_to_have_score, 3),
            semantic_similarity= round(semantic_similarity, 3),
            experience_score   = round(experience_score, 3),
            domain_alignment   = round(domain_score, 3),
            penalties          = penalties,
            total_penalty      = round(total_penalty, 3),
            composite_score    = round(composite_score, 3),
            hard_filter        = hard_filter,
            skill_scores       = skill_scores,
        )

        self.log.info("matching_complete",
                      composite=round(composite_score, 3),
                      must_have=round(must_have_score, 3),
                      semantic=round(semantic_similarity, 3),
                      decision=decision)

        return {
            "candidate_id":        candidate_id,
            "cv_version_id":       cv_version_id,
            "job_id":              job_id,
            "semantic_similarity": round(semantic_similarity, 3),
            "relevance_score":     round(must_have_score * 0.6 + good_to_have_score * 0.4, 3),
            "potential_score":     llm.get("potential_score", 0.5),
            "composite_score":     round(composite_score, 3),
            "score_breakdown":     breakdown.model_dump(),
            "skill_scores":        [s.model_dump() for s in skill_scores],
            "decision":            decision.value,
            "rejection_reason":    None,
            "strengths":           llm.get("strengths", []),
            "gaps":                llm.get("gaps", []),
            "risk_flags":          llm.get("risk_flags", [p.description for p in penalties]),
            "transferable_skills": llm.get("transferable_skills", []),
            "value_add_insights":  llm.get("value_add_insights", []),
            "llm_rationale":       llm.get("rationale", ""),
            "ai_summary":          llm.get("ai_summary", ""),
            "evidence_map":        llm.get("evidence_map", {}),
        }

    # ─────────────────────────────────────────────────────────────────────────
    # FUZZY HARD FILTERS (zero network calls)
    # ─────────────────────────────────────────────────────────────────────────

    def _run_hard_filters_fuzzy(
        self,
        parsed_cv: dict,
        mandatory_skills: List[str],
        min_years: Optional[float],
        jd_domain: str,
        cv_full_text: str,
        semantic_similarity: float,
    ) -> HardFilterResult:

        # Filter 1: mandatory skills via fuzzy match
        missing = []
        for skill in mandatory_skills:
            score, _ = _fuzzy_skill_match(skill, cv_full_text)
            if score < FUZZY_PARTIAL_THRESHOLD:
                missing.append(skill)

        if missing:
            return HardFilterResult(
                passed=False,
                rejection_reason=RejectionReason.NO_MANDATORY_SKILLS,
                missing_mandatory=missing,
            )

        # Filter 2: experience
        if min_years and min_years > 0:
            exp_years = years_from_experience(parsed_cv.get("experience", []))
            if exp_years == 0:
                exp_years = parsed_cv.get("total_years_exp") or 0.0
            ratio = exp_years / min_years if min_years else 1.0
            if ratio < 0.30:
                return HardFilterResult(
                    passed=False,
                    rejection_reason=RejectionReason.INSUFFICIENT_EXPERIENCE,
                    years_required=min_years,
                    years_found=exp_years,
                )

        # Filter 3: near-zero semantic
        if semantic_similarity < 0.10 and mandatory_skills:
            return HardFilterResult(
                passed=False,
                rejection_reason=RejectionReason.ZERO_SEMANTIC_MATCH,
            )

        return HardFilterResult(passed=True)

    # ─────────────────────────────────────────────────────────────────────────
    # FUZZY SKILL SCORING (zero network calls)
    # ─────────────────────────────────────────────────────────────────────────

    def _score_skills_fuzzy(
        self,
        mandatory: List[str],
        good_to_have: List[str],
        cv_full_text: str,
    ) -> List[SkillScore]:
        results = []
        all_skills = [(s, True) for s in mandatory] + [(s, False) for s in good_to_have]

        for skill, is_mandatory in all_skills:
            weight = 0.9 if is_mandatory else 0.5
            score, match_type = _fuzzy_skill_match(skill, cv_full_text)
            present = score >= FUZZY_MATCH_THRESHOLD
            results.append(SkillScore(
                skill=skill, present=present, is_mandatory=is_mandatory,
                weight=weight, score=round(score, 3), match_type=match_type
            ))

        return results

    def _aggregate_skill_score(self, scores: List[SkillScore]) -> float:
        if not scores:
            return 0.0  # FIXED: was 0.5 which inflated scores for jobs with no skills defined
        weighted_sum = sum(s.score * s.weight for s in scores)
        total_weight = sum(s.weight for s in scores)
        return weighted_sum / total_weight if total_weight else 0.0

    # ─────────────────────────────────────────────────────────────────────────
    # EXPERIENCE & DOMAIN
    # ─────────────────────────────────────────────────────────────────────────

    def _score_experience(self, parsed_cv: dict, min_years: Optional[float]) -> Tuple[float, float]:
        exp_years = years_from_experience(parsed_cv.get("experience", []))
        if exp_years == 0:
            exp_years = parsed_cv.get("total_years_exp") or 0.0

        if not min_years or min_years <= 0:
            return min(1.0, exp_years / 10.0), exp_years

        ratio = exp_years / min_years
        if ratio >= 1.0:
            score = min(1.0, 0.8 + 0.2 * min(ratio - 1.0, 1.0))
        elif ratio >= 0.60:
            score = 0.4 + 0.4 * (ratio - 0.60) / 0.40
        else:
            score = ratio * 0.6
        return round(score, 3), exp_years

    def _score_domain(self, parsed_cv: dict, jd_domain: str, semantic_sim: float) -> Tuple[float, float]:
        if not jd_domain:
            return 1.0, 1.0
        cv_domains  = [d.lower() for d in (parsed_cv.get("domain_expertise") or [])]
        cv_exp_text = " ".join(
            (e.get("description") or "") + " " + (e.get("company") or "")
            for e in (parsed_cv.get("experience") or [])
        ).lower()
        domain_keywords = jd_domain.split()
        direct_hit = any(
            kw in " ".join(cv_domains) or kw in cv_exp_text
            for kw in domain_keywords
        )
        if direct_hit:
            return 1.0, 1.0
        if semantic_sim >= 0.50:
            return 0.85, semantic_sim
        elif semantic_sim >= 0.30:
            return 0.65, semantic_sim
        else:
            return DOMAIN_MISMATCH_MULTIPLIER, semantic_sim

    # ─────────────────────────────────────────────────────────────────────────
    # PENALTIES
    # ─────────────────────────────────────────────────────────────────────────

    def _compute_penalties(
        self, parsed_cv: dict, cv_text: str, all_jd_skills: List[str],
        domain_multiplier: float, exp_years: float, min_years: Optional[float],
    ) -> List[PenaltyRecord]:
        penalties = []

        if detect_keyword_stuffing(cv_text, all_jd_skills):
            penalties.append(PenaltyRecord(
                penalty_type="keyword_stuffing", severity=KEYWORD_STUFFING_PENALTY,
                description="Suspicious keyword density — possible stuffing",
                evidence="High skill-to-word-count ratio",
            ))

        if domain_multiplier < 0.80:
            penalties.append(PenaltyRecord(
                penalty_type="domain_mismatch", severity=DOMAIN_MISMATCH_PENALTY,
                description="Domain/industry appears misaligned",
                evidence=f"Alignment multiplier: {domain_multiplier:.2f}",
            ))

        if min_years and exp_years < min_years * 0.60:
            deficit     = min_years - exp_years
            penalty_val = min(0.20, deficit * settings.min_experience_penalty_factor)
            penalties.append(PenaltyRecord(
                penalty_type="insufficient_experience", severity=round(penalty_val, 3),
                description=f"Candidate has {exp_years:.1f} yrs vs {min_years:.1f} required",
                evidence=f"Gap: {deficit:.1f} years",
            ))

        return penalties

    # ─────────────────────────────────────────────────────────────────────────
    # REJECTION BUILDER
    # ─────────────────────────────────────────────────────────────────────────

    def _build_rejection_result(
        self, candidate_id: str, cv_version_id: str, job_id: str,
        semantic_similarity: float, hard_filter: HardFilterResult,
    ) -> Dict[str, Any]:
        reason_text = hard_filter.rejection_reason.value if hard_filter.rejection_reason else "hard_filter_failed"
        breakdown = ScoreBreakdown(
            must_have_score=0.0, good_to_have_score=0.0,
            semantic_similarity=round(semantic_similarity, 3),
            experience_score=0.0, domain_alignment=0.0,
            composite_score=0.0, hard_filter=hard_filter,
        )
        gaps = []
        if hard_filter.missing_mandatory:
            gaps = [f"Missing: {s}" for s in hard_filter.missing_mandatory]
        if hard_filter.years_required:
            gaps.append(f"Experience: {hard_filter.years_found:.1f}/{hard_filter.years_required:.1f} yrs")
        return {
            "candidate_id": candidate_id, "cv_version_id": cv_version_id, "job_id": job_id,
            "semantic_similarity": round(semantic_similarity, 3),
            "relevance_score": 0.0, "potential_score": 0.0, "composite_score": 0.0,
            "score_breakdown": breakdown.model_dump(), "skill_scores": [],
            "decision": ScreeningDecision.AUTO_REJECTED.value,
            "rejection_reason": reason_text,
            "strengths": [], "gaps": gaps, "risk_flags": [f"Hard filter: {reason_text}"],
            "transferable_skills": [], "value_add_insights": [],
            "llm_rationale": f"REJECTED: {reason_text}. {'; '.join(gaps)}",
            "ai_summary": f"Does not meet minimum requirements: {reason_text.replace('_', ' ')}.",
        }

    # ─────────────────────────────────────────────────────────────────────────
    # EMBEDDINGS (only for CV↔JD semantic score — NOT for skills)
    # ─────────────────────────────────────────────────────────────────────────

    async def _embed_cached(self, text: str, cache_key: str) -> List[float]:
        if cache_key in _CV_EMBED_CACHE:
            return _CV_EMBED_CACHE[cache_key]
        response = await self.ollama.embeddings(
            model=settings.ollama_embed_model,
            prompt=text[:3000],
        )
        vec = response["embedding"]
        if len(_CV_EMBED_CACHE) > 200:
            for k in list(_CV_EMBED_CACHE.keys())[:50]:
                del _CV_EMBED_CACHE[k]
        _CV_EMBED_CACHE[cache_key] = vec
        return vec

    async def _get_jd_embedding(self, job_id: str, job_description: str) -> List[float]:
        # Global cache keyed by job_id — computed ONCE per job, reused for all CVs
        if job_id in _JD_EMBED_CACHE:
            return _JD_EMBED_CACHE[job_id]

        # Try DB first
        try:
            jd_row = await self.db.execute(
                text("SELECT embedding::text FROM jobs WHERE id = :id"), {"id": job_id}
            )
            row = jd_row.fetchone()
            if row and row[0]:
                raw = row[0].strip("[]").split(",")
                vec = [float(x) for x in raw]
                _JD_EMBED_CACHE[job_id] = vec
                return vec
        except Exception:
            pass

        # Compute and cache
        response = await self.ollama.embeddings(
            model=settings.ollama_embed_model,
            prompt=truncate_text(job_description, 3000),
        )
        vec = response["embedding"]
        _JD_EMBED_CACHE[job_id] = vec
        return vec

    async def _store_cv_embedding(self, cv_version_id: str, cv_embed: List[float]):
        try:
            await self.db.execute(
                text("UPDATE cv_versions SET embedding = :emb WHERE id = :id"),
                {"emb": self._pgvec(cv_embed), "id": cv_version_id}
            )
        except Exception as e:
            self.log.warning("cv_embedding_store_failed", error=str(e))

    # ─────────────────────────────────────────────────────────────────────────
    # CV TEXT BUILDERS
    # ─────────────────────────────────────────────────────────────────────────

    def _cv_to_text(self, parsed_cv: dict) -> str:
        """Compact text for embedding."""
        parts = []
        if parsed_cv.get("cv_summary"):
            parts.append(parsed_cv["cv_summary"])
        tech = ", ".join(parsed_cv.get("technical_skills") or [])
        if tech:
            parts.append(f"Skills: {tech}")
        domains = ", ".join(parsed_cv.get("domain_expertise") or [])
        if domains:
            parts.append(f"Domain: {domains}")
        for exp in (parsed_cv.get("experience") or [])[:4]:
            parts.append(f"{exp.get('role','')} at {exp.get('company','')}: {exp.get('description','')}")
        return "\n".join(parts)

    def _cv_full_text(self, parsed_cv: dict) -> str:
        """Full CV text for fuzzy skill matching — no LLM, no network."""
        parts = []
        for field in ["technical_skills", "soft_skills", "domain_expertise", "certifications"]:
            v = parsed_cv.get(field) or []
            if isinstance(v, list):
                parts.append(" ".join(str(x) for x in v))
            else:
                parts.append(str(v))
        for exp in (parsed_cv.get("experience") or []):
            parts.append(exp.get("role") or "")
            parts.append(exp.get("description") or "")
            parts.append(exp.get("company") or "")
            for t in (exp.get("technologies") or []):
                parts.append(str(t))
        if parsed_cv.get("cv_summary"):
            parts.append(parsed_cv["cv_summary"])
        for edu in (parsed_cv.get("education") or []):
            parts.append(f"{edu.get('degree','')} {edu.get('field','')} {edu.get('institution','')}")
        return " ".join(p for p in parts if p).lower()

    # ─────────────────────────────────────────────────────────────────────────
    # LLM ANALYSIS (called only for non-obvious cases)
    # ─────────────────────────────────────────────────────────────────────────

    async def _llm_analyze(
        self, parsed_cv: dict, job_description: str,
        jd_requirements: dict, must_have_score: float,
        mandatory_skills: List[str], good_to_have: List[str],
    ) -> dict:
        cv_blob = build_cv_evidence_blob(parsed_cv)
        mandatory_present = [s for s in mandatory_skills if skill_in_cv(s, cv_blob)]
        mandatory_missing = [s for s in mandatory_skills if not skill_in_cv(s, cv_blob)]
        nice_present      = [s for s in good_to_have if skill_in_cv(s, cv_blob)]

        cv_summary = self._cv_to_text(parsed_cv)

        prompt = (
            f"ATS analyst. JSON only. No markdown.\n"
            f"SKILLS PRESENT:{mandatory_present} MISSING:{mandatory_missing} NICE:{nice_present}\n"
            f"JD:{truncate_text(job_description,500)}\n"  # FIXED: was 300
            f"CV:{cv_summary[:700]}\n"  # FIXED: was 400
            f'Return:{{"potential_score":float,"strengths":[str],"gaps":[str],'
            f'"risk_flags":[str],"transferable_skills":[str],"value_add_insights":[str],'
            f'"rationale":"2 sentences","ai_summary":"1 sentence"}}'
        )

        try:
            response = await self.ollama.chat(
                model=settings.ollama_llm_model,
                messages=[{"role": "user", "content": prompt}],
                options={"temperature": 0.05, "num_predict": 700, "num_ctx": 3072},  # FIXED: increased from 2048
            )
            raw = response["message"]["content"]
            if isinstance(raw, dict):
                llm_out = raw
            else:
                llm_out = json.loads(re.sub(r"```json\s*|```\s*", "", raw).strip())

            llm_out["strengths"]           = filter_to_cv_grounded(llm_out.get("strengths", []), cv_blob)
            llm_out["transferable_skills"] = filter_to_cv_grounded(llm_out.get("transferable_skills", []), cv_blob)
            llm_out["evidence_map"] = {
                "mandatory_present": mandatory_present,
                "mandatory_missing": mandatory_missing,
                "nice_present":      nice_present,
            }
            return llm_out

        except Exception as e:
            self.log.error("llm_analysis_failed", error=str(e))
            return self._rule_based_summary(parsed_cv, mandatory_skills, good_to_have, must_have_score, 0)

    def _rule_based_summary(
        self, parsed_cv: dict, mandatory: List[str],
        good_to_have: List[str], must_have_score: float, composite: float,
    ) -> dict:
        """Zero-LLM fallback summary — used for clear rejects and LLM failures."""
        cv_blob  = build_cv_evidence_blob(parsed_cv)
        present  = [s for s in mandatory if skill_in_cv(s, cv_blob)]
        missing  = [s for s in mandatory if not skill_in_cv(s, cv_blob)]
        return {
            "potential_score":     round(len(present) / max(len(mandatory), 1), 2),
            "strengths":           present or ["General professional background"],
            "gaps":                [f"Missing: {s}" for s in missing] or ["No specific gaps identified"],
            "risk_flags":          ["Rule-based only — LLM skipped for speed"],
            "transferable_skills": present,
            "value_add_insights":  [],
            "rationale":           (
                f"Rule-based: {len(present)}/{len(mandatory)} mandatory skills found. "
                f"Missing: {missing or 'none'}."
            ),
            "ai_summary": f"{len(present)}/{len(mandatory)} mandatory skills matched.",
            "evidence_map": {"mandatory_present": present, "mandatory_missing": missing},
        }
