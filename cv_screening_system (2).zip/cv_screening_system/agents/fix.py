﻿content = open('ingestion_agent.py', encoding='utf-8').read()

bad = '    name = None\n    for line in text.split("\\n")[:15]:\n        line = line.strip()\n        if 3 < len(line) < 45 and " " in line and not any(c.isdigit() for c in line) and "@" not in line:\n            name = line\n            break'

good = '    _BAD = {"summary","objective","profile","experience","education","skills","certifications","languages","contact","references","professional","career","employment","history","qualifications","overview","about","introduction","background","expertise","work","academic","personal","details","information","ambitious","motivated","dedicated","passionate","seeking","declaration","activities","interests","achievements","awards","technical","soft","core","key"}\n    name = None\n    for line in text.split("\\n")[:30]:\n        line = line.strip()\n        if not (3 < len(line) < 50): continue\n        if " " not in line: continue\n        if any(c.isdigit() for c in line): continue\n        if "@" in line or ":" in line or "/" in line or "|" in line: continue\n        words = line.lower().split()\n        if len(words) > 5: continue\n        if any(w in _BAD for w in words): continue\n        name = line\n        break'

if bad in content:
    content = content.replace(bad, good)
    open('ingestion_agent.py','w', encoding='utf-8').write(content)
    print('FIXED')
else:
    print('PATTERN NOT FOUND')
