﻿import psycopg2, os, json
conn = psycopg2.connect(os.getenv('DATABASE_URL'))
cur = conn.cursor()
cur.execute("SELECT parsed_data FROM cv_versions LIMIT 1")
row = cur.fetchone()
p = row[0] if row else {}
print('=== FULL PARSED DATA ===')
print(json.dumps(p, indent=2))
