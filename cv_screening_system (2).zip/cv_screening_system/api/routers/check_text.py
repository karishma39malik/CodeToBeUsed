﻿import sys
sys.path.insert(0, '/app')
import asyncio, pdfplumber

def extract():
    parts = []
    with pdfplumber.open('/tmp/cv_uploads/' + __import__('os').listdir('/tmp/cv_uploads')[0]) as pdf:
        for page in pdf.pages:
            t = page.extract_text()
            if t: parts.append(t)
    return '\n'.join(parts)

text = extract()
print('=== FULL TEXT ===')
print(text[:3000])
print('...')
print('=== LAST 1000 ===')
print(text[-1000:])
print('=== LENGTH ===', len(text))
