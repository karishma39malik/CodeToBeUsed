from fastapi import APIRouter
from fastapi.responses import FileResponse
import os

router = APIRouter()

@router.get("/cv/{cv_id}")
def get_cv(cv_id: str, db: Session = Depends(get_db)):
    cv = db.query(CVVersion).filter(CVVersion.id == cv_id).first()

    file_path = cv.stored_path

    if not os.path.exists(file_path):
        return {"error": "file not found"}

    return FileResponse(
        path=file_path,
        filename=cv.original_filename,
        media_type="application/pdf"
    )