import logging
import os
import structlog
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from api.routers import candidates, jobs, screening
from database.connection import check_db_health
from shared.models import HealthResponse
from config.settings import settings

structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.JSONRenderer(),
    ],
    wrapper_class=structlog.stdlib.BoundLogger,
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
)

logger = structlog.get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("system_startup", version="5.0.0", environment=settings.environment)
    os.makedirs(f"{settings.upload_dir}/cvs", exist_ok=True)
    os.makedirs(settings.log_dir, exist_ok=True)
    yield
    logger.info("system_shutdown")


app = FastAPI(
    title="TalentScan v5 — Recruitment Intelligence API",
    description="Hybrid AI CV screening with semantic matching, hard filters, and penalty system",
    version="5.0.0",
    docs_url="/docs" if settings.environment == "development" else None,
    redoc_url="/redoc" if settings.environment == "development" else None,
    openapi_url="/openapi.json" if settings.environment == "development" else None,
    lifespan=lifespan,
)

# SECURITY: Explicit origin whitelist — wildcard '*' is NOT permitted
ALLOWED_ORIGINS = [
    "http://localhost:8501",
    "http://frontend:8501",
    "http://127.0.0.1:8501",
    "http://cv_frontend:8501",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "DELETE"],
    allow_headers=["Content-Type", "Authorization", "X-Request-ID"],
)

app.include_router(jobs.router, prefix="/api/v1/jobs", tags=["Jobs"])
app.include_router(candidates.router, prefix="/api/v1/candidates", tags=["Candidates"])
app.include_router(screening.router, prefix="/api/v1/screenings", tags=["Screenings"])


@app.get("/health", response_model=HealthResponse)
async def health_check():
    db_ok = await check_db_health()
    import httpx
    ollama_ok = False
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            resp = await client.get(f"{settings.ollama_base_url}/api/tags")
            ollama_ok = resp.status_code == 200
    except Exception:
        pass
    return HealthResponse(
        status="healthy" if (db_ok and ollama_ok) else "degraded",
        database=db_ok,
        ollama=ollama_ok,
    )