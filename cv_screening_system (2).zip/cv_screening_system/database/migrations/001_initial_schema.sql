-- TalentScan v5 — Full Schema
-- Run this once on a fresh PostgreSQL database

CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ============================================================
-- ENUM TYPES
-- ============================================================
DO $$ BEGIN
  CREATE TYPE candidate_status AS ENUM (
    'new','parsing','parsed','screened',
    'shortlisted','interview_scheduled','interviewed',
    'offered','hired','rejected','on_hold','withdrawn'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE screening_decision AS ENUM (
    'auto_shortlisted','auto_rejected','needs_review',
    'hr_approved','hr_rejected','hr_hold','forwarded'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE file_format AS ENUM ('pdf','docx','txt','unknown');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE anomaly_type AS ENUM (
    'duplicate_cv','employment_gap','inconsistent_dates',
    'missing_required_skills','low_parse_confidence',
    'suspicious_pattern','borderline_score','keyword_stuffing'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ============================================================
-- TABLE: jobs
-- ============================================================
CREATE TABLE IF NOT EXISTS jobs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title           TEXT NOT NULL,
    department      TEXT,
    location        TEXT,
    description_raw TEXT NOT NULL,
    requirements    JSONB,          -- {mandatory_skills, good_to_have_skills, min_years_experience, domain}
    embedding       vector(768),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    created_by      TEXT NOT NULL
);

-- ============================================================
-- TABLE: candidates
-- ============================================================
CREATE TABLE IF NOT EXISTS candidates (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email           TEXT UNIQUE,
    full_name       TEXT,
    phone           TEXT,
    linkedin_url    TEXT,
    current_status  candidate_status DEFAULT 'new',
    first_seen_at   TIMESTAMPTZ DEFAULT NOW(),
    last_updated_at TIMESTAMPTZ DEFAULT NOW(),
    source          TEXT,
    is_returning    BOOLEAN DEFAULT FALSE,
    notes           TEXT
);

-- ============================================================
-- TABLE: cv_versions
-- ============================================================
CREATE TABLE IF NOT EXISTS cv_versions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    candidate_id        UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
    job_id              UUID REFERENCES jobs(id),
    original_filename   TEXT NOT NULL,
    stored_path         TEXT NOT NULL,
    file_format         file_format NOT NULL,
    file_size_bytes     INTEGER,
    file_hash           TEXT NOT NULL,
    parsed_data         JSONB,
    parse_confidence    FLOAT,
    parse_errors        JSONB,
    embedding           vector(768),
    embedding_model     TEXT,
    ingestion_status    TEXT DEFAULT 'pending',
    correlation_id      UUID DEFAULT uuid_generate_v4(),
    uploaded_at         TIMESTAMPTZ DEFAULT NOW(),
    processed_at        TIMESTAMPTZ
);

-- ============================================================
-- TABLE: screenings
-- ============================================================
CREATE TABLE IF NOT EXISTS screenings (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cv_version_id       UUID NOT NULL REFERENCES cv_versions(id),
    job_id              UUID NOT NULL REFERENCES jobs(id),
    candidate_id        UUID NOT NULL REFERENCES candidates(id),

    -- Scores (0.0 to 1.0)
    semantic_similarity FLOAT DEFAULT 0.0,
    relevance_score     FLOAT DEFAULT 0.0,
    potential_score     FLOAT DEFAULT 0.0,
    composite_score     FLOAT DEFAULT 0.0,

    -- Detailed score breakdown (JSON)
    score_breakdown     JSONB,          -- Full ScoreBreakdown object
    skill_scores        JSONB,          -- Per-skill scoring detail

    -- Decision
    decision            screening_decision DEFAULT 'needs_review',
    rejection_reason    TEXT,           -- RejectionReason enum value or null
    decision_by         TEXT,
    decision_at         TIMESTAMPTZ,

    -- Explainability
    strengths           JSONB DEFAULT '[]',
    gaps                JSONB DEFAULT '[]',
    risk_flags          JSONB DEFAULT '[]',
    transferable_skills JSONB DEFAULT '[]',
    value_add_insights  JSONB DEFAULT '[]',
    llm_rationale       TEXT DEFAULT '',
    ai_summary          TEXT DEFAULT '',

    -- Metadata
    screened_at         TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABLE: anomalies
-- ============================================================
CREATE TABLE IF NOT EXISTS anomalies (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cv_version_id   UUID REFERENCES cv_versions(id),
    candidate_id    UUID REFERENCES candidates(id),
    job_id          UUID REFERENCES jobs(id),
    anomaly_type    anomaly_type NOT NULL,
    severity        TEXT NOT NULL,
    description     TEXT,
    raw_evidence    JSONB,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABLE: screening_history
-- Tracks all score changes over time (for Excel history sheet)
-- ============================================================
CREATE TABLE IF NOT EXISTS screening_history (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    screening_id    UUID REFERENCES screenings(id),
    candidate_id    UUID REFERENCES candidates(id),
    job_id          UUID REFERENCES jobs(id),
    composite_score FLOAT,
    decision        TEXT,
    changed_by      TEXT,
    changed_at      TIMESTAMPTZ DEFAULT NOW(),
    note            TEXT
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_screenings_job     ON screenings(job_id);
CREATE INDEX IF NOT EXISTS idx_screenings_cand    ON screenings(candidate_id);
CREATE INDEX IF NOT EXISTS idx_screenings_score   ON screenings(composite_score DESC);
CREATE INDEX IF NOT EXISTS idx_screenings_job_score ON screenings(job_id, composite_score DESC);
CREATE INDEX IF NOT EXISTS idx_screenings_decision ON screenings(job_id, decision);
CREATE UNIQUE INDEX IF NOT EXISTS idx_screenings_unique ON screenings(cv_version_id, job_id);
CREATE INDEX IF NOT EXISTS idx_cv_versions_cand   ON cv_versions(candidate_id);
CREATE INDEX IF NOT EXISTS idx_anomalies_cv       ON anomalies(cv_version_id);
CREATE INDEX IF NOT EXISTS idx_history_cand       ON screening_history(candidate_id);