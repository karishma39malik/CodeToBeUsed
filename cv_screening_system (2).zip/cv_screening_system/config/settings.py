from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
from urllib.parse import quote_plus


class Settings(BaseSettings):
    # ─────────────────────────────
    # Database
    # ─────────────────────────────
    postgres_host: str = Field(validation_alias="POSTGRES_HOST")
    postgres_port: int = Field(5432, validation_alias="POSTGRES_PORT")
    postgres_db: str = Field(validation_alias="POSTGRES_DB")
    postgres_user: str = Field(validation_alias="POSTGRES_USER")
    postgres_password: str = Field(validation_alias="POSTGRES_PASSWORD")

    @property
    def database_url(self) -> str:
        pw = quote_plus(self.postgres_password)
        return (
            f"postgresql+asyncpg://{self.postgres_user}:{pw}"
            f"@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"
        )

    @property
    def database_url_sync(self) -> str:
        return (
            f"postgresql://{self.postgres_user}:{self.postgres_password}"
            f"@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"
        )

    # ─────────────────────────────
    # Ollama
    # ─────────────────────────────
    ollama_base_url: str = "http://localhost:11434"
    ollama_llm_model: str = "llama3.1:8b"
    ollama_embed_model: str = "nomic-embed-text"

    # ─────────────────────────────
    # API
    # ─────────────────────────────
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    # SECURITY: secret_key reserved for JWT signing (Sprint 2 auth implementation)
    # Currently not used — do NOT remove; required for auth middleware
    secret_key: str = "change-me-in-production"  # FIXED: default prevents crash if missing from .env
    environment: str = "production"

    # ─────────────────────────────
    # Files
    # ─────────────────────────────
    upload_dir: str = "/app/uploads"
    max_file_size_mb: int = 20
    allowed_extensions: str = "pdf,docx,txt"

    @property
    def allowed_ext_list(self) -> list[str]:
        return [ext.strip() for ext in self.allowed_extensions.split(",")]

    # ─────────────────────────────
    # Logging
    # ─────────────────────────────
    log_level: str = "INFO"
    log_dir: str = "/app/logs"

    # ─────────────────────────────
    # System
    # ─────────────────────────────
    max_bulk_upload: int = 500
    embedding_dimension: int = 768

    # ─────────────────────────────
    # Matching Thresholds (FIXED)
    # ─────────────────────────────
    shortlist_threshold: float = 0.65   # FIXED: was 0.75 — too aggressive; aligned with scoring model
    reject_threshold:   float = 0.35   # FIXED: was 0.45 — allows more candidates into review
    review_threshold:   float = 0.64   # FIXED: = shortlist_threshold - 0.01 (no ambiguous gap)
    min_experience_penalty_factor: float = 0.03

    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore",
        case_sensitive=False
    )


# Singleton instance
settings = Settings()