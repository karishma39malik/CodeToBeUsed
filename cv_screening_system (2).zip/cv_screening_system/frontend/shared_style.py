"""
Shared CSS, chart utilities, and navigation helpers for all TalentScan pages.

Import in every page:
    import sys; sys.path.insert(0, "/app/frontend")
    from shared_style import (
        CSS, topnav, sidebar_nav, badge_html, parse_list, initials,
        PLOTLY_CFG, score_color, metric_card, donut, score_trend, score_dist,
        pool_bar, hbar, gauge, radar, waterfall,
        FB_BLUE, FB_GREEN, FB_ORANGE, FB_RED, FB_GREY
    )
"""

import plotly.graph_objects as go
from collections import Counter

# ── Import branding config ─────────────────────────────────────────────────────
try:
    from branding import (
        BRAND_NAME, BRAND_TAGLINE, BRAND_ICON, BRAND_LOGO_URL,
        PRIMARY, PRIMARY_DARK, PRIMARY_LIGHT,
        COLOR_SUCCESS, COLOR_WARNING, COLOR_DANGER, COLOR_NEUTRAL,
        BG_APP, BG_CARD, BG_SIDEBAR, BG_FILTER_PANEL, BG_INFO_BOX,
        FONT_FAMILY, FONT_WEIGHTS,
        BRAND_VERSION, BRAND_FOOTER_NOTE,
    )
except ImportError:
    BRAND_NAME        = "TalentScan"
    BRAND_TAGLINE     = "AI Screening Intelligence"
    BRAND_ICON        = "🎯"
    BRAND_LOGO_URL    = ""
    PRIMARY           = "#1877F2"
    PRIMARY_DARK      = "#1244A2"
    PRIMARY_LIGHT     = "#EBF3FF"
    COLOR_SUCCESS     = "#42B72A"
    COLOR_WARNING     = "#F5A623"
    COLOR_DANGER      = "#FA3E3E"
    COLOR_NEUTRAL     = "#BCC0C4"
    BG_APP            = "#F0F2F5"
    BG_CARD           = "#FFFFFF"
    BG_SIDEBAR        = "#FFFFFF"
    BG_FILTER_PANEL   = "#FFFFFF"
    BG_INFO_BOX       = "#F7F8FA"
    FONT_FAMILY       = "Plus Jakarta Sans"
    FONT_WEIGHTS      = "400;500;600;700;800;900"
    BRAND_VERSION     = "v2.0"
    BRAND_FOOTER_NOTE = "UAE Data Residency · AI augments — HR decides."

# ── Legacy colour aliases ──────────────────────────────────────────────────────
FB_BLUE   = PRIMARY
FB_GREEN  = COLOR_SUCCESS
FB_ORANGE = COLOR_WARNING
FB_RED    = COLOR_DANGER
FB_GREY   = COLOR_NEUTRAL
PLOT_BG   = BG_CARD
PLOTLY_CFG = {"displayModeBar": False}

CSS = f"""
<style>
@import url('https://fonts.googleapis.com/css2?family={FONT_FAMILY.replace(" ", "+")}:wght@{FONT_WEIGHTS}&display=swap');

:root {{
  --brand-primary:       {PRIMARY};
  --brand-primary-dark:  {PRIMARY_DARK};
  --brand-primary-light: {PRIMARY_LIGHT};
  --brand-success:       {COLOR_SUCCESS};
  --brand-warning:       {COLOR_WARNING};
  --brand-danger:        {COLOR_DANGER};
  --brand-neutral:       {COLOR_NEUTRAL};
  --bg-app:              {BG_APP};
  --bg-card:             {BG_CARD};
  --bg-sidebar:          {BG_SIDEBAR};
  --bg-info:             {BG_INFO_BOX};
  --text-primary:        #0A0A0A;
  --text-secondary:      #4B5563;
  --text-muted:          #9CA3AF;
  --border:              #E5E7EB;
  --border-strong:       #D1D5DB;
  --font:                '{FONT_FAMILY}', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  --radius-sm:           6px;
  --radius-md:           10px;
  --radius-lg:           14px;
  --shadow-sm:           0 1px 3px rgba(0,0,0,0.07), 0 1px 2px rgba(0,0,0,0.04);
  --shadow-md:           0 4px 12px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.04);
  --shadow-focus:        0 0 0 3px {PRIMARY}33;
}}

html, body, [class*="css"] {{
  font-family: var(--font) !important;
  font-size: 14px;
  -webkit-font-smoothing: antialiased;
}}

/* ── Hide Streamlit chrome ── */
header, [data-testid="stHeader"], [data-testid="stToolbar"],
[data-testid="stDecoration"], [data-testid="stStatusWidget"],
[data-testid="stSidebarNav"], [data-testid="stSidebarNavItems"],
[data-testid="stSidebarNavSeparator"], section[data-testid="stSidebarNav"],
#MainMenu, .stDeployButton, footer {{ display: none !important; }}
[data-testid="stAppViewBlockContainer"] > div:first-child {{ padding-top: 0 !important; }}

/* ── Layout ── */
.stApp           {{ background: var(--bg-app) !important; }}
.block-container {{ padding: 0 1.75rem 3rem !important; max-width: 1440px; }}
section[data-testid="stSidebar"] {{
  background: var(--bg-sidebar) !important;
  border-right: 1px solid var(--border) !important;
  box-shadow: 2px 0 8px rgba(0,0,0,0.04);
}}

/* ── Typography ── */
h1, h2, h3, h4 {{ color: var(--text-primary) !important; font-weight: 700 !important; letter-spacing: -0.02em; }}
p, li           {{ color: var(--text-primary) !important; }}
label           {{ color: var(--text-secondary) !important; font-size: 0.78rem !important; font-weight: 600 !important; }}

.page-heading {{ font-size:1.55rem; font-weight:800; color:var(--text-primary); letter-spacing:-0.03em; line-height:1.2; margin:0; }}
.page-sub     {{ font-size:0.82rem; color:var(--text-secondary); font-weight:500; margin-top:3px; }}
.section-heading    {{ font-size:1.05rem; font-weight:700; color:var(--text-primary); letter-spacing:-0.02em; margin-bottom:0.6rem; }}
.section-heading-lg {{ font-size:1.2rem;  font-weight:800; color:var(--text-primary); letter-spacing:-0.025em; margin-bottom:0.75rem; }}

/* ── Nav bar ── */
.fb-nav {{
  background: var(--bg-card);
  border-bottom: 3px solid var(--brand-primary);
  padding: 0 1.75rem; height: 62px;
  display: flex; align-items: center; justify-content: space-between;
  margin: 0 -1.75rem 2rem -1.75rem;
  box-shadow: 0 2px 16px rgba(0,0,0,0.08);
  position: relative; z-index: 9999;
}}
.fb-nav-left {{ display:flex; align-items:center; gap:14px; }}
.fb-nav-logo-img   {{ height:34px; width:auto; object-fit:contain; }}
.fb-nav-logo-text  {{ font-size:1.25rem; font-weight:900; color:var(--brand-primary); letter-spacing:-0.04em; line-height:1; }}
.fb-nav-logo-dot   {{ width:7px; height:7px; background:var(--brand-success); border-radius:50%; display:inline-block; margin-left:2px; vertical-align:middle; margin-bottom:2px; }}
.fb-nav-divider    {{ width:1px; height:22px; background:var(--border); flex-shrink:0; }}
.fb-nav-title      {{ font-size:0.82rem; font-weight:700; color:var(--brand-primary-dark); background:var(--brand-primary-light); border:1px solid {PRIMARY}44; padding:5px 14px; border-radius:20px; letter-spacing:0.01em; white-space:nowrap; }}
.fb-nav-right      {{ display:flex; align-items:center; gap:10px; font-size:0.72rem; color:var(--text-muted); font-weight:600; white-space:nowrap; }}
.fb-nav-badge      {{ background:var(--brand-primary-light); color:var(--brand-primary); border-radius:20px; padding:3px 10px; font-size:0.7rem; font-weight:700; letter-spacing:0.04em; text-transform:uppercase; }}

/* ── Cards ── */
.fb-card {{
  background:var(--bg-card); border-radius:var(--radius-md); border:1px solid var(--border);
  padding:1.25rem 1.5rem; margin-bottom:12px; box-shadow:var(--shadow-sm);
  transition:box-shadow 0.15s ease;
}}
.fb-card:hover {{ box-shadow:var(--shadow-md); }}
.fb-card-lg {{
  background:var(--bg-card); border-radius:var(--radius-lg); border:1px solid var(--border);
  padding:1.6rem 1.75rem; margin-bottom:18px; box-shadow:var(--shadow-sm);
}}
.fb-card-lg:hover {{ box-shadow:var(--shadow-md); transition:box-shadow 0.15s ease; }}
.fb-card-blue {{ background:var(--brand-primary-light); border-radius:var(--radius-md); border:1px solid {PRIMARY}44; padding:1.25rem 1.5rem; margin-bottom:12px; }}
.fb-card-accent {{
  background:linear-gradient(135deg, var(--brand-primary) 0%, {PRIMARY_DARK} 100%);
  border-radius:var(--radius-lg); padding:1.75rem; margin-bottom:18px;
  box-shadow:0 4px 20px {PRIMARY}40; color:white;
}}

/* ── Labels & dividers ── */
.sec-label {{ font-size:0.66rem; font-weight:800; text-transform:uppercase; letter-spacing:0.12em; color:var(--text-muted); margin-bottom:12px; }}
.divider   {{ height:1px; background:var(--border); margin:1.4rem 0; }}

/* ── Badges ── */
.badge        {{ display:inline-flex; align-items:center; gap:5px; padding:4px 12px; border-radius:20px; font-size:0.72rem; font-weight:700; letter-spacing:0.01em; }}
.badge-green  {{ background:#DCFCE7; color:#15803D; border:1px solid #BBF7D0; }}
.badge-blue   {{ background:var(--brand-primary-light); color:var(--brand-primary); border:1px solid {PRIMARY}44; }}
.badge-orange {{ background:#FEF3C7; color:#B45309; border:1px solid #FDE68A; }}
.badge-red    {{ background:#FEE2E2; color:#DC2626; border:1px solid #FECACA; }}
.badge-grey   {{ background:#F3F4F6; color:#6B7280; border:1px solid #E5E7EB; }}
.badge-dot    {{ width:6px; height:6px; border-radius:50%; flex-shrink:0; }}

/* ── Metric cards ── */
.metric-card {{
  background:var(--bg-card); border-radius:var(--radius-md); border:1px solid var(--border);
  padding:1.2rem 1.4rem; box-shadow:var(--shadow-sm); position:relative; overflow:hidden;
}}
.metric-card::before {{ content:''; position:absolute; top:0; left:0; right:0; height:4px; background:var(--accent,var(--brand-primary)); border-radius:var(--radius-md) var(--radius-md) 0 0; }}
.metric-val {{ font-size:2rem; font-weight:900; color:var(--text-primary); line-height:1; letter-spacing:-0.03em; }}
.metric-lbl {{ font-size:0.67rem; font-weight:800; text-transform:uppercase; letter-spacing:0.1em; color:var(--text-muted); margin-top:5px; }}
.metric-sub {{ font-size:0.72rem; color:var(--text-muted); margin-top:2px; }}

/* ── Exec metrics ── */
.exec-metric {{
  background:var(--bg-card); border-radius:var(--radius-lg); border:1px solid var(--border);
  padding:1.3rem 1.5rem; box-shadow:var(--shadow-sm); position:relative; overflow:hidden;
}}
.exec-metric::before {{ content:''; position:absolute; top:0; left:0; right:0; height:4px; background:var(--accent,var(--brand-primary)); }}
.exec-metric-val {{ font-size:2.1rem; font-weight:900; color:var(--text-primary); line-height:1; letter-spacing:-0.03em; }}
.exec-metric-lbl {{ font-size:0.67rem; font-weight:800; text-transform:uppercase; letter-spacing:0.1em; color:var(--text-muted); margin-top:5px; }}
.exec-metric-sub {{ font-size:0.72rem; color:var(--text-muted); margin-top:2px; }}

/* ── Misc UI ── */
.filter-panel {{ background:var(--bg-card); border-radius:var(--radius-lg); border:1px solid var(--border); padding:1.2rem 1.6rem 1.4rem; margin-bottom:1.5rem; box-shadow:var(--shadow-sm); }}
.filter-title {{ font-size:0.7rem; font-weight:800; text-transform:uppercase; letter-spacing:0.12em; color:var(--text-muted); margin-bottom:1rem; }}
.empty-state  {{ text-align:center; padding:4rem 2rem; background:var(--bg-card); border-radius:var(--radius-lg); border:1px solid var(--border); }}
.result-meta  {{ display:flex; align-items:center; justify-content:space-between; background:var(--bg-card); border-radius:var(--radius-sm); border:1px solid var(--border); padding:10px 16px; margin-bottom:1rem; font-size:0.8rem; color:var(--text-secondary); }}

.pipeline-step {{ display:flex; align-items:center; gap:14px; padding:12px 16px; background:var(--bg-info); border-radius:var(--radius-sm); border:1px solid var(--border); margin-bottom:8px; transition:background 0.15s; }}
.pipeline-step:hover {{ background:var(--brand-primary-light); border-color:{PRIMARY}44; }}
.step-num  {{ width:30px; height:30px; border-radius:50%; background:var(--brand-primary); color:white; font-weight:800; font-size:0.78rem; display:flex; align-items:center; justify-content:center; flex-shrink:0; box-shadow:0 2px 8px {PRIMARY}50; }}
.step-name {{ font-weight:700; font-size:0.88rem; color:var(--text-primary); }}
.step-desc {{ font-size:0.74rem; color:var(--text-secondary); margin-top:2px; line-height:1.4; }}

.job-row    {{ display:flex; align-items:center; gap:14px; padding:1.1rem 1.3rem; background:var(--bg-card); border-radius:var(--radius-md); border:1px solid var(--border); margin-bottom:10px; box-shadow:var(--shadow-sm); transition:box-shadow 0.15s,border-color 0.15s; }}
.job-row:hover {{ box-shadow:var(--shadow-md); border-color:var(--border-strong); }}
.job-avatar {{ width:44px; height:44px; border-radius:var(--radius-sm); background:linear-gradient(135deg,var(--brand-primary) 0%,{PRIMARY_DARK} 100%); display:flex; align-items:center; justify-content:center; font-size:1.1rem; font-weight:800; color:white; flex-shrink:0; box-shadow:0 2px 8px {PRIMARY}40; }}
.job-title-text {{ font-weight:700; font-size:0.95rem; color:var(--text-primary); }}
.job-meta-text  {{ font-size:0.75rem; color:var(--text-secondary); margin-top:3px; }}

.history-row {{ display:flex; align-items:center; gap:12px; padding:10px 14px; background:var(--bg-card); border-radius:var(--radius-sm); border:1px solid var(--border); margin-bottom:6px; }}
.hist-avatar {{ width:36px; height:36px; border-radius:50%; background:var(--brand-primary); color:white; font-weight:700; font-size:0.75rem; display:flex; align-items:center; justify-content:center; flex-shrink:0; }}

.nojd-badge {{ display:inline-flex; align-items:center; gap:6px; background:#FEF3C7; border:1px solid #FDE68A; border-radius:20px; padding:4px 12px; font-size:0.75rem; font-weight:700; color:#92400E; }}
.jd-badge   {{ display:inline-flex; align-items:center; gap:6px; background:var(--brand-primary-light); border:1px solid {PRIMARY}44; border-radius:20px; padding:4px 12px; font-size:0.75rem; font-weight:700; color:var(--brand-primary-dark); }}

.info-box {{ background:var(--brand-primary-light); border:1px solid {PRIMARY}44; border-left:4px solid var(--brand-primary); border-radius:var(--radius-sm); padding:12px 16px; font-size:0.82rem; color:var(--brand-primary-dark); margin-bottom:1rem; }}
.warn-box {{ background:#FEF3C7; border:1px solid #FDE68A; border-left:4px solid var(--brand-warning); border-radius:var(--radius-sm); padding:12px 16px; font-size:0.82rem; color:#92400E; margin-bottom:1rem; }}

/* ── Streamlit widgets ── */
.stButton > button {{ background:var(--brand-primary) !important; color:#FFFFFF !important; border:none !important; border-radius:var(--radius-sm) !important; font-weight:700 !important; font-size:0.83rem !important; padding:9px 20px !important; transition:background 0.15s,box-shadow 0.15s; letter-spacing:0.01em; }}
.stButton > button:hover {{ background:{PRIMARY_DARK} !important; box-shadow:0 4px 12px {PRIMARY}50 !important; }}
.stSelectbox > div > div   {{ background:var(--bg-card) !important; border-color:var(--border) !important; border-radius:var(--radius-sm) !important; color:var(--text-primary) !important; }}
.stTextInput > div > div   {{ background:var(--bg-card) !important; border-color:var(--border) !important; border-radius:var(--radius-sm) !important; }}
.stTextInput input          {{ color:var(--text-primary) !important; }}
.stTextArea > div > div    {{ background:var(--bg-card) !important; border-color:var(--border) !important; border-radius:var(--radius-sm) !important; }}
.stTextArea textarea        {{ color:var(--text-primary) !important; }}
.stMultiSelect > div       {{ background:var(--bg-card) !important; border-color:var(--border) !important; border-radius:var(--radius-sm) !important; }}
.stFileUploader            {{ background:var(--bg-card) !important; border-color:var(--border) !important; border-radius:var(--radius-sm) !important; }}
[data-testid="stMetricValue"] {{ color:var(--text-primary) !important; font-weight:900 !important; letter-spacing:-0.02em; }}
[data-testid="stMetricLabel"] {{ color:var(--text-muted) !important; font-size:0.7rem !important; font-weight:700 !important; text-transform:uppercase; letter-spacing:0.08em; }}
div[data-testid="stExpander"] {{ background:var(--bg-card) !important; border:1px solid var(--border) !important; border-radius:var(--radius-md) !important; margin-bottom:8px !important; }}
div[data-testid="stExpander"] summary {{ font-weight:700 !important; color:var(--text-primary) !important; }}
.stTabs [data-baseweb="tab-list"] {{ background:var(--bg-info) !important; border-radius:var(--radius-md) !important; padding:4px !important; }}
.stTabs [data-baseweb="tab"]      {{ border-radius:var(--radius-sm) !important; font-weight:600 !important; font-size:0.8rem !important; color:var(--text-secondary) !important; }}
.stTabs [aria-selected="true"]    {{ background:var(--bg-card) !important; color:var(--brand-primary) !important; box-shadow:var(--shadow-sm) !important; }}
[data-testid="stSidebar"] a {{ display:flex; align-items:center; gap:8px; padding:8px 12px; border-radius:var(--radius-sm); font-size:0.82rem; font-weight:600; color:var(--text-secondary) !important; text-decoration:none; transition:background 0.12s,color 0.12s; margin-bottom:2px; }}
[data-testid="stSidebar"] a:hover {{ background:var(--brand-primary-light) !important; color:var(--brand-primary) !important; }}
</style>
"""

# ── Logo HTML helper ─────────────────────────────────────────────────────────
def _logo_html(size="nav"):
    if BRAND_LOGO_URL:
        if size == "sidebar":
            return f'<img src="{BRAND_LOGO_URL}" style="height:36px;width:auto;object-fit:contain;margin-bottom:4px;" alt="{BRAND_NAME}" />'
        return f'<img src="{BRAND_LOGO_URL}" class="fb-nav-logo-img" alt="{BRAND_NAME}" />'
    return (f'<span class="fb-nav-logo-text">{BRAND_NAME}'
            f'<span class="fb-nav-logo-dot"></span></span>')

# ── Sidebar helper ────────────────────────────────────────────────────────────
def sidebar_nav(active=""):
    import streamlit as st
    with st.sidebar:
        logo_html = _logo_html("sidebar")
        st.markdown(f"""
        <div style="padding:0.75rem 0 1rem;">
          {logo_html}
          <div style="font-size:0.65rem;color:var(--text-muted,#9CA3AF);margin-top:4px;font-weight:700;
                      text-transform:uppercase;letter-spacing:0.1em;">{BRAND_TAGLINE}</div>
        </div>
        <div style="height:1px;background:#E5E7EB;margin-bottom:1rem;"></div>
        <div style="font-size:0.62rem;font-weight:800;color:#9CA3AF;
                    text-transform:uppercase;letter-spacing:0.12em;margin-bottom:6px;">Navigation</div>
        """, unsafe_allow_html=True)
        st.page_link("app.py",                        label="🏠  Dashboard")
        st.page_link("pages/01_Post_a_Job.py",         label="📋  Post a Job")
        st.page_link("pages/02_Upload_CVs.py",         label="📤  Upload CVs")
        st.page_link("pages/03_High_Level_Review.py",  label="📊  High-Level Review")
        st.page_link("pages/04_Detailed_Insights.py",  label="🔬  Detailed Insights")
        st.page_link("pages/05_Candidate_History.py",  label="📁  Candidate History")

def topnav(page_title, sub="", badge=""):
    sub = sub or BRAND_TAGLINE
    logo_html = _logo_html("nav")
    badge_html_str = f'<span class="fb-nav-badge">{badge}</span>' if badge else ""
    return f"""
    <div class="fb-nav">
      <div class="fb-nav-left">
        <div style="display:flex;align-items:center;gap:9px;">{logo_html}</div>
        <div class="fb-nav-divider"></div>
        <div class="fb-nav-title">{page_title}</div>
      </div>
      <div class="fb-nav-right">{badge_html_str}<span>{sub}</span></div>
    </div>"""

def page_header(title, subtitle="", icon=""):
    icon_html = f'<span style="font-size:1.6rem;margin-right:10px;vertical-align:middle;">{icon}</span>' if icon else ""
    sub_html  = f'<div class="page-sub">{subtitle}</div>' if subtitle else ""
    return f"""<div style="margin-bottom:1.6rem;">
      <div class="page-heading">{icon_html}{title}</div>
      {sub_html}
    </div>"""

def sidebar_status_footer():
    return (f'<div style="margin-top:1.5rem;background:#F7F8FA;border-radius:6px;'
            f'padding:10px 14px;font-size:0.72rem;color:#4B5563;line-height:1.9;">'
            f'{BRAND_VERSION} · {BRAND_FOOTER_NOTE}</div>')

# ── Utilities ─────────────────────────────────────────────────────────────────
def score_color(s):
    return FB_GREEN if s >= 0.65 else (FB_ORANGE if s >= 0.45 else FB_RED)

def badge_html(decision):
    d     = (decision or "").lower()
    label = (decision or "").replace("_", " ").title()
    if "shortlisted" in d or "approved" in d: cls, dot = "badge-green",  COLOR_SUCCESS
    elif "rejected"  in d:                    cls, dot = "badge-red",    COLOR_DANGER
    elif "hold"      in d:                    cls, dot = "badge-grey",   COLOR_NEUTRAL
    elif "forward"   in d:                    cls, dot = "badge-blue",   PRIMARY
    else:                                     cls, dot = "badge-orange", COLOR_WARNING
    return (f'<span class="badge {cls}">'
            f'<span class="badge-dot" style="background:{dot};"></span>{label}</span>')

def parse_list(val):
    import json
    if isinstance(val, list): return val
    if not val: return []
    try:
        r = json.loads(val)
        return r if isinstance(r, list) else [str(r)]
    except Exception:
        return [str(val)] if val else []

def initials(name):
    parts = (name or "?").split()
    return "".join(p[0] for p in parts[:2]).upper()

def metric_card(val, label, sub="", color="#050505", accent=None):
    accent = accent or PRIMARY
    return f"""<div class="metric-card" style="--accent:{accent};">
      <div class="metric-val" style="color:{color};">{val}</div>
      <div class="metric-lbl">{label}</div>
      {"<div class='metric-sub'>"+sub+"</div>" if sub else ""}
    </div>"""

# ── Chart builders ────────────────────────────────────────────────────────────
_FONT = {"family": f"'{FONT_FAMILY}', system-ui, sans-serif"}

def gauge(value, title="Score"):
    pct   = value * 100
    color = score_color(value)
    fig   = go.Figure(go.Indicator(
        mode="gauge+number", value=pct,
        number={"suffix": "%", "font": {"size": 38, "color": "#0A0A0A"}},
        title={"text": title, "font": {"size": 11, "color": "#9CA3AF"}},
        gauge={
            "axis": {"range": [0,100], "tickvals": [0,25,50,75,100],
                     "tickfont": {"size": 9, "color": "#BCC0C4"}, "tickwidth": 0},
            "bar": {"color": color, "thickness": 0.28},
            "bgcolor": "#F3F4F6", "borderwidth": 0,
            "steps": [{"range":[0,45],"color":"#FEE2E2"},
                      {"range":[45,65],"color":"#FEF3C7"},
                      {"range":[65,100],"color":"#DCFCE7"}],
            "threshold": {"line":{"color":color,"width":3},"thickness":0.8,"value":pct}
        }
    ))
    fig.update_layout(height=200, margin=dict(t=30,b=10,l=20,r=20),
                      paper_bgcolor=PLOT_BG, font=_FONT)
    return fig

def radar(rel, sem, pot):
    cats = ["Relevance", "Semantic", "Potential"]
    vals = [rel*100, sem*100, pot*100]
    fig  = go.Figure(go.Scatterpolar(
        r=vals+[vals[0]], theta=cats+[cats[0]],
        fill="toself", fillcolor="rgba(24,119,242,0.1)",
        line=dict(color=PRIMARY, width=2),
        marker=dict(color=PRIMARY, size=6),
        hovertemplate="%{theta}: %{r:.0f}%<extra></extra>"
    ))
    fig.update_layout(
        polar=dict(bgcolor="#F3F4F6",
                   radialaxis=dict(visible=True, range=[0,100],
                                   tickvals=[0,25,50,75,100],
                                   tickfont=dict(size=8,color="#BCC0C4"),
                                   gridcolor="#E5E7EB"),
                   angularaxis=dict(tickfont=dict(size=10,color="#0A0A0A"),
                                    gridcolor="#E5E7EB")),
        showlegend=False, height=230, margin=dict(t=20,b=20,l=40,r=40),
        paper_bgcolor=PLOT_BG, font=_FONT
    )
    return fig

def waterfall(rel, sem, pot, composite):
    r=rel*.4*100; s=sem*.35*100; p=pot*.25*100
    color = score_color(composite)
    fig = go.Figure(go.Waterfall(
        orientation="v",
        measure=["relative","relative","relative","total"],
        x=["Relevance<br>×40%","Semantic<br>×35%","Potential<br>×25%","Composite"],
        y=[r,s,p,0],
        text=[f"{r:.1f}",f"{s:.1f}",f"{p:.1f}",f"{composite*100:.1f}"],
        textposition="outside", textfont={"size":10,"color":"#0A0A0A"},
        increasing={"marker":{"color":PRIMARY}},
        totals={"marker":{"color":color}},
        connector={"line":{"color":"#E5E7EB","width":1}},
        hovertemplate="%{x}: %{y:.1f} pts<extra></extra>"
    ))
    fig.update_layout(height=260, margin=dict(t=30,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
                      xaxis=dict(showgrid=False,tickfont=dict(size=10,color="#0A0A0A")),
                      yaxis=dict(range=[0,110],gridcolor="#F3F4F6",
                                 tickfont=dict(size=9,color="#9CA3AF")),
                      showlegend=False, font=_FONT)
    return fig

def pool_bar(results):
    if len(results) < 2: return None
    names  = [(r.get("full_name") or f"#{i+1}")[:18] for i,r in enumerate(results)]
    scores = [r.get("composite_score",0)*100 for r in results]
    colors = [score_color(s/100) for s in scores]
    fig = go.Figure(go.Bar(
        x=names, y=scores, marker_color=colors,
        text=[f"{s:.0f}%" for s in scores], textposition="outside",
        textfont=dict(size=10,color="#0A0A0A"),
        hovertemplate="%{x}: %{y:.1f}%<extra></extra>", showlegend=False,
        marker_line_width=0,
    ))
    fig.add_hline(y=65, line_dash="dot", line_color=FB_GREEN,
                  annotation_text="Shortlist 65%",
                  annotation_font_size=9, annotation_font_color=FB_GREEN)
    fig.update_layout(height=280, margin=dict(t=30,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
                      xaxis=dict(tickfont=dict(size=10,color="#0A0A0A"),showgrid=False),
                      yaxis=dict(range=[0,115],gridcolor="#F3F4F6",
                                 tickfont=dict(size=9,color="#9CA3AF"),title="Score %"),
                      bargap=0.35, font=_FONT)
    return fig

def donut(results):
    counts = Counter(r.get("decision","unknown") for r in results)
    labels = list(counts.keys()); values = list(counts.values())
    cmap   = {"auto_shortlisted":FB_GREEN,"hr_approved":FB_GREEN,
               "needs_review":FB_ORANGE,"hr_hold":FB_GREY,
               "auto_rejected":FB_RED,"hr_rejected":FB_RED,"forwarded":FB_BLUE}
    colors = [cmap.get(l,FB_GREY) for l in labels]
    fig = go.Figure(go.Pie(
        labels=[l.replace("_"," ").title() for l in labels],
        values=values, hole=0.58,
        marker=dict(colors=colors,line=dict(color="white",width=3)),
        textinfo="label+percent", textfont=dict(size=10),
        hovertemplate="%{label}: %{value}<extra></extra>"
    ))
    fig.update_layout(height=250, margin=dict(t=20,b=20,l=20,r=20),
                      paper_bgcolor=PLOT_BG, showlegend=False, font=_FONT,
                      annotations=[dict(text=f"<b>{sum(values)}</b>",
                                        x=0.5,y=0.5,font_size=18,showarrow=False,
                                        font_color="#0A0A0A")])
    return fig

def hbar(items, color=None):
    color = color or PRIMARY
    if not items: return None
    labels = [s[:40]+"…" if len(s)>40 else s for s in items[:8]]
    fig = go.Figure(go.Bar(
        x=list(range(len(labels),0,-1)), y=labels,
        orientation="h", marker_color=color, marker_opacity=0.8,
        hovertemplate="%{y}<extra></extra>", showlegend=False,
        text=labels, textposition="inside",
        insidetextanchor="start", textfont=dict(color="white",size=10),
        marker_line_width=0,
    ))
    fig.update_layout(height=max(150,len(labels)*30+40),
                      margin=dict(t=10,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
                      xaxis=dict(visible=False), yaxis=dict(visible=False),
                      bargap=0.3, font=_FONT)
    return fig

def score_trend(results):
    if len(results) < 2: return None
    dates  = [(r.get("screened_at") or "")[:10] for r in results]
    scores = [r.get("composite_score",0)*100 for r in results]
    names  = [(r.get("full_name") or "Unknown")[:15] for r in results]
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=dates, y=scores, mode="lines+markers+text",
        line=dict(color=PRIMARY, width=2.5),
        marker=dict(color=PRIMARY, size=8, line=dict(color="white",width=2)),
        text=names, textposition="top center",
        textfont=dict(size=9,color="#9CA3AF"),
        hovertemplate="%{text}: %{y:.0f}%<extra></extra>",
        name="Score", fill="tozeroy", fillcolor="rgba(24,119,242,0.05)"
    ))
    fig.add_hline(y=65, line_dash="dot", line_color=FB_GREEN)
    fig.update_layout(height=250, margin=dict(t=20,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
                      xaxis=dict(showgrid=False,tickfont=dict(size=9,color="#9CA3AF")),
                      yaxis=dict(range=[0,110],gridcolor="#F3F4F6",
                                 tickfont=dict(size=9,color="#9CA3AF"),title="Score %"),
                      showlegend=False, font=_FONT)
    return fig

def score_dist(results):
    scores = [r.get("composite_score",0)*100 for r in results]
    fig = go.Figure(go.Histogram(
        x=scores, nbinsx=10,
        marker_color=PRIMARY, marker_opacity=0.8,
        hovertemplate="Score %{x:.0f}%: %{y} candidates<extra></extra>",
        marker_line_width=0,
    ))
    fig.add_vline(x=65, line_dash="dot", line_color=FB_GREEN,
                  annotation_text="Shortlist", annotation_font_size=9,
                  annotation_font_color=FB_GREEN)
    fig.update_layout(height=220, margin=dict(t=20,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
                      xaxis=dict(title="Score %",tickfont=dict(size=9,color="#9CA3AF"),showgrid=False),
                      yaxis=dict(title="Candidates",gridcolor="#F3F4F6",
                                 tickfont=dict(size=9,color="#9CA3AF")),
                      showlegend=False, font=_FONT, bargap=0.08)
    return fig
