import streamlit as st
import requests
import os
import plotly.graph_objects as go
import sys
sys.path.insert(0, "/app/frontend")
from shared_style import (CSS, topnav, sidebar_nav, sidebar_status_footer,
    badge_html, score_color, PLOTLY_CFG, pool_bar, donut, score_dist,
    score_trend, FB_BLUE, FB_GREEN, FB_ORANGE, FB_RED, page_header)
from branding import BRAND_NAME, BRAND_TAGLINE, BRAND_ICON, BRAND_VERSION, BRAND_FOOTER_NOTE

st.set_page_config(
    page_title=f"{BRAND_NAME} AI · Dashboard",
    page_icon=BRAND_ICON,
    layout="wide",
    initial_sidebar_state="expanded"
)
st.markdown(CSS, unsafe_allow_html=True)

API_URL = os.getenv("API_URL", "http://api:8000")
API     = f"{API_URL}/api/v1"

# ── Sidebar ────────────────────────────────────────────────────────────────────
sidebar_nav()
with st.sidebar:
    st.markdown('<div style="height:1px;background:#E5E7EB;margin:1rem 0;"></div>', unsafe_allow_html=True)
    st.markdown('<div style="font-size:0.62rem;font-weight:800;color:#9CA3AF;text-transform:uppercase;letter-spacing:0.12em;margin-bottom:8px;">System Status</div>', unsafe_allow_html=True)
    try:
        h = requests.get(f"{API_URL}/health", timeout=4).json()
        api_ok = True; db_ok = h.get("database", False); ai_ok = h.get("ollama", False)
    except Exception:
        api_ok = db_ok = ai_ok = False
    for label, ok in [("API Gateway", api_ok), ("PostgreSQL", db_ok), ("Ollama LLM", ai_ok)]:
        dot_color = "#22C55E" if ok else "#EF4444"
        status    = "Online" if ok else "Offline"
        st.markdown(
            f'<div style="display:flex;align-items:center;justify-content:space-between;'
            f'font-size:0.78rem;color:#4B5563;padding:5px 0;">'
            f'<span style="display:flex;align-items:center;gap:7px;">'
            f'<span style="width:8px;height:8px;border-radius:50%;background:{dot_color};'
            f'flex-shrink:0;display:inline-block;box-shadow:0 0 0 2px {dot_color}33;"></span>'
            f'{label}</span>'
            f'<span style="font-size:0.68rem;font-weight:700;color:{dot_color};">{status}</span>'
            f'</div>',
            unsafe_allow_html=True
        )
    st.markdown(sidebar_status_footer(), unsafe_allow_html=True)

# ── Topnav ─────────────────────────────────────────────────────────────────────
st.markdown(topnav("Dashboard · Hiring Overview", badge="Live"), unsafe_allow_html=True)
st.markdown(page_header(
    "Hiring Overview",
    subtitle="Real-time pipeline metrics across all active roles.",
    icon="🏠"
), unsafe_allow_html=True)

# ── Fetch data ─────────────────────────────────────────────────────────────────
try:
    jobs_data = requests.get(f"{API}/jobs/", timeout=5).json()
    if not isinstance(jobs_data, list): jobs_data = []
except Exception:
    jobs_data = []

all_screenings = []
for job in jobs_data:
    try:
        results = requests.get(
            f"{API}/screenings/results/{job['id']}",
            params={"min_score": 0, "limit": 500}, timeout=8
        ).json()
        if isinstance(results, list):
            for r in results: r["_job_title"] = job["title"]
            all_screenings.extend(results)
    except Exception:
        pass

total_jobs     = len(jobs_data)
total_screened = len(all_screenings)
shortlisted    = sum(1 for r in all_screenings if "shortlisted" in (r.get("decision") or ""))
avg_score      = (sum(r.get("composite_score", 0) for r in all_screenings) / total_screened) if total_screened else 0
pending_review = sum(1 for r in all_screenings if r.get("decision") == "needs_review")

# ── KPI Metrics ────────────────────────────────────────────────────────────────
st.markdown('<div class="sec-label">Key Performance Indicators</div>', unsafe_allow_html=True)
m1, m2, m3, m4, m5 = st.columns(5)
m1.metric("Active Roles",   total_jobs)
m2.metric("CVs Screened",   total_screened)
m3.metric("Shortlisted",    shortlisted)
m4.metric("Pending Review", pending_review)
m5.metric("Avg Score",      f"{avg_score:.0%}" if avg_score else "—")
st.markdown('<div class="divider"></div>', unsafe_allow_html=True)

# ── Charts row ─────────────────────────────────────────────────────────────────
if all_screenings:
    st.markdown('<div class="sec-label">Pipeline Analytics</div>', unsafe_allow_html=True)
    cc1, cc2, cc3 = st.columns([2, 2, 2], gap="medium")

    with cc1:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Score Distribution</div>', unsafe_allow_html=True)
        fig = score_dist(all_screenings)
        if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)

    with cc2:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Decision Breakdown</div>', unsafe_allow_html=True)
        fig = donut(all_screenings)
        if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)

    with cc3:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Scores Over Time</div>', unsafe_allow_html=True)
        sorted_s = sorted(all_screenings, key=lambda x: x.get("screened_at") or "")
        fig = score_trend(sorted_s[-20:])
        if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)

    if total_jobs > 1:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Candidate Scores by Role</div>', unsafe_allow_html=True)
        fig = pool_bar(sorted(all_screenings, key=lambda x: x.get("composite_score", 0), reverse=True)[:20])
        if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)

# ── Pipeline explainer ─────────────────────────────────────────────────────────
st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="sec-label">Architecture & Scoring Model</div>', unsafe_allow_html=True)
pc1, pc2 = st.columns([2, 1], gap="large")

with pc1:
    st.markdown('<div class="fb-card-lg"><div class="section-heading">🤖 AI Pipeline Architecture</div>', unsafe_allow_html=True)
    for i, (name, desc) in enumerate([
        ("Ingestion Agent",  "PDF/DOCX/TXT parsing · LLM-powered structured field extraction · confidence scoring"),
        ("Matching Agent",   "Semantic embedding similarity · LLM relevance analysis · composite score calculation"),
        ("Potential Agent",  "Career trajectory analysis · learning velocity · leadership signal detection"),
        ("Validation Agent", "Duplicate detection · anomaly flagging · borderline score identification"),
    ], 1):
        st.markdown(f"""<div class="pipeline-step">
          <div class="step-num">{i}</div>
          <div><div class="step-name">{name}</div><div class="step-desc">{desc}</div></div>
        </div>""", unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

with pc2:
    st.markdown('<div class="fb-card-lg"><div class="section-heading">📐 Scoring Model</div>', unsafe_allow_html=True)
    from shared_style import FB_BLUE, FB_GREEN, FB_ORANGE
    weights = {"Relevance": (0.40, FB_BLUE), "Semantic": (0.35, FB_GREEN), "Potential": (0.25, FB_ORANGE)}
    fig_w = go.Figure(go.Pie(
        labels=list(weights.keys()),
        values=[v[0]*100 for v in weights.values()],
        hole=0.5,
        marker=dict(colors=[v[1] for v in weights.values()], line=dict(color="white", width=2)),
        textinfo="label+percent", textfont=dict(size=11),
        hovertemplate="%{label}: %{value:.0f}%<extra></extra>"
    ))
    fig_w.update_layout(height=220, margin=dict(t=10,b=10,l=10,r=10),
                        paper_bgcolor="#FFFFFF", showlegend=False,
                        font={"family": "Plus Jakarta Sans, system-ui"})
    st.plotly_chart(fig_w, use_container_width=True, config=PLOTLY_CFG)
    st.markdown("""<div style="font-size:0.75rem;color:#4B5563;line-height:2;margin-top:4px;">
      <b>Relevance</b> — LLM JD/CV alignment<br>
      <b>Semantic</b> — Vector cosine similarity<br>
      <b>Potential</b> — Growth &amp; trajectory signals
    </div>""", unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

# ── Active roles ───────────────────────────────────────────────────────────────
if jobs_data:
    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-label">Active Roles</div>', unsafe_allow_html=True)
    for job in jobs_data[:8]:
        dept = job.get("department") or "—"
        loc  = job.get("location")   or "—"
        date = (job.get("created_at") or "")[:10]
        cnt  = sum(1 for r in all_screenings if r.get("job_id") == str(job.get("id", "")))
        ini  = (job.get("title") or "J")[0].upper()
        st.markdown(f"""<div class="job-row">
          <div class="job-avatar">{ini}</div>
          <div style="flex:1;min-width:0;">
            <div class="job-title-text">{job['title']}</div>
            <div class="job-meta-text">{dept} · {loc}</div>
          </div>
          <div style="display:flex;gap:8px;align-items:center;flex-shrink:0;">
            <span class="badge badge-blue">{cnt} screened</span>
            <span style="font-size:0.72rem;color:#9CA3AF;">{date}</span>
          </div>
        </div>""", unsafe_allow_html=True)
else:
    st.markdown("""<div class="fb-card" style="text-align:center;padding:3rem;">
      <div style="font-size:2.5rem;margin-bottom:0.75rem;">📋</div>
      <div class="section-heading">No roles posted yet</div>
      <div style="font-size:0.82rem;color:#4B5563;max-width:340px;margin:0 auto;">
        Go to <strong>Post a Job</strong> to create your first role and start screening candidates.
      </div>
    </div>""", unsafe_allow_html=True)
