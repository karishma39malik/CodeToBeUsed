"""TalentScan — Post a Job"""
import os, sys
sys.path.insert(0, "/app/frontend")
from shared_style import CSS, topnav, sidebar_nav, page_header, sidebar_status_footer
from branding import BRAND_NAME, BRAND_ICON

import streamlit as st
import requests

st.set_page_config(page_title=f"Post a Job · {BRAND_NAME}", page_icon="📋", layout="wide",
    initial_sidebar_state="expanded")
st.markdown(CSS, unsafe_allow_html=True)
st.markdown(topnav("Post a Role", "Step 1 of 3"), unsafe_allow_html=True)
st.markdown(page_header(
    "Post a New Role",
    subtitle="Define the job and let AI match your candidates. Takes under 2 minutes.",
    icon="📋"
), unsafe_allow_html=True)

API_BASE = os.getenv("API_URL", "http://api:8000")
API      = f"{API_BASE}/api/v1"

sidebar_nav()
with st.sidebar:
    st.markdown("""
    <div style="margin-top:1rem;background:#F0F2F5;border-radius:8px;padding:10px 12px;">
      <div style="font-size:0.65rem;font-weight:700;color:#65676B;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;">Two Modes</div>
      <div style="font-size:0.75rem;color:#050505;line-height:2.0;">
        📄 <b>With JD</b> — role-specific scoring<br>
        🏢 <b>No JD</b> — dept-fit screening
      </div>
    </div>""", unsafe_allow_html=True)

# ── Page body ──────────────────────────────────────────────────────────────────
form_col, info_col = st.columns([3, 2], gap="large")

with form_col:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Role Details</div>', unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    with c1:
        title = st.text_input("Job Title *", placeholder="e.g. Senior Systems Engineer")
        dept  = st.text_input("Department",  placeholder="e.g. Engineering")
    with c2:
        loc       = st.text_input("Location",   placeholder="e.g. Abu Dhabi, UAE")
        posted_by = st.text_input("Your Name *", placeholder="HR Manager name")

    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-label">Job Description Mode</div>', unsafe_allow_html=True)

    mode = st.radio("mode",
        ["📄  I have a Job Description (JD)", "🏢  No JD — Generic Department Screening"],
        label_visibility="collapsed")
    no_jd_mode = "No JD" in mode

    if no_jd_mode:
        st.markdown("""
        <div style="background:#FFF8E6;border:1px solid #FFD975;border-radius:8px;
            padding:12px 16px;font-size:0.82rem;color:#7A5700;margin-bottom:1rem;">
          ⚠️ <strong>No-JD Mode:</strong> CVs screened against department taxonomy
          (15 clusters, 130+ depts). Scores capped at 72%.
        </div>""", unsafe_allow_html=True)
        jd_file = None
        description_text = None
    else:
        jd_tab1, jd_tab2 = st.tabs(["📎 Upload PDF / TXT", "✏️ Paste JD Text"])
        with jd_tab1:
            jd_file = st.file_uploader("Upload JD", type=["txt","pdf"], label_visibility="collapsed")
        with jd_tab2:
            description_text = st.text_area("Paste JD here", height=200,
                                            placeholder="Paste the full job description…")
            jd_file = None if description_text else jd_file

    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)

    if st.button("🚀  Post Role", type="primary", use_container_width=True):
        if not title.strip():
            st.error("Job title is required.")
        elif not posted_by.strip():
            st.error("Your name is required.")
        elif not no_jd_mode and not jd_file and not (description_text or "").strip():
            st.error("Please upload a JD or paste JD text, or switch to No-JD mode.")
        else:
            with st.spinner("Creating role…"):
                try:
                    data = {
                        "title":      title.strip(),
                        "department": dept.strip() or "General",
                        "location":   loc.strip() or "UAE",
                        "created_by": posted_by.strip(),
                        "no_jd":      str(no_jd_mode).lower(),
                    }
                    if description_text and description_text.strip():
                        data["description"] = description_text.strip()
                    files = {}
                    if jd_file:
                        files["jd_file"] = (jd_file.name, jd_file.getvalue(), jd_file.type)

                    resp = requests.post(f"{API}/jobs/", data=data, files=files or None, timeout=30)

                    if resp.status_code == 200:
                        result = resp.json()
                        mode_badge = "🏢 No-JD" if no_jd_mode else "📄 JD-Matched"
                        st.success(f"✅ Role **{title}** created! ({mode_badge} Mode)")
                        st.markdown(f"""
                        <div style="background:#E6F9EE;border:1px solid #B5E8C9;border-radius:8px;
                            padding:14px 16px;margin-top:1rem;font-size:0.85rem;">
                          <strong>Job ID:</strong> <code>{result.get('id','')}</code><br>
                          <strong>Mode:</strong> {mode_badge}<br>
                          {"<strong>⚠️ Note:</strong> Scores capped at 72% — recommend adding a JD." if no_jd_mode else ""}
                        </div>""", unsafe_allow_html=True)
                        st.info("➡️ Next: Go to **Upload CVs** to start screening.")
                    else:
                        try:
                            err = resp.json()
                        except Exception:
                            err = {}
                        st.error(f"Error {resp.status_code}: {err.get('detail', resp.text[:200])}")
                except requests.exceptions.ConnectionError:
                    st.error("Cannot reach API. Is the backend running?")
                except requests.exceptions.Timeout:
                    st.error("Request timed out. Try again.")
                except Exception as e:
                    st.error(f"Unexpected error: {e}")

    st.markdown('</div>', unsafe_allow_html=True)

with info_col:
    st.markdown("""
    <div class="fb-card-lg">
      <div class="sec-label">Mode Comparison</div>
      <div style="background:#EBF3FF;border:1px solid #BBD3FB;border-radius:10px;padding:1.2rem 1.4rem;margin-bottom:1rem;">
        <div style="font-weight:700;font-size:0.9rem;color:#1877F2;margin-bottom:6px;">📄 With Job Description</div>
        <div style="font-size:0.8rem;color:#050505;line-height:1.9;">
          ✓ Role-specific skill matching<br>
          ✓ Must-have / nice-to-have scoring<br>
          ✓ Scores up to 100%<br>
          ✓ Full LLM rationale vs JD
        </div>
      </div>
      <div style="background:#FFF8E6;border:1px solid #FFD975;border-radius:10px;padding:1.2rem 1.4rem;">
        <div style="font-weight:700;font-size:0.9rem;color:#B35900;margin-bottom:6px;">🏢 No JD — Generic Screening</div>
        <div style="font-size:0.8rem;color:#050505;line-height:1.9;">
          ✓ No JD required<br>
          ✓ 15 dept clusters · 130+ depts<br>
          ✓ Suggests best-fit departments<br>
          ⚠ Scores capped at 72%
        </div>
      </div>
    </div>
    <div class="fb-card-lg">
      <div class="sec-label">Department Clusters</div>
      <div style="font-size:0.78rem;color:#050505;line-height:2.0;">
        Finance &amp; Accounts · Engineering &amp; Design<br>
        Flight Test &amp; Prototypes · Manufacturing<br>
        Missiles &amp; Defence R&amp;D · Digital &amp; IT<br>
        Program &amp; Project Mgmt · Quality &amp; Safety<br>
        Supply Chain · People &amp; Culture<br>
        Marketing · Business Development<br>
        Facilities · Legal &amp; Admin · UAV Ops
      </div>
      <div style="margin-top:8px;font-size:0.7rem;color:#8A9BB0;">130+ sub-departments mapped</div>
    </div>
    """, unsafe_allow_html=True)
