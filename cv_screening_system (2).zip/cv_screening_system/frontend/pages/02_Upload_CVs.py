"""TalentScan — Upload CVs"""
import os, sys
sys.path.insert(0, "/app/frontend")
from shared_style import CSS, topnav, sidebar_nav, page_header, sidebar_status_footer, FB_BLUE, FB_GREEN, FB_ORANGE, FB_RED

from branding import BRAND_NAME, BRAND_ICON
import streamlit as st
import requests
import plotly.graph_objects as go

st.set_page_config(page_title="Upload CVs · TalentScan", page_icon="📤", layout="wide")
st.markdown(CSS, unsafe_allow_html=True)
st.markdown(topnav("Upload CVs", "Step 2 of 3"), unsafe_allow_html=True)
st.markdown(page_header("Upload Candidate CVs", subtitle="Batch-upload CVs and run the full AI screening pipeline.", icon="📤"), unsafe_allow_html=True)

API_BASE = os.getenv("API_URL", "http://api:8000")
API      = f"{API_BASE}/api/v1"

sidebar_nav()
with st.sidebar:
    st.markdown("""
    <div style="margin-top:1rem;background:#F0F2F5;border-radius:8px;padding:10px 12px;">
      <div style="font-size:0.65rem;font-weight:700;color:#65676B;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;">Pipeline Agents</div>
      <div style="font-size:0.75rem;color:#050505;line-height:2.0;">
        1️⃣ Ingestion Agent<br>
        2️⃣ Matching / No-JD Agent<br>
        3️⃣ Potential Agent<br>
        4️⃣ Validation Agent
      </div>
    </div>""", unsafe_allow_html=True)

# ── Fetch jobs ─────────────────────────────────────────────────────────────────
try:
    jobs_resp = requests.get(f"{API}/jobs/", timeout=8)
    jobs_list = jobs_resp.json() if jobs_resp.status_code == 200 else []
    if not isinstance(jobs_list, list):
        jobs_list = []
except requests.exceptions.ConnectionError:
    st.error("Cannot connect to API. Is the backend running?")
    st.stop()
except Exception as e:
    st.error(f"API error: {e}")
    st.stop()

if not jobs_list:
    st.warning("No active roles found. Please post a job first.")
    st.stop()

job_map = {j["title"]: j for j in jobs_list}

# ── Layout ─────────────────────────────────────────────────────────────────────
upload_col, pipe_col = st.columns([3, 2], gap="large")

with upload_col:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Upload Configuration</div>', unsafe_allow_html=True)

    selected_label  = st.selectbox("Select Role", list(job_map.keys()))
    selected_job    = job_map[selected_label]
    selected_job_id = selected_job["id"]
    is_no_jd        = bool(selected_job.get("no_jd"))

    if is_no_jd:
        st.markdown("""
        <div class="nojd-badge">🏢 No-JD Mode — Generic Department Screening</div>
        <div style="background:#FFF8E6;border:1px solid #FFD975;border-radius:8px;
            padding:10px 14px;margin:8px 0 12px;font-size:0.8rem;color:#7A5700;">
          <strong>⚠️ No Job Description for this role.</strong><br>
          CVs screened against dept taxonomy. Scores capped at 72%.
        </div>""", unsafe_allow_html=True)
    else:
        st.markdown("""
        <div class="jd-badge">📄 JD Mode — Role-Specific Screening</div>
        <div style="background:#EBF3FF;border:1px solid #BBD3FB;border-radius:8px;
            padding:8px 14px;margin:8px 0 12px;font-size:0.8rem;color:#1244A2;">
          CVs scored against the job description with full must-have / nice-to-have analysis.
        </div>""", unsafe_allow_html=True)

    uploaded_by = st.text_input("Your Name *", placeholder="HR Officer full name")

    cv_files = st.file_uploader(
        "Upload CVs (PDF, DOCX, or TXT)",
        type=["pdf", "docx", "txt"],
        accept_multiple_files=True,
        help="Upload multiple CVs — each processed through the AI pipeline"
    )

    if cv_files:
        st.markdown(f'<div style="font-size:0.78rem;color:#65676B;margin:8px 0;">{len(cv_files)} file(s) selected</div>',
                    unsafe_allow_html=True)
        for f in cv_files[:5]:
            size_kb = len(f.getvalue()) / 1024
            ext = f.name.split(".")[-1].upper()
            ext_color = {"PDF":"#FA3E3E","DOCX":"#1877F2","TXT":"#42B72A"}.get(ext,"#65676B")
            st.markdown(f"""
            <div style="display:flex;align-items:center;gap:10px;padding:6px 10px;
                background:#F0F2F5;border-radius:6px;margin:4px 0;">
              <span style="background:{ext_color};color:white;font-size:0.65rem;font-weight:700;
                  padding:2px 6px;border-radius:3px;">{ext}</span>
              <span style="font-size:0.8rem;color:#050505;flex:1;overflow:hidden;
                  text-overflow:ellipsis;white-space:nowrap;">{f.name}</span>
              <span style="font-size:0.72rem;color:#BCC0C4;">{size_kb:.0f} KB</span>
            </div>""", unsafe_allow_html=True)
        if len(cv_files) > 5:
            st.markdown(f'<div style="font-size:0.72rem;color:#BCC0C4;padding:4px 10px;">+ {len(cv_files)-5} more</div>',
                        unsafe_allow_html=True)

    start = st.button("🚀  Start Screening Pipeline", use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

    if start:
        if not cv_files:
            st.error("Please upload at least one CV.")
        elif not uploaded_by.strip():
            st.error("Please enter your name.")
        else:
            progress = st.progress(0, text="Preparing upload…")
            try:
                file_tuples = [
                    ("files", (f.name, f.getvalue(), f.type or "application/octet-stream"))
                    for f in cv_files
                ]
                progress.progress(30, text="Sending to API…")
                resp = requests.post(
                    f"{API}/screenings/upload/{selected_job_id}",
                    files=file_tuples,
                    timeout=180,
                )
                progress.progress(100, text="Upload complete!")

                if resp.status_code != 200:
                    st.error(f"Upload failed ({resp.status_code})")
                    try:    st.json(resp.json())
                    except: st.code(resp.text[:500])
                    st.stop()

                result  = resp.json()
                total_r = result.get("total_received", 0)
                queued  = result.get("queued", 0)
                failed  = result.get("failed", 0)
                errors  = result.get("errors", [])

                if is_no_jd:
                    st.success(f"✅ {queued} CV(s) queued — No-JD screening running.")
                    st.info("Department-fit scores (max 72%) will appear in High-Level Review once complete.")
                else:
                    st.success(f"✅ {queued} CV(s) queued for AI processing!")

                r1, r2, r3 = st.columns(3)
                r1.metric("Received", total_r)
                r2.metric("Queued",   queued)
                r3.metric("Failed",   failed, delta=f"-{failed}" if failed else None, delta_color="inverse")

                if errors:
                    with st.expander(f"⚠️ {len(errors)} file(s) failed"):
                        for e in errors:
                            fname  = e.get("file") or e.get("filename") or "?"
                            reason = e.get("reason") or e.get("error") or ""
                            st.markdown(f'<div style="font-size:0.8rem;color:#FA3E3E;padding:2px 0;">• {fname} — {reason}</div>',
                                        unsafe_allow_html=True)

                est = queued * 4
                st.markdown(f'<div style="font-size:0.75rem;color:#8A9BB0;margin-top:6px;">⏳ Est. ~{est} min · {queued} CV × ~4 min on CPU</div>',
                            unsafe_allow_html=True)

            except requests.exceptions.Timeout:
                st.error("Request timed out. Try uploading fewer files.")
                progress.empty()
            except requests.exceptions.ConnectionError:
                st.error("Cannot reach API.")
                progress.empty()
            except Exception as e:
                st.error(f"Unexpected error: {e}")
                progress.empty()

with pipe_col:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Pipeline Architecture</div>', unsafe_allow_html=True)

    agents = ["Ingestion","Match/NoJD","Potential","Validation","Result"]
    colors = [FB_BLUE, "#6366F1" if not is_no_jd else FB_ORANGE, FB_ORANGE, "#8B5CF6", FB_GREEN]
    fig_pipe = go.Figure()
    for i, (agent, color) in enumerate(zip(agents, colors)):
        fig_pipe.add_trace(go.Scatter(
            x=[i], y=[0], mode="markers+text",
            marker=dict(size=46, color=color, line=dict(color="white",width=3)),
            text=[str(i+1)], textfont=dict(size=13,color="white"),
            textposition="middle center", showlegend=False,
            hovertemplate=f"{agent}<extra></extra>",
        ))
        fig_pipe.add_annotation(x=i, y=-0.38, text=agent,
                                showarrow=False, font=dict(size=9,color="#65676B"))
        if i < len(agents)-1:
            fig_pipe.add_annotation(x=i+0.55, y=0, text="→",
                                    showarrow=False, font=dict(size=16,color="#E2E6EA"))
    fig_pipe.update_layout(
        height=155, margin=dict(t=10,b=45,l=10,r=10),
        paper_bgcolor="#FFFFFF", plot_bgcolor="#FFFFFF",
        xaxis=dict(visible=False,range=[-0.5,4.5]),
        yaxis=dict(visible=False,range=[-0.75,0.5]),
        font={"family":"Inter,system-ui"},
    )
    st.plotly_chart(fig_pipe, use_container_width=True, config={"displayModeBar":False})

    agent2_label = "No-JD Agent — dept taxonomy" if is_no_jd else "Matching Agent — JD scoring"
    agent2_style = "background:#FFF8E6;border:1px solid #FFD975;color:#7A5700;" if is_no_jd else "background:#EBF3FF;border:1px solid #BBD3FB;color:#1244A2;"
    st.markdown(f'<div style="{agent2_style}border-radius:6px;padding:8px 12px;font-size:0.75rem;margin-top:-8px;margin-bottom:8px;">Agent 2 = <strong>{agent2_label}</strong></div>',
                unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)

    n_files = len(cv_files) if cv_files else 0
    est_min = n_files * 4
    st.markdown(f"""
    <div class="fb-card">
      <div class="sec-label">Estimate</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
        <div class="metric-card" style="--accent:#1877F2;">
          <div class="metric-val">{n_files}</div>
          <div class="metric-lbl">Files Selected</div>
        </div>
        <div class="metric-card" style="--accent:#42B72A;">
          <div class="metric-val" style="color:#1877F2;">~{est_min}m</div>
          <div class="metric-lbl">Est. Time</div>
        </div>
      </div>
      <div style="font-size:0.72rem;color:#BCC0C4;margin-top:8px;">~4 min per CV · Ollama LLaMA 3.1 8B</div>
    </div>""", unsafe_allow_html=True)

    try:
        pipe_status = requests.get(f"{API}/jobs/{selected_job_id}/pipeline", timeout=8).json()
        total_ = pipe_status.get("total_screened", 0)
        pend_  = pipe_status.get("pending_review", 0)
        avg_   = pipe_status.get("avg_score") or 0
        st.markdown(f"""
        <div class="fb-card">
          <div class="sec-label">Role Status — {selected_label}</div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;">
            <div class="metric-card" style="padding:0.7rem;--accent:#1877F2;">
              <div class="metric-val" style="font-size:1.4rem;">{total_}</div>
              <div class="metric-lbl">Screened</div>
            </div>
            <div class="metric-card" style="padding:0.7rem;--accent:#F5A623;">
              <div class="metric-val" style="font-size:1.4rem;color:#F5A623;">{pend_}</div>
              <div class="metric-lbl">Pending</div>
            </div>
            <div class="metric-card" style="padding:0.7rem;--accent:#6B2FA0;">
              <div class="metric-val" style="font-size:1.4rem;color:#1877F2;">
                {f"{avg_:.0%}" if avg_ else "—"}
              </div>
              <div class="metric-lbl">Avg Score</div>
            </div>
          </div>
          {"<div style='font-size:0.7rem;color:#B35900;margin-top:8px;'>⚠️ Scores capped at 72% — No-JD mode</div>" if is_no_jd else ""}
        </div>""", unsafe_allow_html=True)
    except Exception:
        pass

    st.markdown("""
    <div class="fb-card">
      <div class="sec-label">Supported Formats</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <span style="background:#FFEBEE;color:#C62828;font-weight:700;font-size:0.75rem;padding:4px 10px;border-radius:4px;">PDF</span>
        <span style="background:#EBF3FF;color:#1877F2;font-weight:700;font-size:0.75rem;padding:4px 10px;border-radius:4px;">DOCX</span>
        <span style="background:#E7F3E8;color:#1A6B1E;font-weight:700;font-size:0.75rem;padding:4px 10px;border-radius:4px;">TXT</span>
      </div>
      <div style="font-size:0.72rem;color:#BCC0C4;margin-top:8px;">Max 10MB per file · Up to 500 files per batch</div>
    </div>""", unsafe_allow_html=True)
