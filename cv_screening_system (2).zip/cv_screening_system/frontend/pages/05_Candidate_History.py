# TalentScan — Candidate History
import os
import sys
import time

import pandas as pd
import requests
import streamlit as st

sys.path.insert(0, "/app/frontend")
from shared_style import (
    CSS, topnav, page_header, sidebar_status_footer,
    badge_html, initials, PLOTLY_CFG,
    score_color, donut, score_trend, score_dist, pool_bar,
)
from branding import (
    BRAND_NAME, BRAND_ICON, BRAND_TAGLINE, BRAND_LOGO_URL,
    PRIMARY, BRAND_VERSION, BRAND_FOOTER_NOTE,
)

st.set_page_config(
    page_title=f"Candidate History · {BRAND_NAME}",
    page_icon="📁",
    layout="wide",
    initial_sidebar_state="expanded",
)
st.markdown(CSS, unsafe_allow_html=True)

API_BASE = os.getenv("API_URL", "http://api:8000")
API      = f"{API_BASE}/api/v1"

# ── Fetch jobs (needed before sidebar renders) ─────────────────────────────────
try:
    jobs_resp = requests.get(f"{API}/jobs/", timeout=8)
    jobs = jobs_resp.json() if jobs_resp.status_code == 200 else []
    if not isinstance(jobs, list):
        jobs = []
except Exception:
    jobs = []

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    logo_html = (
        f'<img src="{BRAND_LOGO_URL}" style="height:34px;width:auto;object-fit:contain;margin-bottom:4px;" alt="{BRAND_NAME}" />'
        if BRAND_LOGO_URL else
        f'<span style="font-size:1.25rem;font-weight:900;color:{PRIMARY};letter-spacing:-0.04em;">'
        f'{BRAND_NAME}<span style="width:7px;height:7px;background:#42B72A;border-radius:50%;'
        f'display:inline-block;margin-left:3px;vertical-align:middle;margin-bottom:2px;"></span></span>'
    )
    st.markdown(f"""
    <div style="padding:0.75rem 0 1rem;">
      {logo_html}
      <div style="font-size:0.65rem;color:#9CA3AF;margin-top:4px;font-weight:700;
                  text-transform:uppercase;letter-spacing:0.1em;">{BRAND_TAGLINE}</div>
    </div>
    <div style="height:1px;background:#E5E7EB;margin-bottom:1rem;"></div>
    <div style="font-size:0.62rem;font-weight:800;color:#9CA3AF;
                text-transform:uppercase;letter-spacing:0.12em;margin-bottom:6px;">Navigation</div>
    """, unsafe_allow_html=True)
    st.page_link("app.py",                        label="🏠  Dashboard")
    st.page_link("pages/01_Post_a_Job.py",         label="📋  Post a Job")
    st.page_link("pages/02_Upload_CVs.py",         label="📤  Upload CVs")
    st.page_link("pages/03_High_Level_Review.py",  label="📊  High-Level Review")
    st.page_link("pages/04_Detailed_Insights.py",  label="🔬  Detailed Insights")
    st.page_link("pages/05_Candidate_History.py",  label="📁  Candidate History")

    # ── Filters ────────────────────────────────────────────────────────────────
    st.markdown("""
    <div style="height:1px;background:#E5E7EB;margin:1rem 0;"></div>
    <div style="font-size:0.62rem;font-weight:800;color:#9CA3AF;
                text-transform:uppercase;letter-spacing:0.12em;margin-bottom:8px;">🔍 Filters</div>
    """, unsafe_allow_html=True)

    job_options = {"All Roles": None}
    for j in jobs:
        job_options[j["title"]] = j["id"]
    selected_job_label = st.selectbox("Role", list(job_options.keys()), label_visibility="collapsed")
    selected_job_id    = job_options[selected_job_label]

    st.markdown('<div style="font-size:0.72rem;font-weight:600;color:#4B5563;margin-top:8px;margin-bottom:2px;">Min Score</div>', unsafe_allow_html=True)
    min_score_h = st.slider("Min Score", 0, 100, 0, step=5, format="%d%%", label_visibility="collapsed") / 100

    st.markdown('<div style="font-size:0.72rem;font-weight:600;color:#4B5563;margin-top:8px;margin-bottom:2px;">Decision</div>', unsafe_allow_html=True)
    decision_options = ["All", "auto_shortlisted", "hr_approved", "forwarded",
                        "needs_review", "hr_hold", "auto_rejected", "hr_rejected"]
    decision_filter = st.selectbox("Decision", decision_options, label_visibility="collapsed")

    st.markdown('<div style="font-size:0.72rem;font-weight:600;color:#4B5563;margin-top:8px;margin-bottom:2px;">Search by Name</div>', unsafe_allow_html=True)
    search_name = st.text_input("Name Search", placeholder="Type a name…", label_visibility="collapsed")

    # ── System status ──────────────────────────────────────────────────────────
    st.markdown("""
    <div style="height:1px;background:#E5E7EB;margin:1rem 0;"></div>
    <div style="font-size:0.62rem;font-weight:800;color:#9CA3AF;
                text-transform:uppercase;letter-spacing:0.12em;margin-bottom:8px;">⚡ System Status</div>
    """, unsafe_allow_html=True)
    try:
        h      = requests.get(f"{API_BASE}/health", timeout=4).json()
        api_ok = True; db_ok = h.get("database", False); ai_ok = h.get("ollama", False)
    except Exception:
        api_ok = db_ok = ai_ok = False
    for lbl, ok in [("API Gateway", api_ok), ("PostgreSQL", db_ok), ("Ollama LLM", ai_ok)]:
        dot    = "#22C55E" if ok else "#EF4444"
        status = "Online"  if ok else "Offline"
        st.markdown(
            f'<div style="display:flex;align-items:center;justify-content:space-between;'
            f'font-size:0.78rem;color:#4B5563;padding:5px 0;">'
            f'<span style="display:flex;align-items:center;gap:7px;">'
            f'<span style="width:8px;height:8px;border-radius:50%;background:{dot};'
            f'flex-shrink:0;display:inline-block;box-shadow:0 0 0 2px {dot}33;"></span>'
            f'{lbl}</span>'
            f'<span style="font-size:0.68rem;font-weight:700;color:{dot};">{status}</span>'
            f'</div>', unsafe_allow_html=True)
    st.markdown(
        f'<div style="margin-top:1.5rem;background:#F7F8FA;border-radius:6px;'
        f'padding:10px 14px;font-size:0.72rem;color:#4B5563;line-height:1.9;">'
        f'{BRAND_VERSION} · {BRAND_FOOTER_NOTE}</div>', unsafe_allow_html=True)

# ── Top nav + page header ──────────────────────────────────────────────────────
st.markdown(topnav("Candidate History · Audit Trail"), unsafe_allow_html=True)
st.markdown(page_header(
    "Candidate History",
    subtitle="Track every candidate's journey and HR decisions over time.",
    icon="📁",
), unsafe_allow_html=True)

# ── Guard: no jobs ─────────────────────────────────────────────────────────────
if not jobs:
    st.markdown("""
    <div class="fb-card" style="text-align:center;padding:3rem;">
      <div style="font-size:2rem;margin-bottom:0.5rem;">📁</div>
      <div style="font-weight:700;margin-bottom:4px;">No jobs posted yet</div>
      <div style="font-size:0.82rem;color:#65676B;">Post a job and upload CVs to see candidate history.</div>
    </div>""", unsafe_allow_html=True)
    st.stop()

# ── Fetch results ──────────────────────────────────────────────────────────────
all_results   = []
fetch_errors  = []
jobs_to_fetch = [j for j in jobs if selected_job_id is None or j["id"] == selected_job_id]
for job in jobs_to_fetch:
    try:
        resp = requests.get(
            f"{API}/screenings/results/{job['id']}",
            params={"min_score": 0.0, "limit": 500},  # always fetch all, filter client-side
            timeout=15,
        )
        if resp.status_code == 200:
            r = resp.json()
            if isinstance(r, list):
                for item in r:
                    item["_job_title"] = job["title"]
                all_results.extend(r)
            else:
                fetch_errors.append(f"{job['title']}: unexpected response {type(r)}")
        else:
            fetch_errors.append(f"{job['title']}: HTTP {resp.status_code} — {resp.text[:120]}")
    except Exception as e:
        fetch_errors.append(f"{job['title']}: {e}")

# Show fetch errors if any
if fetch_errors:
    for err in fetch_errors:
        st.warning(f"⚠️ {err}")

# Apply min_score filter client-side (avoids NULL composite_score DB issue)
if min_score_h > 0:
    all_results = [r for r in all_results if (r.get("composite_score") or 0) >= min_score_h]

# Apply remaining filters
if decision_filter != "All":
    all_results = [r for r in all_results if r.get("decision") == decision_filter]
if search_name:
    all_results = [r for r in all_results if search_name.lower() in (r.get("full_name") or "").lower()]
all_results.sort(key=lambda x: x.get("screened_at") or "", reverse=True)

# ── Debug panel (remove once working) ─────────────────────────────────────────
with st.expander("🔧 Debug — API Response", expanded=(len(all_results) == 0)):
    st.write(f"**Jobs fetched:** {len(jobs)} | **Jobs to fetch:** {len(jobs_to_fetch)}")
    st.write(f"**Raw results returned:** {len(all_results)}")
    if jobs:
        st.write(f"**Job IDs:** {[j['id'] for j in jobs]}")
    if all_results:
        st.write("**First result keys:**", list(all_results[0].keys()))
        st.write("**First result sample:**", {k: all_results[0].get(k) for k in ["full_name","decision","composite_score","screened_at"]})
    else:
        st.info("No results returned from API. Check fetch errors above.")
        # Try raw API call to show exact response
        if jobs_to_fetch:
            try:
                test_url = f"{API}/screenings/results/{jobs_to_fetch[0]['id']}"
                st.write(f"**Testing URL:** `{test_url}`")
                raw = requests.get(test_url, params={"min_score": 0.0, "limit": 10}, timeout=10)
                st.write(f"**Status:** {raw.status_code}")
                st.write(f"**Response:** {raw.text[:500]}")
            except Exception as e:
                st.error(f"Request failed: {e}")

# ── KPI metrics ────────────────────────────────────────────────────────────────
total     = len(all_results)
approved  = sum(1 for r in all_results if r.get("decision") in ["hr_approved", "auto_shortlisted", "forwarded"])
rejected  = sum(1 for r in all_results if r.get("decision") in ["hr_rejected", "auto_rejected"])
returning = sum(1 for r in all_results if r.get("is_returning"))
avg_s     = (sum(r.get("composite_score", 0) for r in all_results) / total) if total else 0

m1, m2, m3, m4, m5 = st.columns(5)
m1.metric("Total Records",  total)
m2.metric("Approved / Fwd", approved)
m3.metric("Rejected",       rejected)
m4.metric("Returning",      returning)
m5.metric("Avg Score",      f"{avg_s:.0%}" if avg_s else "—")

if not all_results:
    st.markdown("""
    <div class="fb-card" style="text-align:center;padding:2.5rem;margin-top:1rem;">
      <div style="font-size:2rem;margin-bottom:0.5rem;">🔍</div>
      <div style="font-weight:700;margin-bottom:4px;">No records found</div>
      <div style="font-size:0.82rem;color:#65676B;">Try adjusting the filters in the sidebar.</div>
    </div>""", unsafe_allow_html=True)
    st.stop()

st.markdown('<div class="divider"></div>', unsafe_allow_html=True)

# ── Analytics charts ───────────────────────────────────────────────────────────
st.markdown('<div class="sec-label">Pipeline Analytics</div>', unsafe_allow_html=True)
ch1, ch2, ch3 = st.columns(3, gap="medium")
with ch1:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Decision Distribution</div>', unsafe_allow_html=True)
    fig = donut(all_results)
    if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
    st.markdown('</div>', unsafe_allow_html=True)
with ch2:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Score Distribution</div>', unsafe_allow_html=True)
    fig = score_dist(all_results)
    if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
    st.markdown('</div>', unsafe_allow_html=True)
with ch3:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Score Timeline</div>', unsafe_allow_html=True)
    sorted_r = sorted(all_results, key=lambda x: x.get("screened_at") or "")
    fig = score_trend(sorted_r[-15:])
    if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
    st.markdown('</div>', unsafe_allow_html=True)

if len(all_results) >= 2:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Top Candidates by Score</div>', unsafe_allow_html=True)
    top20 = sorted(all_results, key=lambda x: x.get("composite_score", 0), reverse=True)[:20]
    fig   = pool_bar(top20)
    if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
    st.markdown('</div>', unsafe_allow_html=True)

st.markdown('<div class="divider"></div>', unsafe_allow_html=True)

# ── Interactive scrollable summary table ───────────────────────────────────────
import json, streamlit.components.v1 as components

st.markdown(f'<div class="sec-label">Candidate Summary — {total} Records</div>', unsafe_allow_html=True)

# Build rows for JS
def _dec_badge(d):
    d = (d or "").lower()
    if "shortlisted" in d or "approved" in d: return ("Shortlisted", "#15803D", "#DCFCE7", "#BBF7D0")
    if "rejected"    in d:                    return ("Rejected",    "#DC2626", "#FEE2E2", "#FECACA")
    if "review"      in d:                    return ("Review",      "#B45309", "#FEF3C7", "#FDE68A")
    if "hold"        in d:                    return ("Hold",        "#6B7280", "#F3F4F6", "#E5E7EB")
    if "forward"     in d:                    return ("Forwarded",   "#1244A2", "#EBF3FF", "#93C5FD")
    return ("Pending", "#B45309", "#FEF3C7", "#FDE68A")

rows_data = []
for r in all_results:
    email   = r.get("email") or ""
    masked  = (email[:2] + "***@" + email.split("@")[-1]) if "@" in email else "—"
    score   = r.get("composite_score", 0)
    rel     = r.get("relevance_score", 0)
    sem     = r.get("semantic_similarity", 0)
    pot     = r.get("potential_score", 0)
    dec     = r.get("decision") or ""
    dlabel, dcolor, dbg, dborder = _dec_badge(dec)
    rows_data.append({
        "name":      r.get("full_name") or "Unknown",
        "email":     masked,
        "role":      r.get("_job_title", "—"),
        "score":     round(score * 100),
        "rel":       round(rel   * 100),
        "sem":       round(sem   * 100),
        "pot":       round(pot   * 100),
        "dlabel":    dlabel,
        "dcolor":    dcolor,
        "dbg":       dbg,
        "dborder":   dborder,
        "returning": r.get("is_returning", False),
        "flags":     r.get("anomaly_count", 0),
        "screened":  (r.get("screened_at") or "")[:10],
    })

rows_json = json.dumps(rows_data)

# ── Interactive table — HTML built with plain strings (no f-string) ────────────
# Using plain concatenation avoids f-string {{ }} escaping issues with CSS/JS

_CSS = """
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Plus Jakarta Sans',sans-serif;background:#F0F2F5;padding:0;}
.toolbar{display:flex;align-items:center;gap:10px;padding:12px 14px;background:#fff;border:1px solid #E5E7EB;border-radius:10px 10px 0 0;border-bottom:none;flex-wrap:wrap;}
.search-wrap{position:relative;flex:1;min-width:180px;}
.search-wrap svg{position:absolute;left:10px;top:50%;transform:translateY(-50%);opacity:0.4;pointer-events:none;}
#searchBox{width:100%;padding:7px 10px 7px 34px;border:1px solid #E5E7EB;border-radius:7px;font-size:12px;font-family:inherit;outline:none;background:#F9FAFB;color:#111;transition:border-color 0.15s;}
#searchBox:focus{border-color:#1877F2;background:#fff;}
.filter-sel{padding:7px 10px;border:1px solid #E5E7EB;border-radius:7px;font-size:11px;font-family:inherit;background:#F9FAFB;color:#374151;outline:none;cursor:pointer;}
.rec-count{font-size:11px;font-weight:700;color:#6B7280;white-space:nowrap;margin-left:auto;}
.export-btn{padding:7px 14px;background:#1877F2;color:#fff;border:none;border-radius:7px;font-size:11px;font-weight:700;font-family:inherit;cursor:pointer;white-space:nowrap;}
.export-btn:hover{background:#1244A2;}
.tbl-wrap{border:1px solid #E5E7EB;border-radius:0 0 10px 10px;overflow:auto;max-height:400px;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,0.06);}
table{width:100%;border-collapse:collapse;font-size:12px;}
thead tr{background:#F8FAFC;position:sticky;top:0;z-index:10;box-shadow:0 1px 0 #E5E7EB;}
th{padding:10px 12px;text-align:left;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:0.08em;color:#6B7280;white-space:nowrap;cursor:pointer;user-select:none;border-bottom:2px solid #E5E7EB;}
th:hover{color:#1877F2;}
td{padding:9px 12px;border-bottom:1px solid #F3F4F6;color:#111;vertical-align:middle;white-space:nowrap;}
tr:last-child td{border-bottom:none;}
tr:hover td{background:#F8FAFF;}
.score-cell{display:flex;align-items:center;gap:7px;}
.score-val{font-size:12px;font-weight:700;width:32px;text-align:right;flex-shrink:0;}
.bar-bg{flex:1;height:6px;background:#F3F4F6;border-radius:3px;overflow:hidden;min-width:50px;}
.bar-fill{height:100%;border-radius:3px;}
.badge{display:inline-flex;align-items:center;gap:4px;padding:3px 9px;border-radius:20px;font-size:10px;font-weight:700;border:1px solid;white-space:nowrap;}
.badge-dot{width:5px;height:5px;border-radius:50%;flex-shrink:0;}
.name-cell{display:flex;align-items:center;gap:8px;}
.avatar{width:30px;height:30px;border-radius:50%;background:#1877F2;color:#fff;font-weight:700;font-size:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.name-main{font-weight:600;font-size:12px;color:#111;}
.name-email{font-size:10px;color:#9CA3AF;margin-top:1px;}
.flag-none{color:#15803D;font-size:11px;}
.flag-warn{color:#DC2626;font-size:11px;font-weight:700;}
.ret-badge{display:inline-flex;align-items:center;gap:3px;background:#FEF3C7;color:#92400E;border:1px solid #FDE68A;border-radius:10px;padding:2px 7px;font-size:10px;font-weight:700;}
.empty{text-align:center;padding:40px;color:#9CA3AF;font-size:13px;}
.pagination{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:#fff;border:1px solid #E5E7EB;border-top:none;border-radius:0 0 10px 10px;font-size:11px;color:#6B7280;}
.pg-btns{display:flex;gap:4px;}
.pg-btn{padding:4px 10px;border:1px solid #E5E7EB;border-radius:5px;font-size:11px;font-family:inherit;background:#fff;color:#374151;cursor:pointer;font-weight:600;}
.pg-btn:hover{background:#EBF3FF;border-color:#1877F2;color:#1877F2;}
.pg-btn.active{background:#1877F2;color:#fff;border-color:#1877F2;}
.pg-btn:disabled{opacity:0.4;cursor:not-allowed;}
</style>
"""

_HTML_BODY = """
<!DOCTYPE html><html><head>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
CSS_PLACEHOLDER
</head><body>
<div class="toolbar">
  <div class="search-wrap">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
    <input id="searchBox" placeholder="Search name, role, email..." oninput="applyFilters()">
  </div>
  <select class="filter-sel" id="decFilter" onchange="applyFilters()">
    <option value="">All Decisions</option>
    <option>Shortlisted</option><option>Rejected</option><option>Review</option>
    <option>Hold</option><option>Forwarded</option><option>Pending</option>
  </select>
  <select class="filter-sel" id="sortSel" onchange="applyFilters()">
    <option value="score-desc">Score High-Low</option>
    <option value="score-asc">Score Low-High</option>
    <option value="name-asc">Name A-Z</option>
    <option value="screened-desc">Date Latest</option>
  </select>
  <span class="rec-count" id="recCount"></span>
  <button class="export-btn" onclick="exportCSV()">&#11015; Export CSV</button>
</div>
<div class="tbl-wrap">
<table>
  <thead><tr>
    <th onclick="sortBy('name')">Candidate</th>
    <th onclick="sortBy('role')">Role</th>
    <th onclick="sortBy('score')">Score</th>
    <th>Relevance</th>
    <th>Semantic</th>
    <th>Potential</th>
    <th onclick="sortBy('dlabel')">Decision</th>
    <th>Status</th>
    <th>Flags</th>
    <th onclick="sortBy('screened')">Screened</th>
  </tr></thead>
  <tbody id="tbody"></tbody>
</table>
</div>
<div class="pagination">
  <span id="pgInfo"></span>
  <div class="pg-btns" id="pgBtns"></div>
</div>
<script>
const RAW = DATA_PLACEHOLDER;
const PAGE_SIZE = 15;
let filtered = [...RAW];
let currentPage = 1;
let sortKey = 'score';
let sortDir = -1;

function initials(n){return n.split(' ').slice(0,2).map(w=>w[0]||'').join('').toUpperCase()||'?';}
function barColor(v){return v>=65?'#16A34A':v>=45?'#D97706':'#DC2626';}
function scoreColor(v){return v>=65?'#15803D':v>=45?'#B45309':'#DC2626';}
function scoreBar(v){
  return '<div class="score-cell"><span class="score-val" style="color:'+scoreColor(v)+'">'+v+'%</span>'
    +'<div class="bar-bg"><div class="bar-fill" style="width:'+v+'%;background:'+barColor(v)+'"></div></div></div>';
}
function miniBar(v,color){return '<div class="bar-bg" style="min-width:40px"><div class="bar-fill" style="width:'+v+'%;background:'+color+'"></div></div>';}

function render(){
  var tbody=document.getElementById('tbody');
  var start=(currentPage-1)*PAGE_SIZE;
  var page=filtered.slice(start,start+PAGE_SIZE);
  document.getElementById('recCount').textContent=filtered.length+' records';
  document.getElementById('pgInfo').textContent=
    filtered.length===0?'No records':'Showing '+(start+1)+'–'+Math.min(start+PAGE_SIZE,filtered.length)+' of '+filtered.length;
  if(page.length===0){tbody.innerHTML='<tr><td colspan="10"><div class="empty">No candidates match the filters.</div></td></tr>';renderPagination();return;}
  tbody.innerHTML=page.map(function(r){
    var avatarBg=r.score>=65?'#1877F2':r.score>=45?'#D97706':'#DC2626';
    return '<tr>'
      +'<td><div class="name-cell"><div class="avatar" style="background:'+avatarBg+'">'+initials(r.name)+'</div>'
      +'<div><div class="name-main">'+r.name+'</div><div class="name-email">'+r.email+'</div></div></div></td>'
      +'<td style="max-width:140px;overflow:hidden;text-overflow:ellipsis;color:#374151">'+r.role+'</td>'
      +'<td style="min-width:130px">'+scoreBar(r.score)+'</td>'
      +'<td><div style="font-size:11px;font-weight:600;color:#1877F2;margin-bottom:2px">'+r.rel+'%</div>'+miniBar(r.rel,'#3B82F6')+'</td>'
      +'<td><div style="font-size:11px;font-weight:600;color:#059669;margin-bottom:2px">'+r.sem+'%</div>'+miniBar(r.sem,'#10B981')+'</td>'
      +'<td><div style="font-size:11px;font-weight:600;color:#D97706;margin-bottom:2px">'+r.pot+'%</div>'+miniBar(r.pot,'#F59E0B')+'</td>'
      +'<td><span class="badge" style="color:'+r.dcolor+';background:'+r.dbg+';border-color:'+r.dborder+'">'
      +'<span class="badge-dot" style="background:'+r.dcolor+'"></span>'+r.dlabel+'</span></td>'
      +'<td>'+(r.returning?'<span class="ret-badge">&#8629; Returning</span>':'<span style="font-size:11px;color:#9CA3AF">New</span>')+'</td>'
      +'<td>'+(r.flags>0?'<span class="flag-warn">&#9873; '+r.flags+'</span>':'<span class="flag-none">&#10003;</span>')+'</td>'
      +'<td style="font-size:11px;color:#6B7280">'+(r.screened||'—')+'</td>'
      +'</tr>';
  }).join('');
  renderPagination();
}

function renderPagination(){
  var total=filtered.length,pages=Math.ceil(total/PAGE_SIZE),btn=document.getElementById('pgBtns');
  if(pages<=1){btn.innerHTML='';return;}
  var h='<button class="pg-btn" onclick="goPage('+(currentPage-1)+')" '+(currentPage===1?'disabled':'')+'>&#8249;</button>';
  for(var i=1;i<=pages;i++){
    if(i===1||i===pages||Math.abs(i-currentPage)<=1)
      h+='<button class="pg-btn'+(i===currentPage?' active':'')+'" onclick="goPage('+i+')">'+i+'</button>';
    else if(Math.abs(i-currentPage)===2) h+='<span style="padding:4px;color:#9CA3AF">...</span>';
  }
  h+='<button class="pg-btn" onclick="goPage('+(currentPage+1)+')" '+(currentPage===pages?'disabled':'')+'>&#8250;</button>';
  btn.innerHTML=h;
}

function goPage(p){var pages=Math.ceil(filtered.length/PAGE_SIZE);currentPage=Math.max(1,Math.min(p,pages));render();}

function sortBy(key){if(sortKey===key)sortDir*=-1;else{sortKey=key;sortDir=-1;}applyFilters();}

function applyFilters(){
  var q=document.getElementById('searchBox').value.toLowerCase();
  var dec=document.getElementById('decFilter').value.toLowerCase();
  var srt=document.getElementById('sortSel').value.split('-');
  filtered=RAW.filter(function(r){
    if(q&&!r.name.toLowerCase().includes(q)&&!r.role.toLowerCase().includes(q)&&!r.email.toLowerCase().includes(q))return false;
    if(dec&&r.dlabel.toLowerCase()!==dec)return false;
    return true;
  });
  var sk=srt[0],sd=srt[1];
  filtered.sort(function(a,b){
    var av=a[sk]||'',bv=b[sk]||'';
    if(typeof av==='number')return sd==='asc'?av-bv:bv-av;
    return sd==='asc'?String(av).localeCompare(String(bv)):String(bv).localeCompare(String(av));
  });
  currentPage=1;render();
}

function exportCSV(){
  var cols=['name','email','role','score','rel','sem','pot','dlabel','returning','flags','screened'];
  var hdr=['Name','Email','Role','Score%','Relevance%','Semantic%','Potential%','Decision','Returning','Flags','Screened'];
  var rows=filtered.map(function(r){return cols.map(function(c){return '"'+String(r[c]||'').replace(/"/g,'""')+'"';}).join(',');});
  var csv=[hdr.join(',')].concat(rows).join('\\n');
  var a=document.createElement('a');a.href='data:text/csv;charset=utf-8,'+encodeURIComponent(csv);
  a.download='candidates.csv';a.click();
}

applyFilters();
</script></body></html>
"""

# Final assembly — no f-strings, pure string replacement
html_final = _HTML_BODY.replace('CSS_PLACEHOLDER', _CSS).replace('DATA_PLACEHOLDER', rows_json, 1)
components.html(html_final, height=560, scrolling=False)

st.markdown('<div class="divider"></div>', unsafe_allow_html=True)

# ── Candidate detail cards ─────────────────────────────────────────────────────
st.markdown('<div class="sec-label">Candidate Detail View</div>', unsafe_allow_html=True)

for r in all_results[:30]:
    name      = r.get("full_name") or "Unknown"
    score     = r.get("composite_score", 0)
    rel       = r.get("relevance_score", 0)
    sem       = r.get("semantic_similarity", 0)
    pot       = r.get("potential_score", 0)
    dec       = r.get("decision") or "needs_review"
    date      = (r.get("screened_at") or "")[:10]
    job_ttl   = r.get("_job_title", "—")
    email     = r.get("email") or ""
    masked    = (email[:2] + "***@" + email.split("@")[-1]) if "@" in email else "Not extracted"
    fname     = r.get("original_filename", "—")
    rationale = r.get("llm_rationale") or ""
    returning = r.get("is_returning", False)
    anoms     = r.get("anomaly_count", 0)
    ini       = initials(name)
    comp_color = score_color(score)
    bar_color  = (
        "linear-gradient(90deg,#42B72A,#66BB6A)" if score >= 0.65
        else ("linear-gradient(90deg,#F5A623,#FFB74D)" if score >= 0.45
              else "linear-gradient(90deg,#FA3E3E,#EF5350)")
    )

    with st.expander(f"{'↩ ' if returning else ''}{name}  ·  {job_ttl}  ·  {int(score * 100)}%"):
        hc1, hc2 = st.columns([2, 3], gap="medium")
        with hc1:
            st.markdown(f"""
            <div class="fb-card">
              <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
                <div style="width:44px;height:44px;border-radius:50%;background:{PRIMARY};
                            color:white;font-weight:700;font-size:0.9rem;display:flex;
                            align-items:center;justify-content:center;flex-shrink:0;">{ini}</div>
                <div>
                  <div style="font-weight:700;font-size:0.95rem;color:#050505;">{name}</div>
                  <div style="font-size:0.75rem;color:#65676B;">{masked}</div>
                </div>
              </div>
              <div style="font-size:0.78rem;color:#65676B;line-height:2.0;">
                <b>Role:</b> {job_ttl}<br>
                <b>File:</b> {fname}<br>
                <b>Screened:</b> {date}<br>
                <b>Flags:</b> {'⚑ ' + str(anoms) if anoms else '✓ None'}
              </div>
              <div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap;">
                {badge_html(dec)}
                {"<span class='badge badge-orange'>↩ Returning</span>" if returning else ""}
              </div>
            </div>""", unsafe_allow_html=True)

        with hc2:
            st.markdown(f"""
            <div class="fb-card">
              <div class="sec-label">Score Breakdown</div>
              <div style="margin:8px 0;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
                  <span style="font-size:0.78rem;font-weight:600;color:#050505;">Composite</span>
                  <span style="font-size:0.85rem;font-weight:700;color:{comp_color};">{int(score * 100)}%</span>
                </div>
                <div style="height:8px;background:#F0F2F5;border-radius:4px;overflow:hidden;">
                  <div style="width:{int(score * 100)}%;height:100%;background:{bar_color};border-radius:4px;"></div>
                </div>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:10px;">
                <div style="text-align:center;">
                  <div style="font-size:1rem;font-weight:700;color:{PRIMARY};">{int(rel * 100)}%</div>
                  <div style="font-size:0.65rem;color:#65676B;text-transform:uppercase;letter-spacing:0.06em;">Relevance</div>
                </div>
                <div style="text-align:center;">
                  <div style="font-size:1rem;font-weight:700;color:#42B72A;">{int(sem * 100)}%</div>
                  <div style="font-size:0.65rem;color:#65676B;text-transform:uppercase;letter-spacing:0.06em;">Semantic</div>
                </div>
                <div style="text-align:center;">
                  <div style="font-size:1rem;font-weight:700;color:#F5A623;">{int(pot * 100)}%</div>
                  <div style="font-size:0.65rem;color:#65676B;text-transform:uppercase;letter-spacing:0.06em;">Potential</div>
                </div>
              </div>
            </div>""", unsafe_allow_html=True)

        if rationale:
            st.markdown(f"""
            <div style="background:#F0F2F5;border-left:3px solid {PRIMARY};border-radius:0 6px 6px 0;
                        padding:10px 14px;font-size:0.8rem;color:#050505;line-height:1.7;
                        font-style:italic;margin-top:4px;">
              <div style="font-size:0.65rem;font-weight:700;text-transform:uppercase;
                          letter-spacing:0.08em;color:{PRIMARY};margin-bottom:4px;">AI Rationale</div>
              {rationale[:400]}{"…" if len(rationale) > 400 else ""}
            </div>""", unsafe_allow_html=True)

st.markdown('<div style="height:2rem;"></div>', unsafe_allow_html=True)
