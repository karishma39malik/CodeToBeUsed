"""
TalentScan — Branding Configuration
====================================
Edit this file to customise the look of TalentScan for your organisation.
All pages import from here, so one change propagates everywhere.

HOW TO ADD YOUR LOGO
--------------------
1. Copy your logo file (PNG or SVG recommended) to:
       frontend/static/logo.png       ← inside the frontend folder

2. Set BRAND_LOGO_FILE to the filename (just the name, not the full path):
       BRAND_LOGO_FILE = "logo.png"

3. Rebuild / restart the frontend container:
       docker compose up --build frontend

The logo will appear in the top-nav bar and the sidebar automatically.
Leave BRAND_LOGO_FILE = "" to use the text logo instead.
"""

import os
import base64

# ── Identity ──────────────────────────────────────────────────────────────────
BRAND_NAME        = "TalentScan"           # Short product / company name
BRAND_TAGLINE     = "AI Screening Intelligence"  # Below logo in sidebar & nav
BRAND_ICON        = "🎯"                   # Streamlit page icon (emoji or URL)

# Logo filename inside frontend/static/  (e.g. "logo.png", "logo.svg")
# Leave as "" to use the text logo.
BRAND_LOGO_FILE   = "logo.png"

# ── Colour palette ────────────────────────────────────────────────────────────
PRIMARY           = "#1877F2"
PRIMARY_DARK      = "#1244A2"
PRIMARY_LIGHT     = "#EBF3FF"

COLOR_SUCCESS     = "#42B72A"
COLOR_WARNING     = "#F5A623"
COLOR_DANGER      = "#FA3E3E"
COLOR_NEUTRAL     = "#BCC0C4"

BG_APP            = "#F0F2F5"
BG_CARD           = "#FFFFFF"
BG_SIDEBAR        = "#FFFFFF"
BG_FILTER_PANEL   = "#FFFFFF"
BG_INFO_BOX       = "#F7F8FA"

# ── Typography ────────────────────────────────────────────────────────────────
FONT_FAMILY       = "Plus Jakarta Sans"
FONT_WEIGHTS      = "400;500;600;700;800;900"

# ── Version / legal footer ────────────────────────────────────────────────────
BRAND_VERSION     = "v2.0"
BRAND_FOOTER_NOTE = "UAE Data Residency · AI augments — HR decides."

# ── Logo resolution (auto — do not edit below this line) ─────────────────────
def _resolve_logo_url() -> str:
    """
    Converts the logo file to a base64 data-URI so it works inside Docker
    without needing a static file server.  Returns "" if no logo is found.
    """
    if not BRAND_LOGO_FILE:
        return ""

    # Search paths — works both locally and inside the Docker container
    search_dirs = [
        os.path.join(os.path.dirname(__file__), "static"),   # frontend/static/
        os.path.join(os.path.dirname(__file__)),              # frontend/
        "/app/frontend/static",                               # Docker absolute path
        "/app/frontend",
    ]

    for directory in search_dirs:
        full_path = os.path.join(directory, BRAND_LOGO_FILE)
        if os.path.isfile(full_path):
            ext = os.path.splitext(BRAND_LOGO_FILE)[1].lower()
            mime = {
                ".png":  "image/png",
                ".jpg":  "image/jpeg",
                ".jpeg": "image/jpeg",
                ".svg":  "image/svg+xml",
                ".webp": "image/webp",
            }.get(ext, "image/png")
            with open(full_path, "rb") as fh:
                b64 = base64.b64encode(fh.read()).decode()
            return f"data:{mime};base64,{b64}"

    # File declared but not found — warn once, fall back to text logo
    import warnings
    warnings.warn(
        f"[TalentScan branding] Logo file '{BRAND_LOGO_FILE}' not found in "
        f"frontend/static/. Falling back to text logo. "
        f"Place your logo at: frontend/static/{BRAND_LOGO_FILE}",
        stacklevel=2,
    )
    return ""

# Resolved at import time — cached for the lifetime of the Streamlit process
BRAND_LOGO_URL: str = _resolve_logo_url()
