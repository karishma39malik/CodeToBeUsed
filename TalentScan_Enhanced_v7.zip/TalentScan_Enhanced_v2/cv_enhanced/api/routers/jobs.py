import json
import uuid
import io
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Form, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
import ollama as ollama_client
import structlog
import pdfplumber

from database.connection import get_db
from shared.models import JobResponse
from config.settings import settings

router = APIRouter()
logger = structlog.get_logger(__name__)


@router.post("/", response_model=dict)
async def create_job(
    title: str = Form(...),
    department: str = Form(...),
    location: str = Form(...),
    created_by: str = Form(...),
    description: Optional[str] = Form(None),
    jd_file: Optional[UploadFile] = File(None),
    db: AsyncSession = Depends(get_db),
):
    job_id = str(uuid.uuid4())

    # Extract text from PDF if provided, else fall back to description field
    if jd_file and jd_file.filename:
        file_bytes = await jd_file.read()
        try:
            with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                description_raw = "\n".join(
                    page.extract_text() or "" for page in pdf.pages
                ).strip()
        except Exception as e:
            logger.warning("pdf_extraction_failed", error=str(e))
            description_raw = description or ""
    else:
        description_raw = description or ""

    if not description_raw:
        raise HTTPException(status_code=400, detail="Either description or jd_file must be provided")

    # Generate JD embedding
    ollama = ollama_client.AsyncClient(host=settings.ollama_base_url)
    embed_str = None
    try:
        emb_response = await ollama.embeddings(
            model=settings.ollama_embed_model,
            prompt=description_raw[:4000],
        )
        jd_embed = emb_response["embedding"]
        embed_str = "[" + ",".join(str(float(x)) for x in jd_embed) + "]"
    except Exception as e:
        logger.warning("jd_embedding_failed", error=str(e))

    await db.execute(
        text("""
            INSERT INTO jobs (id, title, department, location, description_raw, requirements, embedding, created_by)
            VALUES (:id, :title, :dept, :loc, :desc, CAST(:req AS jsonb), CAST(:emb AS vector), :by)
        """),
        {
            "id": job_id,
            "title": title,
            "dept": department,
            "loc": location,
            "desc": description_raw,
            "req": json.dumps({}),
            "emb": embed_str,
            "by": created_by,
        }
    )
    await db.commit()
    return {"id": job_id, "title": title, "message": "Job created successfully"}

@router.get("/")
async def list_jobs(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("SELECT id, title, department, location, is_active, created_at FROM jobs WHERE is_active=TRUE ORDER BY created_at DESC")
    )
    return [dict(row._mapping) for row in result.fetchall()]


@router.get("/{job_id}")
async def get_job(job_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("SELECT id, title, department, location, description_raw, requirements, is_active, created_at FROM jobs WHERE id=:id"),
        {"id": job_id}
    )
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Job not found")
    return dict(row._mapping)


@router.get("/{job_id}/pipeline")
async def get_pipeline(job_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("""
            SELECT
                COUNT(*) AS total_screened,
                SUM(CASE WHEN decision = 'needs_review' THEN 1 ELSE 0 END) AS pending_review,
                SUM(CASE WHEN decision IN ('auto_shortlisted','hr_approved') THEN 1 ELSE 0 END) AS shortlisted,
                SUM(CASE WHEN decision IN ('auto_rejected','hr_rejected') THEN 1 ELSE 0 END) AS rejected,
                AVG(composite_score) AS avg_score
            FROM screenings WHERE job_id = :id
        """),
        {"id": job_id}
    )
    row = result.fetchone()
    return dict(row._mapping) if row else {}