import os
import uuid
from typing import List

from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
import aiofiles
import structlog
import pdfplumber
import io

from database.connection import get_db
from shared.models import JobResponse
from shared.utils import sanitize_filename, truncate_text
from config.settings import settings
from agents.matching_agent import MatchingAgent

router = APIRouter()
logger = structlog.get_logger(__name__)


@router.post("/", response_model=JobResponse, status_code=201)
async def create_job(
    title: str = Form(...),
    department: str = Form(None),
    location: str = Form(None),
    created_by: str = Form(...),
    jd_file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    """
    Upload a Job Description.
    """

    # ✅ Read JD content safely
    content = await jd_file.read()

    try:
            filename = jd_file.filename.lower()

            if filename.endswith(".pdf"):
                try:
                    with pdfplumber.open(io.BytesIO(content)) as pdf:
                        jd_text = "\n".join(page.extract_text() or "" for page in pdf.pages)
                except Exception:
                    raise HTTPException(400, "Failed to read PDF file")
            else:
                jd_text = content.decode("utf-8", errors="ignore")

            # 🔥 VERY IMPORTANT: remove null bytes
            jd_text = jd_text.replace("\x00", "")
    except Exception:
        raise HTTPException(400, "Invalid file format. Please upload a valid text file.")

    if len(jd_text.strip()) < 100:
        raise HTTPException(
            status_code=400,
            detail="Job description is too short. Please upload a complete JD."
        )

    # ✅ Generate embedding
    agent = MatchingAgent(db)

    try:
        jd_emb = await agent._embed(truncate_text(jd_text, 4000))
    except Exception as e:
        logger.error("embedding_failed", error=str(e))
        raise HTTPException(500, "Embedding generation failed")

    # ✅ Validate embedding
    if not jd_emb or not isinstance(jd_emb, (list, tuple)):
        raise HTTPException(500, "Invalid embedding generated")

    job_id = str(uuid.uuid4())

    # ✅ Insert into DB
    try:
        await db.execute(
            text("""
                INSERT INTO jobs (
                    id, title, department, location,
                    description_raw, embedding, created_by
                )
                VALUES (
                    :id, :title, :dept, :loc,
                    :desc, CAST(:emb AS vector), :by
                )
            """),
            {
                "id": job_id,
                "title": title,
                "dept": department,
                "loc": location,
                "desc": jd_text,
                "emb": "[" + ",".join(str(float(x)) for x in jd_emb) + "]",
                "by": created_by
            }
        )
        await db.commit()
    except Exception as e:
        await db.rollback()
        logger.error("db_insert_failed", error=str(e))
        raise HTTPException(500, "Failed to save job")

    # ✅ Save file
    try:
        filename = sanitize_filename(jd_file.filename)
        jd_dir = os.path.join(settings.upload_dir, "jds")

        os.makedirs(jd_dir, exist_ok=True)

        jd_path = os.path.join(jd_dir, f"{job_id}_{filename}")

        async with aiofiles.open(jd_path, "wb") as f:
            await f.write(content)

    except Exception as e:
        logger.warning("file_save_failed", error=str(e))

    logger.info("job_created", job_id=job_id, title=title)

    # ✅ Fetch inserted job
    result = await db.execute(
        text("SELECT * FROM jobs WHERE id = :id"),
        {"id": job_id}
    )

    job = result.mappings().fetchone()

    if not job:
        raise HTTPException(500, "Failed to retrieve created job")

    return dict(job)


# --------------------------------------------------

@router.get("/", response_model=List[dict])
async def list_jobs(active_only: bool = True, db: AsyncSession = Depends(get_db)):
    """List all job postings."""

    query = """
        SELECT id, title, department, location, is_active, created_at
        FROM jobs
    """

    if active_only:
        query += " WHERE is_active = TRUE"

    query += " ORDER BY created_at DESC"

    result = await db.execute(text(query))

    return [dict(r) for r in result.mappings()]


# --------------------------------------------------

@router.get("/{job_id}/pipeline")
async def get_job_pipeline(job_id: str, db: AsyncSession = Depends(get_db)):
    """Get full hiring pipeline stats for a job."""

    result = await db.execute(
        text("SELECT * FROM v_job_pipeline WHERE id = :id"),
        {"id": job_id},
    )

    row = result.mappings().fetchone()

    if not row:
        raise HTTPException(404, "Job not found")

    return dict(row)