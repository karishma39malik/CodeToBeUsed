from fastapi import APIRouter, UploadFile, File, HTTPException
from typing import List
import uuid

router = APIRouter()

SCREENINGS_DB = {}

@router.post("/upload")
async def upload_cv(
    cv_files: List[UploadFile] = File(...)
):
    if not cv_files:
        raise HTTPException(status_code=400, detail="No files uploaded")

    screening_id = str(uuid.uuid4())

    results = []

    for file in cv_files:
        results.append({
            "name": file.filename,
            "decision": "Pending",
            "score": 0
        })

    SCREENINGS_DB[screening_id] = results

    return {
        "status": "success",
        "screening_id": screening_id,
        "total_received": len(cv_files),
        "queued": len(cv_files),
        "failed": 0
    }