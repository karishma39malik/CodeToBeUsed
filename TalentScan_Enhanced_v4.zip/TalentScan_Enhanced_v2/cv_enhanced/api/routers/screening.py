import json
import os
import uuid
from typing import List

from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
import aiofiles
import structlog

from database.connection import get_db, AsyncSessionLocal
from shared.models import BulkUploadResponse
from shared.utils import sanitize_filename, compute_file_hash, get_file_extension
from config.settings import settings
from agents.ingestion_agent import IngestionAgent
from agents.matching_agent import MatchingAgent
from agents.potential_agent import PotentialAgent
from agents.validation_agent import ValidationAgent

router = APIRouter()
logger = structlog.get_logger(__name__)


# =====================================================
# BULK UPLOAD
# =====================================================
@router.post("/upload", response_model=BulkUploadResponse)
async def upload_cvs(
    job_id: str = Form(...),
    uploaded_by: str = Form(...),
    cv_files: List[UploadFile] = File(...),
    background_tasks: BackgroundTasks = None,
    db: AsyncSession = Depends(get_db),
):
    if len(cv_files) > settings.max_bulk_upload:
        raise HTTPException(
            status_code=400,
            detail=f"Maximum {settings.max_bulk_upload} files allowed."
        )

    # verify job exists
    job_check = await db.execute(
        text("SELECT id FROM jobs WHERE id = :id"),
        {"id": job_id}
    )
    if not job_check.fetchone():
        raise HTTPException(status_code=404, detail="Job not found")

    queued = []
    failed = []
    correlation_ids = []

    for cv_file in cv_files:

        correlation_id = str(uuid.uuid4())

        try:
            ext = get_file_extension(cv_file.filename)

            if ext not in settings.allowed_ext_list:
                failed.append({
                    "filename": cv_file.filename,
                    "error": f"Unsupported file type: {ext}. Allowed: pdf, docx, txt"
                })
                continue

            content = await cv_file.read()

            size_mb = len(content) / (1024 * 1024)
            if size_mb > settings.max_file_size_mb:
                failed.append({
                    "filename": cv_file.filename,
                    "error": f"File too large ({size_mb:.1f}MB). Max {settings.max_file_size_mb}MB."
                })
                continue

            # -----------------------------
            # SAVE FILE
            # -----------------------------
            os.makedirs(os.path.join(settings.upload_dir, "cvs"), exist_ok=True)

            safe_name = sanitize_filename(cv_file.filename)
            file_path = os.path.join(
                settings.upload_dir,
                "cvs",
                f"{correlation_id}_{safe_name}"
            )

            async with aiofiles.open(file_path, "wb") as f:
                await f.write(content)

            file_hash = compute_file_hash(content)

            # -----------------------------
            # CREATE CANDIDATE
            # BUG FIX: 'uploaded' is not in candidate_status enum.
            # Valid values: new, parsing, parsed, screened, shortlisted,
            # interview_scheduled, interviewed, offered, hired, rejected,
            # on_hold, withdrawn. Use 'new'.
            # -----------------------------
            candidate_id = str(uuid.uuid4())

            await db.execute(
                text("""
                    INSERT INTO candidates
                    (id, full_name, email, current_status, created_at)
                    VALUES
                    (:id, :name, :email, 'new', NOW())
                """),
                {
                    "id": candidate_id,
                    "name": cv_file.filename,
                    "email": None
                }
            )

            # -----------------------------
            # CREATE CV VERSION
            # -----------------------------
            cv_version_id = str(uuid.uuid4())

            await db.execute(
                text("""
                    INSERT INTO cv_versions
                    (
                        id,
                        candidate_id,
                        job_id,
                        original_filename,
                        stored_path,
                        file_format,
                        file_size_bytes,
                        file_hash,
                        ingestion_status,
                        correlation_id
                    )
                    VALUES
                    (
                        :id,
                        :candidate_id,
                        :job_id,
                        :fname,
                        :path,
                        :fmt,
                        :size,
                        :hash,
                        'pending',
                        :cid
                    )
                """),
                {
                    "id": cv_version_id,
                    "candidate_id": candidate_id,
                    "job_id": job_id,
                    "fname": cv_file.filename,
                    "path": file_path,
                    "fmt": ext,
                    "size": len(content),
                    "hash": file_hash,
                    "cid": correlation_id
                }
            )

            await db.commit()

            queued.append(cv_version_id)
            correlation_ids.append(correlation_id)

            # -----------------------------
            # BACKGROUND TASK
            # -----------------------------
            background_tasks.add_task(
                process_cv_pipeline,
                cv_version_id=cv_version_id,
                candidate_id=candidate_id,
                job_id=job_id,
                file_path=file_path,
                filename=cv_file.filename,
                file_hash=file_hash,
                correlation_id=correlation_id
            )

        except Exception as e:
            await db.rollback()
            failed.append({
                "filename": cv_file.filename,
                "error": str(e)
            })

    return BulkUploadResponse(
        total_received=len(cv_files),
        queued=len(queued),
        failed=len(failed),
        correlation_ids=correlation_ids,
        errors=failed
    )


# =====================================================
# BACKGROUND PIPELINE
# =====================================================
async def process_cv_pipeline(
    cv_version_id: str,
    candidate_id: str,
    job_id: str,
    file_path: str,
    filename: str,
    file_hash: str,
    correlation_id: str
):
    log = logger.bind(correlation_id=correlation_id)

    async with AsyncSessionLocal() as db:

        # -------------------------------------------------------
        # Outer try wraps everything so any unexpected exception
        # is caught, logged, and the cv_version marked failed.
        # -------------------------------------------------------
        try:

            await db.execute(
                text("UPDATE cv_versions SET ingestion_status='processing' WHERE id=:id"),
                {"id": cv_version_id}
            )
            await db.commit()

            # -----------------------------
            # AGENT 1: INGESTION
            # -----------------------------
            log.info("ingestion_started")
            ingestion = IngestionAgent(db)

            try:
                ing_result = await ingestion.run(
                    payload={"file_path": file_path, "filename": filename},
                    correlation_id=correlation_id
                )
            except Exception as e:
                log.error("ingestion_failed", error=str(e))
                await db.execute(
                    text("UPDATE cv_versions SET ingestion_status='failed' WHERE id=:id"),
                    {"id": cv_version_id}
                )
                await db.commit()
                return

            log.info("ingestion_completed")

            parsed_cv = ing_result.get("parsed_cv")
            if not parsed_cv:
                raise ValueError("parsed_cv missing from ingestion result")

            # -----------------------------
            # UPDATE CANDIDATE WITH REAL DATA
            # BUG FIX: if the extracted email already belongs to a
            # different candidate row (re-upload), skip setting it
            # to avoid unique constraint violation.
            # -----------------------------
            extracted_email = parsed_cv.get("email")
            if extracted_email:
                conflict = await db.execute(
                    text("SELECT id FROM candidates WHERE email=:email AND id != :id LIMIT 1"),
                    {"email": extracted_email, "id": candidate_id}
                )
                if conflict.fetchone():
                    extracted_email = None

            await db.execute(
                text("""
                    UPDATE candidates
                    SET full_name=:name, email=:email, last_updated_at=NOW()
                    WHERE id=:id
                """),
                {
                    "id": candidate_id,
                    "name": parsed_cv.get("full_name") or filename,
                    "email": extracted_email
                }
            )

            await db.execute(
                text("""
                    UPDATE cv_versions
                    SET
                        parsed_data=CAST(:data AS jsonb),
                        parse_confidence=:conf,
                        ingestion_status='done',
                        processed_at=NOW()
                    WHERE id=:id
                """),
                {
                    "id": cv_version_id,
                    "data": json.dumps(parsed_cv),
                    "conf": parsed_cv.get("parse_confidence", 0.5)
                }
            )
            await db.commit()

            # -----------------------------
            # FETCH JOB DESCRIPTION
            # -----------------------------
            jd_row = await db.execute(
                text("SELECT description_raw FROM jobs WHERE id=:id"),
                {"id": job_id}
            )
            jd = jd_row.fetchone()
            job_description = jd.description_raw if jd else ""

            # -----------------------------
            # AGENT 2: MATCHING
            # -----------------------------
            log.info("matching_started")
            matcher = MatchingAgent(db)

            try:
                match = await matcher.run(
                    payload={
                        "cv_version_id": cv_version_id,
                        "candidate_id": candidate_id,
                        "job_id": job_id,
                        "parsed_cv": parsed_cv,
                        "job_description": job_description
                    },
                    correlation_id=correlation_id
                )
            except Exception as e:
                log.error("matching_failed", error=str(e))
                await db.execute(
                    text("UPDATE cv_versions SET ingestion_status='failed' WHERE id=:id"),
                    {"id": cv_version_id}
                )
                await db.commit()
                return

            log.info("matching_done", composite=match.get("composite_score"))

            # -----------------------------
            # AGENT 3: POTENTIAL
            # BUG FIX: never raises — always returns a safe fallback dict
            # so pipeline continues even if potential agent fails.
            # -----------------------------
            log.info("potential_started")
            potential = PotentialAgent(db)

            try:
                pot = await potential.run(
                    payload={"parsed_cv": parsed_cv},
                    correlation_id=correlation_id
                )
            except Exception as e:
                log.error("potential_failed", error=str(e))
                pot = {
                    "potential_score": 0.5,
                    "value_add_insights": [],
                    "career_trajectory": "insufficient_data",
                    "growth_potential_label": "Insufficient data"
                }

            log.info("potential_done")

            # -----------------------------
            # AGENT 4: VALIDATION
            # BUG FIX: never raises — always returns safe fallback
            # so screening insert always happens.
            # -----------------------------
            log.info("validation_started")
            validator = ValidationAgent(db)

            try:
                val = await validator.run(
                    payload={
                        "candidate_id": candidate_id,
                        "job_id": job_id,
                        "cv_version_id": cv_version_id,
                        "file_hash": file_hash,
                        "parsed_cv": parsed_cv,
                        "composite_score": match["composite_score"],
                        "parse_confidence": parsed_cv.get("parse_confidence", 0.5)
                    },
                    correlation_id=correlation_id
                )
            except Exception as e:
                log.error("validation_failed", error=str(e))
                val = {"requires_review": False, "anomalies": [], "anomaly_count": 0}

            log.info("validation_done", anomalies=val.get("anomaly_count", 0))

            # -----------------------------
            # INSERT SCREENING RESULT
            # BUG FIX 1: :param::jsonb syntax breaks asyncpg named params.
            #            Use CAST(:param AS jsonb) instead.
            # BUG FIX 2: 'shortlisted' is not in screening_decision enum.
            #            Valid values: auto_shortlisted, auto_rejected,
            #            needs_review, hr_approved, hr_rejected, hr_hold,
            #            forwarded. Use 'auto_shortlisted' for high scores,
            #            'needs_review' otherwise.
            # -----------------------------
            composite = match["composite_score"]
            if val["requires_review"]:
                decision = "needs_review"
            elif composite >= 0.65:
                decision = "auto_shortlisted"
            else:
                decision = "needs_review"

            screening_id = str(uuid.uuid4())
            log.info("screening_insert_started", screening_id=screening_id)

            await db.execute(
                text("""
                    INSERT INTO screenings
                    (
                        id,
                        cv_version_id,
                        candidate_id,
                        job_id,
                        semantic_similarity,
                        relevance_score,
                        potential_score,
                        composite_score,
                        strengths,
                        gaps,
                        transferable_skills,
                        value_add_insights,
                        llm_rationale,
                        decision
                    )
                    VALUES
                    (
                        :id,
                        :cv,
                        :cand,
                        :job,
                        :sim,
                        :rel,
                        :pot,
                        :comp,
                        CAST(:str AS jsonb),
                        CAST(:gaps AS jsonb),
                        CAST(:trans AS jsonb),
                        CAST(:vai AS jsonb),
                        :rat,
                        :decision
                    )
                """),
                {
                    "id":       screening_id,
                    "cv":       cv_version_id,
                    "cand":     candidate_id,
                    "job":      job_id,
                    "sim":      match["semantic_similarity"],
                    "rel":      match["relevance_score"],
                    "pot":      pot.get("potential_score", 0.5),
                    "comp":     composite,
                    "str":      json.dumps(match.get("strengths", [])),
                    "gaps":     json.dumps(match.get("gaps", [])),
                    "trans":    json.dumps(match.get("transferable_skills", [])),
                    "vai":      json.dumps(pot.get("value_add_insights", [])),
                    "rat":      match.get("llm_rationale", ""),
                    "decision": decision
                }
            )

            # BUG FIX: 'screened' is valid in candidate_status enum — OK
            await db.execute(
                text("UPDATE candidates SET current_status='screened' WHERE id=:id"),
                {"id": candidate_id}
            )

            await db.commit()
            log.info("pipeline_complete", screening_id=screening_id, composite=composite, decision=decision)

        except Exception as e:
            await db.rollback()
            log.error("pipeline_failed", error=str(e))

            # Mark failed without raising so container stays healthy
            try:
                async with AsyncSessionLocal() as db2:
                    await db2.execute(
                        text("UPDATE cv_versions SET ingestion_status='failed' WHERE id=:id"),
                        {"id": cv_version_id}
                    )
                    await db2.commit()
            except Exception:
                pass


# =====================================================
# RESULTS
# =====================================================
@router.get("/results/{job_id}")
async def get_screening_results(
    job_id: str,
    min_score: float = 0.0,
    limit: int = 50,
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        text("""
            SELECT
                s.id                    AS screening_id,
                s.candidate_id,
                s.cv_version_id,
                s.job_id,
                s.semantic_similarity,
                s.relevance_score,
                s.potential_score,
                s.composite_score,
                s.strengths,
                s.gaps,
                s.transferable_skills,
                s.value_add_insights,
                s.llm_rationale,
                s.decision,
                s.decision_by,
                s.screened_at,
                c.full_name,
                c.email,
                c.is_returning,
                cv.original_filename,
                (
                    SELECT COUNT(*) FROM anomalies a
                    WHERE a.cv_version_id = s.cv_version_id
                ) AS anomaly_count
            FROM screenings s
            JOIN candidates c   ON c.id  = s.candidate_id
            JOIN cv_versions cv ON cv.id = s.cv_version_id
            WHERE s.job_id = :id
              AND s.composite_score >= :min_score
            ORDER BY s.composite_score DESC
            LIMIT :limit
        """),
        {"id": job_id, "min_score": min_score, "limit": limit}
    )

    return [dict(row._mapping) for row in result.fetchall()]


# =====================================================
# UPDATE DECISION
# =====================================================
@router.patch("/{screening_id}/decision")
async def update_decision(
    screening_id: str,
    decision: str = Form(...),
    decision_by: str = Form(None),
    db: AsyncSession = Depends(get_db)
):
    # BUG FIX: validate decision is a valid enum value before hitting DB
    valid_decisions = {
        "auto_shortlisted", "auto_rejected", "needs_review",
        "hr_approved", "hr_rejected", "hr_hold", "forwarded"
    }
    if decision not in valid_decisions:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid decision '{decision}'. Must be one of: {', '.join(sorted(valid_decisions))}"
        )

    await db.execute(
        text("""
            UPDATE screenings
            SET decision=:d, decision_by=:by, decision_at=NOW()
            WHERE id=:id
        """),
        {"d": decision, "by": decision_by, "id": screening_id}
    )
    await db.commit()

    return {"message": "updated"}
