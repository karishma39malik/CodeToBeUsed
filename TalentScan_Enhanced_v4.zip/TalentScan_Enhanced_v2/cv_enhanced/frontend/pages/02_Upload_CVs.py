import streamlit as st
import requests
import os
import time
import plotly.graph_objects as go
import sys
sys.path.insert(0, "/app/frontend")
from shared_style import CSS, topnav, badge_html, PLOTLY_CFG, FB_BLUE, FB_GREEN, FB_ORANGE, FB_RED, score_color

st.set_page_config(page_title="Upload CVs · TalentScan", page_icon="📤", layout="wide")
st.markdown(CSS, unsafe_allow_html=True)

API_BASE = os.getenv("API_URL", "http://api:8000")
API      = f"{API_BASE}/api/v1"

st.markdown(topnav("Upload CVs · Start Screening"), unsafe_allow_html=True)

# ── Sidebar ───────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="padding:0.5rem 0 1.2rem;">
      <div style="font-size:1.4rem;font-weight:900;color:#1877F2;letter-spacing:-0.5px;">TalentScan</div>
      <div style="font-size:0.72rem;color:#65676B;margin-top:2px;font-weight:600;">Upload CVs</div>
    </div><div style="height:1px;background:#E4E6EB;margin-bottom:1rem;"></div>
    """, unsafe_allow_html=True)
    st.page_link("app.py",                        label="🏠  Dashboard")
    st.page_link("pages/01_Post_a_Job.py",        label="📋  Post a Job")
    st.page_link("pages/02_Upload_CVs.py",        label="📤  Upload CVs")
    st.page_link("pages/03_Screening_Results.py", label="📊  Screening Results")
    st.page_link("pages/04_Candidate_History.py", label="📁  Candidate History")
    st.markdown("""<div style="margin-top:1.5rem;background:#F0F2F5;border-radius:8px;padding:10px 12px;">
      <div style="font-size:0.72rem;font-weight:700;color:#65676B;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;">Pipeline Steps</div>
      <div style="font-size:0.75rem;color:#050505;line-height:2.0;">
        1️⃣ Ingestion Agent<br>2️⃣ Matching Agent<br>3️⃣ Potential Agent<br>4️⃣ Validation Agent
      </div>
    </div>""", unsafe_allow_html=True)

# ── Fetch jobs ─────────────────────────────────────────────────
try:
    jobs_resp = requests.get(f"{API}/jobs/", timeout=5)
    jobs = jobs_resp.json() if jobs_resp.status_code == 200 else []
    if not isinstance(jobs, list): jobs = []
    job_options = {j['title']: j['id'] for j in jobs}
except Exception as e:
    st.error(f"Cannot connect to API: {e}")
    st.stop()

if not job_options:
    st.warning("No active roles found. Please post a job first.")
    st.stop()

# ── Layout: form + pipeline visualiser ────────────────────────
upload_col, pipe_col = st.columns([3, 2], gap="large")

with upload_col:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Upload Configuration</div>', unsafe_allow_html=True)

    selected_label  = st.selectbox("Select Role", list(job_options.keys()))
    selected_job_id = job_options[selected_label]
    uploaded_by     = st.text_input("Your Name", placeholder="HR Officer full name")

    cv_files = st.file_uploader(
        "Upload CVs (PDF, DOCX, or TXT)",
        type=["pdf", "docx", "txt"],
        accept_multiple_files=True,
        help="Upload multiple CVs at once — each will be processed through the 4-agent pipeline"
    )

    if cv_files:
        st.markdown(f'<div style="font-size:0.78rem;color:#65676B;margin:8px 0;">{len(cv_files)} file(s) selected</div>', unsafe_allow_html=True)
        for f in cv_files[:5]:
            size_kb = len(f.getvalue()) / 1024
            ext = f.name.split(".")[-1].upper()
            ext_color = {"PDF":"#FA3E3E","DOCX":"#1877F2","TXT":"#42B72A"}.get(ext, "#65676B")
            st.markdown(f"""<div style="display:flex;align-items:center;gap:10px;padding:6px 10px;background:#F0F2F5;border-radius:6px;margin:4px 0;">
              <span style="background:{ext_color};color:white;font-size:0.65rem;font-weight:700;padding:2px 6px;border-radius:3px;">{ext}</span>
              <span style="font-size:0.8rem;color:#050505;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{f.name}</span>
              <span style="font-size:0.72rem;color:#BCC0C4;">{size_kb:.0f} KB</span>
            </div>""", unsafe_allow_html=True)
        if len(cv_files) > 5:
            st.markdown(f'<div style="font-size:0.72rem;color:#BCC0C4;padding:4px 10px;">+ {len(cv_files)-5} more files</div>', unsafe_allow_html=True)

    st.markdown("", unsafe_allow_html=True)
    start = st.button("🚀  Start Screening Pipeline", use_container_width=True)
    st.markdown('</div>', unsafe_allow_html=True)

    if start:
        if not cv_files:
            st.error("Please upload at least one CV file.")
        elif not uploaded_by.strip():
            st.error("Please enter your name.")
        else:
            progress = st.progress(0, text="Preparing upload…")
            try:
                file_tuples = [("cv_files",(f.name,f.getvalue(),f.type or "application/octet-stream")) for f in cv_files]
                progress.progress(30, text="Sending to API…")
                resp = requests.post(
                    f"{API}/screenings/upload",
                    data={"job_id": selected_job_id, "uploaded_by": uploaded_by.strip()},
                    files=file_tuples, timeout=180,
                )
                progress.progress(100, text="Upload complete!")
                if resp.status_code != 200:
                    st.error(f"Upload failed ({resp.status_code})")
                    try: st.json(resp.json())
                    except: st.text(resp.text)
                    st.stop()
                result = resp.json()
                total_r = result.get("total_received", 0)
                queued  = result.get("queued", 0)
                failed  = result.get("failed", 0)
                errors  = result.get("errors", [])

                st.success(f"✅ {queued} CV(s) queued for AI processing!")
                r1,r2,r3 = st.columns(3)
                r1.metric("Received", total_r)
                r2.metric("Queued",   queued)
                r3.metric("Failed",   failed, delta=f"-{failed}" if failed else None, delta_color="inverse")

                if errors:
                    with st.expander(f"⚠️ {len(errors)} file(s) failed"):
                        for e in errors:
                            st.markdown(f'<div style="font-size:0.8rem;color:#FA3E3E;padding:2px 0;">• {e.get("filename","?")} — {e.get("error","")}</div>', unsafe_allow_html=True)

                st.info("⏳ Pipeline is running in background (3–5 min per CV on CPU). Check Screening Results when complete.")
            except requests.exceptions.Timeout:
                st.error("Request timed out. Try with fewer files.")
                progress.empty()
            except Exception as e:
                st.error(str(e))
                progress.empty()

with pipe_col:
    # Pipeline architecture chart
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Pipeline Architecture</div>', unsafe_allow_html=True)

    agents = ["Ingestion", "Matching", "Potential", "Validation", "Result"]
    fig_pipe = go.Figure()
    for i, agent in enumerate(agents):
        color = [FB_BLUE, "#6366F1", FB_ORANGE, "#8B5CF6", FB_GREEN][i]
        fig_pipe.add_trace(go.Scatter(
            x=[i], y=[0], mode="markers+text",
            marker=dict(size=48, color=color, line=dict(color="white",width=3)),
            text=[f"{i+1}"], textfont=dict(size=14, color="white"),
            textposition="middle center", showlegend=False,
            hovertemplate=f"{agent} Agent<extra></extra>",
            name=agent
        ))
        fig_pipe.add_annotation(x=i, y=-0.35, text=agent,
                                showarrow=False, font=dict(size=10,color="#65676B"))
        if i < len(agents)-1:
            fig_pipe.add_annotation(x=i+0.55, y=0, text="→",
                                    showarrow=False, font=dict(size=18,color="#CED0D4"))

    fig_pipe.update_layout(height=160, margin=dict(t=20,b=40,l=20,r=20),
                           paper_bgcolor="#FFFFFF", plot_bgcolor="#FFFFFF",
                           xaxis=dict(visible=False,range=[-0.5,4.5]),
                           yaxis=dict(visible=False,range=[-0.7,0.5]),
                           font={"family":"system-ui"})
    st.plotly_chart(fig_pipe, use_container_width=True, config=PLOTLY_CFG)
    st.markdown('</div>', unsafe_allow_html=True)

    # Processing time estimate
    n_files = len(cv_files) if cv_files else 0
    est_min = n_files * 4
    st.markdown(f"""<div class="fb-card">
      <div class="sec-label">Estimated Processing Time</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
        <div class="metric-card"><div class="metric-val">{n_files}</div><div class="metric-lbl">Files Selected</div></div>
        <div class="metric-card"><div class="metric-val" style="color:#1877F2;">~{est_min}m</div><div class="metric-lbl">Estimated Time</div></div>
      </div>
      <div style="font-size:0.72rem;color:#BCC0C4;margin-top:10px;">~4 min per CV on CPU · Ollama LLaMA 3.1 8B</div>
    </div>""", unsafe_allow_html=True)

    # Job pipeline status
    try:
        pipe = requests.get(f"{API}/jobs/{selected_job_id}/pipeline", timeout=5).json()
        total_ = pipe.get("total_screened", 0)
        pend_  = pipe.get("pending_review", 0)
        avg_   = pipe.get("avg_score") or 0
        st.markdown(f"""<div class="fb-card">
          <div class="sec-label">Current Role Status — {selected_label}</div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;">
            <div class="metric-card" style="padding:0.7rem;"><div class="metric-val" style="font-size:1.4rem;">{total_}</div><div class="metric-lbl">Screened</div></div>
            <div class="metric-card" style="padding:0.7rem;"><div class="metric-val" style="font-size:1.4rem;color:#F5A623;">{pend_}</div><div class="metric-lbl">Pending</div></div>
            <div class="metric-card" style="padding:0.7rem;"><div class="metric-val" style="font-size:1.4rem;color:#1877F2;">{f"{avg_:.0%}" if avg_ else "—"}</div><div class="metric-lbl">Avg Score</div></div>
          </div>
        </div>""", unsafe_allow_html=True)
    except Exception:
        pass

    # Supported formats card
    st.markdown("""<div class="fb-card">
      <div class="sec-label">Supported Formats</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <span style="background:#FFEBEE;color:#C62828;font-weight:700;font-size:0.75rem;padding:4px 10px;border-radius:4px;">PDF</span>
        <span style="background:#E7F0FF;color:#1877F2;font-weight:700;font-size:0.75rem;padding:4px 10px;border-radius:4px;">DOCX</span>
        <span style="background:#E7F3E8;color:#1A6B1E;font-weight:700;font-size:0.75rem;padding:4px 10px;border-radius:4px;">TXT</span>
      </div>
      <div style="font-size:0.72rem;color:#BCC0C4;margin-top:8px;">Max 20MB per file · Up to 500 files per batch</div>
    </div>""", unsafe_allow_html=True)
