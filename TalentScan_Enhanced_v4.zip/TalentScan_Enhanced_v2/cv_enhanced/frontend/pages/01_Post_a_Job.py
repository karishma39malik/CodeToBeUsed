import streamlit as st
import requests
import os
import plotly.graph_objects as go
import sys
sys.path.insert(0, "/app/frontend")
from shared_style import CSS, topnav, badge_html, PLOTLY_CFG, score_color, pool_bar, donut, FB_BLUE, FB_GREEN, FB_ORANGE

st.set_page_config(page_title="Post a Job · TalentScan", page_icon="📋", layout="wide")
st.markdown(CSS, unsafe_allow_html=True)

API_BASE = os.getenv("API_URL", "http://api:8000")
API      = f"{API_BASE}/api/v1"

st.markdown(topnav("Post a Job · Create a Role"), unsafe_allow_html=True)

# ── Sidebar ───────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="padding:0.5rem 0 1.2rem;">
      <div style="font-size:1.4rem;font-weight:900;color:#1877F2;letter-spacing:-0.5px;">TalentScan</div>
      <div style="font-size:0.72rem;color:#65676B;margin-top:2px;font-weight:600;">Post a Role</div>
    </div><div style="height:1px;background:#E4E6EB;margin-bottom:1rem;"></div>
    """, unsafe_allow_html=True)
    st.page_link("app.py",                        label="🏠  Dashboard")
    st.page_link("pages/01_Post_a_Job.py",        label="📋  Post a Job")
    st.page_link("pages/02_Upload_CVs.py",        label="📤  Upload CVs")
    st.page_link("pages/03_Screening_Results.py", label="📊  Screening Results")
    st.page_link("pages/04_Candidate_History.py", label="📁  Candidate History")
    st.markdown("""<div style="margin-top:1.5rem;background:#F0F2F5;border-radius:8px;padding:10px 12px;">
      <div style="font-size:0.72rem;font-weight:700;color:#65676B;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;">How it works</div>
      <div style="font-size:0.75rem;color:#050505;line-height:1.9;">
        1. Fill in role details<br>
        2. Upload JD (PDF or TXT)<br>
        3. System generates embeddings<br>
        4. Role is ready for CV upload
      </div>
    </div>""", unsafe_allow_html=True)

# ── Layout: form + stats ──────────────────────────────────────
form_col, stats_col = st.columns([3, 2], gap="large")

with form_col:
    st.markdown('<div class="fb-card-lg">', unsafe_allow_html=True)
    st.markdown('<div class="sec-label">Role Details</div>', unsafe_allow_html=True)

    with st.form("post_job_form"):
        c1, c2 = st.columns(2)
        with c1:
            title  = st.text_input("Job Title *", placeholder="e.g. Senior Data Engineer")
            dept   = st.text_input("Department",  placeholder="e.g. Technology")
        with c2:
            loc    = st.text_input("Location",    placeholder="e.g. Dubai, UAE")
            posted_by = st.text_input("Your Name *", placeholder="HR Manager name")

        jd_file = st.file_uploader("Upload Job Description *", type=["txt","pdf"],
                                   help="PDF or plain text · minimum 100 characters")
        st.markdown("")
        submitted = st.form_submit_button("🚀  Post Role & Generate Embeddings",
                                          type="primary", use_container_width=True)
    st.markdown('</div>', unsafe_allow_html=True)

    if submitted:
        if not all([title, posted_by, jd_file]):
            st.error("Please fill all required fields (*) and upload a JD file.")
        else:
            with st.spinner("Generating semantic embeddings via Ollama…"):
                try:
                    resp = requests.post(
                        f"{API}/jobs/",
                        data={"title":title,"department":dept,"location":loc,"created_by":posted_by},
                        files={"jd_file":(jd_file.name, jd_file.getvalue(), jd_file.type or "text/plain")},
                        timeout=90,
                    )
                    if resp.status_code == 201:
                        job = resp.json()
                        st.success("✅ Role posted successfully!")
                        st.markdown(f"""<div class="fb-card-blue">
                          <div style="font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:#1877F2;margin-bottom:6px;">Role Created</div>
                          <div style="font-weight:700;font-size:1rem;color:#050505;margin-bottom:4px;">{job.get('title','')}</div>
                          <div style="font-family:monospace;font-size:0.78rem;color:#65676B;">ID: {job.get('id','')}</div>
                          <div style="font-size:0.75rem;color:#65676B;margin-top:6px;">Share this ID with your team to upload CVs against this role.</div>
                        </div>""", unsafe_allow_html=True)
                        st.balloons()
                    else:
                        st.error(f"Error: {resp.json().get('detail','Unknown error')}")
                except requests.exceptions.ConnectionError:
                    st.error("Cannot connect to API.")
                except Exception as e:
                    st.error(str(e))

with stats_col:
    # Fetch existing jobs for stats
    try:
        jobs = requests.get(f"{API}/jobs/", timeout=5).json()
        if not isinstance(jobs, list): jobs = []
    except Exception:
        jobs = []

    # Metrics
    st.markdown(f"""<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;">
      <div class="metric-card"><div class="metric-val">{len(jobs)}</div><div class="metric-lbl">Active Roles</div></div>
      <div class="metric-card"><div class="metric-val" style="color:#1877F2;">AI</div><div class="metric-lbl">Embedding Ready</div></div>
    </div>""", unsafe_allow_html=True)

    # Dept distribution donut
    if jobs:
        from collections import Counter
        depts = Counter(j.get("department") or "Other" for j in jobs)
        fig_d = go.Figure(go.Pie(
            labels=list(depts.keys()), values=list(depts.values()),
            hole=0.5, textinfo="label+value",
            textfont=dict(size=10),
            marker=dict(line=dict(color="white",width=2)),
            hovertemplate="%{label}: %{value}<extra></extra>"
        ))
        fig_d.update_layout(title=dict(text="Roles by Department",font=dict(size=11,color="#65676B"),x=0.02),
                            height=230, margin=dict(t=40,b=10,l=10,r=10),
                            paper_bgcolor="#FFFFFF", showlegend=False, font={"family":"system-ui"})
        st.markdown('<div class="fb-card-lg">', unsafe_allow_html=True)
        st.plotly_chart(fig_d, use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)

    # Location bar
    if jobs:
        locs = Counter(j.get("location") or "Unknown" for j in jobs)
        fig_l = go.Figure(go.Bar(
            x=list(locs.values()), y=list(locs.keys()),
            orientation="h", marker_color=FB_BLUE, marker_opacity=0.75,
            text=list(locs.values()), textposition="outside",
            hovertemplate="%{y}: %{x}<extra></extra>", showlegend=False
        ))
        fig_l.update_layout(title=dict(text="Roles by Location",font=dict(size=11,color="#65676B"),x=0.02),
                            height=max(180, len(locs)*35+60),
                            margin=dict(t=40,b=10,l=10,r=40),
                            paper_bgcolor="#FFFFFF", plot_bgcolor="#FFFFFF",
                            xaxis=dict(visible=False), yaxis=dict(tickfont=dict(size=10,color="#050505")),
                            font={"family":"system-ui"})
        st.markdown('<div class="fb-card-lg">', unsafe_allow_html=True)
        st.plotly_chart(fig_l, use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)

# ── Active postings ───────────────────────────────────────────
st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="sec-label">Active Postings</div>', unsafe_allow_html=True)

try:
    jobs = requests.get(f"{API}/jobs/", timeout=5).json()
    if not isinstance(jobs, list): jobs = []
except Exception:
    jobs = []

if jobs:
    for job in jobs:
        d = job.get('department') or '—'
        l = job.get('location')   or '—'
        dt= (job.get('created_at') or '')[:10]
        ini = (job.get('title') or 'J')[0].upper()
        with st.expander(f"📋  {job['title']}  ·  {d}  ·  {l}"):
            ec1, ec2 = st.columns([3,1])
            with ec1:
                st.markdown(f"""<div style="font-size:0.8rem;color:#65676B;line-height:2;">
                  <b>Department:</b> {d}<br>
                  <b>Location:</b> {l}<br>
                  <b>Created:</b> {dt}
                </div>""", unsafe_allow_html=True)
            with ec2:
                st.markdown('<div class="sec-label">Job ID</div>', unsafe_allow_html=True)
                st.code(job['id'], language=None)
else:
    st.markdown("""<div class="fb-card" style="text-align:center;padding:2rem;">
      <div style="font-size:1.8rem;margin-bottom:0.5rem;">📋</div>
      <div style="font-weight:700;margin-bottom:4px;">No active roles yet</div>
      <div style="font-size:0.82rem;color:#65676B;">Post your first role using the form above.</div>
    </div>""", unsafe_allow_html=True)
