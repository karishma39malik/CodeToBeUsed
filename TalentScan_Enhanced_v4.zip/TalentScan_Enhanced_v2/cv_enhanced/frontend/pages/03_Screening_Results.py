"""
TalentScan AI — Screening Intelligence Dashboard
Design: Facebook / Meta — white cards, blue-dominant, rounded, generous spacing
Charts: Plotly interactive (gauge, radar, waterfall, bar, pie)
"""

import streamlit as st
import requests
import json
import os
import time
import plotly.graph_objects as go

st.set_page_config(
    page_title="TalentScan · Screening Results",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded"
)

API_BASE = os.getenv("API_URL", "http://api:8000")
API      = f"{API_BASE}/api/v1"

FB_BLUE   = "#1877F2"
FB_GREEN  = "#42B72A"
FB_ORANGE = "#F5A623"
FB_RED    = "#FA3E3E"
FB_GREY   = "#BCC0C4"
PLOT_BG   = "#FFFFFF"

st.markdown("""
<style>
html, body, [class*="css"] {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  font-size: 15px;
}
.stApp { background: #F0F2F5 !important; }
.block-container { padding: 0 1.5rem 3rem !important; max-width: 1280px; }
header, [data-testid="stHeader"] { background: #FFFFFF !important; border-bottom: 1px solid #CED0D4 !important; }
section[data-testid="stSidebar"] { background: #FFFFFF !important; border-right: 1px solid #CED0D4 !important; }
h1,h2,h3,h4 { color: #050505 !important; }
p,li { color: #050505 !important; }
label { color: #65676B !important; font-size:0.8rem !important; }

.fb-nav { background:#1877F2; padding:0 1.5rem; height:56px; display:flex; align-items:center; justify-content:space-between; margin:-0.1rem -1.5rem 1.5rem -1.5rem; }
.fb-nav-logo { font-size:1.5rem; font-weight:900; color:#FFFFFF; letter-spacing:-0.5px; }
.fb-nav-title { font-size:0.85rem; font-weight:600; color:rgba(255,255,255,0.85); background:rgba(255,255,255,0.15); padding:6px 14px; border-radius:20px; }
.fb-nav-right { font-size:0.78rem; color:rgba(255,255,255,0.6); }

.fb-card { background:#FFFFFF; border-radius:8px; border:1px solid #CED0D4; padding:1.2rem 1.4rem; margin-bottom:12px; box-shadow:0 1px 2px rgba(0,0,0,0.06); }
.fb-card-lg { background:#FFFFFF; border-radius:8px; border:1px solid #CED0D4; padding:1.5rem; margin-bottom:16px; box-shadow:0 1px 2px rgba(0,0,0,0.06); }

.sec-label { font-size:0.72rem; font-weight:700; text-transform:uppercase; letter-spacing:0.08em; color:#65676B; margin-bottom:10px; }

.cand-header { display:flex; align-items:center; gap:14px; padding-bottom:14px; border-bottom:1px solid #E4E6EB; margin-bottom:14px; }
.cand-avatar { width:52px; height:52px; border-radius:50%; background:#1877F2; display:flex; align-items:center; justify-content:center; font-size:1.1rem; font-weight:700; color:#FFFFFF; flex-shrink:0; }
.cand-name  { font-size:1.3rem; font-weight:700; color:#050505; line-height:1.2; }
.cand-email { font-size:0.82rem; color:#65676B; margin-top:2px; }
.cand-file  { font-size:0.75rem; color:#BCC0C4; margin-top:1px; }

.badge { display:inline-flex; align-items:center; gap:5px; padding:4px 12px; border-radius:20px; font-size:0.78rem; font-weight:600; }
.badge-green  { background:#E7F3E8; color:#1A6B1E; }
.badge-blue   { background:#E7F0FF; color:#1877F2; }
.badge-orange { background:#FFF3E0; color:#E65100; }
.badge-red    { background:#FFEBEE; color:#C62828; }
.badge-grey   { background:#F0F2F5; color:#65676B; }
.badge-dot    { width:7px; height:7px; border-radius:50%; }

.sbar-row { margin:10px 0; }
.sbar-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:5px; }
.sbar-name { font-size:0.8rem; font-weight:600; color:#050505; }
.sbar-weight { font-size:0.7rem; color:#BCC0C4; }
.sbar-val  { font-size:0.85rem; font-weight:700; }
.sbar-track { height:8px; background:#F0F2F5; border-radius:4px; overflow:hidden; }
.sbar-fill  { height:100%; border-radius:4px; }
.fill-blue   { background:linear-gradient(90deg,#1877F2,#42A5F5); }
.fill-green  { background:linear-gradient(90deg,#42B72A,#66BB6A); }
.fill-orange { background:linear-gradient(90deg,#F5A623,#FFB74D); }
.fill-red    { background:linear-gradient(90deg,#FA3E3E,#EF5350); }

.sg-grid { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
.sg-box { border-radius:8px; padding:1rem; }
.sg-box-s { background:#E7F3E8; border:1px solid #B5DFBB; }
.sg-box-g { background:#FFF3E0; border:1px solid #FFCC80; }
.sg-box-label { font-size:0.72rem; font-weight:700; text-transform:uppercase; letter-spacing:0.08em; margin-bottom:8px; }
.sg-label-s { color:#1A6B1E; }
.sg-label-g { color:#E65100; }
.sg-item { display:flex; gap:8px; align-items:flex-start; padding:5px 0; font-size:0.8rem; line-height:1.5; border-bottom:1px solid rgba(0,0,0,0.05); }
.sg-item:last-child { border-bottom:none; }
.sg-bullet-s { color:#42B72A; margin-top:3px; font-size:0.6rem; flex-shrink:0; }
.sg-bullet-g { color:#F5A623; margin-top:3px; font-size:0.6rem; flex-shrink:0; }
.sg-text-s { color:#1B5E20; }
.sg-text-g { color:#BF360C; }

.chip-wrap { display:flex; flex-wrap:wrap; gap:6px; margin-top:6px; }
.chip { padding:4px 12px; border-radius:20px; font-size:0.75rem; font-weight:600; }
.chip-tech   { background:#E7F0FF; color:#1877F2; border:1px solid #BBD3FB; }
.chip-domain { background:#F3E8FF; color:#6B2FA0; border:1px solid #DDB8FA; }

.insight-item { background:#F0F2F5; border-left:3px solid #1877F2; border-radius:0 6px 6px 0; padding:10px 14px; margin-bottom:8px; font-size:0.82rem; color:#050505; line-height:1.7; }
.insight-num { font-size:0.65rem; font-weight:700; text-transform:uppercase; letter-spacing:0.1em; color:#1877F2; margin-bottom:3px; }

.rationale-box { background:#F0F2F5; border-radius:8px; border:1px solid #CED0D4; padding:1.2rem 1.4rem; font-size:0.85rem; color:#050505; line-height:1.85; font-style:italic; }
.rationale-label { font-size:0.7rem; font-weight:700; text-transform:uppercase; letter-spacing:0.1em; color:#1877F2; margin-bottom:8px; }
.rationale-footer { margin-top:10px; font-size:0.7rem; color:#BCC0C4; font-style:normal; }

.signal-strip { display:grid; grid-template-columns:repeat(4,1fr); gap:1px; background:#CED0D4; border-radius:8px; overflow:hidden; margin-top:8px; }
.signal-cell { background:#FFFFFF; padding:14px 16px; }
.signal-val  { font-size:1.5rem; font-weight:700; color:#050505; line-height:1; }
.signal-lbl  { font-size:0.7rem; font-weight:600; text-transform:uppercase; letter-spacing:0.06em; color:#65676B; margin-top:3px; }
.signal-sub  { font-size:0.72rem; color:#BCC0C4; margin-top:2px; }

.conf-row   { display:flex; align-items:center; gap:10px; margin-top:10px; }
.conf-label { font-size:0.72rem; font-weight:600; color:#65676B; width:120px; flex-shrink:0; }
.conf-track { flex:1; height:6px; background:#F0F2F5; border-radius:3px; overflow:hidden; }
.conf-fill  { height:100%; background:#1877F2; border-radius:3px; }
.conf-pct   { font-size:0.75rem; font-weight:700; color:#1877F2; width:32px; text-align:right; }

.stButton > button { background:#1877F2 !important; color:#FFFFFF !important; border:none !important; border-radius:6px !important; font-weight:700 !important; font-size:0.82rem !important; padding:8px 16px !important; }
.stButton > button:hover { background:#166FE5 !important; }
.stSelectbox > div > div { background:#FFFFFF !important; border-color:#CED0D4 !important; border-radius:6px !important; color:#050505 !important; }
.stTextInput > div > div { background:#FFFFFF !important; border-color:#CED0D4 !important; border-radius:6px !important; }
.stTextInput input { color:#050505 !important; }
.stMultiSelect > div { background:#FFFFFF !important; border-color:#CED0D4 !important; border-radius:6px !important; }
[data-testid="stMetricValue"] { color:#050505 !important; font-weight:700 !important; }
[data-testid="stMetricLabel"] { color:#65676B !important; font-size:0.72rem !important; font-weight:600 !important; }
div[data-testid="stExpander"] { background:#FFFFFF !important; border:1px solid #CED0D4 !important; border-radius:8px !important; margin-bottom:8px !important; }
div[data-testid="stExpander"] summary { font-weight:600 !important; color:#050505 !important; }
</style>
""", unsafe_allow_html=True)


# ── Helpers ───────────────────────────────────────────────────
def parse_list(val):
    if isinstance(val, list): return val
    if not val: return []
    try:
        r = json.loads(val)
        return r if isinstance(r, list) else [str(r)]
    except Exception:
        return [str(val)] if val else []

def score_color(s):
    return FB_GREEN if s >= 0.65 else (FB_ORANGE if s >= 0.45 else FB_RED)

def fill_cls(s):
    return "fill-green" if s >= 0.65 else ("fill-orange" if s >= 0.45 else "fill-red")

def badge_html(decision):
    d = decision.lower()
    label = decision.replace("_", " ").title()
    if "shortlisted" in d or "approved" in d: cls, dot = "badge-green",  "#42B72A"
    elif "rejected" in d:                      cls, dot = "badge-red",    "#FA3E3E"
    elif "hold" in d:                          cls, dot = "badge-grey",   "#BCC0C4"
    elif "forward" in d:                       cls, dot = "badge-blue",   "#1877F2"
    else:                                      cls, dot = "badge-orange", "#F5A623"
    return f'<span class="badge {cls}"><span class="badge-dot" style="background:{dot};"></span>{label}</span>'

def initials(name):
    parts = (name or "?").split()
    return "".join(p[0] for p in parts[:2]).upper()

def subscore_html(name, value, weight):
    pct = int(value * 100)
    col = score_color(value)
    fc  = fill_cls(value)
    return f"""<div class="sbar-row">
      <div class="sbar-header">
        <span class="sbar-name">{name} <span class="sbar-weight">{weight}</span></span>
        <span class="sbar-val" style="color:{col};">{pct}%</span>
      </div>
      <div class="sbar-track"><div class="sbar-fill {fc}" style="width:{pct}%;"></div></div>
    </div>"""

TECH_KW = {"python","sql","spark","cloud","azure","aws","gcp","kafka","airflow","api",
            "ml","ai","etl","pipeline","databricks","power bi","tableau","data",
            "engineering","model","docker","scala","java"}


# ── Chart builders ────────────────────────────────────────────
def gauge_chart(value):
    pct   = value * 100
    color = score_color(value)
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=pct,
        number={"suffix": "%", "font": {"size": 40, "color": "#050505"}},
        title={"text": "Composite Score", "font": {"size": 12, "color": "#65676B"}},
        gauge={
            "axis": {"range": [0, 100], "tickvals": [0,25,50,75,100],
                     "tickfont": {"size": 9, "color": "#BCC0C4"}, "tickwidth": 0},
            "bar": {"color": color, "thickness": 0.25},
            "bgcolor": "#F0F2F5", "borderwidth": 0,
            "steps": [{"range": [0,45], "color": "#FFEBEE"},
                      {"range": [45,65], "color": "#FFF3E0"},
                      {"range": [65,100], "color": "#E7F3E8"}],
            "threshold": {"line": {"color": color, "width": 3}, "thickness": 0.8, "value": pct}
        }
    ))
    fig.update_layout(height=220, margin=dict(t=30,b=10,l=20,r=20),
                      paper_bgcolor=PLOT_BG, font={"family": "system-ui"})
    return fig


def radar_chart(rel, sem, pot):
    cats = ["Relevance<br>Score", "Semantic<br>Similarity", "Potential<br>Score"]
    vals = [rel*100, sem*100, pot*100]
    fig  = go.Figure(go.Scatterpolar(
        r=vals+[vals[0]], theta=cats+[cats[0]],
        fill="toself", fillcolor="rgba(24,119,242,0.12)",
        line=dict(color=FB_BLUE, width=2),
        marker=dict(color=FB_BLUE, size=6),
        hovertemplate="%{theta}: %{r:.0f}%<extra></extra>"
    ))
    fig.update_layout(
        polar=dict(
            bgcolor="#F0F2F5",
            radialaxis=dict(visible=True, range=[0,100], tickvals=[0,25,50,75,100],
                            tickfont=dict(size=9, color="#BCC0C4"), gridcolor="#E4E6EB"),
            angularaxis=dict(tickfont=dict(size=11, color="#050505"), gridcolor="#E4E6EB")
        ),
        showlegend=False, height=260, margin=dict(t=20,b=20,l=50,r=50),
        paper_bgcolor=PLOT_BG, font={"family": "system-ui"}
    )
    return fig


def waterfall_chart(rel, sem, pot, composite):
    r = rel*0.40*100;  s = sem*0.35*100;  p = pot*0.25*100
    color = score_color(composite)
    fig = go.Figure(go.Waterfall(
        orientation="v",
        measure=["relative","relative","relative","total"],
        x=["Relevance<br>×40%","Semantic<br>×35%","Potential<br>×25%","Composite<br>Score"],
        y=[r, s, p, 0],
        text=[f"{r:.1f}",f"{s:.1f}",f"{p:.1f}",f"{composite*100:.1f}"],
        textposition="outside",
        textfont={"size": 11, "color": "#050505"},
        increasing={"marker": {"color": FB_BLUE}},
        totals={"marker": {"color": color}},
        connector={"line": {"color": "#E4E6EB", "width": 1}},
        hovertemplate="%{x}: %{y:.1f} pts<extra></extra>"
    ))
    fig.update_layout(
        height=280, margin=dict(t=30,b=10,l=10,r=10),
        paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
        xaxis=dict(showgrid=False, tickfont=dict(size=11, color="#050505")),
        yaxis=dict(range=[0,110], gridcolor="#F0F2F5",
                   tickfont=dict(size=10, color="#65676B"), title="Score Points"),
        showlegend=False, font={"family": "system-ui"}
    )
    return fig


def pool_bar_chart(results):
    if len(results) < 2: return None
    names  = [r.get("full_name") or f"#{i+1}" for i,r in enumerate(results)]
    scores = [r.get("composite_score",0)*100 for r in results]
    colors = [score_color(s/100) for s in scores]
    fig = go.Figure(go.Bar(
        x=names, y=scores, marker_color=colors,
        text=[f"{s:.0f}%" for s in scores], textposition="outside",
        textfont=dict(size=11, color="#050505"),
        hovertemplate="%{x}: %{y:.1f}%<extra></extra>", showlegend=False
    ))
    fig.add_hline(y=65, line_dash="dot", line_color=FB_GREEN,
                  annotation_text="Shortlist threshold",
                  annotation_font_size=10, annotation_font_color=FB_GREEN)
    fig.update_layout(
        height=300, margin=dict(t=30,b=10,l=10,r=10),
        paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
        xaxis=dict(tickfont=dict(size=11, color="#050505"), showgrid=False),
        yaxis=dict(range=[0,115], gridcolor="#F0F2F5",
                   tickfont=dict(size=10, color="#65676B"), title="Score (%)"),
        bargap=0.35, font={"family": "system-ui"}
    )
    return fig


def pie_chart(results):
    from collections import Counter
    counts = Counter(r.get("decision","unknown") for r in results)
    labels = list(counts.keys())
    values = list(counts.values())
    cmap   = {"auto_shortlisted":FB_GREEN,"hr_approved":FB_GREEN,
               "needs_review":FB_ORANGE,"hr_hold":FB_GREY,
               "auto_rejected":FB_RED,"hr_rejected":FB_RED,"forwarded":FB_BLUE}
    colors = [cmap.get(l, FB_GREY) for l in labels]
    fig = go.Figure(go.Pie(
        labels=[l.replace("_"," ").title() for l in labels],
        values=values, hole=0.6,
        marker=dict(colors=colors, line=dict(color="white", width=2)),
        textinfo="label+percent",
        textfont=dict(size=11),
        hovertemplate="%{label}: %{value}<extra></extra>"
    ))
    fig.update_layout(
        height=260, margin=dict(t=20,b=20,l=20,r=20),
        paper_bgcolor=PLOT_BG, showlegend=False,
        font={"family": "system-ui"},
        annotations=[dict(text=f"<b>{sum(values)}</b><br>Total",
                          x=0.5, y=0.5, font_size=14, showarrow=False,
                          font_color="#050505")]
    )
    return fig


def hbar_chart(items, color=FB_BLUE):
    if not items: return None
    labels = [s[:45]+"…" if len(s)>45 else s for s in items[:8]]
    fig = go.Figure(go.Bar(
        x=list(range(len(labels),0,-1)), y=labels,
        orientation="h", marker_color=color, marker_opacity=0.75,
        hovertemplate="%{y}<extra></extra>", showlegend=False,
        text=labels, textposition="inside",
        insidetextanchor="start", textfont=dict(color="white", size=11)
    ))
    fig.update_layout(
        height=max(160, len(labels)*32+40), margin=dict(t=10,b=10,l=10,r=10),
        paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
        xaxis=dict(visible=False), yaxis=dict(visible=False),
        bargap=0.3, font={"family": "system-ui"}
    )
    return fig


# ── Sidebar ───────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="padding:0.5rem 0 1.2rem;">
      <div style="font-size:1.4rem;font-weight:900;color:#1877F2;letter-spacing:-0.5px;">TalentScan</div>
      <div style="font-size:0.72rem;color:#65676B;margin-top:2px;font-weight:600;">AI Screening Intelligence</div>
    </div>
    <div style="height:1px;background:#E4E6EB;margin-bottom:1rem;"></div>
    """, unsafe_allow_html=True)

    try:
        jobs_resp = requests.get(f"{API}/jobs/", timeout=5)
        jobs = jobs_resp.json() if jobs_resp.status_code == 200 else []
        job_options = {j['title']: j['id'] for j in jobs}
    except Exception:
        job_options = {}

    if not job_options:
        st.warning("No active roles found.")
        st.stop()

    st.markdown('<div class="sec-label">Active Role</div>', unsafe_allow_html=True)
    selected_label  = st.selectbox("Role", list(job_options.keys()), label_visibility="collapsed")
    selected_job_id = job_options[selected_label]

    st.markdown('<div style="height:1px;background:#E4E6EB;margin:1rem 0;"></div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-label">Filters</div>', unsafe_allow_html=True)

    min_score  = st.slider("Min Score", 0.0, 1.0, 0.0, 0.05)
    show_limit = st.slider("Max Candidates", 5, 100, 50, 5)

    filter_decision = st.multiselect(
        "Decision Filter",
        ["auto_shortlisted","auto_rejected","needs_review",
         "hr_approved","hr_hold","hr_rejected","forwarded"],
        default=["auto_shortlisted","needs_review","hr_approved","hr_hold"],
    )

    st.markdown('<div style="height:1px;background:#E4E6EB;margin:1rem 0;"></div>', unsafe_allow_html=True)
    col_r1, col_r2 = st.columns(2)
    with col_r1:
        if st.button("↻ Refresh", use_container_width=True):
            st.rerun()
    with col_r2:
        auto = st.checkbox("Auto 30s")
    if auto:
        time.sleep(30)
        st.rerun()

    st.markdown("""
    <div style="margin-top:1.5rem;background:#F0F2F5;border-radius:8px;padding:10px 12px;">
      <div class="sec-label">Scoring Model</div>
      <div style="font-size:0.8rem;color:#050505;line-height:2.0;">
        Relevance &nbsp;·&nbsp; 40%<br>
        Semantic &nbsp;·&nbsp; 35%<br>
        Potential &nbsp;·&nbsp; 25%
      </div>
    </div>
    """, unsafe_allow_html=True)


# ── Fetch ─────────────────────────────────────────────────────
try:
    resp = requests.get(
        f"{API}/screenings/results/{selected_job_id}",
        params={"min_score": min_score, "limit": show_limit},
        timeout=15,
    )
    if resp.status_code != 200:
        st.error(f"API error {resp.status_code}")
        st.stop()
    all_results = resp.json()
    if not isinstance(all_results, list):
        all_results = []
except Exception as e:
    st.error(f"Cannot reach API: {e}")
    st.stop()

results = [r for r in all_results if isinstance(r, dict)
           and (not filter_decision or r.get("decision") in filter_decision)]


# ── Topnav ────────────────────────────────────────────────────
st.markdown(f"""
<div class="fb-nav">
  <div class="fb-nav-logo">TalentScan</div>
  <div class="fb-nav-title">Screening Intelligence Dashboard</div>
  <div class="fb-nav-right">{selected_label}</div>
</div>
""", unsafe_allow_html=True)


# ── Pool metrics ──────────────────────────────────────────────
try:
    pipe   = requests.get(f"{API}/jobs/{selected_job_id}/pipeline", timeout=5).json()
    total_ = pipe.get("total_screened", 0)
    pend_  = pipe.get("pending_review", 0)
    short_ = pipe.get("shortlisted", 0)
    avg_   = pipe.get("avg_score") or 0
except Exception:
    total_ = len(all_results)
    pend_  = sum(1 for r in all_results if r.get("decision") == "needs_review")
    short_ = sum(1 for r in all_results if "shortlisted" in (r.get("decision") or ""))
    avg_   = (sum(r.get("composite_score",0) for r in all_results)/len(all_results)) if all_results else 0

m1,m2,m3,m4 = st.columns(4)
m1.metric("Total Screened", total_)
m2.metric("Pending Review", pend_)
m3.metric("Shortlisted",    short_)
m4.metric("Avg Score",      f"{avg_:.0%}" if avg_ else "—")


# ── Pool charts ───────────────────────────────────────────────
if len(all_results) >= 2:
    st.markdown('<div class="fb-card-lg">', unsafe_allow_html=True)
    st.markdown('<div class="sec-label">Candidate Pool Overview</div>', unsafe_allow_html=True)
    pc1, pc2 = st.columns([3, 2], gap="medium")
    with pc1:
        fig = pool_bar_chart(all_results)
        if fig: st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
    with pc2:
        fig = pie_chart(all_results)
        if fig: st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
    st.markdown('</div>', unsafe_allow_html=True)

if not results:
    st.markdown("""
    <div class="fb-card" style="text-align:center;padding:3rem;">
      <div style="font-size:2rem;margin-bottom:0.5rem;">🔍</div>
      <div style="font-weight:700;font-size:1rem;margin-bottom:4px;">No candidates match the current filters</div>
      <div style="font-size:0.82rem;color:#65676B;">Adjust the Decision Filter or Min Score in the sidebar.</div>
    </div>
    """, unsafe_allow_html=True)
    st.stop()

st.markdown('<div style="height:1px;background:#CED0D4;margin:0.5rem 0 1.5rem;"></div>', unsafe_allow_html=True)


# ── Render candidates ─────────────────────────────────────────
for rank, r in enumerate(results, 1):
    name      = r.get("full_name") or r.get("original_filename") or "Unknown"
    email     = r.get("email") or ""
    fname     = r.get("original_filename") or ""
    decision  = r.get("decision") or "needs_review"
    ts        = (r.get("screened_at") or "")[:16].replace("T", " ")
    comp      = r.get("composite_score", 0)
    sem       = r.get("semantic_similarity", 0)
    rel       = r.get("relevance_score", 0)
    pot       = r.get("potential_score", 0)
    anoms     = r.get("anomaly_count", 0)
    returning = r.get("is_returning", False)
    sid       = r.get("screening_id", "")
    rationale = r.get("llm_rationale") or ""
    conf      = r.get("parse_confidence") or 0.8

    strengths    = parse_list(r.get("strengths"))
    gaps         = parse_list(r.get("gaps"))
    transferable = parse_list(r.get("transferable_skills"))
    insights     = parse_list(r.get("value_add_insights"))
    ini          = initials(name)
    comp_color   = score_color(comp)

    # Header card
    st.markdown(f"""
    <div class="fb-card-lg">
      <div class="cand-header">
        <div class="cand-avatar">{ini}</div>
        <div style="flex:1;min-width:0;">
          <div class="cand-name">#{rank} &nbsp;{name}</div>
          <div class="cand-email">{email}</div>
          <div class="cand-file">{fname}</div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px;flex-shrink:0;">
          {badge_html(decision)}
          {"<span class='badge badge-orange'>↩ Returning</span>" if returning else ""}
          {f"<span class='badge badge-red'>⚑ {anoms} Flag{'s' if anoms!=1 else ''}</span>" if anoms else ""}
          <div style='font-size:0.72rem;color:#BCC0C4;'>{ts}</div>
        </div>
      </div>
    </div>
    """, unsafe_allow_html=True)

    # Score Intelligence
    with st.expander(f"📊  Score Intelligence — {name}", expanded=(rank == 1)):
        gc1, gc2, gc3 = st.columns(3, gap="medium")
        with gc1:
            st.markdown('<div class="sec-label">Composite Gauge</div>', unsafe_allow_html=True)
            st.plotly_chart(gauge_chart(comp), use_container_width=True,
                            config={"displayModeBar": False})
        with gc2:
            st.markdown('<div class="sec-label">Score Profile Radar</div>', unsafe_allow_html=True)
            st.plotly_chart(radar_chart(rel, sem, pot), use_container_width=True,
                            config={"displayModeBar": False})
        with gc3:
            st.markdown('<div class="sec-label">Score Contribution</div>', unsafe_allow_html=True)
            st.plotly_chart(waterfall_chart(rel, sem, pot, comp), use_container_width=True,
                            config={"displayModeBar": False})

        st.markdown(f"""
        <div class="fb-card">
          <div class="sec-label">Score Breakdown with Weights</div>
          {subscore_html("Relevance Score", rel, "· 40% — LLM JD–CV alignment analysis")}
          {subscore_html("Semantic Similarity", sem, "· 35% — vector embedding cosine similarity")}
          {subscore_html("Potential Score", pot, "· 25% — career trajectory and growth signals")}
          <div style="margin-top:10px;font-size:0.72rem;color:#BCC0C4;background:#F0F2F5;border-radius:6px;padding:8px 10px;font-family:monospace;">
            ({int(rel*100)} × 0.40) + ({int(sem*100)} × 0.35) + ({int(pot*100)} × 0.25)
            &nbsp;=&nbsp; <b style="color:#1877F2;font-size:0.9rem;">{int(comp*100)}</b>
          </div>
        </div>
        """, unsafe_allow_html=True)

    # Strengths & Gaps
    with st.expander(f"✅  Strength & Gap Analysis — {name}"):
        s_rows = "".join(f'<div class="sg-item"><span class="sg-bullet-s">▲</span><span class="sg-text-s">{s}</span></div>' for s in strengths) \
                 or "<div style='font-size:0.8rem;color:#BCC0C4;padding:4px 0;'>None identified</div>"
        g_rows = "".join(f'<div class="sg-item"><span class="sg-bullet-g">▼</span><span class="sg-text-g">{g}</span></div>' for g in gaps) \
                 or "<div style='font-size:0.8rem;color:#BCC0C4;padding:4px 0;'>None identified</div>"
        st.markdown(f"""
        <div class="sg-grid">
          <div class="sg-box sg-box-s">
            <div class="sg-box-label sg-label-s">✓ Strengths ({len(strengths)})</div>{s_rows}
          </div>
          <div class="sg-box sg-box-g">
            <div class="sg-box-label sg-label-g">⚠ Gaps ({len(gaps)})</div>{g_rows}
          </div>
        </div>
        """, unsafe_allow_html=True)
        if strengths:
            st.markdown("<div style='margin-top:12px;'><div class='sec-label'>Strength Signal Depth</div></div>", unsafe_allow_html=True)
            fig = hbar_chart(strengths, FB_BLUE)
            if fig: st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

    # Transferable Skills
    if transferable:
        with st.expander(f"🔄  Transferable Skills — {name}"):
            tech_s   = [s for s in transferable if any(kw in s.lower() for kw in TECH_KW)]
            domain_s = [s for s in transferable if s not in tech_s]
            tc1, tc2 = st.columns(2, gap="medium")
            with tc1:
                st.markdown('<div class="sec-label">Technical</div>', unsafe_allow_html=True)
                chips = "".join(f'<span class="chip chip-tech">{s}</span>' for s in tech_s) \
                        or "<span style='font-size:0.8rem;color:#BCC0C4;'>None</span>"
                st.markdown(f'<div class="chip-wrap">{chips}</div>', unsafe_allow_html=True)
            with tc2:
                st.markdown('<div class="sec-label">Domain</div>', unsafe_allow_html=True)
                chips = "".join(f'<span class="chip chip-domain">{s}</span>' for s in domain_s) \
                        or "<span style='font-size:0.8rem;color:#BCC0C4;'>None</span>"
                st.markdown(f'<div class="chip-wrap">{chips}</div>', unsafe_allow_html=True)

    # Value-Add Insights
    if insights:
        with st.expander(f"💡  Strategic Insights — {name}"):
            for idx, insight in enumerate(insights, 1):
                st.markdown(f"""
                <div class="insight-item">
                  <div class="insight-num">Insight {idx:02d}</div>{insight}
                </div>""", unsafe_allow_html=True)

    # LLM Rationale
    if rationale:
        with st.expander(f"🧠  AI Rationale — {name}"):
            st.markdown(f"""
            <div class="rationale-box">
              <div class="rationale-label">🔵 AI Decision Rationale — Model Reasoning Output</div>
              {rationale}
              <div class="rationale-footer">Generated by LLM pipeline · Not human-authored · For HR augmentation only</div>
            </div>""", unsafe_allow_html=True)

    # System Signals
    with st.expander(f"📡  System Signals — {name}"):
        conf_pct = int(conf * 100)
        st.markdown(f"""
        <div class="signal-strip">
          <div class="signal-cell">
            <div class="signal-val" style="color:{comp_color};">{int(comp*100)}%</div>
            <div class="signal-lbl">Composite Score</div>
            <div class="signal-sub">Weighted AI score</div>
          </div>
          <div class="signal-cell">
            <div class="signal-val" style="color:{'#FA3E3E' if anoms else '#42B72A'};">{anoms}</div>
            <div class="signal-lbl">Anomaly Flags</div>
            <div class="signal-sub">{'Review required' if anoms else 'Clean'}</div>
          </div>
          <div class="signal-cell">
            <div class="signal-val" style="color:{'#1877F2' if returning else '#BCC0C4'};">{'Yes' if returning else 'No'}</div>
            <div class="signal-lbl">Returning</div>
            <div class="signal-sub">{'Prior application' if returning else 'First application'}</div>
          </div>
          <div class="signal-cell">
            <div class="signal-val" style="color:#1877F2;">{conf_pct}%</div>
            <div class="signal-lbl">Parse Confidence</div>
            <div class="signal-sub">CV extraction quality</div>
          </div>
        </div>
        <div class="conf-row">
          <div class="conf-label">Parse Confidence</div>
          <div class="conf-track"><div class="conf-fill" style="width:{conf_pct}%;"></div></div>
          <div class="conf-pct">{conf_pct}%</div>
        </div>""", unsafe_allow_html=True)

    # HR Decision
    with st.expander(f"✍️  HR Decision — {name}"):
        decision_map = {"✅ Approve":"hr_approved","📤 Forward":"forwarded",
                        "⏸ Hold":"hr_hold","❌ Reject":"hr_rejected"}
        da, db, dc = st.columns([2,2,1], gap="medium")
        with da:
            choice = st.selectbox("Decision", list(decision_map.keys()), key=f"dec_{sid}")
        with db:
            hr_name = st.text_input("HR Officer Name", placeholder="Your full name", key=f"name_{sid}")
        with dc:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("Save", key=f"save_{sid}", use_container_width=True):
                if not hr_name.strip():
                    st.error("Name required.")
                else:
                    try:
                        patch = requests.patch(
                            f"{API}/screenings/{sid}/decision",
                            data={"decision": decision_map[choice], "decision_by": hr_name.strip()},
                            timeout=10,
                        )
                        if patch.status_code == 200:
                            st.success("✅ Decision saved.")
                            time.sleep(1)
                            st.rerun()
                        else:
                            st.error(patch.json().get("detail", "Error saving."))
                    except Exception as ex:
                        st.error(str(ex))

    st.markdown('<div style="height:8px;"></div>', unsafe_allow_html=True)
