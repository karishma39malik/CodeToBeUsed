"""
Shared CSS and chart utilities for all TalentScan pages.
Import this in every page: from shared_style import CSS, nav_links, PLOTLY_CFG, score_color, badge_html, parse_list
"""
import plotly.graph_objects as go
from collections import Counter

FB_BLUE   = "#1877F2"
FB_GREEN  = "#42B72A"
FB_ORANGE = "#F5A623"
FB_RED    = "#FA3E3E"
FB_GREY   = "#BCC0C4"
PLOT_BG   = "#FFFFFF"
PLOTLY_CFG = {"displayModeBar": False}

CSS = """
<style>
html, body, [class*="css"] {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  font-size: 15px;
}
.stApp { background: #F0F2F5 !important; }
.block-container { padding: 0 1.5rem 3rem !important; max-width: 1300px; }
header, [data-testid="stHeader"] { background: #FFFFFF !important; border-bottom: 1px solid #CED0D4 !important; }
section[data-testid="stSidebar"] { background: #FFFFFF !important; border-right: 1px solid #CED0D4 !important; }
h1,h2,h3,h4 { color: #050505 !important; }
p,li { color: #050505 !important; }
label { color: #65676B !important; font-size: 0.8rem !important; }

.fb-nav { background: #1877F2; padding: 0 1.5rem; height: 56px; display: flex; align-items: center;
  justify-content: space-between; margin: -0.1rem -1.5rem 1.5rem -1.5rem; }
.fb-nav-logo { font-size: 1.5rem; font-weight: 900; color: #FFFFFF; letter-spacing: -0.5px; }
.fb-nav-title { font-size: 0.85rem; font-weight: 600; color: rgba(255,255,255,0.85);
  background: rgba(255,255,255,0.15); padding: 6px 14px; border-radius: 20px; }
.fb-nav-right { font-size: 0.78rem; color: rgba(255,255,255,0.6); }

.fb-card    { background: #FFFFFF; border-radius: 8px; border: 1px solid #CED0D4;
  padding: 1.2rem 1.4rem; margin-bottom: 12px; box-shadow: 0 1px 2px rgba(0,0,0,0.06); }
.fb-card-lg { background: #FFFFFF; border-radius: 8px; border: 1px solid #CED0D4;
  padding: 1.5rem; margin-bottom: 16px; box-shadow: 0 1px 2px rgba(0,0,0,0.06); }
.fb-card-blue { background: #E7F0FF; border-radius: 8px; border: 1px solid #BBD3FB;
  padding: 1.2rem 1.4rem; margin-bottom: 12px; }

.sec-label { font-size: 0.72rem; font-weight: 700; text-transform: uppercase;
  letter-spacing: 0.08em; color: #65676B; margin-bottom: 10px; }
.divider { height: 1px; background: #E4E6EB; margin: 1.2rem 0; }

.badge { display: inline-flex; align-items: center; gap: 5px; padding: 4px 12px;
  border-radius: 20px; font-size: 0.78rem; font-weight: 600; }
.badge-green  { background: #E7F3E8; color: #1A6B1E; }
.badge-blue   { background: #E7F0FF; color: #1877F2; }
.badge-orange { background: #FFF3E0; color: #E65100; }
.badge-red    { background: #FFEBEE; color: #C62828; }
.badge-grey   { background: #F0F2F5; color: #65676B; }
.badge-dot    { width: 7px; height: 7px; border-radius: 50%; }

.metric-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 1.2rem; }
.metric-card { background: #FFFFFF; border-radius: 8px; border: 1px solid #CED0D4;
  padding: 1rem 1.2rem; box-shadow: 0 1px 2px rgba(0,0,0,0.06); }
.metric-val { font-size: 1.8rem; font-weight: 700; color: #050505; line-height: 1; }
.metric-lbl { font-size: 0.7rem; font-weight: 600; text-transform: uppercase;
  letter-spacing: 0.06em; color: #65676B; margin-top: 4px; }
.metric-sub { font-size: 0.72rem; color: #BCC0C4; margin-top: 2px; }

.pipeline-step { display: flex; align-items: center; gap: 12px; padding: 10px 14px;
  background: #F0F2F5; border-radius: 8px; margin-bottom: 6px; }
.step-num { width: 28px; height: 28px; border-radius: 50%; background: #1877F2;
  color: white; font-weight: 700; font-size: 0.8rem; display: flex;
  align-items: center; justify-content: center; flex-shrink: 0; }
.step-name { font-weight: 600; font-size: 0.85rem; color: #050505; }
.step-desc { font-size: 0.75rem; color: #65676B; margin-top: 1px; }

.upload-zone { border: 2px dashed #BCC0C4; border-radius: 8px; padding: 2.5rem;
  text-align: center; background: #FAFAFA; }
.upload-zone:hover { border-color: #1877F2; background: #F0F5FF; }

.job-row { display: flex; align-items: center; gap: 14px; padding: 1rem 1.2rem;
  background: #FFFFFF; border-radius: 8px; border: 1px solid #CED0D4;
  margin-bottom: 8px; box-shadow: 0 1px 2px rgba(0,0,0,0.04); }
.job-avatar { width: 40px; height: 40px; border-radius: 8px; background: #1877F2;
  display: flex; align-items: center; justify-content: center;
  font-size: 1rem; font-weight: 700; color: white; flex-shrink: 0; }
.job-title-text { font-weight: 700; font-size: 0.92rem; color: #050505; }
.job-meta-text  { font-size: 0.75rem; color: #65676B; margin-top: 2px; }

.history-row { display: flex; align-items: center; gap: 12px; padding: 10px 14px;
  background: #FFFFFF; border-radius: 8px; border: 1px solid #CED0D4;
  margin-bottom: 6px; }
.hist-avatar { width: 34px; height: 34px; border-radius: 50%; background: #1877F2;
  color: white; font-weight: 700; font-size: 0.75rem;
  display: flex; align-items: center; justify-content: center; flex-shrink: 0; }

.stButton > button { background: #1877F2 !important; color: #FFFFFF !important;
  border: none !important; border-radius: 6px !important; font-weight: 700 !important;
  font-size: 0.82rem !important; padding: 8px 18px !important; }
.stButton > button:hover { background: #166FE5 !important; }
.stSelectbox > div > div { background: #FFFFFF !important; border-color: #CED0D4 !important;
  border-radius: 6px !important; color: #050505 !important; }
.stTextInput > div > div { background: #FFFFFF !important; border-color: #CED0D4 !important;
  border-radius: 6px !important; }
.stTextInput input { color: #050505 !important; }
.stTextArea > div > div { background: #FFFFFF !important; border-color: #CED0D4 !important; border-radius: 6px !important; }
.stTextArea textarea { color: #050505 !important; }
.stMultiSelect > div { background: #FFFFFF !important; border-color: #CED0D4 !important; border-radius: 6px !important; }
.stFileUploader { background: #FFFFFF !important; border-color: #CED0D4 !important; border-radius: 6px !important; }
[data-testid="stMetricValue"] { color: #050505 !important; font-weight: 700 !important; }
[data-testid="stMetricLabel"] { color: #65676B !important; font-size: 0.72rem !important; font-weight: 600 !important; }
div[data-testid="stExpander"] { background: #FFFFFF !important; border: 1px solid #CED0D4 !important;
  border-radius: 8px !important; margin-bottom: 8px !important; }
div[data-testid="stExpander"] summary { font-weight: 600 !important; color: #050505 !important; }
[data-testid="stFormSubmitButton"] > button { width: 100% !important; padding: 0.7rem !important; font-size: 1rem !important; }
</style>
"""

def score_color(s):
    return FB_GREEN if s >= 0.65 else (FB_ORANGE if s >= 0.45 else FB_RED)

def badge_html(decision):
    d = (decision or "").lower()
    label = (decision or "").replace("_", " ").title()
    if "shortlisted" in d or "approved" in d: cls, dot = "badge-green",  "#42B72A"
    elif "rejected"  in d:                    cls, dot = "badge-red",    "#FA3E3E"
    elif "hold"      in d:                    cls, dot = "badge-grey",   "#BCC0C4"
    elif "forward"   in d:                    cls, dot = "badge-blue",   "#1877F2"
    else:                                     cls, dot = "badge-orange", "#F5A623"
    return f'<span class="badge {cls}"><span class="badge-dot" style="background:{dot};"></span>{label}</span>'

def parse_list(val):
    import json
    if isinstance(val, list): return val
    if not val: return []
    try:
        r = json.loads(val)
        return r if isinstance(r, list) else [str(r)]
    except Exception:
        return [str(val)] if val else []

def initials(name):
    parts = (name or "?").split()
    return "".join(p[0] for p in parts[:2]).upper()

def topnav(page_title):
    return f"""
    <div class="fb-nav">
      <div class="fb-nav-logo">TalentScan</div>
      <div class="fb-nav-title">{page_title}</div>
      <div class="fb-nav-right">AI Screening Intelligence</div>
    </div>"""

def metric_card(val, label, sub="", color="#050505"):
    return f"""<div class="metric-card">
      <div class="metric-val" style="color:{color};">{val}</div>
      <div class="metric-lbl">{label}</div>
      {"<div class='metric-sub'>"+sub+"</div>" if sub else ""}
    </div>"""

# ── Chart builders ────────────────────────────────────────────
def gauge(value, title="Score"):
    pct   = value * 100
    color = score_color(value)
    fig   = go.Figure(go.Indicator(
        mode="gauge+number",
        value=pct,
        number={"suffix": "%", "font": {"size": 38, "color": "#050505"}},
        title={"text": title, "font": {"size": 11, "color": "#65676B"}},
        gauge={
            "axis": {"range": [0,100], "tickvals": [0,25,50,75,100],
                     "tickfont": {"size": 9, "color": "#BCC0C4"}, "tickwidth": 0},
            "bar": {"color": color, "thickness": 0.25},
            "bgcolor": "#F0F2F5", "borderwidth": 0,
            "steps": [{"range":[0,45],"color":"#FFEBEE"},
                      {"range":[45,65],"color":"#FFF3E0"},
                      {"range":[65,100],"color":"#E7F3E8"}],
            "threshold": {"line":{"color":color,"width":3},"thickness":0.8,"value":pct}
        }
    ))
    fig.update_layout(height=200, margin=dict(t=30,b=10,l=20,r=20),
                      paper_bgcolor=PLOT_BG, font={"family":"system-ui"})
    return fig

def radar(rel, sem, pot):
    cats = ["Relevance", "Semantic", "Potential"]
    vals = [rel*100, sem*100, pot*100]
    fig  = go.Figure(go.Scatterpolar(
        r=vals+[vals[0]], theta=cats+[cats[0]],
        fill="toself", fillcolor="rgba(24,119,242,0.1)",
        line=dict(color=FB_BLUE, width=2),
        marker=dict(color=FB_BLUE, size=5),
        hovertemplate="%{theta}: %{r:.0f}%<extra></extra>"
    ))
    fig.update_layout(
        polar=dict(bgcolor="#F0F2F5",
                   radialaxis=dict(visible=True, range=[0,100],
                                   tickvals=[0,25,50,75,100],
                                   tickfont=dict(size=8,color="#BCC0C4"),
                                   gridcolor="#E4E6EB"),
                   angularaxis=dict(tickfont=dict(size=10,color="#050505"),
                                    gridcolor="#E4E6EB")),
        showlegend=False, height=230, margin=dict(t=20,b=20,l=40,r=40),
        paper_bgcolor=PLOT_BG, font={"family":"system-ui"}
    )
    return fig

def waterfall(rel, sem, pot, composite):
    r=rel*.4*100; s=sem*.35*100; p=pot*.25*100
    color = score_color(composite)
    fig = go.Figure(go.Waterfall(
        orientation="v",
        measure=["relative","relative","relative","total"],
        x=["Relevance<br>×40%","Semantic<br>×35%","Potential<br>×25%","Composite"],
        y=[r,s,p,0],
        text=[f"{r:.1f}",f"{s:.1f}",f"{p:.1f}",f"{composite*100:.1f}"],
        textposition="outside",
        textfont={"size":10,"color":"#050505"},
        increasing={"marker":{"color":FB_BLUE}},
        totals={"marker":{"color":color}},
        connector={"line":{"color":"#E4E6EB","width":1}},
        hovertemplate="%{x}: %{y:.1f} pts<extra></extra>"
    ))
    fig.update_layout(height=260, margin=dict(t=30,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
                      xaxis=dict(showgrid=False,tickfont=dict(size=10,color="#050505")),
                      yaxis=dict(range=[0,110],gridcolor="#F0F2F5",
                                 tickfont=dict(size=9,color="#65676B")),
                      showlegend=False, font={"family":"system-ui"})
    return fig

def pool_bar(results):
    if len(results) < 2: return None
    names  = [(r.get("full_name") or f"#{i+1}")[:18] for i,r in enumerate(results)]
    scores = [r.get("composite_score",0)*100 for r in results]
    colors = [score_color(s/100) for s in scores]
    fig = go.Figure(go.Bar(
        x=names, y=scores, marker_color=colors,
        text=[f"{s:.0f}%" for s in scores], textposition="outside",
        textfont=dict(size=10,color="#050505"),
        hovertemplate="%{x}: %{y:.1f}%<extra></extra>", showlegend=False
    ))
    fig.add_hline(y=65, line_dash="dot", line_color=FB_GREEN,
                  annotation_text="Shortlist 65%",
                  annotation_font_size=9, annotation_font_color=FB_GREEN)
    fig.update_layout(height=280, margin=dict(t=30,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
                      xaxis=dict(tickfont=dict(size=10,color="#050505"),showgrid=False),
                      yaxis=dict(range=[0,115],gridcolor="#F0F2F5",
                                 tickfont=dict(size=9,color="#65676B"),title="Score %"),
                      bargap=0.35, font={"family":"system-ui"})
    return fig

def donut(results):
    counts = Counter(r.get("decision","unknown") for r in results)
    labels = list(counts.keys())
    values = list(counts.values())
    cmap   = {"auto_shortlisted":FB_GREEN,"hr_approved":FB_GREEN,
               "needs_review":FB_ORANGE,"hr_hold":FB_GREY,
               "auto_rejected":FB_RED,"hr_rejected":FB_RED,"forwarded":FB_BLUE}
    colors = [cmap.get(l,FB_GREY) for l in labels]
    fig = go.Figure(go.Pie(
        labels=[l.replace("_"," ").title() for l in labels],
        values=values, hole=0.55,
        marker=dict(colors=colors,line=dict(color="white",width=2)),
        textinfo="label+percent", textfont=dict(size=10),
        hovertemplate="%{label}: %{value}<extra></extra>"
    ))
    fig.update_layout(height=250, margin=dict(t=20,b=20,l=20,r=20),
                      paper_bgcolor=PLOT_BG, showlegend=False,
                      font={"family":"system-ui"},
                      annotations=[dict(text=f"<b>{sum(values)}</b>",
                                        x=0.5,y=0.5,font_size=18,showarrow=False,
                                        font_color="#050505")])
    return fig

def hbar(items, color=FB_BLUE):
    if not items: return None
    labels = [s[:40]+"…" if len(s)>40 else s for s in items[:8]]
    fig = go.Figure(go.Bar(
        x=list(range(len(labels),0,-1)), y=labels,
        orientation="h", marker_color=color, marker_opacity=0.75,
        hovertemplate="%{y}<extra></extra>", showlegend=False,
        text=labels, textposition="inside",
        insidetextanchor="start", textfont=dict(color="white",size=10)
    ))
    fig.update_layout(height=max(150,len(labels)*30+40),
                      margin=dict(t=10,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
                      xaxis=dict(visible=False), yaxis=dict(visible=False),
                      bargap=0.3, font={"family":"system-ui"})
    return fig

def score_trend(results):
    """Line chart of scores over time."""
    if len(results) < 2: return None
    dates  = [(r.get("screened_at") or "")[:10] for r in results]
    scores = [r.get("composite_score",0)*100 for r in results]
    names  = [(r.get("full_name") or "Unknown")[:15] for r in results]
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=dates, y=scores, mode="lines+markers+text",
        line=dict(color=FB_BLUE, width=2),
        marker=dict(color=FB_BLUE, size=8),
        text=names, textposition="top center",
        textfont=dict(size=9,color="#65676B"),
        hovertemplate="%{text}: %{y:.0f}%<extra></extra>",
        name="Score"
    ))
    fig.add_hline(y=65, line_dash="dot", line_color=FB_GREEN)
    fig.update_layout(height=250, margin=dict(t=20,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
                      xaxis=dict(showgrid=False,tickfont=dict(size=9,color="#65676B")),
                      yaxis=dict(range=[0,110],gridcolor="#F0F2F5",
                                 tickfont=dict(size=9,color="#65676B"),title="Score %"),
                      showlegend=False, font={"family":"system-ui"})
    return fig

def score_dist(results):
    """Histogram of score distribution."""
    scores = [r.get("composite_score",0)*100 for r in results]
    fig = go.Figure(go.Histogram(
        x=scores, nbinsx=10,
        marker_color=FB_BLUE, marker_opacity=0.75,
        hovertemplate="Score %{x:.0f}%: %{y} candidates<extra></extra>"
    ))
    fig.add_vline(x=65, line_dash="dot", line_color=FB_GREEN,
                  annotation_text="Shortlist", annotation_font_size=9,
                  annotation_font_color=FB_GREEN)
    fig.update_layout(height=220, margin=dict(t=20,b=10,l=10,r=10),
                      paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
                      xaxis=dict(title="Score %",tickfont=dict(size=9,color="#65676B"),showgrid=False),
                      yaxis=dict(title="Candidates",gridcolor="#F0F2F5",
                                 tickfont=dict(size=9,color="#65676B")),
                      showlegend=False, font={"family":"system-ui"},
                      bargap=0.1)
    return fig
