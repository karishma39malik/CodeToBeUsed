import streamlit as st
import requests
import os
import plotly.graph_objects as go
import sys
sys.path.insert(0, "/app/frontend")
from shared_style import CSS, topnav, badge_html, score_color, PLOTLY_CFG, pool_bar, donut, score_dist, score_trend, FB_BLUE, FB_GREEN, FB_ORANGE, FB_RED

st.set_page_config(page_title="TalentScan AI · Dashboard", page_icon="🎯", layout="wide", initial_sidebar_state="expanded")
st.markdown(CSS, unsafe_allow_html=True)

API_URL = os.getenv("API_URL", "http://api:8000")
API     = f"{API_URL}/api/v1"

# ── Sidebar ───────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="padding:0.5rem 0 1.2rem;">
      <div style="font-size:1.4rem;font-weight:900;color:#1877F2;letter-spacing:-0.5px;">TalentScan</div>
      <div style="font-size:0.72rem;color:#65676B;margin-top:2px;font-weight:600;">AI Screening Intelligence</div>
    </div>
    <div style="height:1px;background:#E4E6EB;margin-bottom:1rem;"></div>
    <div style="font-size:0.72rem;font-weight:700;color:#65676B;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:8px;">Navigation</div>
    """, unsafe_allow_html=True)
    st.page_link("app.py",                        label="🏠  Dashboard")
    st.page_link("pages/01_Post_a_Job.py",        label="📋  Post a Job")
    st.page_link("pages/02_Upload_CVs.py",        label="📤  Upload CVs")
    st.page_link("pages/03_Screening_Results.py", label="📊  Screening Results")
    st.page_link("pages/04_Candidate_History.py", label="📁  Candidate History")
    st.markdown('<div style="height:1px;background:#E4E6EB;margin:1rem 0;"></div>', unsafe_allow_html=True)
    st.markdown('<div style="font-size:0.72rem;font-weight:700;color:#65676B;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:8px;">System Status</div>', unsafe_allow_html=True)
    try:
        h = requests.get(f"{API_URL}/health", timeout=4).json()
        api_ok = True; db_ok = h.get("database", False); ai_ok = h.get("ollama", False)
    except Exception:
        api_ok = db_ok = ai_ok = False
    for label, ok, color in [("API Gateway", api_ok, "#42B72A"), ("PostgreSQL", db_ok, "#42B72A"), ("Ollama LLM", ai_ok, "#F5A623")]:
        dot_color = color if ok else "#FA3E3E"
        st.markdown(f'<div style="display:flex;align-items:center;gap:7px;font-size:0.8rem;color:#65676B;margin:5px 0;"><span style="width:8px;height:8px;border-radius:50%;background:{dot_color};flex-shrink:0;display:inline-block;"></span>{label}</div>', unsafe_allow_html=True)
    st.markdown('<div style="margin-top:1.5rem;background:#F0F2F5;border-radius:8px;padding:10px 12px;font-size:0.72rem;color:#65676B;line-height:1.8;">v2.0 · UAE Data Residency<br>AI augments — HR decides.</div>', unsafe_allow_html=True)

# ── Topnav ────────────────────────────────────────────────────
st.markdown(topnav("Dashboard · Hiring Overview"), unsafe_allow_html=True)

# ── Fetch data ────────────────────────────────────────────────
try:
    jobs_data = requests.get(f"{API}/jobs/", timeout=5).json()
    if not isinstance(jobs_data, list): jobs_data = []
except Exception:
    jobs_data = []

all_screenings = []
for job in jobs_data:
    try:
        results = requests.get(f"{API}/screenings/results/{job['id']}", params={"min_score":0,"limit":500}, timeout=8).json()
        if isinstance(results, list):
            for r in results: r["_job_title"] = job["title"]
            all_screenings.extend(results)
    except Exception:
        pass

total_jobs    = len(jobs_data)
total_screened = len(all_screenings)
shortlisted    = sum(1 for r in all_screenings if "shortlisted" in (r.get("decision") or ""))
avg_score      = (sum(r.get("composite_score",0) for r in all_screenings)/total_screened) if total_screened else 0
pending_review = sum(1 for r in all_screenings if r.get("decision") == "needs_review")

# ── Metrics ───────────────────────────────────────────────────
m1,m2,m3,m4,m5 = st.columns(5)
m1.metric("Active Roles",    total_jobs)
m2.metric("CVs Screened",    total_screened)
m3.metric("Shortlisted",     shortlisted)
m4.metric("Pending Review",  pending_review)
m5.metric("Avg Score",       f"{avg_score:.0%}" if avg_score else "—")

st.markdown('<div class="divider"></div>', unsafe_allow_html=True)

# ── Charts row ────────────────────────────────────────────────
if all_screenings:
    cc1, cc2, cc3 = st.columns([2, 2, 2], gap="medium")

    with cc1:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Score Distribution</div>', unsafe_allow_html=True)
        fig = score_dist(all_screenings)
        if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)

    with cc2:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Decision Breakdown</div>', unsafe_allow_html=True)
        fig = donut(all_screenings)
        if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)

    with cc3:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Scores Over Time</div>', unsafe_allow_html=True)
        sorted_s = sorted(all_screenings, key=lambda x: x.get("screened_at") or "")
        fig = score_trend(sorted_s[-20:])
        if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)

    # Per-job comparison bar
    if total_jobs > 1:
        st.markdown('<div class="fb-card-lg"><div class="sec-label">Candidate Scores by Role</div>', unsafe_allow_html=True)
        fig = pool_bar(sorted(all_screenings, key=lambda x: x.get("composite_score",0), reverse=True)[:20])
        if fig: st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CFG)
        st.markdown('</div>', unsafe_allow_html=True)

# ── Pipeline explainer ────────────────────────────────────────
st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
pc1, pc2 = st.columns([2, 1], gap="large")

with pc1:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">AI Pipeline Architecture</div>', unsafe_allow_html=True)
    for i,(name,desc) in enumerate([
        ("Ingestion Agent",  "PDF/DOCX/TXT parsing · LLM-powered structured field extraction · confidence scoring"),
        ("Matching Agent",   "Semantic embedding similarity · LLM relevance analysis · composite score calculation"),
        ("Potential Agent",  "Career trajectory analysis · learning velocity · leadership signal detection"),
        ("Validation Agent", "Duplicate detection · anomaly flagging · borderline score identification"),
    ], 1):
        st.markdown(f"""<div class="pipeline-step">
          <div class="step-num">{i}</div>
          <div><div class="step-name">{name}</div><div class="step-desc">{desc}</div></div>
        </div>""", unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

with pc2:
    st.markdown('<div class="fb-card-lg"><div class="sec-label">Scoring Model</div>', unsafe_allow_html=True)
    weights = {"Relevance": (0.40, FB_BLUE), "Semantic": (0.35, FB_GREEN), "Potential": (0.25, FB_ORANGE)}
    fig_w = go.Figure(go.Pie(
        labels=list(weights.keys()),
        values=[v[0]*100 for v in weights.values()],
        hole=0.5,
        marker=dict(colors=[v[1] for v in weights.values()], line=dict(color="white",width=2)),
        textinfo="label+percent", textfont=dict(size=11),
        hovertemplate="%{label}: %{value:.0f}%<extra></extra>"
    ))
    fig_w.update_layout(height=220, margin=dict(t=10,b=10,l=10,r=10),
                        paper_bgcolor="#FFFFFF", showlegend=False, font={"family":"system-ui"})
    st.plotly_chart(fig_w, use_container_width=True, config=PLOTLY_CFG)
    st.markdown("""<div style="font-size:0.75rem;color:#65676B;line-height:1.9;margin-top:4px;">
      <b>Relevance</b> — LLM JD/CV alignment<br>
      <b>Semantic</b> — Vector cosine similarity<br>
      <b>Potential</b> — Growth & trajectory signals
    </div>""", unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

# ── Active roles ──────────────────────────────────────────────
if jobs_data:
    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    st.markdown('<div class="sec-label">Active Roles</div>', unsafe_allow_html=True)
    for job in jobs_data[:8]:
        dept = job.get("department") or "—"
        loc  = job.get("location") or "—"
        date = (job.get("created_at") or "")[:10]
        cnt  = sum(1 for r in all_screenings if r.get("job_id") == str(job.get("id","")))
        ini  = (job.get("title") or "J")[0].upper()
        st.markdown(f"""<div class="job-row">
          <div class="job-avatar">{ini}</div>
          <div style="flex:1;min-width:0;">
            <div class="job-title-text">{job['title']}</div>
            <div class="job-meta-text">{dept} · {loc}</div>
          </div>
          <div style="display:flex;gap:8px;align-items:center;flex-shrink:0;">
            <span class="badge badge-blue">{cnt} screened</span>
            <span style="font-size:0.72rem;color:#BCC0C4;">{date}</span>
          </div>
        </div>""", unsafe_allow_html=True)
else:
    st.markdown("""<div class="fb-card" style="text-align:center;padding:2.5rem;">
      <div style="font-size:2rem;margin-bottom:0.5rem;">📋</div>
      <div style="font-weight:700;font-size:1rem;margin-bottom:4px;">No roles posted yet</div>
      <div style="font-size:0.82rem;color:#65676B;">Go to Post a Job to create your first role and start screening candidates.</div>
    </div>""", unsafe_allow_html=True)
