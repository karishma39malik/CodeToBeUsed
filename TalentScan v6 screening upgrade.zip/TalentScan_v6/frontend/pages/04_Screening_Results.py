import streamlit as st
import requests
import pandas as pd
import json
import os

st.set_page_config(
    page_title="Screening Results · TalentScan AI",
    page_icon="📊",
    layout="wide"
)

API_BASE = os.getenv("API_URL", "http://localhost:8000")
API = f"{API_BASE}/api/v1"

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap');

html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
.stApp { background: #080b12 !important; }
section[data-testid="stSidebar"] { background: #0b0e17 !important; border-right: 1px solid #161d2e !important; }
.block-container { padding-top: 1rem; padding-bottom: 2rem; max-width: 1500px; }
header { background: transparent !important; }
h1,h2,h3,h4 { font-family: 'Syne', sans-serif !important; color: #eef2ff !important; }

.page-title  { font-family:'Syne',sans-serif; font-size:1.7rem; font-weight:800; color:#eef2ff; }
.page-sub    { font-size:0.78rem; color:#3d4a65; margin-top:4px; }
.section-hdr { font-family:'Syne',sans-serif; font-size:0.72rem; font-weight:700;
               color:#3d4a65; text-transform:uppercase; letter-spacing:2px; margin:1.4rem 0 0.7rem; }

/* KPI */
.kpi-card { background:#0d1220; border:1px solid #161d2e; border-radius:14px;
             padding:1rem; text-align:center; }
.kpi-val  { font-family:'Syne',sans-serif; font-size:1.9rem; font-weight:800; }
.kpi-lbl  { font-size:0.7rem; color:#3d4a65; text-transform:uppercase; letter-spacing:1px; margin-top:3px; }

/* Candidate expanded card */
.cand-card { background:#0d1220; border:1px solid #161d2e; border-radius:14px;
              padding:1.2rem; margin-bottom:10px; }
.cand-card.selected { border-color:#1e3a6e; background:#0d1828; }

.score-ring {
  width:72px; height:72px; border-radius:50%; display:flex; flex-direction:column;
  align-items:center; justify-content:center; border:3px solid;
  flex-shrink:0;
}

.pill {
  display:inline-block; padding:3px 10px; border-radius:20px;
  font-size:0.68rem; font-weight:600; margin:2px 3px 2px 0;
}
.pill-green { background:#052e1c; color:#10b981; border:1px solid #065f3c; }
.pill-red   { background:#2d0a0a; color:#ef4444; border:1px solid #7f1d1d; }
.pill-blue  { background:#0a1628; color:#60a5fa; border:1px solid #1e40af; }
.pill-grey  { background:#111827; color:#6b7280; border:1px solid #374151; }
.pill-amber { background:#2a1a00; color:#f59e0b; border:1px solid #92400e; }

/* Score breakdown bar */
.score-seg-label { font-size:0.68rem; color:#4a5568; margin-bottom:3px; }
.score-seg-bar-bg { background:#161d2e; border-radius:4px; height:10px; }
.score-seg-bar { height:10px; border-radius:4px; }

/* Expand toggle */
.expand-btn {
  background:none; border:1px solid #1e3056; border-radius:8px;
  color:#4a6fa5; font-size:0.72rem; padding:4px 12px; cursor:pointer;
}

/* Rationale box */
.rationale-box {
  background:#060a10; border:1px solid #0f1826; border-radius:10px;
  padding:0.8rem 1rem; font-size:0.78rem; color:#7a8499; line-height:1.7;
  margin-top:0.5rem;
}

/* Navigation breadcrumb */
.breadcrumb { font-size:0.75rem; color:#3d4a65; margin-bottom:0.6rem; }
.breadcrumb a { color:#4a6fa5; text-decoration:none; }

/* Filter panel */
.filter-panel {
  background:#0d1220; border:1px solid #161d2e; border-radius:12px;
  padding:0.8rem 1rem; margin-bottom:1rem;
}
</style>
""", unsafe_allow_html=True)

# ── Breadcrumb / back link ────────────────────────────────────────────────────
bc1, bc2 = st.columns([8,2])
with bc1:
    st.markdown('<div class="breadcrumb">← <a href="#" onclick="window.history.back()">High-Level Insights</a> &nbsp;/&nbsp; Detailed Screening Results</div>', unsafe_allow_html=True)
with bc2:
    if st.button("← Back to Insights", use_container_width=True):
        st.switch_page("pages/03_High_Level_Insights.py")

# ── Page header ───────────────────────────────────────────────────────────────
st.markdown("""
<div class="page-title">📊 Detailed Screening Results</div>
<div class="page-sub">Full evaluation · Skill breakdown · AI rationale · Penalties</div>
""", unsafe_allow_html=True)

# ── Job selector ──────────────────────────────────────────────────────────────
try:
    jobs_resp = requests.get(f"{API}/jobs", timeout=5)
    jobs = jobs_resp.json() if jobs_resp.ok else []
except:
    jobs = []

if not jobs:
    st.info("No jobs found. Post a job and screen CVs first.")
    st.stop()

job_map = {f"{j['title']} (#{j['id']})": j['id'] for j in jobs}
selected_label = st.selectbox("Select Role", list(job_map.keys()), label_visibility="collapsed")
selected_job_id = job_map[selected_label]

# ── Load data ─────────────────────────────────────────────────────────────────
try:
    resp = requests.get(f"{API}/screenings", params={"job_id": selected_job_id}, timeout=10)
    raw = resp.json() if resp.ok else []
except:
    raw = []

if not raw:
    st.info("No screening results yet for this role.")
    st.stop()

df = pd.DataFrame(raw)
df["score"]    = pd.to_numeric(df.get("composite_score", 0), errors="coerce").fillna(0)
df["name"]     = df.get("candidate_name", "Unknown")
df["status"]   = df.get("status", "unknown")
df["exp"]      = pd.to_numeric(df.get("years_experience", 0), errors="coerce").fillna(0)
df["location"] = df.get("location", "").fillna("").astype(str)
df["gender"]   = df.get("gender", "").fillna("").astype(str)
df["geo_area"] = df.get("geographical_area", "").fillna("").astype(str)
df["skill_pct"]= pd.to_numeric(df.get("skill_match_pct", 0), errors="coerce").fillna(0)
df["education"]= df.get("education_level", "").fillna("").astype(str)

# ── FILTERS ───────────────────────────────────────────────────────────────────
st.markdown('<div class="section-hdr">🔍 Filters</div>', unsafe_allow_html=True)

fc1, fc2, fc3, fc4, fc5, fc6 = st.columns([2,2,2,2,2,2])

locs = sorted([l for l in df["location"].unique() if l])
with fc1:
    sel_location = st.multiselect("📍 Location", locs, placeholder="All locations")

genders = sorted([g for g in df["gender"].unique() if g])
with fc2:
    sel_gender = st.multiselect("👤 Gender", genders, placeholder="All genders")

geos = sorted([g for g in df["geo_area"].unique() if g])
with fc3:
    sel_geo = st.multiselect("🌍 Geo Area", geos, placeholder="All regions")

with fc4:
    exp_min = int(df["exp"].min())
    exp_max = max(int(df["exp"].max()), exp_min + 1)
    sel_exp = st.slider("📅 Yrs Experience", exp_min, exp_max, (exp_min, exp_max))

statuses = sorted([s for s in df["status"].unique() if s])
with fc5:
    sel_status = st.multiselect("✅ Status", statuses, placeholder="All statuses")

with fc6:
    sel_score = st.slider("⭐ Min Score", 0, 100, 0)

# Apply filters
mask = pd.Series([True] * len(df))
if sel_location: mask &= df["location"].isin(sel_location)
if sel_gender:   mask &= df["gender"].isin(sel_gender)
if sel_geo:      mask &= df["geo_area"].isin(sel_geo)
if sel_status:   mask &= df["status"].isin(sel_status)
mask &= (df["exp"] >= sel_exp[0]) & (df["exp"] <= sel_exp[1])
mask &= df["score"] >= sel_score
filtered = df[mask].sort_values("score", ascending=False).reset_index(drop=True)

# ── KPI strip ─────────────────────────────────────────────────────────────────
st.markdown('<div class="section-hdr">Overview</div>', unsafe_allow_html=True)
total      = len(filtered)
shortlisted= len(filtered[filtered["status"]=="shortlisted"])
rejected   = len(filtered[filtered["status"]=="rejected"])
avg_sc     = filtered["score"].mean() if total else 0
avg_exp    = filtered["exp"].mean() if total else 0

k1,k2,k3,k4,k5 = st.columns(5)
with k1: st.markdown(f'<div class="kpi-card"><div class="kpi-val" style="color:#eef2ff">{total}</div><div class="kpi-lbl">Candidates</div></div>', unsafe_allow_html=True)
with k2: st.markdown(f'<div class="kpi-card"><div class="kpi-val" style="color:#10b981">{shortlisted}</div><div class="kpi-lbl">Shortlisted</div></div>', unsafe_allow_html=True)
with k3: st.markdown(f'<div class="kpi-card"><div class="kpi-val" style="color:#ef4444">{rejected}</div><div class="kpi-lbl">Rejected</div></div>', unsafe_allow_html=True)
with k4:
    c = "#10b981" if avg_sc>=70 else "#3b82f6" if avg_sc>=50 else "#f59e0b"
    st.markdown(f'<div class="kpi-card"><div class="kpi-val" style="color:{c}">{avg_sc:.0f}</div><div class="kpi-lbl">Avg Score</div></div>', unsafe_allow_html=True)
with k5: st.markdown(f'<div class="kpi-card"><div class="kpi-val" style="color:#a78bfa">{avg_exp:.1f}</div><div class="kpi-lbl">Avg Exp (yrs)</div></div>', unsafe_allow_html=True)

# ── Helpers ───────────────────────────────────────────────────────────────────
def tier_color(s):
    if s >= 75: return "#10b981"
    if s >= 55: return "#3b82f6"
    if s >= 35: return "#f59e0b"
    return "#ef4444"

def status_style(s):
    if s == "shortlisted": return "background:#052e1c;color:#10b981;border:1px solid #065f3c;"
    if s == "rejected":    return "background:#2d0a0a;color:#ef4444;border:1px solid #7f1d1d;"
    return "background:#1a1a2e;color:#7a8499;border:1px solid #2d3748;"

def pills(items, cls="pill-blue"):
    if not items: return "<span style='color:#3d4a65;font-size:0.72rem'>–</span>"
    if isinstance(items, str):
        try: items = json.loads(items)
        except: items = [items]
    return " ".join(f'<span class="pill {cls}">{i}</span>' for i in (items or []))

def parse_json_field(val, default=[]):
    if isinstance(val, list): return val
    if isinstance(val, str):
        try: return json.loads(val)
        except: return [val] if val else default
    return default

# ── DETAILED CANDIDATE CARDS ──────────────────────────────────────────────────
st.markdown('<div class="section-hdr">Candidate Evaluations</div>', unsafe_allow_html=True)

if filtered.empty:
    st.warning("No candidates match the current filters.")
else:
    # Deep-link to specific candidate from insights page
    highlight_id = st.session_state.get("detail_candidate_id")

    for i, row in filtered.iterrows():
        score    = row["score"]
        tc       = tier_color(score)
        ss       = status_style(row["status"])
        exp_str  = f"{row['exp']:.0f} yrs" if row['exp'] > 0 else "–"
        loc_str  = row["location"] or "–"
        geo_str  = row["geo_area"] or "–"
        gen_str  = row["gender"] or "–"
        edu_str  = row["education"] or "–"
        cand_id  = row.get("id", i)
        is_hl    = (highlight_id and str(cand_id) == str(highlight_id))

        # Parse skill fields
        matched_skills = parse_json_field(row.get("matched_skills", []))
        gap_skills     = parse_json_field(row.get("skill_gaps", []))
        keywords_hit   = parse_json_field(row.get("keywords_matched", []))
        penalty_list   = parse_json_field(row.get("penalties_applied", []))
        rationale      = row.get("ai_rationale", "") or row.get("evaluation_summary", "")

        # Score breakdown
        skill_score = float(row.get("skill_score", 0) or 0)
        exp_score   = float(row.get("experience_score", 0) or 0)
        edu_score   = float(row.get("education_score", 0) or 0)
        penalty_pts = float(row.get("penalty_points", 0) or 0)

        card_class  = "cand-card selected" if is_hl else "cand-card"
        expand_key  = f"expand_{cand_id}"
        if is_hl and expand_key not in st.session_state:
            st.session_state[expand_key] = True

        # ── Header row ──
        col_hdr, col_toggle = st.columns([10,1])
        with col_hdr:
            st.markdown(f"""
            <div class="{card_class}">
              <div style="display:flex;align-items:center;gap:16px">
                <div class="score-ring" style="border-color:{tc};flex-shrink:0">
                  <div style="font-family:'Syne',sans-serif;font-size:1.1rem;font-weight:800;color:{tc}">{score:.0f}</div>
                  <div style="font-size:0.6rem;color:#3d4a65">SCORE</div>
                </div>
                <div style="flex:1">
                  <div style="font-size:1rem;font-weight:600;color:#eef2ff">#{i+1} · {row['name']}</div>
                  <div style="font-size:0.72rem;color:#4a5568;margin-top:3px">
                    📍 {loc_str} &nbsp;|&nbsp; 🌍 {geo_str} &nbsp;|&nbsp; 📅 {exp_str} exp &nbsp;|&nbsp; 👤 {gen_str} &nbsp;|&nbsp; 🎓 {edu_str}
                  </div>
                  <div style="margin-top:7px">
                    <span class="status-chip" style="{ss}margin-right:8px;padding:3px 10px;border-radius:20px;font-size:0.68rem;font-weight:600;">{row['status'].upper()}</span>
                    <span style="font-size:0.72rem;color:#3d4a65">Skill match: <b style="color:#7ab0ff">{row['skill_pct']:.0f}%</b></span>
                  </div>
                </div>
              </div>
            </div>
            """, unsafe_allow_html=True)

        with col_toggle:
            expanded = st.session_state.get(expand_key, False)
            btn_label = "▲ Collapse" if expanded else "▼ Expand"
            if st.button(btn_label, key=f"btn_{cand_id}", use_container_width=True):
                st.session_state[expand_key] = not expanded
                st.rerun()

        # ── Expanded detail ──
        if st.session_state.get(expand_key, False):
            with st.container():
                d1, d2 = st.columns([1,1])

                with d1:
                    st.markdown("**Score Breakdown**")
                    for label, val, maxv, color in [
                        ("Skills (65%)",     skill_score, 65, "#10b981"),
                        ("Experience (15%)", exp_score,   15, "#3b82f6"),
                        ("Education (20%)",  edu_score,   20, "#a78bfa"),
                    ]:
                        pct_bar = (val / maxv * 100) if maxv else 0
                        st.markdown(f"""
                        <div style="margin-bottom:10px">
                          <div class="score-seg-label">{label} — <b style="color:{color}">{val:.1f} / {maxv}</b></div>
                          <div class="score-seg-bar-bg">
                            <div class="score-seg-bar" style="width:{min(pct_bar,100):.0f}%;background:{color}"></div>
                          </div>
                        </div>
                        """, unsafe_allow_html=True)

                    if penalty_pts:
                        st.markdown(f"""
                        <div style="margin-top:6px;padding:6px 10px;background:#1a0a0a;border:1px solid #7f1d1d;border-radius:8px;font-size:0.75rem;color:#ef4444">
                        ⚠️ Penalty applied: <b>−{penalty_pts:.0f} pts</b> · {', '.join(penalty_list) if penalty_list else 'see details'}
                        </div>
                        """, unsafe_allow_html=True)

                with d2:
                    st.markdown("**Skills**")
                    if matched_skills:
                        st.markdown(f"✅ Matched: {pills(matched_skills,'pill-green')}", unsafe_allow_html=True)
                    if gap_skills:
                        st.markdown(f"❌ Gaps: {pills(gap_skills,'pill-red')}", unsafe_allow_html=True)
                    if keywords_hit:
                        st.markdown(f"🔑 Keywords: {pills(keywords_hit,'pill-blue')}", unsafe_allow_html=True)

                if rationale:
                    st.markdown("**AI Rationale**")
                    st.markdown(f'<div class="rationale-box">{rationale}</div>', unsafe_allow_html=True)

                # CV link if available
                cv_url = row.get("cv_url") or row.get("cv_link")
                if cv_url:
                    st.markdown(f'<a href="{cv_url}" target="_blank" style="font-size:0.75rem;color:#4a6fa5">📄 Open CV →</a>', unsafe_allow_html=True)

                st.markdown("---")

# ── Excel Export ──────────────────────────────────────────────────────────────
st.markdown('<div class="section-hdr">Export</div>', unsafe_allow_html=True)
exp1, exp2 = st.columns([3,7])
with exp1:
    if st.button("⬇️ Export Filtered Results to Excel", use_container_width=True):
        try:
            r = requests.get(f"{API}/export/{selected_job_id}/excel", timeout=15)
            if r.ok:
                st.download_button(
                    "📥 Download Excel",
                    data=r.content,
                    file_name=f"screening_{selected_job_id}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
            else:
                st.error("Export failed.")
        except Exception as e:
            st.error(f"Export error: {e}")
