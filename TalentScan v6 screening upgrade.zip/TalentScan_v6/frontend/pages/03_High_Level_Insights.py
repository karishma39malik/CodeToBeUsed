import streamlit as st
import requests
import pandas as pd
import os

st.set_page_config(
    page_title="High-Level Insights · TalentScan AI",
    page_icon="🎯",
    layout="wide"
)

API_BASE = os.getenv("API_URL", "http://localhost:8000")
API = f"{API_BASE}/api/v1"

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap');

html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
.stApp { background: #080b12 !important; }
section[data-testid="stSidebar"] { background: #0b0e17 !important; border-right: 1px solid #161d2e !important; }
.block-container { padding-top: 1rem; padding-bottom: 2rem; max-width: 1400px; }
header { background: transparent !important; }
h1,h2,h3,h4 { font-family: 'Syne', sans-serif !important; color: #eef2ff !important; }

/* Page header */
.page-title { font-family:'Syne',sans-serif; font-size:1.7rem; font-weight:800; color:#eef2ff; }
.page-sub { font-size:0.78rem; color:#3d4a65; margin-top:4px; }

/* KPI cards */
.kpi-grid { display: grid; grid-template-columns: repeat(5,1fr); gap:14px; margin: 1.2rem 0; }
.kpi-card {
  background: #0d1220; border:1px solid #161d2e; border-radius:14px;
  padding:1.1rem 1rem; text-align:center;
}
.kpi-val { font-family:'Syne',sans-serif; font-size:2rem; font-weight:800; }
.kpi-lbl { font-size:0.72rem; color:#3d4a65; text-transform:uppercase; letter-spacing:1px; margin-top:4px; }
.kpi-sub { font-size:0.72rem; color:#4a5568; margin-top:2px; }

/* Candidate score card */
.candidate-row {
  background: #0d1220; border:1px solid #161d2e; border-radius:12px;
  padding: 0.9rem 1.2rem; margin-bottom:8px; display:flex; align-items:center;
  transition: border-color 0.2s;
}
.candidate-row:hover { border-color:#2a3556; }
.rank-badge {
  width:36px; height:36px; border-radius:50%; display:flex;
  align-items:center; justify-content:center; font-weight:800; font-size:0.85rem;
  flex-shrink:0; margin-right:14px;
}
.score-bar-bg { background:#161d2e; border-radius:6px; height:8px; flex:1; margin:0 12px; }
.score-bar-fill { height:8px; border-radius:6px; }
.status-chip {
  padding:3px 10px; border-radius:20px; font-size:0.7rem; font-weight:600;
  letter-spacing:0.5px; white-space:nowrap;
}
.detail-btn {
  background: linear-gradient(135deg,#1a3a6e,#0d2247);
  border:1px solid #1e3a6e; color:#7ab0ff; border-radius:8px;
  padding:5px 14px; font-size:0.72rem; font-weight:600;
  cursor:pointer; white-space:nowrap; text-decoration:none;
}

/* Section header */
.section-hdr {
  font-family:'Syne',sans-serif; font-size:0.75rem; font-weight:700;
  color:#3d4a65; text-transform:uppercase; letter-spacing:2px;
  margin: 1.4rem 0 0.6rem;
}

/* Filter bar */
.filter-bar {
  background:#0d1220; border:1px solid #161d2e; border-radius:12px;
  padding:0.8rem 1rem; margin-bottom:1rem;
}

/* Tier bands */
.tier-excellent { color:#10b981; }
.tier-good      { color:#3b82f6; }
.tier-fair      { color:#f59e0b; }
.tier-weak      { color:#ef4444; }
</style>
""", unsafe_allow_html=True)

# ── Header ────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="page-title">🎯 High-Level Insights</div>
<div class="page-sub">Quick-view candidate scores · Click "View Details" to open full evaluation</div>
""", unsafe_allow_html=True)

# ── Job selector ──────────────────────────────────────────────────────────────
try:
    jobs_resp = requests.get(f"{API}/jobs", timeout=5)
    jobs = jobs_resp.json() if jobs_resp.ok else []
except:
    jobs = []

if not jobs:
    st.info("No jobs found. Post a job and screen some CVs first.")
    st.stop()

job_map = {f"{j['title']} (#{j['id']})": j['id'] for j in jobs}
col_sel, col_btn = st.columns([4,1])
with col_sel:
    selected_label = st.selectbox("Select Role", list(job_map.keys()), label_visibility="collapsed")
selected_job_id = job_map[selected_label]

# ── Load screenings ───────────────────────────────────────────────────────────
try:
    resp = requests.get(f"{API}/screenings", params={"job_id": selected_job_id}, timeout=10)
    raw = resp.json() if resp.ok else []
except:
    raw = []

if not raw:
    st.info("No screening results yet for this role.")
    st.stop()

df = pd.DataFrame(raw)
df["score"]    = pd.to_numeric(df.get("composite_score", 0), errors="coerce").fillna(0)
df["name"]     = df.get("candidate_name", "Unknown")
df["status"]   = df.get("status", "unknown")
df["exp"]      = pd.to_numeric(df.get("years_experience", 0), errors="coerce").fillna(0)
df["location"] = df.get("location", "").fillna("").astype(str)
df["gender"]   = df.get("gender", "").fillna("").astype(str)
df["geo_area"] = df.get("geographical_area", "").fillna("").astype(str)
df["skill_pct"]= pd.to_numeric(df.get("skill_match_pct", 0), errors="coerce").fillna(0)
df["education"]= df.get("education_level", "").fillna("").astype(str)

# ── FILTER BAR ───────────────────────────────────────────────────────────────
st.markdown('<div class="section-hdr">Filters</div>', unsafe_allow_html=True)
with st.container():
    fc1, fc2, fc3, fc4, fc5, fc6 = st.columns([2,2,2,2,2,2])

    # Location filter
    locs = sorted([l for l in df["location"].unique() if l])
    with fc1:
        sel_location = st.multiselect("📍 Location", locs, placeholder="All locations")

    # Gender filter
    genders = sorted([g for g in df["gender"].unique() if g])
    with fc2:
        sel_gender = st.multiselect("👤 Gender", genders, placeholder="All genders")

    # Geographical area
    geos = sorted([g for g in df["geo_area"].unique() if g])
    with fc3:
        sel_geo = st.multiselect("🌍 Geo Area", geos, placeholder="All regions")

    # Years of experience
    with fc4:
        exp_min = int(df["exp"].min())
        exp_max = max(int(df["exp"].max()), exp_min + 1)
        sel_exp = st.slider("📅 Yrs Experience", exp_min, exp_max, (exp_min, exp_max))

    # Status filter
    statuses = sorted([s for s in df["status"].unique() if s])
    with fc5:
        sel_status = st.multiselect("✅ Status", statuses, placeholder="All statuses")

    # Score range
    with fc6:
        sel_score = st.slider("⭐ Min Score", 0, 100, 0)

# Apply filters
mask = pd.Series([True] * len(df))
if sel_location:  mask &= df["location"].isin(sel_location)
if sel_gender:    mask &= df["gender"].isin(sel_gender)
if sel_geo:       mask &= df["geo_area"].isin(sel_geo)
if sel_status:    mask &= df["status"].isin(sel_status)
mask &= (df["exp"] >= sel_exp[0]) & (df["exp"] <= sel_exp[1])
mask &= df["score"] >= sel_score
filtered = df[mask].sort_values("score", ascending=False).reset_index(drop=True)

# ── KPI STRIP ─────────────────────────────────────────────────────────────────
total     = len(filtered)
shortlist = len(filtered[filtered["status"] == "shortlisted"])
rejected  = len(filtered[filtered["status"] == "rejected"])
avg_score = filtered["score"].mean() if total else 0
top_score = filtered["score"].max() if total else 0

st.markdown('<div class="section-hdr">Overview</div>', unsafe_allow_html=True)
k1,k2,k3,k4,k5 = st.columns(5)
with k1:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val" style="color:#eef2ff">{total}</div><div class="kpi-lbl">Total Candidates</div></div>', unsafe_allow_html=True)
with k2:
    pct = round(shortlist/total*100) if total else 0
    st.markdown(f'<div class="kpi-card"><div class="kpi-val tier-excellent">{shortlist}</div><div class="kpi-lbl">Shortlisted</div><div class="kpi-sub">{pct}% of total</div></div>', unsafe_allow_html=True)
with k3:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val tier-weak">{rejected}</div><div class="kpi-lbl">Rejected</div></div>', unsafe_allow_html=True)
with k4:
    color = "#10b981" if avg_score>=70 else "#3b82f6" if avg_score>=50 else "#f59e0b"
    st.markdown(f'<div class="kpi-card"><div class="kpi-val" style="color:{color}">{avg_score:.0f}</div><div class="kpi-lbl">Avg Score</div></div>', unsafe_allow_html=True)
with k5:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val" style="color:#a78bfa">{top_score:.0f}</div><div class="kpi-lbl">Top Score</div></div>', unsafe_allow_html=True)

# ── CANDIDATE SCORE LIST ──────────────────────────────────────────────────────
st.markdown('<div class="section-hdr">Candidate Rankings</div>', unsafe_allow_html=True)

if filtered.empty:
    st.warning("No candidates match the selected filters.")
else:
    # Tier colors
    def tier_color(s):
        if s >= 75: return "#10b981"
        if s >= 55: return "#3b82f6"
        if s >= 35: return "#f59e0b"
        return "#ef4444"

    def status_style(s):
        if s == "shortlisted":
            return "background:#052e1c;color:#10b981;border:1px solid #065f3c;"
        if s == "rejected":
            return "background:#2d0a0a;color:#ef4444;border:1px solid #7f1d1d;"
        return "background:#1a1a2e;color:#7a8499;border:1px solid #2d3748;"

    def rank_style(i):
        if i == 0: return "background:linear-gradient(135deg,#b8860b,#ffd700);color:#000;"
        if i == 1: return "background:linear-gradient(135deg,#708090,#c0c0c0);color:#000;"
        if i == 2: return "background:linear-gradient(135deg,#8b4513,#cd853f);color:#fff;"
        return "background:#161d2e;color:#7a8499;"

    for i, row in filtered.iterrows():
        score    = row["score"]
        tc       = tier_color(score)
        bar_pct  = min(score, 100)
        rs       = rank_style(i)
        ss       = status_style(row["status"])
        exp_str  = f"{row['exp']:.0f} yrs" if row['exp'] > 0 else "–"
        loc_str  = row["location"] or "–"
        geo_str  = row["geo_area"] or "–"

        col_main, col_btn = st.columns([10,1])
        with col_main:
            st.markdown(f"""
            <div class="candidate-row">
                <div class="rank-badge" style="{rs}">#{i+1}</div>
                <div style="width:180px;flex-shrink:0">
                    <div style="color:#eef2ff;font-weight:600;font-size:0.9rem">{row['name']}</div>
                    <div style="font-size:0.72rem;color:#3d4a65;margin-top:2px">{loc_str} · {geo_str}</div>
                </div>
                <div style="flex:1;margin:0 16px">
                    <div style="display:flex;align-items:center;gap:8px">
                        <div style="font-size:1.25rem;font-weight:800;color:{tc};width:46px;flex-shrink:0">{score:.0f}</div>
                        <div class="score-bar-bg" style="flex:1">
                            <div class="score-bar-fill" style="width:{bar_pct}%;background:{tc};"></div>
                        </div>
                        <div style="font-size:0.72rem;color:#3d4a65;width:70px;text-align:right">Skill {row['skill_pct']:.0f}%</div>
                    </div>
                    <div style="display:flex;gap:12px;margin-top:5px;font-size:0.7rem;color:#4a5568">
                        <span>🎓 {row['education'] or '–'}</span>
                        <span>📅 {exp_str} exp</span>
                        <span>👤 {row['gender'] or '–'}</span>
                    </div>
                </div>
                <span class="status-chip" style="{ss}">{row['status'].upper()}</span>
            </div>
            """, unsafe_allow_html=True)
        with col_btn:
            if st.button("Details →", key=f"det_{i}_{row.get('id',i)}"):
                st.session_state["detail_candidate_id"] = row.get("id")
                st.session_state["detail_job_id"] = selected_job_id
                st.switch_page("pages/04_Screening_Results.py")

# ── Score distribution bar chart ──────────────────────────────────────────────
if len(filtered) >= 3:
    st.markdown('<div class="section-hdr">Score Distribution</div>', unsafe_allow_html=True)
    import streamlit.components.v1 as components

    bins = {"0–24": 0, "25–49": 0, "50–74": 0, "75–89": 0, "90–100": 0}
    for s in filtered["score"]:
        if s < 25: bins["0–24"] += 1
        elif s < 50: bins["25–49"] += 1
        elif s < 75: bins["50–74"] += 1
        elif s < 90: bins["75–89"] += 1
        else: bins["90–100"] += 1

    bar_colors = {"0–24":"#ef4444","25–49":"#f59e0b","50–74":"#3b82f6","75–89":"#10b981","90–100":"#a78bfa"}
    max_v = max(bins.values()) or 1

    bars_html = ""
    for label, count in bins.items():
        pct = count / max_v * 100
        c = bar_colors[label]
        bars_html += f"""
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
            <div style="width:60px;text-align:right;font-size:0.72rem;color:#4a5568">{label}</div>
            <div style="flex:1;background:#161d2e;border-radius:4px;height:20px">
                <div style="width:{pct}%;background:{c};height:20px;border-radius:4px;transition:width 0.4s"></div>
            </div>
            <div style="width:24px;font-size:0.78rem;color:#eef2ff;font-weight:600">{count}</div>
        </div>
        """

    st.markdown(f"""
    <div style="background:#0d1220;border:1px solid #161d2e;border-radius:12px;padding:1rem 1.2rem">
    {bars_html}
    </div>
    """, unsafe_allow_html=True)

# ── Status split ─────────────────────────────────────────────────────────────
if total:
    st.markdown('<div class="section-hdr">Status Breakdown by Location</div>', unsafe_allow_html=True)
    loc_grouped = filtered.groupby(["location","status"]).size().unstack(fill_value=0)
    if not loc_grouped.empty:
        st.dataframe(
            loc_grouped.style
                .background_gradient(cmap="Blues", axis=None)
                .format("{:.0f}"),
            use_container_width=True
        )
