# TalentScan v6 — Change Summary
## What Changed from v5

### NEW: Two-Page Screening Architecture

#### Page 3 — High-Level Insights (03_High_Level_Insights.py)
- **Purpose:** Quick-glance view for recruiters who just need rankings, not deep analysis
- **Shows:** KPI strip (total / shortlisted / rejected / avg score / top score)
- **Candidate rows:** Rank badge → Name + Location/Geo → Score bar → Skill % → Status chip
- **Mini info:** Education, Experience, Gender per candidate
- **"Details →" button:** Jumps directly to the detailed page, pre-highlighting that candidate
- **Score distribution bar chart** (5 bands: 0–24, 25–49, 50–74, 75–89, 90–100)
- **Status by Location** cross-tab table

#### Page 4 — Detailed Screening Results (04_Screening_Results.py)  
- **Purpose:** Full AI evaluation per candidate — unchanged depth from v5
- **Shows everything from v5:** Score breakdown bars (Skills/Experience/Education), matched skills, gaps, keywords, penalties, AI rationale, CV links
- **Back button:** Returns to High-Level Insights
- **Deep-link support:** Coming from Insights page → auto-expands that candidate card

---

### NEW: Filters on BOTH Pages

Both pages now have an identical 6-filter bar at the top:

| Filter | Type | Description |
|---|---|---|
| 📍 Location | Multi-select | Candidate's city/country |
| 👤 Gender | Multi-select | Candidate gender |
| 🌍 Geo Area | Multi-select | Geographical region (e.g. GCC, South Asia) |
| 📅 Years of Experience | Range slider | Min–Max experience range |
| ✅ Status | Multi-select | shortlisted / rejected / review |
| ⭐ Min Score | Slider | Minimum composite score threshold |

All filters are applied simultaneously. Filter state is NOT shared between pages (each is independent).

---

### Backend Requirements (no change to API needed)

The new fields used by filters are **already expected** from the screening API response:
- `location` — candidate location string
- `gender` — candidate gender string  
- `geographical_area` — regional area string
- `years_experience` — numeric
- `status` — shortlisted / rejected / review
- `composite_score` — numeric 0–100

If the existing API does not return `gender` or `geographical_area`, the filter will just show empty (no multi-select options). The rest of the pages work fine regardless.

---

### File Map

```
frontend/pages/
  03_High_Level_Insights.py   ← NEW  (replaces old 03_Screening_Results)
  04_Screening_Results.py     ← UPDATED  (detailed view, was 03, now 04)
  05_Candidate_History.py     ← unchanged from v5
```

Rename old `03_Screening_Results.py` → `04_Screening_Results.py` (done).
Old file is superseded — do not keep both.
